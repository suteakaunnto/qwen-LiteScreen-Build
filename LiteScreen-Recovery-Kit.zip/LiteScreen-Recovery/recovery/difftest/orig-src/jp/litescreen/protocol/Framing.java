package jp.litescreen.protocol;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import kotlin.KotlinVersion;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: Proto.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\t\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tJ\u001e\u0010\u000b\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\rJ\u001a\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\t\u0012\u0004\u0012\u00020\t0\u000f2\u0006\u0010\u0010\u001a\u00020\u0011J\u0016\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0013\u001a\u00020\tJ&\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0015\u001a\u00020\r2\u0006\u0010\u0016\u001a\u00020\t2\u0006\u0010\u0013\u001a\u00020\tJ\u000e\u0010\u0017\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\tJ\u000e\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u001aJ\u0016\u0010\u001b\u001a\u00020\t2\u0006\u0010\u001c\u001a\u00020\r2\u0006\u0010\u0016\u001a\u00020\tJ\u0016\u0010\u001d\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\r2\u0006\u0010\u0016\u001a\u00020\t¨\u0006\u001e"}, d2 = {"Ljp/litescreen/protocol/Framing;", "", "<init>", "()V", "writeHeader", "", "out", "Ljava/io/OutputStream;", "type", "", "payloadLength", "writeMessage", "payload", "", "readHeader", "Lkotlin/Pair;", "input", "Ljava/io/InputStream;", "readPayload", "len", "readFully", "buf", "off", "intBytes", "v", "longBytes", "", "readInt", "b", "readLong", "protocol_debug"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Framing {
    public static final Framing INSTANCE = new Framing();

    private Framing() {
    }

    public final void writeHeader(OutputStream out, int type, int payloadLength) throws IOException {
        Intrinsics.checkNotNullParameter(out, "out");
        byte[] h = {Proto.INSTANCE.getMAGIC()[0], Proto.INSTANCE.getMAGIC()[1], Proto.INSTANCE.getMAGIC()[2], Proto.INSTANCE.getMAGIC()[3], (byte) type, (byte) ((payloadLength >>> 16) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((payloadLength >>> 8) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) (payloadLength & KotlinVersion.MAX_COMPONENT_VALUE)};
        out.write(h);
    }

    public final void writeMessage(OutputStream out, int type, byte[] payload) throws IOException {
        Intrinsics.checkNotNullParameter(out, "out");
        Intrinsics.checkNotNullParameter(payload, "payload");
        writeHeader(out, type, payload.length);
        if (!(payload.length == 0)) {
            out.write(payload);
        }
        out.flush();
    }

    public final Pair<Integer, Integer> readHeader(InputStream input) throws IOException {
        Intrinsics.checkNotNullParameter(input, "input");
        byte[] h = new byte[8];
        readFully(input, h, 0, 8);
        if (h[0] != Proto.INSTANCE.getMAGIC()[0] || h[1] != Proto.INSTANCE.getMAGIC()[1] || h[2] != Proto.INSTANCE.getMAGIC()[2]) {
            throw new ProtocolException("magic mismatch");
        }
        int type = h[4] & 0xFF;
        int len = ((h[6] & 0xFF) << 8) | ((h[5] & 0xFF) << 16) | (h[7] & 0xFF);
        if (len < 0 || len > 8388608) {
            throw new ProtocolException("payload too large: " + len);
        }
        return TuplesKt.to(Integer.valueOf(type), Integer.valueOf(len));
    }

    public final byte[] readPayload(InputStream input, int len) throws IOException {
        Intrinsics.checkNotNullParameter(input, "input");
        byte[] b = new byte[len];
        if (len > 0) {
            readFully(input, b, 0, len);
        }
        return b;
    }

    public final void readFully(InputStream input, byte[] buf, int off, int len) throws IOException {
        Intrinsics.checkNotNullParameter(input, "input");
        Intrinsics.checkNotNullParameter(buf, "buf");
        int done = 0;
        while (done < len) {
            int n = input.read(buf, off + done, len - done);
            if (n < 0) {
                throw new ProtocolException("unexpected end of stream");
            }
            done += n;
        }
    }

    public final byte[] intBytes(int v) {
        return new byte[]{(byte) ((v >>> 24) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((v >>> 16) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) ((v >>> 8) & KotlinVersion.MAX_COMPONENT_VALUE), (byte) (v & KotlinVersion.MAX_COMPONENT_VALUE)};
    }

    public final byte[] longBytes(long v) {
        return new byte[]{(byte) ((v >>> 56) & 255), (byte) ((v >>> 48) & 255), (byte) ((v >>> 40) & 255), (byte) ((v >>> 32) & 255), (byte) ((v >>> 24) & 255), (byte) ((v >>> 16) & 255), (byte) ((v >>> 8) & 255), (byte) (255 & v)};
    }

    public final int readInt(byte[] b, int off) {
        Intrinsics.checkNotNullParameter(b, "b");
        return ((b[off] & 0xFF) << 24) | ((b[off + 1] & 0xFF) << 16) | ((b[off + 2] & 0xFF) << 8) | (b[off + 3] & 0xFF);
    }

    public final long readLong(byte[] b, int off) {
        Intrinsics.checkNotNullParameter(b, "b");
        return ((((long) readInt(b, off)) & 4294967295L) << 32) | (4294967295L & ((long) readInt(b, off + 4)));
    }
}
