package jp.litescreen.protocol;

import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;

/* JADX INFO: compiled from: Proto.kt */
/* JADX INFO: loaded from: classes2.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u001d\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007R\u000e\u0010\b\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u000f\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0011\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0018\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0019\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001b\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001c\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001e\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u001f\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010 \u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010!\u001a\u00020\tX\u0086T¢\u0006\u0002\n\u0000R\u0011\u0010\"\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u0007R\u0011\u0010$\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b%\u0010\u0007¨\u0006&"}, d2 = {"Ljp/litescreen/protocol/Proto;", "", "<init>", "()V", "MAGIC", "", "getMAGIC", "()[B", "VERSION", "", "MSG_HELLO", "MSG_VIDEO_CONFIG", "MSG_CODEC_CONFIG", "MSG_VIDEO", "MSG_KEYFRAME_REQUEST", "MSG_PING", "MSG_PONG", "MSG_STATS", "STATS_V2_SIZE", "MSG_BYE", "MSG_AUDIO_UNSUPPORTED", "MSG_ERROR", "MSG_INFO", "MAX_TEXT", "MSG_PROPOSE", "MSG_PROPOSE_ACK", "PROPOSE_ACK_V2_HEADER", "CODEC_ERROR_UNSUPPORTED", "HEADER_SIZE", "MAX_PAYLOAD", "FLAG_KEY_FRAME", "FLAG_CODEC_CONFIG", "DEFAULT_TCP_PORT", "DEFAULT_UDP_PORT", "PROBE", "getPROBE", "PROBE_ACK", "getPROBE_ACK", "protocol_debug"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Proto {
    public static final int CODEC_ERROR_UNSUPPORTED = -2147414011;
    public static final int DEFAULT_TCP_PORT = 47820;
    public static final int DEFAULT_UDP_PORT = 47821;
    public static final int FLAG_CODEC_CONFIG = 2;
    public static final int FLAG_KEY_FRAME = 1;
    public static final int HEADER_SIZE = 8;
    public static final Proto INSTANCE = new Proto();
    private static final byte[] MAGIC = {76, 83, 67, 1};
    public static final int MAX_PAYLOAD = 8388608;
    public static final int MAX_TEXT = 4096;
    public static final int MSG_AUDIO_UNSUPPORTED = 10;
    public static final int MSG_BYE = 9;
    public static final int MSG_CODEC_CONFIG = 3;
    public static final int MSG_ERROR = 11;
    public static final int MSG_HELLO = 1;
    public static final int MSG_INFO = 12;
    public static final int MSG_KEYFRAME_REQUEST = 5;
    public static final int MSG_PING = 6;
    public static final int MSG_PONG = 7;
    public static final int MSG_PROPOSE = 13;
    public static final int MSG_PROPOSE_ACK = 14;
    public static final int MSG_STATS = 8;
    public static final int MSG_VIDEO = 4;
    public static final int MSG_VIDEO_CONFIG = 2;
    private static final byte[] PROBE;
    private static final byte[] PROBE_ACK;
    public static final int PROPOSE_ACK_V2_HEADER = 24;
    public static final int STATS_V2_SIZE = 24;
    public static final int VERSION = 1;

    private Proto() {
    }

    static {
        byte[] bytes = "LITESCREEN?".getBytes(Charsets.US_ASCII);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        PROBE = bytes;
        byte[] bytes2 = "LITESCREEN!".getBytes(Charsets.US_ASCII);
        Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
        PROBE_ACK = bytes2;
    }

    public final byte[] getMAGIC() {
        return MAGIC;
    }

    public final byte[] getPROBE() {
        return PROBE;
    }

    public final byte[] getPROBE_ACK() {
        return PROBE_ACK;
    }
}
