# jadx 出力の既知の誤り（復元時に必ず smali と突き合わせること）

作成: 2026-10-29 ／ 対象: jadx 1.5.6 の出力（`recovery/decompiled/*-jadx/sources/jp/litescreen/`）

## 結論（最重要）

**jadx の Java 出力をそのまま Kotlin に書き写すと、プロトコルが壊れる。**
`protocol/Framing.java` に **6 箇所**、jadx が誤った定数を出力している。
必ず apktool の smali（DEX からの直接逆アセンブル＝正）と突き合わせること。

---

## BUG-1: `UByte.MAX_VALUE` が int の 255 として出力される

### 現象

jadx は Kotlin の `UByte.MAX_VALUE` を Java の `kotlin.UByte.MAX_VALUE` 参照として出力する。
しかし **`kotlin.UByte` の Java からの見える `MAX_VALUE` は `UByte` 型（内部表現 byte = -1）** であり、
Java で `byte & UByte.MAX_VALUE` と書くと `UByte.MAX_VALUE` が int 255 に符号拡張されてしまう
（コンパイルは通ってしまうため気付きにくい）。

正しい Kotlin のセマンティクスは `b.toInt() and 0xFF`（= 0..255）だが、
jadx 出力をそのまま javac すると `b.toInt() and 255` ではなく
**`b.toInt() and (-1)` = 符号付きのまま**になる。

### 該当箇所（`protocol/Framing.java`、送信側・受信側の両 APK で同一）

| メソッド | jadx 出力（誤） | smali の実際（正） |
|---|---|---|
| `readHeader` | `int type = h[4] & UByte.MAX_VALUE;` | `aget-byte` → `and-int/lit16 v2, v2, 0xff` |
| `readHeader` | `((h[6] & UByte.MAX_VALUE) << 8)` | `aget-byte` → `and-int/lit16 v3, v3, 0xff` → `shl-int/lit8 v3, v3, 0x10` |
| `readHeader` | `((h[5] & UByte.MAX_VALUE) << 16)` | `aget-byte` → `and-int/lit16 v4, v4, 0xff` → `shl-int/lit8 v0, v4, 0x8` |
| `readHeader` | `(h[7] & UByte.MAX_VALUE)` | `aget-byte` → `and-int/lit16 v3, v3, 0xff` |
| `readInt` | `((b[off] & UByte.MAX_VALUE) << 24)` ほか4箇所 | すべて `aget-byte` → `and-int/lit16 vX, vX, 0xff` → `shl-int/lit8` |

`writeHeader` / `intBytes` / `longBytes` も jadx は `(x >>> n) & KotlinVersion.MAX_COMPONENT_VALUE`
と出力するが、こちらは smali で `ushr-int/lit8` → `and-int/lit16 vX, vX, 0xff` を確認済みで、
`KotlinVersion.MAX_COMPONENT_VALUE` は int 255 として正しく解決されるため **実害はない**。

### 影響（もし jadx 出力をそのまま採用していたら）

差分テストで実際に観測された誤動作:

```
readInt(47820)  → 期待 47820, 実際 -52
readInt(255)    → 期待 255,   実際 -1
readInt(8388608)→ 期待 8388608, 実際 -8388608
readLong(1700000000000) → 期待 1700000000000, 実際 -498217949184
readHeader type=255 → 期待 255, 実際 -1
payload too large の例外メッセージ: 期待 "8388609", 実際 "-8388607"
```

→ **ポート番号・幅・高さ・ビットレート・PTS・統計値がすべて壊れる。**
   もしこれで再ビルドしていたら、アプリは接続直後に全フィールドを誤解釈して即失敗していた。

### 対処（実施済み）

- 再構成した `Proto.kt` は **smali を正として** `and 0xFF` で記述した
- `scripts/10_diff_test_protocol.sh` は、基準実装を作る際に
  `& UByte.MAX_VALUE` → `& 0xFF` のみ自動置換する（`& KotlinVersion.MAX_COMPONENT_VALUE` は無害なので置換しない）
  置換した内容は差分テストのログに出力する
- `scripts/11_verify_dex_constants.py` が smali から定数を直接読み取り、
  `Proto.kt` の値と機械的に照合する（jadx を介さない独立経路）

---

## 影響範囲の確認

`UByte.MAX_VALUE` の誤出力は **`protocol/Framing.java` の 6 箇所のみ**。

```
$ grep -rn "UByte.MAX_VALUE" *-jadx/sources/jp | wc -l
6
$ grep -rln "UByte.MAX_VALUE" *-jadx/sources/jp
sender-v1.0.11-jadx/sources/jp/litescreen/protocol/Framing.java
receiver-v1.0.11-jadx/sources/jp/litescreen/protocol/Framing.java
```

アプリ側（sender / receiver の独自クラス）には `UByte` / `UInt` / `ULong` の使用は無く、
この種のエラーは他に存在しない **[検証済]**。

ただし `0xff` マスクを使う独自コードは他にもあるので、smali との照合は済ませてある:

| ファイル | 用途 | smali 確認結果 |
|---|---|---|
| `SenderClient.enqueue()` | 自前ヘッダ構築 `(len>>>16)&0xff, (len>>>8)&0xff, len&0xff` | ✅ jadx 出力どおり（`ushr-int/lit8` → `and-int/lit16 0xff` → `int-to-byte`） |
| `SenderActivity` | ポート入力検証 `IntRange(1, 65535)` | ✅ `const v5, 0xffff` |

---

## その他の jadx 由来の注意点（バグではないが復元時に注意）

1. **`kotlin.Result` の展開**: `runCatching { ... }` が
   `Result.Companion companion = Result.INSTANCE; ... Result.m8constructorimpl(...)` という形の
   合成メソッド呼び出しに展開される。この Java は**そのままではコンパイルできない**
   （`m8constructorimpl` は jadx が付けた名前）。Kotlin に戻すときは `runCatching {}` に戻すこと。
   ※ `protocol` の3クラスには Result 展开が無いため javac がそのまま通る（差分テストで確認済み）。
2. **data class の展開**: `component1..N` / `copy` / `copy$default` / `equals` / `hashCode` / `toString` が
   明示的に出力される。Kotlin では `data class` 宣言1行に戻す。
3. **getter の重複出力**: jadx が「renamed from getter」と「通常のgetter」を両方出すため、
   `StreamConfig.java` などに同じシグネチャのメソッドが2回現れる。そのままではコンパイル不可。
4. **ローカル変数名の損失**: `str3`, `i2`, `objM17constructorimpl`, `z`, `bArr` など。
   意味は文脈から復元するしかない（[推定] と明記すること）。
5. **制御フローの乱れ**: `DecoderCaps.probe()` など大きいメソッドは
   `while (true)` + Multi-variable type inference failed で構造が崩れている。
   **こうした箇所は必ず smali を読んで意味を取り直すこと。**
6. **`@Metadata` の `d2` 配列が最高の手がかり**: 元の Kotlin の
   クラス名・プロパティ名・関数名・シグネチャが文字列としてそのまま入っている。
   例: `"Ljp/litescreen/sender/core/StreamConfig;", "", "host", "", "port", "", ...`
   → プロパティの順序と型が正確に分かる。
