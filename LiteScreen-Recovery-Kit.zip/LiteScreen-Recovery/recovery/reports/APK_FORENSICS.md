# APK フォレンジック解析レポート (Phase B)

対象: LiteScreen 送信側 v1.0.11 / 受信側 v1.0.11 / 送信側 v1.0.10（比較用）
実施日: 2026-10-29 (UTC)
実施環境: Debian 12 / OpenJDK 17.0.21 / apktool 2.11.1 / jadx 1.5.6 / build-tools 34.0.0

## 証拠ラベルの凡例

| ラベル | 意味 |
|---|---|
| **[APK確認]** | 現物APKの Manifest / DEX / smali / リソースから直接確認した |
| **[検証済]** | この環境でコマンドを実行し、その出力で確認した |
| **[旧報告]** | 旧セッションの報告書にあり、現物では未確認 |
| **[推定]** | 証拠からの仮説。確定事項として扱わない |
| **[未確認]** | 実機などが無く確認できていない |

本レポートの記載は、明記しない限りすべて **[APK確認]** または **[検証済]**。

---

## 1. 入力ファイルの同一性

`recovery/evidence/INPUT_APK.md` に詳細。要約:

| ファイル | サイズ | SHA-256 |
|---|---:|---|
| litescreen-sender-v1.0.11-debug.apk | 2,521,362 | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` |
| litescreen-receiver-v1.0.11-debug.apk | 2,512,825 | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` |
| litescreen-sender-v1.0.10-debug.apk | 2,518,766 | `b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc` |

- 3本ともサイズがマスタープロンプト記載値と一致、ZIP magic `PK\x03\x04` を確認 **[検証済]**
- sender v1.0.11 の `git hash-object` = `54df19e4013ea3f371491499ea38a3aee47e4257` でマスタープロンプト記載の Git blob SHA と一致 **[検証済]**
- GitHub API `/contents/` の結果、リポジトリ直下は上記3 APK のみ。ソースコードは存在しない **[検証済]**

## 2. パッケージ・バージョン・SDK

| 項目 | 送信側 v1.0.11 | 受信側 v1.0.11 | 送信側 v1.0.10 |
|---|---|---|---|
| package (applicationId) | `jp.litescreen.sender.debug` | `jp.litescreen.receiver.debug` | `jp.litescreen.sender.debug` |
| versionCode | 11 | 11 | 10 |
| versionName | `1.0.11-debug` | `1.0.11-debug` | `1.0.10-debug` |
| minSdkVersion | 28 | 28 | 28 |
| targetSdkVersion | 36 | 36 | 36 |
| compileSdkVersion | 36 (codename "16") | 36 (codename "16") | 36 |
| application-label | `LiteScreen 送信` | `LiteScreen 受信` | `LiteScreen 送信` |
| debuggable | true | true | true |
| launchable-activity | `jp.litescreen.sender.SenderActivity` | `jp.litescreen.receiver.ReceiverActivity` | 同左 |

**重要な発見:**

1. **applicationId に `.debug` サフィックスが付いている** → `buildTypes.debug { applicationIdSuffix ".debug" }` 相当の構成。クラスのパッケージ名（`jp.litescreen.sender`）と applicationId（`jp.litescreen.sender.debug`）が異なる。Kotlin メタデータ内のモジュール名も `sender_debug` / `receiver_debug` / `protocol_debug` となっており、**debug ビルドバリアントであることが DEX 内部からも裏付けられる** [APK確認]
2. **受信側の targetSdk は 36 だが minSdk は 28**。Android 9 (API 28) のチャレンジパッドNext には minSdk=28 によりインストール可能。ただし targetSdk 36 のアプリを API 28 端末で動かす構成は、API 29+ 向けの挙動分岐がコード側に必要 [APK確認]
3. **compileSdk 36** → 再構成時のビルドには `platforms;android-36` が必要。現状この環境には android-34 しか無い（Phase D で取得予定）[検証済]

## 3. 権限とコンポーネント

### 送信側
```
android.permission.FOREGROUND_SERVICE
android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION
android.permission.POST_NOTIFICATIONS
android.permission.INTERNET
android.permission.ACCESS_NETWORK_STATE
android.permission.ACCESS_WIFI_STATE
android.permission.CHANGE_WIFI_MULTICAST_STATE
<uses-feature android:name="android.hardware.wifi" android:required="true"/>
```
- `SenderActivity` — exported=true, launchMode=singleTask, configChanges 多数
- `MirrorService` — exported=false, **foregroundServiceType="mediaProjection"**
- `android:allowBackup="false"`, `android:dataExtractionRules="@xml/data_extraction_rules"`, `android:supportsRtl="false"`

### 受信側
```
android.permission.INTERNET
android.permission.ACCESS_NETWORK_STATE
android.permission.CHANGE_WIFI_MULTICAST_STATE
<uses-feature android:name="android.hardware.wifi" android:required="true"/>
<uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
```
- `ReceiverActivity` のみ（Service なし）
- **受信側には `android:dataExtractionRules` が無い**（送信側のみ）→ 再構成時にこの非対称を再現するか要判断

### Smart Cast に関する確認
- 両 Manifest にも DEX にも **Miracast / WifiDisplay / Cast SDK 関連の API 参照は一切存在しない** [APK確認]
- 送信側 strings.xml に明示的な文言あり [APK確認]:
  > `warning_not_smartcast`: 「注意: このアプリは REDMAGIC 本体の「スマートキャスト」からは利用できません。スマートキャストの検索一覧には表示されません。両端末に専用アプリを入れて使う独自方式です。」
- → **マスタープロンプトの指示どおり、Smart Cast 受信機としては動作しないと結論できる** [APK確認]

## 4. 署名

3 APK すべてが **同一の証明書** で署名されている [検証済]

```
Signer #1 certificate DN:        C=US, O=Android, CN=Android Debug
Signer #1 certificate SHA-256:   bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf
Signer #1 certificate SHA-1:     812c5dfd0b1bd48098dc6dbb844b9077dd341984
Signer #1 key algorithm:         RSA 2048 bit
署名スキーマ:                     v1=false, v2=true, v3=false, v3.1=false, v4=false
```

- DN が `C=US, O=Android, CN=Android Debug` → **Android Gradle Plugin が自動生成する debug キーストア**（`~/.android/debug.keystore`, alias `androiddebugkey`）の証明書 **[推定]**
- AOSP 公開 testkey（`build/target/product/security/testkey.x509.pem`, DN に `ST=California, L=Mountain View, emailAddress=android@android.com` を含む）とは **DN も指紋も一致しない**。実際にダウンロードして比較した **[検証済]** → 公開鍵での再署名は不可能
- **秘密鍵は APK から復元できない。** 元ビルドマシンの `~/.android/debug.keystore` が無い限り、同一署名での再ビルドは不可 **[APK確認に基づく結論]**

### 再ビルド後のインストール影響（重要）
| 条件 | 判定 |
|---|---|
| パッケージ名一致 | ✅ `jp.litescreen.sender.debug` / `jp.litescreen.receiver.debug` を維持すれば一致 |
| 署名証明書一致 | ❌ 新規鍵では不一致 |
| → 既存インストール済み端末への `-r` 上書き更新 | **不可**（`INSTALL_FAILED_UPDATE_INCOMPATIBLE`） |
| → 必要な手順 | `adb uninstall` 後に新規インストール。アプリ内保存データ（設定）は消える |

※ ただし **一度新しい鍵を作ってしまえば、以後の更新はその鍵で上書き更新できる**。鍵は必ずバックアップすること。

## 5. 難読化・ビルド構成

- **難読化なし** [APK確認]
  - クラス総数 1085（送信側）。うち 1〜2 文字の難読化クラス名は **0 件**
  - クラス名・メソッド名・フィールド名がすべて原形を保っている
  - `application-debuggable=true`、`isMinifyEnabled=false` 相当
- **AndroidX を一切使っていない** [APK確認]
  - DEX 内のパッケージ: `jp.litescreen.*`(49クラス), `kotlin.*`(1004クラス), `org.intellij.lang.annotations` / `org.jetbrains.annotations`(32クラス)
  - `androidx.*` のクラス数 = **0**
  - → Activity は `android.app.Activity`、Service は `android.app.Service` を直接継承 **[推定: 依存が無いことから確度สูง]**
- **Kotlin 製** [APK確認]
  - `kotlin/*.kotlin_builtins` を同梱、全クラスに `@kotlin.Metadata`
  - `kotlin.Result` の inline class 跡（`Result.m8constructorimpl` 等）が多数 → Kotlin 標準ライブラリの runCatching を多用
- **AGP バージョン**: `META-INF/com/android/build/gradle/app-metadata.properties` に `androidGradlePluginVersion=8.13.2`, `appMetadataVersion=1.1` [APK確認]
- **ネイティブライブラリ無し**（`lib/` ディレクトリが存在しない）、**assets 無し** [APK確認]
- **DEX は 5 分割**: classes.dex (2,338,632 B = Kotlin stdlib 中心) / classes2 (6,840 B = protocol) / classes3 (6,148 B = R クラス) / classes4 (50,592 B) / classes5 (67,548 B) [APK確認]

## 6. モジュール構成（元プロジェクトの Gradle 構成の推定）

両 APK に **同一の `jp.litescreen.protocol` パッケージ**が同一内容で含まれている [検証済: diff で完全一致]

```
(元プロジェクト推定)
├── protocol/          … Android Library モジュール（jp.litescreen.protocol）
├── sender/            … Android Application（jp.litescreen.sender, applicationIdSuffix ".debug"）
└── receiver/          … Android Application（jp.litescreen.receiver, applicationIdSuffix ".debug"）
```

根拠:
- `jp/litescreen/protocol/R.smali` が両 APK に存在（ライブラリモジュールの R クラス）
- Kotlin メタデータのモジュール名が `protocol_debug` / `sender_debug` / `receiver_debug`
- Proto.java と Framing.java の `/* JADX INFO: compiled from: Proto.kt */` → **`Proto.kt` 1ファイルに Proto と Framing の両方が定義されていた** [APK確認]

## 7. クラス一覧（復元できた独自コード）

### protocol モジュール（両 APK 共通・完全一致）
| クラス | 元ファイル | 行数(jadx出力) |
|---|---|---:|
| `Proto` | Proto.kt | 64 |
| `Framing` | Proto.kt | 92 |
| `ProtocolException` | (別ファイル) | 16 |

### sender モジュール
| クラス | 元ファイル | 行数 | 役割 |
|---|---|---:|---|
| `SenderActivity` | SenderActivity.kt | 826 | メインUI・権限要求・設定保存 |
| `MirrorService` | MirrorService.kt | 719 | 前景サービス・配信制御・適応ビットレート |
| `core.ScreenCapturer` | ScreenCapturer.kt | 877 | MediaProjection→VirtualDisplay→H.264エンコード |
| `core.SenderClient` | SenderClient.kt | 647 | TCP送信・ネゴシエーション・RTT |
| `core.ReceiverDiscovery` | ReceiverDiscovery.kt | 339 | UDPブロードキャスト探索 |
| `core.StreamConfig` | StreamConfig.kt | 186 | 配信設定 data class + 推奨ビットレート |
| `core.NetInfo` | NetInfo.kt | 172 | 自端末IPv4列挙・ブロードキャスト先算出 |

### receiver モジュール
| クラス | 元ファイル | 行数 | 役割 |
|---|---|---:|---|
| `ReceiverActivity` | ReceiverActivity.kt | 813 | メインUI・SurfaceView・能力診断・ログ表示 |
| `core.ReceiverServer` | ReceiverServer.kt | 802 | TCPサーバ・プロトコル処理・統計 |
| `core.H264Decoder` | H264Decoder.kt | 796 | MediaCodec非同期デコード・描画ペーシング |
| `core.DecoderCaps` | DecoderCaps.kt | 1074 | デコーダー能力判定・レベル計算・診断文生成 |
| `core.DiscoveryResponder` | DiscoveryResponder.kt | 246 | UDP 47821 でプローブ応答 |
| `core.LocalLog` | LocalLog.kt | 83 | 端末内リングバッファログ |
| `core.NetUtil` | NetUtil.kt | 84 | 自端末IPv4列挙 |
| `core.H264Decoder$callback$1` | H264Decoder.kt | 143 | MediaCodec.Callback 実装 |

合計: 送信側 4,250 行 / 受信側 4,443 行（jadx 出力の Java 換算。元 Kotlin はこれより短い）

## 8. 通信プロトコル仕様（すべて [APK確認]）

### 8.1 定数（`Proto.kt`）

```kotlin
MAGIC               = byteArrayOf(0x4C, 0x53, 0x43, 0x01)  // "LSC" + 0x01
VERSION             = 1
HEADER_SIZE         = 8
MAX_PAYLOAD         = 8388608          // 8 MiB
MAX_TEXT            = 4096
DEFAULT_TCP_PORT    = 47820
DEFAULT_UDP_PORT    = 47821
FLAG_KEY_FRAME      = 1
FLAG_CODEC_CONFIG   = 2
STATS_V2_SIZE       = 24
PROPOSE_ACK_V2_HEADER = 24
CODEC_ERROR_UNSUPPORTED = -2147414011  // 0x80001005 の符号付き表現
PROBE               = "LITESCREEN?".toByteArray(US_ASCII)   // 11 bytes
PROBE_ACK           = "LITESCREEN!".toByteArray(US_ASCII)   // 11 bytes

MSG_HELLO             = 1
MSG_VIDEO_CONFIG      = 2
MSG_CODEC_CONFIG      = 3
MSG_VIDEO             = 4
MSG_KEYFRAME_REQUEST  = 5
MSG_PING              = 6
MSG_PONG              = 7
MSG_STATS             = 8
MSG_BYE               = 9
MSG_AUDIO_UNSUPPORTED = 10
MSG_ERROR             = 11
MSG_INFO              = 12
MSG_PROPOSE           = 13
MSG_PROPOSE_ACK       = 14
```

### 8.2 フレーム形式（`Framing`）

```
offset  size  内容
0       4     MAGIC  (0x4C 0x53 0x43 0x01)
4       1     type   (uint8, 上記 MSG_*)
5       3     payloadLength (uint24, ビッグエンディアン)
8       N     payload
```

- `readHeader()` は MAGIC の **先頭3バイトのみ**を検査（4バイト目の version は検査していない）
- payloadLength > 8,388,608 なら `ProtocolException("payload too large: N")`
- 整数は `intBytes()` / `readInt()` が **ビッグエンディアン 4 バイト**、`longBytes()` / `readLong()` が **ビッグエンディアン 8 バイト**
- ヘッダ内の 3 バイト長は `(len>>>16)&0xFF, (len>>>8)&0xFF, len&0xFF` の順で書き込み、読み出しは `(h[5]<<16)|(h[6]<<8)|h[7]` → 整合している [検証済: 読み書きのビット演算を照合]

### 8.3 UDP 探索（ポート 47821）

```
送信側 → ブロードキャスト:  "LITESCREEN?"                        (11 bytes, 素のUDPペイロード)
受信側 → ユニキャスト応答:  "LITESCREEN!" + JSON(UTF-8)
     JSON = {"proto":1,"app":"LiteScreen Receiver","tcpPort":<int>,"android":<Build.VERSION.SDK_INT>}
```
- 受信側は `DiscoveryResponder` が UDP 47821 を bind、`MulticastLock("litescreen-discovery")` を取得、SO_TIMEOUT 500ms でループ
- 送信側は応答の先頭 11 バイトが `LITESCREEN!` かを確認し、`substring(11)` を JSON パース（`org.json.JSONObject`）
- 送信側は `NetInfo.broadcastTargets()` で全 NIC のサブネットブロードキャスト宛先を算出

### 8.4 TCP セッション（ポート 47820）

**接続確立シーケンス** [APK確認]

```
1. 受信側が ServerSocket(47820) で accept
2. 受信側 → 送信側: MSG_HELLO(1)
      payload(16B) = [int32 version=1][int32 audioSupport=1][int32 0][int32 udpPort=47821]
3. 送信側は off0=version, off8=audioSupport を読む。version!=1 なら切断
4. 送信側 → 受信側: MSG_HELLO(1)
      payload(16B) = [int32 version=1][int32 audioSupport=1][int32 0][int32 0]
5. 受信側は off0=version のみ検証し、"sender hello: proto=1" をログ出力
6. 送信側 → MSG_PROPOSE(13) で能力ネゴシエーション開始
```

> ⚠ 注意点 **[APK確認]**: 受信側 HELLO の `audioSupport=1`（audio対応と宣言）だが、送信側は「受信側が音声非対応を通知（想定どおり。音声は送っていない）」と MSG_AUDIO_UNSUPPORTED に対してログしており、**音声は実際には一切送っていない**。受信側 HELLO の off4 の意味は [推定] だが、送信側は `!= 0` を audioSupport として読む。**再構成時にこの値を勝手に変えると挙動が変わる可能性があるため、1 のまま維持する。**

**メッセージ別ペイロード仕様**

| type | 方向 | payload | 備考 |
|---|---|---|---|
| 1 HELLO | R→S, S→R | `int32 version, int32 audioSupport, int32 (0), int32 (udpPort or 0)` = 16B | 上記 |
| 2 VIDEO_CONFIG | S→R | `int32 width, int32 height, int32 fps, int32 bitrateKbps` = 16B | 適応制御のたびに再送される |
| 3 CODEC_CONFIG | S→R | `int32 count, { int32 len, byte[len] } * count` | count は受信側で最大4にクランプ。SPS/PPS |
| 4 VIDEO | S→R | `int64 ptsUs, int32 flags(bit0=key), int32 sendMs, byte[] annexB` | sendMs = `System.currentTimeMillis() % 1000` |
| 5 KEYFRAME_REQUEST | R→S | 空 | デコーダが `consumeKeyFrameRequest()` で要求したとき |
| 6 PING | S→R | `int64 sentMs (epoch ms)` = 8B | 3秒間隔 |
| 7 PONG | R→S | PING の payload をそのままエコー | 送信側が RTT 算出 |
| 8 STATS | R→S | `int32 recvFps, int32 recvKbps, int32 lastSendMs, int32 dropped, int32 pending, int32 decoded` = **24B** | 1秒間隔。len>=8 で旧式、len>=24 で v2 |
| 9 BYE | 両方向 | 空 | |
| 10 AUDIO_UNSUPPORTED | R→S | (未使用) | 送信側は受信してログするのみ |
| 11 ERROR | 両方向 | UTF-8 text (≤4096B, 超過は切り詰め) | |
| 12 INFO | 両方向 | UTF-8 text (≤4096B) | |
| 13 PROPOSE | S→R | `int32 w, int32 h, int32 fps` = 12B | |
| 14 PROPOSE_ACK | R→S | `int32 ok, int32 w, int32 h, int32 fps, int32 profile, int32 level, utf8 detail` (≥24B) | len>=16 の旧式(24Bヘッダ無し)も送信側は受理 |

**STATS のフィールド対応の検証** [検証済: 送信側の読み取りオフセットと受信側の書き込み順を照合]
- 受信側が書く順: fps(0), kbps(4), lastSendMs(8), dropped(12), pending(16), decoded(20)
- 送信側が読む位置: fps(0), kbps(4), dropped(12), pending(16) → **一致**。off8(lastSendMs) と off20(decoded) は送信側が読んでいない（内部遅延表示用に確保されていると [推定]）

**PROPOSE_ACK のフィールド対応の検証** [検証済]
- 受信側が書く順: ok(0), width(4), height(8), fps(12), profile(16), level(20), detail(24〜)
- 送信側が読む位置: ok(0), w(4), h(8), fps(12), profile(16), level(20), detail = `String(payload, 24, len-24, UTF_8)` → **完全一致**

### 8.5 ソケットオプション・スレッド構成

| 項目 | 送信側 | 受信側 |
|---|---|---|
| TCP_NODELAY | true | true |
| SO_SNDBUF | 524,288 | 65,536 |
| SO_RCVBUF | 65,536 | 1,048,576 |
| SO_KEEPALIVE | true | true |
| SO_TIMEOUT | 接続時のみ 8,000ms → 以後 0 | 15,000ms |
| 入力ストリーム | BufferedInputStream 65,536 | BufferedInputStream 131,072 |
| 出力ストリーム | DataOutputStream(BufferedOutputStream 65,536) | 同左 |
| 接続タイムアウト | 8,000ms (`CONNECT_TIMEOUT_MS`) | — |
| スレッド | `LS-Writer` / `LS-Reader` / `LS-Watchdog` / `LS-Start` | `LS-Accept`(推定) / `LS-Reader` / `LS-Codec` / `LS-Stats` / `LS-Discovery` |
| 送信キュー | `ArrayBlockingQueue<byte[]>(40)` | — |
| PING間隔 | 3,000ms | — |
| 無通信切断 | 15,000ms（送信側ウォッチドッグ） | 15,000ms（SO_TIMEOUT） |
| 書き込み排他 | `writeLock` オブジェクトで synchronized | 同左 |

**背圧制御（送信側）** [APK確認]
- `enqueue()` は **ヘッダを付けた完成形バイト列**をキューに積む（書き込みは `LS-Writer` 1スレッドのみ → フレーム混在が起きない設計。マスタープロンプト §6 の懸念は解消済み）
- キュー満杯時: 重要メッセージ(type 2,3,6,7,13) は先頭を poll して押し込み、非重要(type 4=VIDEO) は破棄して `backpressureCount++` と `listener.onBackpressure()`
- `onBackpressure()` → `ScreenCapturer.enterResync()`（キーフレーム再同期）

## 9. 送信側の実装詳細 [APK確認]

### 9.1 ScreenCapturer（H.264 エンコーダ）

`buildFormat()` が設定する MediaFormat:
```
mime              = "video/avc"
color-format      = 2130708361 (COLOR_FormatSurface)
bitrate           = currentBitrate (bps)
frame-rate        = config.fps
i-frame-interval  = 2  (秒)
priority          = 0  (リアルタイム)
bitrate-mode      = pickBitrateMode() の結果（未対応なら設定しない）
latency           = 1        ※ try{} で保護（API 30+ の KEY_LATENCY）
operating-rate    = config.fps ※ try{} で保護（API 23+）
max-bframes       = 0        ※ try{} で保護  ← v1.0.11 で追加された行
profile           = 指定値
level             = 指定値
```

- エンコーダ取得は `MediaCodec.createEncoderByType("video/avc")` を **variant 違いで複数回リトライ**し、失敗を `errors` リストにためる（`safeCodecName()` / `profileLabel()` あり）
- `createVirtualDisplay("LiteScreen", w, h, densityFor(w), DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR(=16), surface, VirtualDisplay.Callback{...}, mainHandler)`
  - **Callback が非 null かつ Handler も非 null（mainHandler）** → v1.0.2 修正が現物に入っている [APK確認]
- `MediaProjection.Callback` を `createVirtualDisplay` **より前**に `registerCallback(cb, mainHandler)` で登録 → Android 14+ 要件を満たす [APK確認]
- エラーメッセージに Android 14+ の要件を明記した文字列が埋め込まれている:
  > 「Android 14以降は createVirtualDisplay の前に MediaProjection.Callback の登録が必須です。」
  > 「Android 14以降では foregroundServiceType=mediaProjection のサービスを起動した「後」に getMediaProjection/createVirtualDisplay を呼ぶ必要があり、createVirtualDisplay はトークン1個につき1回だけです。」
- CSD 送出は `emitCodecConfigFromFormat()` + `sentCsdHash` / `csdHash` で **同一 CSD の再送を抑制** [APK確認]
- `splitAnnexB(data)` で Annex-B を NAL 分割する処理あり

### 9.2 MirrorService（適応ビットレート制御）

```
targetBitrateKbps  = config.bitrateKbps
currentBitrateKbps = config.bitrateKbps
floorBitrateKbps   = max(1500, config.bitrateKbps / 3)
```

`onReceiverStats(fps, kbps, droppedTotal, pending)`（STATS 受信ごとに呼ばれる、1秒間隔）:
```
droppedDelta = (lastDroppedTotal<0 || droppedTotal<lastDroppedTotal) ? 0 : droppedTotal-lastDroppedTotal
arrived      = max(fps + droppedDelta, 1)
dropPct      = 100 * droppedDelta / arrived
overloaded   = (droppedDelta >= 2 && dropPct >= 5) || pending >= 2

過負荷でない場合:
  overloadStreak = 0
  currentBitrateKbps < targetBitrateKbps なら healthyStreak++
  healthyStreak >= 6 で +max(target/10, 100) kbps（加算的増加, target で頭打ち）

過負荷の場合:
  healthyStreak = 0; overloadStreak++
  overloadStreak >= 2 かつ currentBitrateKbps > floor であれば
      currentBitrateKbps = max(current * 3 / 4, floor)   （乗算的減少 25%）
      overloadStreak = 0
  floor まで下がっても破棄が続く場合は 30 秒に 1 回だけ MSG_INFO で
      「帯域ではなく受信側の処理能力が入力フレームレートに追いついていない可能性」を通知
```

→ **静止画面の低 FPS だけを過負荷の証拠にしない**（`droppedDelta` と `pending` のみで判定し、`fps` は分母にしか使わない）。v1.0.7 で報告された設計が現物に入っている [APK確認]

- `applyBitrate(reason)` は `ScreenCapturer.setBitrate(kbps*1000)` + `SenderClient.sendVideoConfig(...)` + `sendInfo("適応ビットレート: ...")` を実行し、1.5秒に1回だけ状態表示を更新
- `onBackpressure()` → `capturer.enterResync()`
- `panelHz` = `DisplayManager.getDisplay(0).getRefreshRate()` を取得し、MSG_INFO に「 / パネル=NNNHz」として付加 [APK確認]
- 起動は `onStartCommand` から **`LS-Start` という別スレッド**で接続処理を行う（`onStartCommand$lambda$0` が static メソッド化されている）
- 通知: `CHANNEL_ID = "litescreen_mirror"`, `NOTIF_ID = 1001`
- Intent アクション: `jp.litescreen.sender.action.START` / `.STOP`
- Extras: `resultCode`, `resultData`(Parcelable), `host`, `port`, `maxLongEdge`, `fps`, `bitrateKbps`

### 9.3 StreamConfig（設定値と推奨ビットレート）

```kotlin
data class StreamConfig(host: String, port: Int = 47820, maxLongEdge: Int = 1280,
                        fps: Int = 30, bitrateKbps: Int = 2500)

RESOLUTION_CHOICES = intArrayOf(1280, 1600, 1920)
FPS_CHOICES        = intArrayOf(15, 24, 30, 60)
BITRATE_CHOICES    = intArrayOf(2500, 4000, 8000, 12000, 16000)

fun suggestBitrateKbps(w: Int, h: Int, fps: Int): Int {
    val pixels = w.toLong() * h.toLong()
    val kbps = (fps.toLong() * pixels * 7L / 100L) / 1000L
    return kbps.toInt().coerceIn(2000, 20000)
}
```
→ `kbps = fps * w * h * 0.07 / 1000`、範囲 2000〜20000 [APK確認]

ラベル文字列（そのまま UI に出る）:
- 1280px → `1280px → 1280x800 (実測:余裕あり・推奨)`
- 1600px → `1600px → 1600x1000 (実測:対応・高画質)`
- 1920px → `1920px → 1728x1080 に自動縮小 (高さ上限1088)`
- 2500 → `2.5 Mbps (1280px/30fps 向け)`、4000 → `4.0 Mbps (1600px/30fps 向け・推奨)`、8000 → `8.0 Mbps (1600px/60fps・1920px/30fps 向け)`、12000 → `12 Mbps (1920px/60fps 向け)`、16000 → `16 Mbps (最高画質・LAN帯域をフルに使う)`

### 9.4 送信側 UI

- レイアウト `activity_sender.xml`: ScrollView > LinearLayout ×10, TextView ×17, Spinner ×3（解像度/FPS/ビットレート）, Button ×3（検索/開始/停止）, EditText ×2（host/port）, ImageView ×1
- ID: `bitrate_hint, bitrate_spinner, fps_spinner, host_input, my_ip_text, port_input, quality_warning, resolution_spinner, search_button, start_button, status_dot, status_text, stop_button`
- ビットレート推奨は `hint_bitrate_suggest`（タップで適用）と `hint_bitrate_applied`（適用済み）の 2 文字列を使い分け → **v1.0.10 の「手動選択を上書きしない」修正が現物に入っている** [APK確認]
- 色: `accent=#8b5cf6`(violet-500), `accent_deep=#6366f1`(indigo-500), `bg=#080b12`, `surface=#121926`, `surface2=#1a2231`, `fg=#f1f5f9`, `fg_dim=#9aa9ba`, `warn=#fbbf24`, `outline=#26313f`, `accent_line=#4a4590`, `ripple_light=#33ffffff`
  → 概要書 §7 の「インディゴ〜バイオレット系」と一致 [APK確認]
- drawable 35 個（`bg_card*`, `btn_*`, `ic_play/ic_stop/ic_search/ic_wifi/ic_chevron/ic_notification`, adaptive icon 3種）

## 10. 受信側の実装詳細 [APK確認]

### 10.1 H264Decoder

```
DEFAULT_PERIOD_NS = 16_666_666   // 60fps 相当の既定描画周期
RENDER_MARGIN_NS  =  3_000_000   // 描画判定のマージン 3ms
MAX_PENDING       = 2
LATENCY_WINDOW    = 30           // 遅延サンプルの移動平均窓
PTS_MAP_MAX       = 64           // arrivalByPts (LinkedHashMap) の上限
```

- `MediaCodec.createDecoderByType("video/avc")` → `format.setInteger("color-format", COLOR_FormatSurface)` / `"priority", 0` → `configure(format, targetSurface, null, 0)` → **`setCallback(callback, ensureCodecHandler())`** → `start()`
  - `ensureCodecHandler()` は **`HandlerThread("LS-Codec")`** の Handler → **v1.0.11 の「コールバックを専用スレッドへ分離」が現物に入っている** [APK確認]
- 同期 API の `dequeueInputBuffer` / `dequeueOutputBuffer` は **一切呼ばれていない**（grep で 0 件）→ v1.0.6 の「非同期/同期混用」修正が維持されている [APK確認]。入力は `queueInputBuffer(index, 0, len, ptsUs, 0)` のみ
- **描画ペーシング**（`onOutputBufferAvailable`）:
  ```java
  boolean due = lastRenderNs == 0 || (now - lastRenderNs) >= displayPeriodNs - RENDER_MARGIN_NS;
  if (due) { codec.releaseOutputBuffer(index, true);  lastRenderNs = now; rendered++;  recordLatency(ptsUs); }
  else     { codec.releaseOutputBuffer(index, false); renderSkipped++; }
  ```
  → **スキップ時も `releaseOutputBuffer(index, false)` で出力を消費している**（v1.0.11 報告どおり）[APK確認]
  → `info.size <= 0` の場合も `releaseOutputBuffer(index, false)`
  → `running == false` の場合も `releaseOutputBuffer(index, false)`（try/catch 保護）
- **古い世代のコールバック対策**: `codecGen` フィールドを持ち、`onInputBufferAvailable` で `gen = codecGen` を捕獲して `feedNext(codec, gen)` に渡す [APK確認]
- **エラー時の退避再構成**: `onError` で `e.isRecoverable() && !unsupported` の場合、**`handler.post { listener.onFatalError(...); softReset() }`** とコールバック外へ退避 → v1.0.11 のデッドロック回避が現物に入っている [APK確認]
- `ERROR_UNSUPPORTED`（`errorCode == -2147418107` またはメッセージに `0x80001005`）は回復不能扱いにし、専用の日本語メッセージを出す
  > 「この端末のデコーダーがこの映像に対応していません (ERROR_UNSUPPORTED 0x80001005)。送信側で解像度とフレームレートを下げてください。」
- `onOutputFormatChanged` で `crop-left/top/right/bottom` から実サイズを計算し `listener.onVideoSize(cw, ch)`
- 統計: `decoded`, `rendered`, `renderSkipped`, `dropped` の AtomicLong、`droppedTotal()`, `pendingCount()`, `decodedTotal()`, `renderedTotal()`, `renderSkippedTotal()`, `avgLatencyMs()`
- `LS-Stats` スレッドで定期ログ

### 10.2 ReceiverServer

- `maybeSendStats(output, lastSendMs)`: **1 秒以上経過していたら** STATS(24B) を送信し、カウンタをリセット
- `maybeLogStreamStats(...)`: **5 秒以上経過していたら**次の形式でログ（v1.0.11 報告の「5秒ごとのストリーム統計」）[APK確認]
  ```
  ストリーム統計: 受信=Nfps Nkbps / デコード=Nfps / 描画=Nfps / 描画スキップ=Nfps / 破棄+N / 待ち=N / 遅延=Nms
  ```
- **CSD 重複対策**: `decoderReady && sameCsd(newCsd0, csd0) && sameCsd(newCsd1, csd1)` なら
  > 「同一のコーデック設定の再送 → 無視します（デコーダーは稼働中）」
  とログして **デコーダーを破棄しない** [APK確認]
- CSD は最大 4 個まで読み取るが `csd0`/`csd1` のみ使用
- `onSurfaceRecreated()`: decoder 破棄 → `decoderReady=false` → `tryInitDecoder()` → `requestKeyFrame()`
- `closeClient(reason)`: BYE 送信 → socket close → reader interrupt → decoder release → `callbacks.onDisconnected(reason)`
- デコーダー致命エラー時は `MSG_ERROR(11)` を送信側へ返してから切断
- 受信側が送信側からの MSG_ERROR を受け取ると `lastSenderError` に保存し、BYE 受信時の切断理由に流用する（「理由の通知なし」を防ぐ設計）
- `Callbacks` インターフェース: `onWaitingForConnection, onClientConnected(remote), onVideoConfig(w,h,fps,kbps), onFirstFrame, onDisconnected(reason), onError(message), onSenderInfo(text), onStreamStats(receivedFps, receivedKbps), currentSurface(): Surface?`
  - `onSenderInfo` と `onStreamStats` には `DefaultImpls`（既定実装）あり

### 10.3 DecoderCaps（能力判定・レベル計算）

**H.264 レベル表（LEVEL_TABLE, smali から数値を復元）** [APK確認]

| maxMacroblocks | maxMBPS | level値 | レベル名 |
|---:|---:|---:|---|
| 1,620 | 40,500 | 256 | 1b |
| 3,600 | 108,000 | 512 | 2 |
| 5,120 | 216,000 | 1,024 | 3 |
| 8,192 | 245,760 | 2,048 | 3.1 |
| 8,192 | 245,760 | 4,096 | 3.2 |
| 8,704 | 522,240 | 8,192 | 4 |
| 22,080 | 589,824 | 16,384 | 4.1 |
| 36,864 | 983,040 | 32,768 | 4.2 |
| 36,864 | 2,073,600 | 65,536 | 5 |

```kotlin
private fun macroBlocks(w: Int, h: Int): Long = ((w + 15) / 16).toLong() * ((h + 15) / 16).toLong()

fun requiredLevel(w: Int, h: Int, fps: Int): Int {
    val mb = macroBlocks(w, h)
    val mbps = (if (fps > 0) fps else 30) * mb
    for (row in LEVEL_TABLE) if (mb <= row[0] && mbps <= row[1]) return row[2]
    return 0
}
```
→ **規格表に基づく算出**。`isFormatSupported` が true になった最小レベルを鵜呑みにしていない（v1.0.9 の修正が現物に入っている）[APK確認]

**プロファイル選択**:
```kotlin
val profiles = intArrayOf(8, 2, 1)   // High(8) → Main(2) → Baseline(1) の順に優先
for (prof in profiles) {
    val f = MediaFormat.createVideoFormat("video/avc", w, h).apply {
        setInteger("profile", prof); setInteger("level", level)
        if (fps > 0) setInteger("frame-rate", fps)
    }
    if (runCatching { full.isFormatSupported(f) }.getOrDefault(false)) return prof to level
}
return 0 to 0
```
- `profileName()`: 0=不明, 1=Baseline, 2=Main, 8=High（他に ConstrainedBaseline / ConstrainedHigh の文字列も存在）
- ソフトウェアデコーダー判定は名前に `OMX.google.` を含むかで判定（`isSoftware(name)`）

**縮小スケール候補（SCALES, smali の .array-data から実数を復元）** [APK確認]
```kotlin
private val SCALES = doubleArrayOf(1.0, 0.9, 0.8, 0.75, 0.667, 0.6, 0.5, 0.4, 0.333, 0.25)
```
- 1920px 指定 → 1920x1200 が非対応なら scale=0.9 で **1728x1080** となり、文字列どおりの挙動 [検証済: 計算で確認]
- `probe(reqW, reqH, reqFps)` は scale を大きい順に試し、`isSizeSupported` → `getSupportedFrameRatesFor` で上限 fps にクランプ → `areSizeAndRateSupported` を満たす最初の組を採用。align は `alignOf(caps)` から取得し `coerceAtLeast(2)`
- `getAchievableFrameRatesFor(w,h)`（API 23+）で実測能力を取得し、detail 文言に「（実測能力 N〜Mfps の範囲内）」等を付与
- `supportsAdaptive()` で adaptive 再生対応を判定
- `diagnose()` は能力診断用の長文テキストを生成。検査サイズ列:
  ```
  2560x1600, 1920x1200, 1920x1080, 1600x1000, 1440x900, 1280x800,
  1280x720, 1152x720, 1024x640, 960x600, 854x480, 800x500, 640x400, 640x360
  ```
  フォーマット: `"  %4dx%-4d  ○ %s%s\n"` / `"  %4dx%-4d  × 非対応\n"`

### 10.4 DiscoveryResponder / LocalLog / 受信側 UI

- UDP 47821 bind、SO_TIMEOUT 500ms、MulticastLock 使用（§8.3）
- `LocalLog`: 端末内のみ保持するリングバッファ。strings.xml に「ローカルログ（端末内のみ・外部送信なし）」→ **外部送信なし** [APK確認]
- レイアウト `activity_receiver.xml`: FrameLayout×2, LinearLayout×3, TextView×11, View×2, **SurfaceView×1**
- ID: `diag_button, error_text, info_panel, ip_list_text, ip_text, log_button, log_text, port_text, root, stats_text, status_dot, status_text, surface_view, video_container`
- `dialog_log.xml` あり（ログ表示ダイアログ）
- 色: `accent=#34d399`(emerald-400), `accent_deep=#10b981`(emerald-500), `bg=#070c0f`, `surface=#0f1a18`, `surface2=#16241f`, `error=#f87171`, `video_bg=#000000`, `scrim=#cc070a0f`, `accent_soft=#0c2e26`, `accent_line=#1f6b54`, `outline=#223530`
  → 概要書 §7 の「エメラルド〜シアン系」と一致 [APK確認]
- drawable 23 個（`bg_card_accent`, `bg_card_error`, `bg_chip`, `bg_pill_status`, `ic_diag`, `ic_log` など → **ピル型状態表示**の存在を確認）

### 10.5 strings.xml から分かる既知の実測値（アプリ内に埋め込まれた文言）[APK確認]

送信側 `hint_measured`:
> 実測（チャレンジパッドNext / OMX.MTK.VIDEO.DECODER.AVC）: 対応幅 64〜2048 / 対応高さ 64〜1088 / 1920x1080 は 0〜64fps（実測能力 50〜100）/ 1280x800 は 0〜130fps（実測能力 180〜270）。高さ上限 1088 のため 1920px 指定時は 1728x1080 へ自動縮小されます。

→ 概要書 §5 の v1.0.5「対応高さ上限1088」と一致。**ただしこれはアプリ内にハードコードされた文字列であり、この環境で実機測定した結果ではない** [APK確認 / 実測値そのものは旧報告]

送信側 `warning_lan_only`:
> 通信は同一LAN内の端末間のみで、暗号化は行っていません。外部サーバには一切接続しません。公衆Wi-Fiでの利用は避けてください。

→ **平文通信であることが APK 内の文言でも確認できる** [APK確認]。DEX 内に TLS/SSL 関連 API 参照は無し [検証済: grep 0件]

## 11. v1.0.11 で報告された機能の現物確認マトリクス

| # | 旧セッションの報告 | 現物での確認結果 | 根拠 |
|---|---|:--:|---|
| 1 | MediaCodecコールバックを専用スレッド `LS-Codec` に分離 | ✅ **入っている** | H264Decoder に `"LS-Codec"` HandlerThread、`setCallback(cb, ensureCodecHandler())` |
| 2 | 描画をディスプレイ周期にペーシング、スキップ時は `releaseOutputBuffer(index, false)` | ✅ **入っている** | `displayPeriodNs - RENDER_MARGIN_NS(3ms)` 判定、false での消費を確認 |
| 3 | 受信/デコード/描画/スキップ/破棄の統計を分離 | ✅ **入っている** | `decoded/rendered/renderSkipped/dropped` の AtomicLong |
| 4 | 5秒ごとのストリーム統計ログ | ✅ **入っている** | `maybeLogStreamStats` の `dtNs < 5_000_000_000L` ガードと文言 |
| 5 | 破棄率が高い状態を一定時間検知してから適応ビットレートを下げる | ✅ **入っている** | `overloadStreak >= 2` のガード |
| 6 | 静止画面の低FPSだけを過負荷の証拠にしない | ✅ **入っている** | 判定式は `droppedDelta` と `pending` のみ。fps は分母 |
| 7 | パネルリフレッシュレートをログ/状態表示へ | ✅ **入っている** | `panelHz`、`" / パネル=" + Hz` |
| 8 | エンコード実測FPSの表示 | ✅ **入っている** | `ScreenCapturer.Listener.onStats(encodedFps, kbps)`、`maybeReportStats` |
| 9 | `max-bframes=0` の導入 | ✅ **入っている** | `f.setInteger("max-bframes", 0)`（try保護）。**v1.0.10 との diff で追加行であることを確認** |
| 10 | 回復可能エラー時の再構成をコールバック実行中から退避 | ✅ **入っている** | `onError` → `handler.post { ... softReset() }` |
| 11 | v1.0.11 で「4ターゲットビルド成功」 | ⬜ **確認不能** | ビルド成果物は APK のみ。ビルドログは無い [未確認] |
| 12 | Lint 0 errors / NewApi 0 / InlinedApi 0 | ⬜ **確認不能** | 再構成後に自前で Lint を実行して検証する予定 [未確認] |
| 13 | 実機で遅延 30〜60ms / 破棄が止まった | ❌ **未確認** | 実機が接続されていない。旧報告でも未確認と明記 |

### v1.0.10 → v1.0.11 の実差分 [検証済: jadx出力の diff]

独自クラスの差分は **2 ファイルのみ**:
- `ScreenCapturer.java`: **9 行差分** = `max-bframes=0` の try ブロック追加のみ
- `MirrorService.java`: **332 行差分** = `panelHz` / `lastReceivedFps` / `lastNotBandwidthWarnMs` / `sentCaptureInfo` / `statsCalls` の追加、`DisplayManager` からのリフレッシュレート取得、`onStartCommand$lambda$0` の static 化（`LS-Start` スレッドでの実行）、floor 到達時の警告 throttling
- `SenderClient.java` / `SenderActivity.java` / `ReceiverDiscovery.java` / `StreamConfig.java` / `NetInfo.java` / `protocol/*` は **差分ゼロ**

→ **送信側の v1.0.10 と v1.0.11 はプロトコルレベルで完全互換** [検証済]

## 12. 送信 v1.0.11 ↔ 受信 v1.0.11 の互換性判定

| 項目 | 送信 v1.0.11 | 受信 v1.0.11 | 判定 |
|---|---|---|:--:|
| MAGIC | `4C 53 43 01` | 同一 | ✅ [検証済 diff一致] |
| VERSION | 1 | 1 | ✅ |
| TCP ポート | 47820 | 47820 | ✅ |
| UDP ポート | 47821 | 47821 | ✅ |
| PROBE / PROBE_ACK | `LITESCREEN?` / `LITESCREEN!` | 同一 | ✅ |
| 探索 JSON のキー | `tcpPort`, `app` を読む | `proto`, `app`, `tcpPort`, `android` を書く | ✅ |
| HELLO の送受信順 | 受信側が先に出す HELLO を待つ | accept 直後に HELLO を送る | ✅ |
| HELLO 長 | 16B 送信 / 受信は off0,off8 を読む | 16B 送信 / 受信は off0 を読む | ✅ |
| VIDEO_CONFIG | w,h,fps,kbps を書く | off 0,4,8,12 を読む | ✅ |
| CODEC_CONFIG | count + {len,data} | 同形式を解析、count≤4 | ✅ |
| VIDEO | pts(8) + flags(4) + sendMs(4) + data | off 0,8,12 を読み 16 以降を frame として扱う | ✅ |
| PING/PONG | 3秒間隔で int64 送信 | payload をそのまま PONG でエコー | ✅ |
| STATS | off 0,4,12,16 を読む（len≥24 で v2） | 24B を書く | ✅ |
| PROPOSE | w,h,fps の 12B | off 0,4,8 を読む | ✅ |
| PROPOSE_ACK | off 0,4,8,12,16,20 + detail(24〜) | 同順で書く | ✅ |
| KEYFRAME_REQUEST | 受信して `onKeyFrameRequested` | `requestKeyFrame()` / `consumeKeyFrameRequest()` で送信 | ✅ |
| BYE / ERROR / INFO | 送受とも実装 | 送受とも実装 | ✅ |
| AUDIO_UNSUPPORTED | 受信してログのみ | 送信コードは確認できず | ⚠ [未確認] 実害なし |

**結論: 送信 v1.0.11 と受信 v1.0.11 は静的解析の範囲でプロトコル完全互換** [検証済]
（`protocol` モジュールの 3 ファイルが両 APK で **バイト単位で同一の jadx 出力** になったことが最强の根拠。加えて各メッセージの書き込み順と読み取りオフセットを 1 件ずつ照合した）

**未確認事項:**
- 実際の通信シーケンス（タイミング・同時実行）は静的解析では検証できない → **[未確認]**（実機 or エミュレータ必要）
- `MSG_AUDIO_UNSUPPORTED` を受信側が送信する経路は今回の grep では見つからず **[未確認]**

## 13. セキュリティ・プライバシー所見 [APK確認]

| 項目 | 状態 |
|---|---|
| 通信の暗号化 | **なし**（平文 TCP/UDP）。strings.xml でも明示 |
| 認証 | **なし**。同一 LAN 内の任意の端末が 47820 に接続して映像を受信可能 |
| 受信側 ServerSocket | bind するのは全インターフェース（`ServerSocket(port)`）と [推定] → LAN 内に公開される |
| 外部サーバへの通信 | コード上に URL/HTTP クライアントの参照なし（`okhttp`/`HttpURLConnection`/`URL` の独自利用は grep 0 件） |
| 個人情報 | `LocalLog` は端末内のみ。`Build.MANUFACTURER/MODEL/VERSION` を MSG_INFO で送信側→受信側に送る |
| 権限 | 必要最小限に見える（カメラ・マイク・位置情報・ストレージは要求していない） |
| debuggable | **true** → 本番配布には不適。release ビルド構成を追加すべき |

→ **推奨**: 自宅/信頼できる LAN 内でのみ使用。`docs/KNOWN_ISSUES.md` に記載予定。

## 14. 逆コンパイルの制約（成果物の性格について）

1. **これは jadx が生成した Java であって、元の Kotlin ソースではない。**
   - `@Metadata` アノテーションから元の Kotlin シグネチャ（`d2` 配列）が読めるため、Kotlin への復元精度は高い
   - しかし以下は失われている:
     - コメント、空行、元のローカル変数名（一部は `str3`, `i2`, `objM17constructorimpl` 等に化けている）
     - `runCatching {}` が `Result.Companion` + `Result.mXXconstructorimpl(...)` という形の展開になっている
     - data class が手書きの `component1..N` / `copy` / `equals` / `hashCode` / `toString` に展開されている
     - 拡張関数・デフォルト引数・null 安全演算子が Java の分岐に展開されている
     - coroutine は使われていない模様（`kotlinx.coroutines` クラスが DEX に無い）[APK確認]
2. **jadx は 406 クラスでデコンパイルエラーを出したが、`jp.litescreen.*` の独自クラスには 1 件もエラーが無い** [検証済: ログを grep]。エラーはすべて Kotlin 標準ライブラリ側
3. **apktool の smali 出力は再ビルド可能な正**として保持している。jadx の Java が壊れている箇所は smali と突き合わせて確認する
4. **リソースは完全に復元可能**（難読化されていないため、layout / drawable / values / mipmap がそのまま取り出せた）。ただし apktool 出力は `$ic_launcher_background__0.xml` のような AAPT2 内部形式のファイルを含むため、そのまま res/ に戻すとビルドできない → Phase C で整形する

## 15. Phase C への申し送り

再構成プロジェクト `LiteScreen-Recovered/` は次の構成で作る:

```
LiteScreen-Recovered/
├── settings.gradle.kts        include(":protocol", ":sender", ":receiver")
├── build.gradle.kts
├── gradle.properties          低RAM対応の設定
├── gradle/wrapper/            Gradle Wrapper（自己完結）
├── protocol/                  Android Library, namespace jp.litescreen.protocol
│   └── src/main/java/jp/litescreen/protocol/Proto.kt
├── sender/                    Android App, namespace jp.litescreen.sender, applicationIdSuffix ".debug"
│   └── src/main/java/jp/litescreen/sender/{SenderActivity,MirrorService}.kt, core/*.kt
│   └── src/main/res/...       apktool 出力から復元
└── receiver/                  Android App, namespace jp.litescreen.receiver, applicationIdSuffix ".debug"
```

- **言語は Kotlin で再構成する**（元が Kotlin であることが @Metadata から確定しており、jadx 出力を Kotlin に戻す方が Java のままより忠実）
- compileSdk 36 / minSdk 28 / targetSdk 36 / AGP 8.13.2 / versionCode 11 / versionName "1.0.11-debug" を APK と一致させる
- 依存は **kotlin-stdlib のみ**（AndroidX 不使用を維持）
- 復元コード（APK から起こした）と、新規に書いた互換修正・ビルドスクリプトを **ファイルヘッダのコメントで区別する**

---

## 付録: 実行したコマンド

```bash
# 取得・保全
curl -sSL --retry 3 -o <name>.apk https://raw.githubusercontent.com/suteakaunnto/qwen-LiteScreen-Build/main/<name>.apk
sha256sum *.apk ; stat -c '%n %s bytes' *.apk ; git hash-object *.apk
curl -sSL https://api.github.com/repos/suteakaunnto/qwen-LiteScreen-Build/contents/

# 基本情報
aapt2 dump badging <apk>
apksigner verify --print-certs -v <apk>
unzip -l <apk>

# 展開
apktool d -f -o recovery/decompiled/<name>-apktool <apk>
jadx -d recovery/decompiled/<name>-jadx --show-bad-code -j 2 <apk>

# 比較
diff -r sender-v1.0.11-jadx/sources/jp sender-v1.0.10-jadx/sources/jp
diff sender-.../protocol/Proto.java receiver-.../protocol/Proto.java

# smali から数値定数を復元
python3 (SCALES の .array-data 8 の 64bit パターンを IEEE754 double に変換)
```

生ログ: `recovery/evidence/RAW_badging_signing.txt`, `recovery/evidence/jadx-*.log`, `recovery/evidence/apktool-sender-v1010.log`
