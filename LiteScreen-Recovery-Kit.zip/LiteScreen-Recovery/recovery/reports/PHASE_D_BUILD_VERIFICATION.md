# Phase D — Gradle 実ビルドと元 APK との照合報告

作成: 2026-10-29 / 対象: `LiteScreen-Recovered`（protocol, receiver, sender）
証拠ラベル: [APK確認] = 元 APK から直接確認 / [検証済] = 当セッションで実行して確認 / [旧報告] / [推定] / [未確認]

> **大前提（ユーザー指示 5）**: 再ビルドした APK は **元 APK と同一物ではない**。
> 署名鍵が復元できないため証明書が異なり、既存インストールアプリへの**上書き更新はできない**。
> 本レポートの「一致」はすべて *内容の照合結果* であり、同一バイナリを意味しない。

> **【Phase F 訂正（2026-10-30）】** 本レポート内にある「既存アプリは**アンインストールせずに残す**」という方針は
> **実機テストを実施する限り成立しない**（同一 packageName は並存できず、上書きもできないため、
> 再構築版が永久にインストールできない）。方針は **`docs/INSTALL_UNINSTALL_POLICY.md`** に確定した:
> ①元 APK **ファイル**は必ず保存（`recovery/input-apk/` に chmod 444 ＋ SHA-256、キット ZIP 内にも複製）、
> ②同一 packageName の再構築版を入れるときは**端末上の元アプリのアンインストールが必要**（ユーザー承認済み・記録必須）、
> ③テスト後は元 APK を入れ直して復元。
> なお本レポートは Phase D 時点の記録として**原文を改変せず保持**し、この注記で読み替えるものとする
> （該当箇所: §3.2 の「インストール時の注意」）。

---

## 0. 結論サマリ

| 項目 | 結果 | ラベル |
|---|---|---|
| Gradle ビルド（3モジュール） | **BUILD SUCCESSFUL / exit 0**（Kotlin 2.2.20・2.0.21 の両方で確認） | [検証済] |
| パッケージ名・versionCode/Name・minSdk/targetSdk・権限・feature・activity/service・debuggable | **aapt2 badging 差分ゼロ**（両モジュール・両 Kotlin 版） | [検証済] |
| 署名証明書 | **不一致**（元 `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf` → 再構築 `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847`。旧環境ビルドは `7a1fd7bb…27bd`）。debug keystore は復元不可。2026-10-30 に全 7 APK を再実測（§3.2） | [APK確認] |
| インストール手順 | **上書き更新不可・並存不可** → 再構築版を入れるには端末上の元アプリの**アンインストールが必要**（元 APK ファイルは保存済み）。方針は `docs/INSTALL_UNINSTALL_POLICY.md`（Phase F で確定。旧記述「アンインストールせずに残す」は訂正済み） | [検証済] |
| ZIP エントリ構成 | 2.0.21: **完全一致**（receiver 41/41, sender 54/54）<br>2.2.20: **+1**（`kotlin/concurrent/atomics/atomics.kotlin_builtins` が増える） | [検証済] |
| kotlin-stdlib の DEX（`classes.dex`, 2,338,632 B） | **2.0.21 ビルドで元 APK とバイト完全一致** | [検証済] |
| R クラスの DEX（`classes3.dex`） | **全 4 ビルドで元 APK とバイト完全一致** → リソース ID 復元は完全 | [検証済] |
| クラス構成（`jp.litescreen` 配下） | receiver 65/65, sender 49/49（不足・余分ゼロ※） | [検証済] |
| 合成ラムダクラスの形状 | receiver 37/37, sender 14/14 → 形状一致 | [検証済] |
| AndroidManifest.xml（バイナリ AXML） | **差分は埋め込み行番号のみ**。要素順・属性・値・リソース ID は完全一致 | [検証済] |
| ビルド再現性 | clean ビルドを 2 回 → **ソース未変更モジュールは APK/AAR がバイト一致**（protocol, sender） | [検証済] |
| Phase D で発見・修正した復元バグ | **9 件**（§4）。修正後に全モジュール再ビルド（exit 0）・再比較済み | [検証済] |
| 実機動作（映像転送・遅延・FPS） | **未検証**（実機が無い。この環境からは検証不能） | [未確認] |

※ sender の匿名クラス 3 個だけ *名前（連番）* が異なる（`$3/$4/$5` ↔ `$2/$3/$4` 相当の振り方差）。実体・メソッド構成は一致。

**元アプリの Kotlin バージョンは 2.0.21 で確定**（§5 に根拠）。
プロジェクトの既定値は現在 **2.2.20**（メンテナンス継続を優先）。1 行で 2.0.21 に切替可能（§9）。

---

## 1. ビルド環境 [検証済]

| 項目 | 値 |
|---|---|
| OS / CPU / メモリ | Debian 12, 2 CPU, **MemTotal 1,083 MB**（swap 無し・`swapon` 不可） |
| JDK | 17.0.21 |
| Gradle | 8.13（`/opt/gradle/dist/gradle-8.13/bin/gradle`, `GRADLE_USER_HOME=/root/.gradle`） |
| Android SDK | `/opt/android-sdk`（build-tools 36, platform 36 / 28） |
| AGP | 8.13.2（元 APK の `META-INF/com/android/build/gradle/app-metadata.properties` が**バイト一致** → 元も AGP 8.13.2）[検証済] |
| Kotlin | 2.2.20（既定） / 2.0.21（比較用） |
| 補助ツール | apktool 2.11.1, jadx 1.5.6, aapt2, zipalign, apksigner |

### 1.1 低メモリ対策（これが無いと OOM で落ちる）[検証済]

`gradle.properties` に以下を設定して安定した。**daemon は 1 本のみ・モジュールは 1 つずつ**ビルドする。

```properties
org.gradle.jvmargs=-Xmx384m -XX:MaxMetaspaceSize=224m -XX:ReservedCodeCacheSize=32m \
  -XX:MaxDirectMemorySize=48m -XX:+UseSerialGC -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10 \
  -Dorg.gradle.internal.instrumentation.agent=false
org.gradle.daemon=true
org.gradle.parallel=false
org.gradle.workers.max=1
kotlin.daemon.jvmargs=-Xmx256m -XX:MaxMetaspaceSize=192m -XX:+UseSerialGC
```

実測ピーク RSS: protocol 53 s / receiver 1 m 45 s（**656 MB**）/ sender 1 m 34 s（**648 MB**）。
`--no-daemon` は Gradle 8.13 では単発 fork が避けられないため採用しない（試行済み・非効率）。

### 1.2 実行コマンドと終了コード [検証済]

```bash
cd LiteScreen-Recovery
GRADLE_USER_HOME=/root/.gradle /opt/gradle/dist/gradle-8.13/bin/gradle \
    -p LiteScreen-Recovered clean                       # exit 0
... :protocol:assembleDebug                             # exit 0（BUILD SUCCESSFUL）
... :receiver:assembleDebug                             # exit 0（BUILD SUCCESSFUL）
... :sender:assembleDebug                               # exit 0（BUILD SUCCESSFUL）
```

ログ: `recovery/evidence/PHASE_D_clean_all_final.log`, `PHASE_D_final_{protocol,receiver,sender}assembleDebug.log`
（+ 同名 `.rss` にメモリ実測）。2.0.21 側は `PHASE_D_clean_all_k2021.log`, `PHASE_D_build_*_k2021*.log`。
過去の失敗（OOM）ログも**削除せず保存**: `PHASE_D_build_receiver_attempt3.log`, `PHASE_D_hs_err_pid10607_attempt3.log` など。

---

## 2. 成果物一覧（サイズ / SHA-256）

### 2.1 元 APK（変更禁止・`chmod 444`）[APK確認]

| ファイル | サイズ(B) | sha256 |
|---|---|---|
| `recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk` | 2,512,825 | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` |
| `recovery/input-apk/litescreen-sender-v1.0.11-debug.apk` | 2,521,362 | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` |
| `recovery/input-apk/litescreen-sender-v1.0.10-debug.apk` | 2,518,766 | `b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc` |

### 2.2 再構築 APK — Kotlin 2.2.20（**最終成果物**）[検証済]

保存先 `out/phase-d/kotlin-2.2.20/`（`SHA256SUMS.txt` 同梱）

**正式（修正 #1〜#9 反映・clean ビルド）** — ファイル名末尾 `_fix8-9` が正式。ハッシュ一覧は `SHA256SUMS-current.txt`。

| ファイル | サイズ(B) | sha256 | 台帳 |
|---|---|---|---|
| `protocol-debug_fix8-9.aar` | 5,786 | `ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25` | row 15 |
| `receiver-debug_kotlin2.2.20_fix8-9.apk` | 2,616,008 | `5cba428d3385f06e219acd38e1804c574bb38861e828baf035a9ff08d33f99be` | row 16 |
| `sender-debug_kotlin2.2.20_fix8-9.apk` | 2,625,017 | `02d9fe481b1b35e4368cc4d5cb048558b248c290c4e176caf3f41593d92a55d9` | row 17 |

修正 #8/#9 適用前の履歴（`SHA256SUMS.txt` に記載・ファイルは残置）:
`protocol-debug.aar` 5,786 B `ebfc031a…`（**正式と同一**）/ `receiver-debug_kotlin2.2.20.apk` 2,615,972 B `d4808f48…` /
`sender-debug_kotlin2.2.20.apk` 2,625,017 B `02d9fe48…`（**正式と同一**）。

### 2.3 再構築 APK — Kotlin 2.0.21（比較用・構造修正 2 件反映後）[検証済]

保存先 `out/phase-d/kotlin-2.0.21/`（`SHA256SUMS.txt` 同梱）

| ファイル | サイズ(B) | sha256 | 元との差 | 台帳 |
|---|---|---|---|---|
| `receiver-debug_kotlin2.0.21_fix8-9.apk` **（正式）** | **2,512,149** | `6f5fe29f945a8bb26e7c848c5b0064f5f432f44a4371dda12b2de1ae8530c5ba` | **−676 B** | row 14 |
| `sender-debug_kotlin2.0.21.apk` **（正式）** | 2,522,246 | `4fdf559c4d73cd40e22a0a42d832673780fef7b65d7e2c8ade27c94b5ad947fd` | **+884 B** | row 8 |
| `receiver-debug_kotlin2.0.21.apk`（履歴・修正#7まで） | 2,512,201 | `44e8b904…277a` | −624 B | row 7 |
| `receiver-debug_kotlin2.0.21_fix89.apk`（履歴・修正#8のみ） | 2,512,121 | `186450fc…cb92` | −704 B | row 12 |

全 17 ビルドの時系列（失敗・途中版を含む）は `out/phase-d/APK_BUILD_LOG.md`（追記専用）。
**「今どれを使うか」は `out/phase-d/CURRENT_ARTIFACTS.md`** にまとめてある。

> **APK のファイルサイズは指標にならない**: zipalign のパディングはエントリ順・圧縮率で変動するため、
> 内容一致の判定は §3 のエントリ単位ハッシュで行うこと。

### 2.4 ビルド再現性 [検証済]

clean → ビルドを 2 回実行した結果、**ソースを変更しなかったモジュールは出力がバイト単位で一致した**:

| モジュール | 1 回目 | 2 回目 | 判定 |
|---|---|---|---|
| protocol (AAR) | row 9 `ebfc031a…` | row 15 `ebfc031a…` | **バイト一致** |
| sender (APK, 2.2.20) | row 11 `02d9fe48…` | row 17 `02d9fe48…` | **バイト一致** |

→ 復元プロジェクトのビルドは再現可能（同じソース・同じ環境なら同じ成果物が出る）。

### 2.5 ⚠ 作業コンテナの再生成と、成果物の復元証明（2026-10-29 22:30 頃）[検証済]

Phase D の記録を書いている途中で**作業コンテナが再生成**され、次のものが失われた:

- `out/` 配下の全成果物（APK / AAR / apktool 展開物 / `APK_BUILD_LOG.md` / `CURRENT_ARTIFACTS.md`）
  → **`out` というディレクトリ名はワークスペースのスナップショット対象外**だったため（同様に `build`, `dist` も対象外）。
- `LiteScreen-Recovered/*/build/`（ビルド中間物。対象外）
- ツールチェーン（JDK 17 / Android SDK / Gradle 8.13 / apktool / jadx。ワークスペース外の `/opt`, `/usr/local`）
- Gradle の依存キャッシュ（`/root/.gradle`）と debug keystore（`/root/.android`）

**無傷だったもの**: 復元ソース一式、`recovery/evidence/`（120 ファイルの検証記録）、`recovery/decompiled/`（元の展開物 6 本）、
`recovery/input-apk/`（元 APK 3 本・ハッシュ一致を確認）、`CHECKPOINT.md`、各レポート、`scripts/`（18 本）。

対応: `scripts/00_setup_env.sh` でツールチェーンを再導入（46 秒）→ SDK に `platforms;android-36` /
`build-tools;36.0.0` / `build-tools;35.0.0` を追加 → Gradle 8.13 を再取得 → 全モジュールを再ビルド。

**再ビルド結果（すべて exit 0・BUILD SUCCESSFUL）と、消失前の成果物との内容同一性証明**:

| モジュール | 新ビルド | 消失前 | ZIP 全エントリの照合 |
|---|---|---|---|
| protocol AAR (2.2.20) | 5,786 B `ebfc031a…` | row 9/15 と同一 | **ファイル全体がバイト一致** |
| receiver (2.2.20) | 2,616,008 B `93163c5a…` | 2,616,008 B `5cba428d…` | **41/41 エントリ バイト一致**（相違 0） |
| sender (2.2.20) | 2,625,017 B `4aa5d63d…` | 2,625,017 B `02d9fe48…` | **54/54 エントリ バイト一致**（相違 0） |
| receiver (2.0.21) | 2,512,149 B `50d3f715…` | 2,512,149 B `6f5fe29f…` | **40/40 エントリ バイト一致**（相違 0） |
| sender (2.0.21) | 2,521,242 B `d57b619b…` | 2,522,246 B `4fdf559c…` | **53/53 エントリ バイト一致**（相違 0） |

- 照合方法: 消失前に生成した**エントリ単位 sha256 の証拠ファイル**（`recovery/evidence/PHASE_D_zip_entries_*.txt`）が
  永続領域に残っていたため、それと新ビルドの各エントリを突き合わせた。
- APK 全体の sha256 が変わるのは**署名ブロックだけ**（debug keystore が環境ごとに自動生成されるため）。
  dex・リソース・マニフェストは完全に同一。
- sender 2.0.21 の −1,004 B も署名ブロック/パディングの差（内容は同一）。
- **教訓（再発防止）**: 成果物は `recovery/artifacts/` のような**スナップショット対象外のディレクトリ名を避けた場所**に置く。
  `out/`, `build/`, `dist/`, `target/`, `node_modules/` などは保存されない。

> 現在の正式成果物と対応表は **`recovery/artifacts/CURRENT_ARTIFACTS.md`**、
> ビルド全履歴（row 1〜22 + OOM 失敗 1 件）は **`recovery/artifacts/APK_BUILD_LOG.md`** を参照。
> §2.2 / §2.3 のハッシュは消失前ビルドの記録として残してある（内容は現行成果物と同一）。

### 2.6 ⚠ OOM とビルド粒度（環境再構築後に再発・対処済み）[検証済]

依存キャッシュが空の状態で clean 後に `:receiver:assembleDebug` を一括実行したところ、
**カーネルの OOM キラーで JVM が殺された**（`hs_err_pid2073.log`: `Native memory allocation (mmap) failed`、
`physical 1048576k(30772k free), swap 0k`）。

対処（ユーザー指示「OOM 時は無限リトライせず、ログを保存してメモリ設定とビルド粒度を見直す」に従った）:

```bash
gradle :receiver:compileDebugKotlin   # exit 0 / 1m13s
gradle :receiver:assembleDebug        # exit 0 / 49s   ← 2 段階に分けると成功
```

ログ: `recovery/evidence/PHASE_E_recv_step1_compile.log`, `PHASE_E_recv_step2_assemble.log`,
`PHASE_E_hs_err_pid2073_receiver.log`（クラッシュ記録）。`gradle.properties` の JVM 設定は変更していない。

### 2.7 ⚠ インクリメンタルビルドのパディング問題 [検証済]

`clean` せずに receiver だけ再ビルドしたところ、**dex の内容差は 28 B なのに APK が +96,561 B 大きくなった**
（2,512,149 B → 2,608,682 B。ZIP エントリ数・圧縮方式は同一で、パディング/オフセットだけが増加）。
→ **比較や配布に使う APK は必ず clean ビルドで作る**こと。この検証ビルドは台帳 row 13 に記録のみ（成果物としては保存していない）。

---

## 3. 照合結果

比較スクリプト: `scripts/26_compare_apk.sh`（badging / 署名 / ZIP 一覧 / dex ヘッダ）、
`scripts/27_compare_rebuilt_smali.py`（クラス・ラムダ形状・定数）、`scripts/28_class_level_consts.py`（クラス単位定数）、
`scripts/30_zip_entry_hashes.py`（**エントリ単位 sha256**）。
出力: `recovery/evidence/PHASE_D_{apk,smali,class_consts,zip_entries}_compare_*` 系（`-k2021` 付きが 2.0.21 版）。

### 3.1 aapt2 dump badging — **差分なし** [検証済]

receiver / sender とも、2.2.20・2.0.21 の**全 4 組み合わせで差分ゼロ**（`diff` 出力が空）。一致を確認した項目:

**receiver**（元 APK の badging 全文と一致）:
- `package: name='jp.litescreen.receiver.debug' versionCode='11' versionName='1.0.11-debug'`
  `compileSdkVersion='36'` / `minSdkVersion:'28'` / `targetSdkVersion:'36'`
- 権限（3 件）: `INTERNET`, `ACCESS_NETWORK_STATE`, `CHANGE_WIFI_MULTICAST_STATE`
- `application-label:'LiteScreen 受信'` / `application-debuggable`
- `launchable-activity: jp.litescreen.receiver.ReceiverActivity`
- icon: `res/mipmap-anydpi-v21/ic_launcher.xml`（densities `160` / `65534`）
- feature-group: `uses-feature-not-required: android.hardware.touchscreen`, `uses-feature: android.hardware.wifi`
- `supports-screens: 'small' 'normal' 'large' 'xlarge'` / `supports-any-density: 'true'`

**sender**:
- `package: name='jp.litescreen.sender.debug' versionCode='11' versionName='1.0.11-debug'`
  `compileSdkVersion='36'` / `minSdkVersion:'28'` / `targetSdkVersion:'36'`
- 権限（7 件）: `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION`, `POST_NOTIFICATIONS`,
  `INTERNET`, `ACCESS_NETWORK_STATE`, `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE`
- `application-label:'LiteScreen 送信'` / `application-debuggable`
- `launchable-activity: jp.litescreen.sender.SenderActivity`
- icon: `res/mipmap-anydpi-v21/ic_launcher.xml`
- feature-group: `uses-feature: android.hardware.wifi`, `android.hardware.faketouch`
  + `uses-implied-feature: android.hardware.faketouch reason='default feature for all apps'`
- サービス宣言あり（badging の `other-services`）

**両モジュール共通**: `native-code` 行なし＝ネイティブライブラリ無し（Kotlin + android.jar のみ）。
なお sender に `RECORD_AUDIO` / `WAKE_LOCK` は**無い**（画面キャプチャのみで音声は送信しない）。

### 3.2 署名 — **不一致（想定内・要注意）** [APK確認]

| | 証明書 DN | 証明書 SHA-256 | 方式 |
|---|---|---|---|
| 元 APK | `C=US, O=Android, CN=Android Debug` | `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf` | **v2 のみ** |
| 再構築（旧環境の鍵） | `C=US, O=Android, CN=Android Debug`（別鍵） | `7a1fd7bb1a40a6e6a4cdcfea6edae6608f80222c90a8e4ca09dbfc72aa3277bd` | **v2 のみ** |
| 再構築（現環境の鍵） | 同上（別鍵） | `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847` | **v2 のみ** |

**【Phase F 再実測 2026-10-30】** `apksigner verify --print-certs`（apksigner 0.9）で**全 7 APK を実測**した結果:

| 群 | 対象 | 証明書 SHA-256 | 証明書 SHA-1 | signer 数 | v1 / v2 |
|---|---|---|---|---|---|
| 元 APK | receiver v1.0.11 / sender v1.0.11 / sender v1.0.10 の **3 本すべて同一** | `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf` | `812c5dfd0b1bd48098dc6dbb844b9077dd341984` | 1 | false / **true** |
| 再構築 APK | Kotlin **2.0.21** 版 receiver・sender ＋ **2.2.20** 版 receiver・sender の **4 本すべて同一** | `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847` | `51e27981323a821f4bb9ffede06f29d4f09a16d9` | 1 | false / **true** |

- DN は両群とも `C=US, O=Android, CN=Android Debug`（**DN が同じでも鍵は別物**）。
- **元 sender v1.0.10 と v1.0.11 は同一証明書** → 相互に更新インストール可能（versionCode が下がる場合のみ `-d` が必要）。
- 上表の再構築側の値は**当環境でビルドした APK の実測値**。別環境でビルドし直すと debug keystore が自動生成されるため変わる
  （`7a1fd7bb…` → `530053f9…` がその実例）。**古いメモの省略値を転記しないこと。**

署名スキームは元 APK と**完全に同じ**（`apksigner verify -v`: v1=false / v2=true / v3=false / v3.1=false / v4=false /
signers=1）。違うのは**鍵（証明書）だけ**。
> 訂正: 初版レポートでは再構築側を「v1+v2」と記したが、`apksigner verify -v` の実測は **v2 のみ**（元と同じ）。

- 元の debug keystore は **復元不能**（APK からは公開鍵しか取り出せない）。AOSP の testkey とも不一致を確認済み [APK確認]。
- **インストール時の注意**: 再構築 APK は既存アプリの**上書き更新ができない**（`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）。
  → 既存アプリは**アンインストールせずに残し**、再構築版は別アプリとして検証すること。
  アンインストールすると受信側の実行時状態（保存設定など）は失われる。

> **【Phase F 訂正（2026-10-30）】上記 3 行のうち、太字の事実（上書き更新ができない）は正しいが、
> 矢印以降の指示は誤り。** 同一 packageName は**並存インストールができない**ため、
> 「アンインストールせずに残す」を守ると再構築版は永久にインストールできず、実機テストが不能になる。
> 確定方針（**`docs/INSTALL_UNINSTALL_POLICY.md`**）:
> - 元 APK **ファイル**は必ず保存（`recovery/input-apk/` chmod 444 ＋ SHA-256、キット ZIP 内にも複製）→ **条件は満たしている**。
> - 再構築版を入れるには**端末上の元アプリのアンインストールが必要**（ユーザー承認済み）。
>   実行前に「対象端末／アプリ／packageName／versionCode／失われるデータ／実行コマンド」を記録する。
> - テスト後は元 APK を `adb install -r` で入れ直して復元する。
> - **Test A では受信側をアンインストールしない**（元 receiver を使う試験のため）。
>
> また「アンインストールすると**受信側**の実行時状態（保存設定など）は失われる」も**不正確**（ソース実測）:
> **永続データを持つのは送信側**（`SharedPreferences("litescreen")`: host / port / res_pos / fps_pos / bitrate_pos）で、
> **受信側に永続データは無い**（SharedPreferences・ファイル書き込みとも無し。アプリ内ログはメモリ内 200 行のみ）。
- 今後のリリースでは**自分の keystore を新規作成して署名し、それを必ず保管**すること（`docs/SIGNING_GUIDE.md`）。
- ⚠ debug keystore は `~/.android/debug.keystore` に**環境ごとに自動生成**される。
  実際にコンテナ再生成の前後で証明書が `7a1fd7bb…` → `530053f9…` に変わった（§2.5）。
  つまり **debug 署名の APK は環境を変えると別の署名になる**＝配布には使えない。

### 3.3 ZIP エントリ構成 [検証済]

| | receiver | sender |
|---|---|---|
| 元 APK | 41 エントリ | 54 エントリ |
| 再構築 2.0.21 | **41（完全一致・欠損0/余分0）** | **54（完全一致・欠損0/余分0）** |
| 再構築 2.2.20 | 42（+1） | 55（+1） |

2.2.20 で増える 1 件は `kotlin/concurrent/atomics/atomics.kotlin_builtins`（Kotlin 2.1+ の stdlib に同梱されるメタデータ。
2.0.21 には存在しない）。**アプリのコードではなく stdlib 付属物**であり、動作・通信には影響しない。

### 3.4 エントリ単位 sha256（`scripts/30_zip_entry_hashes.py`）[検証済]

| 一致エントリ数 | receiver | sender |
|---|---|---|
| Kotlin 2.0.21 | **15 / 41** | **15 / 54** |
| Kotlin 2.2.20 | 7 / 42 | 7 / 55 |

**2.0.21 でバイト完全一致した 15 エントリ**（receiver の例・sender も同じ内訳）:

| エントリ | サイズ | 意味 |
|---|---|---|
| `classes.dex` | **2,338,632 B** | **kotlin-stdlib の DEX**（1036 クラス = `kotlin/**` 1004 + `org.intellij/org.jetbrains` 注釈 32、アプリのクラスは 0） |
| `classes3.dex` | 4,644 B (receiver) / 6,148 B (sender) | **R クラスの DEX**（`jp.litescreen.protocol.R` + `R$color/drawable/id/layout/mipmap/string/style`） |
| `META-INF/com/android/build/gradle/app-metadata.properties` | 57 B | AGP のバージョン記録 → **元も AGP 8.13.2** |
| `kotlin/*.kotlin_builtins` ×7 | 200–18,661 B | stdlib 同梱メタデータ |
| `res/drawable/{bg_card,bg_card_accent,bg_card_inset,bg_pill_status,dot_accent}.xml` ×5 | 516–612 B | 復元した drawable が**バイト単位で一致** |

2.2.20 で一致するのが 7 件に減るのは、`classes.dex`（stdlib が 2.2 系で別物）と 7 個の builtins、
`res/drawable` 5 件のうち一部が入れ替わるため。**`classes3.dex`（R クラス）は 4 ビルド全てで一致**しており、
リソース ID の復元が完全であることは Kotlin 版に依らない。

### 3.5 AndroidManifest.xml（バイナリ AXML）[検証済]

```bash
aapt2 dump xmltree --file AndroidManifest.xml <apk>
```

- receiver: 元 3,212 B / 再構築 3,212 B（**サイズ同一**）、sha256 のみ異なる
- 差分を `aapt2 dump xmltree` 出力で比較した結果、**違いは `(line=NN)` の埋め込み行番号だけ**
  （例: `<manifest>` が元 line=34 / 再構築 line=29）。行番号を除けば**出力は完全一致**。
- すなわち要素の並び順・属性名・属性値・リソース ID 参照はすべて元と同一。
  差は「元の `AndroidManifest.xml` ソースの空行/コメントの行数」に由来する**デバッグ情報のみ**。
- sender も同様に 53 行同士の出力で**行番号以外の差分ゼロ**。
- （任意の追加作業）元の行番号に揃えれば manifest もバイト一致にできるが、マージ後 manifest の行番号合わせ込みが
  必要でビルド反復を要する。機能・互換性への影響は無いので**未実施**。

### 3.6 クラス構成と smali レベルの比較 [検証済]

**正式ビルド（修正 #1〜#9 反映後）** の値。evidence は receiver が `*-receiver-fix89.txt`（2.2.20）と
`*-receiver-k2021-fix8-9.txt`（2.0.21）、sender は `*-sender.txt` / `*-sender-k2021.txt`。

| 指標 | receiver 2.2.20 | receiver 2.0.21 | sender 2.2.20 | sender 2.0.21 |
|---|---|---|---|---|
| クラス数（元 / 再構築） | 65 / **65** | 65 / **65** | 49 / **49** | 49 / **49** |
| クラス名の不足 / 余分 | 0 / 0 | 0 / 0 | 3 / 3 ※ | 3 / 3 ※ |
| 合成ラムダ（形状一致） | 37 / 37 | 37 / 37 | 14 / 14 | 14 / 14 |
| 通常クラス **完全一致** | 9 / 28 | **23 / 28** | 10 / 32 | **24 / 32** |
| 差分あり | 19 | 5 | 22 | 8 |
| うち `@Metadata mv` のみ | 14 | 0 | 14 | 0 |

修正 #8/#9 適用前との差（receiver）: `DecoderCaps` の `+ 再構築だけ: 0x1c0=448 x3` が**消滅**し、
`const-wide/16 0x1e`（30L の畳み込み）も**消滅**した（§4 の #8 #9）。通常クラスの完全一致数は変化なし
（2.0.21 = 23/28、2.2.20 = 9/28。差分の主因は `@Metadata mv` とインライン codegen のため）。

※ sender の匿名クラス 3 個の**連番の振り方**だけが異なる（実体は一致）。

`@Metadata mv` は Kotlin メタデータ形式のバージョン（元 `{2,0,0}` / 2.2.20 `{2,2,0}`）。2.0.21 では**元と一致**する。

### 3.7 DEX 内訳（class_defs_size）[検証済]

| dex | 元 receiver | 再構築 receiver | 内容 |
|---|---|---|---|
| `classes.dex` | 1,036 | 1,088 (2.2.20) / **1,036 (2.0.21)** | kotlin-stdlib |
| `classes2.dex` | 3 | 3 | `jp.litescreen.protocol.{Framing,Proto,ProtocolException}` |
| `classes3.dex` | 9 | 9 | R クラス |
| `classes4.dex` | 35 | 35 | アプリ本体 |
| `classes5.dex` | 18 | 18 | アプリ本体（ラムダ等） |

sender は `classes3.dex` = 10、以降同様に一致。

---

## 4. Phase D で発見・修正した不具合（計 9 件）

Phase C の「文字列・メンバ一致」検証では検出できなかった**意味レベルの誤り**を、
smali の数値定数・`$default` マスク・ラムダ構造と突き合わせて発見し、修正した。
すべて修正後に再ビルド（exit 0）→ 再比較済み。

| # | ファイル | 誤り（復元時） | 正しい値（smali 根拠） | 影響 |
|---|---|---|---|---|
| 1 | `receiver/.../H264Decoder.kt` | `THREAD_PRIORITY_BACKGROUND`(=10) | **`THREAD_PRIORITY_URGENT_DISPLAY`(=−8)**（smali `const/16 v0, -0x8`） | デコードスレッド優先度。映像の遅延/カクつきに直結 |
| 2 | `receiver/.../MirrorService.kt` | `FLAG_ACTIVITY_CLEAR_TOP`(=0x04000000) | **`FLAG_ACTIVITY_SINGLE_TOP`(=0x20000000)**（smali `0x20000000`） | 通知タップ時の Activity 起動挙動（CLEAR_TOP だと再生成される） |
| 3 | `sender/.../SenderClient.kt` | `System.currentTimeMillis() % 1000L` | **`% 1000000`**（smali `rem-long … 0xf4240`） | STATS の sendMs 算出。**プロトコル互換に関わる** |
| 4 | `receiver/.../H264Decoder.kt` | `contains(..., ignoreCase = true)` | **大文字小文字を区別**（smali が `contains$default` mask `0x2` = 引数既定値を使用 = `false`） | csd 判定ロジック |
| 5 | `protocol/.../Proto.kt`（`StreamConfig`） | `port: Int = 47820` と既定値を付与 | 元に**既定値は無い**（合成コンストラクタの mask は `0x4/0x8/0x10` のみで port ビット無し） | API 形状・呼び出し側コード生成 |
| 6 | `receiver/.../H264Decoder.kt`（`markFatal`） | ラムダ 2 個に分解された形 | **単一ラムダ `markFatal$lambda$10(Listener,String)`**（smali `.line 402-403`） | 構造（クラス数・ラムダ数） |
| 7 | `receiver/.../ReceiverDiscovery.kt` | callback 呼び出しが `finally` 内 | **`finally` の外**（cleanup は ×3、`sortedWith` は ×1） | 構造。修正で sender/receiver のクラス数が元と一致 |
| 8 | `receiver/.../DecoderCaps.kt` | 失敗時の `Probe(fps = 448)` | **`fps = 0`**。`0x1c0`(=448) は `Probe` 合成コンストラクタの**第10引数＝既定値マスク**（bits 6,7,8 = profile/level/adaptive）で、fps は第4引数 `const/4 0x0` | `Probe` オブジェクトの fps 値（呼び出し側は `width > 0` で判定するため実害は無いが、**事実として誤り**）。修正で再構築側の `0x1c0` が 6 個 → **3 個（元と一致）** |
| 9 | `receiver/.../DecoderCaps.kt`（`diagnose()`） | `${30L * mb}` | **`val fps = 30` + `${fps.toLong() * mb}`**。元 smali は `const/16 0x1e` → `int-to-long` → `mul-long` の順で、続く `requiredLevel(1280,800,30)` でも同じレジスタを再利用している | `30L` / `30.toLong()` は Kotlin 2.0.21 でも `const-wide/16` に畳み込まれ元と異なる命令になる（**実測で確認**）。修正後は `int-to-long` 形が元と一致 |

### 4.1 この 9 件から得られた教訓（今後の修正作業で必ず守る）

1. **Android 定数は「値」で確認する**（名前でない）。
   `javap -classpath <android.jar> -constants android.os.Process` で数値を出す。
   例: THREAD_PRIORITY: AUDIO=−16, URGENT_AUDIO=−19, VIDEO=−10, URGENT_DISPLAY=−8,
   BACKGROUND=10, LOWEST=19, DEFAULT=0。
   Intent: NEW_TASK=0x10000000, SINGLE_TOP=0x20000000, CLEAR_TOP=0x04000000。
2. **`$default` の mask ビットは「その引数が既定値を使っている」印**。
   ソースに既定値を明示的に書くと codegen が変わり、意味も変わりうる。
   データクラスの既定値は**合成コンストラクタの mask ビットからだけ**復元する。
   → 修正 #8 はこれを逆に誤読した例。`invoke-direct/range {v27 .. v38}` の**レジスタ並びで
   引数の位置を確定**してから値を読むこと（末尾 2 つは必ず `mask:Int, marker:DefaultConstructorMarker`）。
   mask `0x1c0` = bits 6,7,8 = 9 引数中の profile / level / adaptive。
3. **jadx 1.5.6 は `UByte.MAX_VALUE` を 255 → −1 と誤描画する**など複数の既知バグがある。
   ビット演算・符号・キャストは必ず smali で裏取りする（`recovery/reports/JADX_ERRORS.md`）。
4. `MediaCodec.CodecException.ERROR_UNSUPPORTED`（@hide）= `0x80010005`。
   元アプリのユーザー向け文言 "0x80001005" は**原文のまま保持**（修正しない）。
5. 例外の catch 順: `SocketTimeoutException` → `ProtocolException` → `EOFException` → `IOException` → `Exception`
   （`ProtocolException` は `IOException` の子なので順を間違えると到達不能になる）。
6. **数値リテラルの「型」も smali で確認する**（修正 #9）。`30L` と `30.toLong()` と「ローカル変数 `fps` の
   `fps.toLong()`」は、同じ値でも生成される命令が違う（`const-wide/16` か `const/16` + `int-to-long` か）。
   元の smali に `int-to-long` があるなら、ソースは**変数の `.toLong()`**。
7. **定数の「個数」はレジスタ割り当てに依存する**。元が 4 個・再構築が 3 個でも、
   値の意味が同じなら codegen ノイズ（§7）。個数合わせを目的にソースを歪めないこと。

---

## 5. 元アプリの Kotlin バージョン判定 → **2.0.21** [検証済]

根拠（強い順）:

1. **`classes.dex`（kotlin-stdlib 1036 クラス）が 2.0.21 ビルドでバイト完全一致**（2,338,632 B, sha256 一致）。
   2.2.20 では不一致。stdlib の DEX が一致する＝**同梱 stdlib のバージョンが完全一致**＝ 2.0.21。
2. `kotlin/*.kotlin_builtins` 7 個が 2.0.21 で一致、2.2.20 では不一致＋`atomics.kotlin_builtins` が余分に増える。
3. `@Metadata mv = {2,0,0}`（Kotlin 2.0 系メタデータ）が 2.0.21 で一致。
4. 通常クラスの完全一致数: receiver 23/28, sender 24/32（2.2.20 は 9/28, 10/32）。
5. サイズ差: 2.0.21 は −624 B / +884 B。2.2.20 は +103 kB / +104 kB。

→ **元プロジェクトは Kotlin 2.0.21 + AGP 8.13.2 + Gradle 8.13 でビルドされていた**と結論できる [検証済]。
（2.0 系の他パッチ版である可能性は §5.1 のとおり残るが、stdlib DEX 一致は 2.0.21 を強く支持する。）

### 5.1 2.2.20 を使う場合の追加差分（すべてコンパイラ由来・機能影響なし）[検証済]

- `kotlin/concurrent/atomics/atomics.kotlin_builtins` エントリが +1
- ラムダの連番（`$lambda$N`, `$r8$lambda$<hash>`, `$$ExternalSyntheticLambdaN`）の振り方
- プラットフォーム型の null チェック文言（`Intrinsics.checkNotNullExpressionValue(x, "call(...)")`）の差
  → NetUtil の list/getInetAddresses、ScreenCapturer の getCodecInfos/getDisplayMetrics/createInputSurface/getByName
- 定数 `in IntRange` を 2.2 は直接比較（0x10000 / 0xffff）に最適化、2.0 は `IntRange.contains` を呼ぶ
- インライン `run {}` 内で定数が複製され、`$i$a$-run-...` ローカルが増える（DecoderCaps）
- `try-finally` 内の `continue` により finally 本体が出口ごとに複製されるのは**両バージョン共通**。
  ただし 2.0 はインライン関数末尾（`sortedWith` ×1）を共有し、2.2 はコンパレータ全体を複製（×3）する
- `const/4 vN, 0x0` の冗長ロードを 2.2 が削除する箇所がある

---

## 6. 意図的に入れた差分（元と違うが、意図的）

| # | 内容 | 理由 | ユーザー決定 |
|---|---|---|---|
| 1 | `MirrorService.startMirroring()` を **private 関数として維持**（元の smali では `onStartCommand` のラムダ内にインライン展開されていた） | 可読性・保守性。挙動は同一 | **keep_function**（2026-10-29） |
| 2 | Kotlin 既定版を **2.2.20** にしている | 今後の修正・更新を新しいコンパイラで継続するため。忠実再現が必要なら 2.0.21 に 1 行で切替可 | **try_both**（両方ビルドして比較） |
| 3 | アイコン用 res ディレクトリを `mipmap-anydpi-v21` にしている | 元の APK のエントリ名（`res/mipmap-anydpi-v21/...`）に合わせるため。`v26` だと APK 内パスが変わる | — |

---

## 7. 残存する良性差分（2.0.21 ビルド時点・文書化のみ）[検証済]

- `DecoderCaps`: `0x1e`(30) が元 4 個 / 再構築 3 個、`0x320`(800) と `0x500`(1280) が元より 2 個ずつ少ない、
  `0x0` が元より 5 個少ない → いずれも**レジスタ再利用（CSE）による codegen 差**。
  命令の形（`const/16` + `int-to-long`）と mask（`0x1c0` ×3）は元と一致させた（修正 #9）
- 匿名クラスの連番 3 個（sender）
- プラットフォーム型 null チェックのメッセージ文字列（§5.1）
- `DecoderCaps` の `run {}` 内定数複製
- `ScreenCapturer$doStart$3/$4` ↔ `$2/$3` のスロットずれ
- `const/4 …, 0x0` の codegen ノイズ（`scripts/28_class_level_consts.py` でクラス単位に見ると残差は小さい）

いずれも**プロトコル・UI・権限・リソース ID には影響しない**。

---

## 8. 未検証事項（重要）[未確認]

以下は**この環境では検証していない**。実施したと誤解されないよう明記する。

1. **実機での動作**（sender 画面キャプチャ → receiver 表示）: 実機が無いため未検証。
2. **通信互換**（再構築 sender ↔ 元 receiver、再構築 receiver ↔ 元 sender）:
   MAGIC `4C 53 43 01` / TCP 47820 / UDP 47821 / メッセージ 1..14 / VIDEO ヘッダ構成 / STATS v2 24 B は
   **バイト列レベルで一致を確認済み**[APK確認] なので成立する**はず**だが、実測はしていない。
3. **遅延・FPS の改善**: 未測定。数値を主張しない。
4. **receiver の API 28（チャレンジパッドNext TAB-A05-BA1）での実動作**: minSdk 28 の宣言一致のみ確認。
5. **Play ストア/配布時の挙動**: debug ビルドのため対象外。

---

## 9. Kotlin バージョンの切り替え手順 [検証済]

```bash
cd LiteScreen-Recovery
./scripts/31_switch_kotlin_version.sh              # 現在値を表示
./scripts/31_switch_kotlin_version.sh 2.0.21       # 2.0.21 に切替（build.gradle.kts を自動バックアップ）
./scripts/31_switch_kotlin_version.sh 2.2.20 --build   # 2.2.20 に戻して clean→3モジュール再ビルド
```

切り替わるのは `LiteScreen-Recovered/build.gradle.kts` 8 行目の 1 箇所だけ:

```kotlin
id("org.jetbrains.kotlin.android") version "2.2.20" apply false   // ← ここ
```

**注意**: 版を切り替えたら必ず `clean` すること（増分ビルド状態が混ざると §3.6 の比較が壊れる）。
2.0.21 では `kotlin { compilerOptions { } }` DSL が使えない場合があるため、
モジュール側は `android { kotlinOptions { jvmTarget = "17" } }` 記法でも通る形にしてある。

---

## 10. 推奨事項

1. **配布・実機検証用には 2.0.21 ビルドを第一候補にする**（元 APK と最も近い: stdlib DEX バイト一致、
   エントリ構成一致、サイズ差 ±900 B 以内）。`out/phase-d/kotlin-2.0.21/` に保存済み。
2. **今後の開発の既定は 2.2.20 のままでも良い**が、その場合は §5.1 の差分（builtins +1、ラムダ連番、
   null チェック文言）が「元と違うが正常」であることを引き継ぎメモに残す。
   どちらを既定にするかはユーザー判断（本レポート提出時に確認する）。
3. **自分の署名鍵を新規作成して保管**し、以後はそれで署名する（§3.2）。既存アプリは消さない。
4. 実機が用意でき次第、最低限 (a) 再構築 sender ↔ 元 receiver、(b) 再構築 receiver ↔ 元 sender の
   2 通りの相互接続を確認する。確認できたら本レポート §8 を更新する。
