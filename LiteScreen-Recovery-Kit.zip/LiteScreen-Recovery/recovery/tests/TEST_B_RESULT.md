# TEST B 結果記録 — **元** sender v1.0.11 ↔ 再構築 receiver（Kotlin 2.0.21）

| 項目 | 値 |
|---|---|
| テスト ID | **Test B**（**最重要**。プロトコル復元の正しさの実証） |
| 目的 | 復元した**受信側**が、**元の送信側**から映像を受けられるか |
| 実施日時 | **未実施** |
| 実施者 | **未実施** |
| 実施環境（PC / OS / adb version） | **未実施** |
| **現在の状態** | **NOT TESTED（BLOCKED：復旧コンテナに実機接続なし。`adb devices` 空・`/dev/bus/usb` 不在）** |
| 判定 | **NOT TESTED** ← 実施後に PASS / FAIL / BLOCKED のいずれかへ変更 |

> 根拠（実測）: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`
> 手順書: `docs/DEVICE_TEST_GUIDE.md` §3 / Windows の adb 準備: `docs/ADB_SETUP_WINDOWS.md`
> **未実施の項目を埋めてはならない。**

---

## 1. 使用する APK（実施前にハッシュ確認）

| 役割 | 端末 | ファイル | SHA-256（期待値） | サイズ |
|---|---|---|---|---|
| 送信（**元・基準は v1.0.11**） | REDMAGIC Astra NP05J (Android 16 / API 36) | `recovery/input-apk/litescreen-sender-v1.0.11-debug.apk` | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` | 2,521,362 B |
| 受信（**再構築**） | チャレンジパッドNext TAB-A05-BA1 (Android 9 / API 28) | `recovery/artifacts/kotlin-2.0.21/receiver-debug_kotlin2.0.21_fix8-9.apk` | `50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408` | 2,512,149 B |
| 退避（元の受信側） | — | `recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk` | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` | 2,512,825 B |

### 1.1 元 sender の基準バージョン（**混同禁止**）

| 選択 | ファイル | packageName | versionCode / versionName | 証明書 SHA-256 |
|---|---|---|---|---|
| **今回の基準（既定）** | `litescreen-sender-v1.0.11-debug.apk` | `jp.litescreen.sender.debug` | **11** / `1.0.11-debug` | `bf068d16…fdaf` |
| 別バージョン（使う場合のみ） | `litescreen-sender-v1.0.10-debug.apk` | `jp.litescreen.sender.debug` | **10** / `1.0.10-debug` | `bf068d16…fdaf`（**同一証明書**） |

- **v1.0.10 と v1.0.11 は packageName が同じで versionCode だけ違う別物。同一視しない。**
- 端末に同時には入らない。v1.0.11 → v1.0.10 は **ダウングレードなので `adb install -r -d`** が必要。
- v1.0.10 を使う場合、理由を記入し、**v1.0.11 の結果と分けて**報告する:

```
v1.0.10 を使った理由: （未使用なら「使っていない」と記入）
v1.0.10 での結果（別欄として）:
```

- 実測ハッシュ（PC 側 `certutil -hashfile ... SHA256`）: 元 sender = `________________` / 再構築 receiver = `________________`
- 期待値と一致したか: [ ] はい / [ ] いいえ（**いいえならテストを中止して報告**）

## 2. 端末の状態（実施前に記入）

| 項目 | Astra（送信） | TAB-A05-BA1（受信） |
|---|---|---|
| `adb devices -l` のシリアル | ____________ | ____________ |
| `getprop ro.product.model` | ____________ | ____________ |
| `getprop ro.build.version.release` / `sdk` | ____ / ____ | ____ / ____ |
| Wi-Fi SSID / IP アドレス | ____________ / ____________ | ____________ / ____________ |
| テスト前の sender versionCode | **11（元）** | — |
| テスト前の receiver versionCode | — | 11（元）→ 実施後 11（再構築） |

- 送信側 → 受信側への ping 結果: `________________`
- 再構築 receiver 起動後の TCP 47820 LISTEN 確認: `________________`

## 3. アンインストール記録（`docs/INSTALL_UNINSTALL_POLICY.md` §4 の様式）

**Test B でアンインストールするのは受信側（TAB-A05-BA1）の元 receiver のみ。送信側は元に戻す／元のまま。**

```text
[アンインストール記録]
- 実施日時（ローカル / UTC）: ____ / ____
- 対象端末: チャレンジパッドNext TAB-A05-BA1 (Android 9 / API 28)
- 対象アプリ名（ラベル）: LiteScreen 受信
- packageName: jp.litescreen.receiver.debug
- versionCode / versionName: 11 / 1.0.11-debug（実施前に実測して記入）
- 署名（dumpsys の signatures 行）: ____________
- 失われるデータ: **なし**（ソース実測: 受信側に SharedPreferences / ファイル書き込み / 外部ストレージ利用なし。
                  アプリ内ログ LocalLog はメモリ内 200 行のみで、終了時点で消える）
                  → 失われるのはアプリ本体だけ。
- 元 APK のバックアップ場所と SHA-256: recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk
                                        384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473
- 実行コマンド: adb -s <TAB> uninstall jp.litescreen.receiver.debug
- 実行結果: ____________（Success / Failure と出力そのまま）
- 復元予定: テスト後に同じ元 APK を install -r（§6）
```

## 4. 実施ログ（手順は `docs/DEVICE_TEST_GUIDE.md` §3.1 の B-1〜B-17）

| 手順 | 時刻 | 実行したコマンド／操作 | 出力・観察結果 |
|---|---|---|---|
| B-1 元 sender v1.0.11 の確認 | | | |
| B-4 アンインストール | | | |
| B-5 再構築 receiver インストール | | | |
| B-6 versionCode 確認 | | | |
| B-8 receiver 起動・IP/ポート記録 | | | |
| B-10 元 sender で受信端末の検索（UDP 47821） | | | |
| B-11 配信開始・収録許可 | | | |
| B-12 **映像確認** | | | |
| B-13 能力診断 | | | |
| B-14 証拠保存 | | | |

## 5. チェックリスト（`docs/DEVICE_TEST_GUIDE.md` §3.2）

| 確認項目 | 結果（OK / NG / 未確認） | 備考 |
|---|---|---|
| 再構築 receiver が TCP 47820 で LISTEN | | |
| 元 sender の PROBE に応答し、端末名が元 sender 側に出る | | |
| **受信側の画面に送信側の映像が実際に出た** | | **PASS の必須条件** |
| H.264 デコーダ生成・csd（SPS/PPS）処理ができる | | |
| 色がおかしくない（緑/紫ノイズ、ブロックノイズなし） | | |
| 解像度/FPS 変更でデコーダーを作り直せる | | |
| 「能力診断」で fps=448 が出ない（修正 #8） | | |
| アプリ内ログ（200 行）にエラーが無い | | |

### 5.1 能力診断の結果（Test B で必須）

```
デコーダー名:
HW / SW:
対応サイズ（最大 / 最小 / アラインメント）:
対応 FPS:
プロファイル / レベル対応:
1920x1200 を要求した場合の自動縮小結果:
失敗時の返り値（fps / width）: ← fps=0 / width=0 なら修正 #8 が効いている
```

## 6. 復元（テスト後）

- 実行コマンド: `adb -s <TAB> install -r recovery\input-apk\litescreen-receiver-v1.0.11-debug.apk`
- 結果: ____________
- 復元後の versionCode / versionName: ____ / ________
- 元どうし（元 sender ↔ 元 receiver）で映像が出ることを確認したか: [ ] はい / [ ] いいえ

## 7. 添付する証拠

- [ ] `send_logcat.txt`（送信側 Astra）
- [ ] `recv_logcat.txt`（受信側 TAB-A05-BA1）
- [ ] `testB_recv_screen.png`（**映像が写っている受信側画面**）
- [ ] 2 台を並べた写真／動画
- [ ] 受信側アプリ内ログ（200 行）のスクリーンショット
- [ ] 「能力診断」結果のスクリーンショット
- [ ] 症状が出た場合の操作手順と設定値

## 8. 最終判定

- **判定**: ☐ PASS ☐ FAIL ☐ NOT TESTED ☐ BLOCKED
- 判定の理由（**映像が出たかどうかを必ず書く**。インストール成功・TCP 接続成功だけでは PASS にしない）:

```
（記入）
```

- FAIL / BLOCKED の場合の症状・ログ抜粋:

```
（記入）
```
