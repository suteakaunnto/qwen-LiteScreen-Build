# recovery/tests — 実機テストの結果記録（テンプレート）

作成: 2026-10-30（Phase F）

## 現在の状態：**全テスト NOT TESTED（BLOCKED）**

| テスト | 内容 | 状態 | 記録ファイル |
|---|---|---|---|
| **Test A** | 再構築 sender（Kotlin 2.0.21）↔ **元** receiver v1.0.11 | **NOT TESTED / BLOCKED** | `TEST_A_RESULT.md` |
| **Test B** | **元** sender v1.0.11 ↔ 再構築 receiver（Kotlin 2.0.21） | **NOT TESTED / BLOCKED** | `TEST_B_RESULT.md` |
| **Test C**（任意） | 再構築 sender ↔ 再構築 receiver（2.0.21、比較で 2.2.20） | **NOT TESTED / BLOCKED** | `TEST_C_RESULT.md` |

**BLOCKED の根拠（実測・捏造なし）**: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`
— 復旧コンテナには `/dev/bus/usb` が存在せず、`adb devices` の一覧は空（接続実機 0 台）。adb 自体は動作する（1.0.41 / 37.0.1）。
したがって **この環境ではいかなる実機テストも実施していない**。インストール・アンインストールも **0 件**。

## 使い方（ユーザー側で実施する場合）

1. `docs/ADB_SETUP_WINDOWS.md` で Windows に adb を入れ、2 台を認識させる。
2. `docs/DEVICE_TEST_GUIDE.md` の **Test A → Test B →（任意）Test C** の順で実施する。
3. アンインストールを行う前に `docs/INSTALL_UNINSTALL_POLICY.md` §4 の記録様式を各 RESULT ファイルに転記する。
4. 観察した結果・ログ・スクリーンショットを各 RESULT ファイルに貼り付ける。
5. 判定は **PASS / FAIL / NOT TESTED / BLOCKED** のいずれか。
   **PASS は「受信側の画面に送信側の映像が実際に出た」場合のみ**（インストール成功・TCP 接続成功だけでは PASS ではない）。

## 規則

- 実施していないテストを成功として記録しない（空欄は空欄のまま）。
- ログは**送信側・受信側の両方**を保存する（タグは `LiteScreen*`。実測一覧は
  `recovery/evidence/PHASE_F_logtags_ports_verification_*.txt`）。
- 対象端末は REDMAGIC Astra（NP05J）と チャレンジパッドNext（TAB-A05-BA1）のみ。
- 元 APK ファイル（`recovery/input-apk/` の 3 本）は改変・削除・上書きしない。
