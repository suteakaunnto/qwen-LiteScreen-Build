# TEST C 結果記録（任意） — 再構築 sender ↔ 再構築 receiver（Kotlin 2.0.21 / 比較で 2.2.20）

| 項目 | 値 |
|---|---|
| テスト ID | **Test C**（任意。Test A / Test B の後に実施） |
| 目的 | 再構築版どうしで映像が通ること、および **Kotlin 2.0.21 版と 2.2.20 版の挙動差が無いこと**の確認 |
| 実施日時 | **未実施** |
| 実施者 | **未実施** |
| **現在の状態** | **NOT TESTED（BLOCKED：復旧コンテナに実機接続なし。`adb devices` 空・`/dev/bus/usb` 不在）** |
| 判定 | **NOT TESTED** ← 実施後に PASS / FAIL / BLOCKED のいずれかへ変更 |

> **優先順位は Test A → Test B → （任意）Test C。** A/B が未実施なら C のみを実施しない。
> 手順書: `docs/DEVICE_TEST_GUIDE.md` §4 / Windows の adb 準備: `docs/ADB_SETUP_WINDOWS.md`

---

## 1. 使用する APK

| 役割 | 端末 | ファイル | SHA-256（期待値） | サイズ |
|---|---|---|---|---|
| 送信（再構築・2.0.21） | Astra NP05J (API 36) | `recovery/artifacts/kotlin-2.0.21/sender-debug_kotlin2.0.21_fix8-9.apk` | `d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd` | 2,521,242 B |
| 受信（再構築・2.0.21） | TAB-A05-BA1 (API 28) | `recovery/artifacts/kotlin-2.0.21/receiver-debug_kotlin2.0.21_fix8-9.apk` | `50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408` | 2,512,149 B |
| 送信（比較用・2.2.20） | Astra | `recovery/artifacts/kotlin-2.2.20/sender-debug_kotlin2.2.20_fix8-9.apk` | `4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116` | 2,625,017 B |
| 受信（比較用・2.2.20） | TAB-A05-BA1 | `recovery/artifacts/kotlin-2.2.20/receiver-debug_kotlin2.2.20_fix8-9.apk` | `93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5` | 2,616,008 B |

- **2.2.20 版は削除も上書きもしない。** 比較のために一時的に入れる場合も、`kotlin-2.2.20/` の APK ファイル自体は触らない。
- 2.0.21 と 2.2.20 は**同じ packageName・同じ再構築証明書**なので、`adb install -r` で相互に更新できる（アンインストール不要）。

## 2. アンインストールの要否

| 状況 | アンインストール |
|---|---|
| Test A（Astra に再構築 sender）と Test B（TAB に再構築 receiver）を既に実施済み | **不要**（両端末とも再構築版が入っている） |
| Test B 後に Astra を元 sender v1.0.11 に戻していた | **必要**（`adb -s <ASTRA> uninstall jp.litescreen.sender.debug`）。記録様式は `docs/INSTALL_UNINSTALL_POLICY.md` §4 |
| Test B 後に TAB を元 receiver に戻していた | **必要**（`adb -s <TAB> uninstall jp.litescreen.receiver.debug`）。同上 |

```text
[アンインストール記録]（必要な場合のみ記入）
- 実施日時（ローカル / UTC）:
- 対象端末:
- 対象アプリ名（ラベル）:
- packageName:
- versionCode / versionName:
- 失われるデータ: 送信側 = SharedPreferences("litescreen") の設定値のみ / 受信側 = なし（永続データ無し）
- 元 APK のバックアップ場所と SHA-256:
- 実行コマンド:
- 実行結果:
- 復元予定:
```

## 3. 実施ログ

| # | 時刻 | 操作 | 結果 |
|---|---|---|---|
| C-1 | | 2.0.21 版 sender / receiver を両端末にインストール | |
| C-2 | | 受信側起動 → IP・ポート 47820 記録 | |
| C-3 | | 送信側で「受信端末を検索」→ 選択 | |
| C-4 | | 配信開始（画面収録許可「全画面」） | |
| C-5 | | **映像が出たか**（PASS 判定の本体）＋スクショ | |
| C-6 | | 停止 → 再開、回転・解像度変更 | |
| C-7 | | 2.2.20 版に入れ替えて C-2〜C-6 を繰り返し | |
| C-8 | | 2.0.21 と 2.2.20 の挙動差を比較 | |

## 4. 2.0.21 版と 2.2.20 版の比較

| 観点 | 2.0.21 | 2.2.20 | 差の有無 |
|---|---|---|---|
| 検索（discovery）で見つかるか | | | |
| 接続できるか | | | |
| **映像が出るか** | | | |
| 色・ブロックノイズ | | | |
| 受信 fps（同条件下） | | | |
| 遅延（体感・実測） | | | |
| エラーログの有無 | | | |

## 5. 添付する証拠

- [ ] `send_logcat.txt` / `recv_logcat.txt`（2.0.21 版）
- [ ] `send_logcat_2220.txt` / `recv_logcat_2220.txt`（2.2.20 版を実施した場合）
- [ ] `testC_recv_screen.png`（映像が写っている受信側画面）
- [ ] 2 台を並べた写真／動画

## 6. 最終判定

- **判定**: ☐ PASS ☐ FAIL ☐ NOT TESTED ☐ BLOCKED
- 判定の理由（映像が出たかどうかを必ず書く）:

```
（記入）
```
