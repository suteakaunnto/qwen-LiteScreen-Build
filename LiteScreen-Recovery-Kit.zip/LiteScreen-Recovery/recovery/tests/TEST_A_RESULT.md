# TEST A 結果記録 — 再構築 sender（Kotlin 2.0.21） ↔ **元** receiver v1.0.11

| 項目 | 値 |
|---|---|
| テスト ID | **Test A** |
| 目的 | 復元した**送信側**が、**元の受信側**とプロトコル互換で映像を流せるか |
| 実施日時 | **未実施** |
| 実施者 | **未実施** |
| 実施環境（PC / OS / adb version） | **未実施** |
| **現在の状態** | **NOT TESTED（BLOCKED：復旧コンテナに実機接続なし。`adb devices` 空・`/dev/bus/usb` 不在）** |
| 判定 | **NOT TESTED** ← 実施後に PASS / FAIL / BLOCKED のいずれかへ変更 |

> 根拠（実測）: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`
> 手順書: `docs/DEVICE_TEST_GUIDE.md` §2 / Windows の adb 準備: `docs/ADB_SETUP_WINDOWS.md`
> **このファイルは「実施していない」ことを示すテンプレート。未実施の項目を埋めてはならない。**

---

## 1. 使用する APK（実施前にハッシュ確認）

| 役割 | 端末 | ファイル | SHA-256（期待値） | サイズ |
|---|---|---|---|---|
| 送信（**再構築**） | REDMAGIC Astra NP05J (Android 16 / API 36) | `recovery/artifacts/kotlin-2.0.21/sender-debug_kotlin2.0.21_fix8-9.apk` | `d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd` | 2,521,242 B |
| 受信（**元・変更しない**） | チャレンジパッドNext TAB-A05-BA1 (Android 9 / API 28) | `recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk` | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` | 2,512,825 B |
| 退避（元の送信側） | — | `recovery/input-apk/litescreen-sender-v1.0.11-debug.apk` | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` | 2,521,362 B |

- 実測ハッシュ（PC 側 `certutil -hashfile ... SHA256`）: 送信再構築版 = `________________` / 元 receiver = `________________`
- 期待値と一致したか: [ ] はい / [ ] いいえ（**いいえならテストを中止して報告**）

## 2. 端末の状態（実施前に記入）

| 項目 | Astra（送信） | TAB-A05-BA1（受信） |
|---|---|---|
| `adb devices -l` のシリアル | ____________ | ____________ |
| `getprop ro.product.model` | ____________ | ____________ |
| `getprop ro.build.version.release` / `sdk` | ____ / ____ | ____ / ____ |
| Wi-Fi SSID / IP アドレス | ____________ / ____________ | ____________ / ____________ |
| テスト前の `jp.litescreen.sender.debug` versionCode | ____ | — |
| テスト前の `jp.litescreen.receiver.debug` versionCode | — | **11（元のまま。変更しない）** |

- 送信側 → 受信側への ping 結果: `________________`
- 受信側で TCP 47820 の LISTEN 確認（`netstat -an | grep 47820`）: `________________`

## 3. アンインストール記録（`docs/INSTALL_UNINSTALL_POLICY.md` §4 の様式）

**Test A でアンインストールするのは送信側（Astra）の元 sender のみ。受信側は絶対にアンインストールしない。**

```text
[アンインストール記録]
- 実施日時（ローカル / UTC）: ____ / ____
- 対象端末: REDMAGIC Astra NP05J (Android 16 / API 36)
- 対象アプリ名（ラベル）: LiteScreen 送信
- packageName: jp.litescreen.sender.debug
- versionCode / versionName: 11 / 1.0.11-debug（実施前に実測して記入）
- 署名（dumpsys の signatures 行）: ____________
- 失われるデータ: SharedPreferences("litescreen") の host / port / res_pos / fps_pos / bitrate_pos
                  ＝接続先 IP・ポート・解像度/FPS/ビットレートの選択。再入力で復旧可能。
                  個人のファイル・アカウント・認証情報は保持していない（ソース実測）。
- 退避前の設定値メモ（スクショ推奨）: host=____ port=____ res=____ fps=____ bitrate=____
- 元 APK のバックアップ場所と SHA-256: recovery/input-apk/litescreen-sender-v1.0.11-debug.apk
                                        70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4
- 実行コマンド: adb -s <ASTRA> uninstall jp.litescreen.sender.debug
- 実行結果: ____________（Success / Failure と出力そのまま）
- 復元予定: テスト後に同じ元 APK を install -r（§6）
```

## 4. 実施ログ（手順は `docs/DEVICE_TEST_GUIDE.md` §2.1 の A-1〜A-18）

| 手順 | 時刻 | 実行したコマンド／操作 | 出力・観察結果 |
|---|---|---|---|
| A-3 アンインストール | | | |
| A-4 再構築 sender インストール | | | |
| A-5 versionCode 確認 | | | |
| A-6 元 receiver 起動・IP/ポート記録 | | | |
| A-10 受信端末の検索（UDP 47821） | | | |
| A-11 配信開始・収録許可 | | | |
| A-12 **映像確認** | | | |
| A-13 証拠保存 | | | |
| A-15 停止 | | | |

## 5. チェックリスト（`docs/DEVICE_TEST_GUIDE.md` §2.2）

| 確認項目 | 結果（OK / NG / 未確認） | 備考 |
|---|---|---|
| UDP 47821 discovery で受信端末が見つかる | | |
| 手入力 IP でも接続できる | | |
| TCP 47820 に接続できる | | |
| **受信側の画面に送信側の映像が実際に出た** | | **PASS の必須条件** |
| 送信側を操作すると受信側の表示が変わる | | |
| 色がおかしくない（緑/紫ノイズなし） | | |
| 画面回転・解像度変更で追従する | | |
| 停止 → 再開ができる | | |
| 通知タップで Activity が複製されない（修正 #2） | | |
| 静止画面でビットレートが下がり続けない | | |

## 6. 復元（テスト後）

- 実行コマンド: `adb -s <ASTRA> install -r recovery\input-apk\litescreen-sender-v1.0.11-debug.apk`
- 結果: ____________
- 復元後の versionCode / versionName: ____ / ________
- 設定（host/port/res/fps/bitrate）を再入力したか: [ ] はい / [ ] いいえ

## 7. 添付する証拠

- [ ] `send_logcat.txt`（送信側 Astra）
- [ ] `recv_logcat.txt`（受信側 TAB-A05-BA1）
- [ ] `testA_recv_screen.png`（**映像が写っている受信側画面**）
- [ ] 2 台を並べた写真／動画
- [ ] 受信側アプリ内ログ（200 行）のスクリーンショット
- [ ] 症状が出た場合の操作手順と設定値

## 8. 最終判定

- **判定**: ☐ PASS ☐ FAIL ☐ NOT TESTED ☐ BLOCKED
- 判定の理由（**映像が出たかどうかを必ず書く**。インストール成功・TCP 接続成功だけでは PASS にしない）:

```
（記入）
```

- FAIL / BLOCKED の場合の症状・ログ抜粋:

```
（記入）
```
