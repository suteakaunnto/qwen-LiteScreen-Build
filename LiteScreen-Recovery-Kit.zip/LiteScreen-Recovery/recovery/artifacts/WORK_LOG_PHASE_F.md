# WORK_LOG_PHASE_F — 最終整合性修正・インストール手順修正・実機テスト準備（2026-10-30）

指示書: `uploads/LiteScreen-Recovery-Kit 最終整合性修正・インストール手順修正・実機テスト実施指示書`
対象: `LiteScreen-Recovery/`（Phase A〜E の成果一式）
原則: **既存ファイルを削除・破壊的に上書きしない**（修正前の原文は必ず退避）／**実施していないことを実施済みと書かない**

---

## 0. 結論（先に）

| 項目 | 結果 |
|---|---|
| インストール手順の矛盾 | **解消**。`docs/INSTALL_UNINSTALL_POLICY.md` を新設し、6 ファイルの旧記述を訂正（過去レポートは原文保持＋訂正注記） |
| ZIP の内容量の誤記（「474 ファイル」） | **修正**。実測は **473 ZIP エントリ＝360 通常ファイル＋113 ディレクトリエントリ**（Phase E 版 ZIP） |
| 証明書ハッシュ | **全 7 APK を再実測**してフルハッシュで記載（元 3 本＝同一鍵、再構築 4 本＝同一鍵、両者は別鍵） |
| ログタグ・ポート | **元 APK の DEX・再構築 APK の DEX・現行ソースの 3 者で再確認**（TCP 47820 / UDP 47821、タグ一致） |
| 実機テスト（Test A / B / C） | **NOT TESTED / BLOCKED**（実機接続なし。実測証拠あり）。インストール／アンインストール実行 **0 件** |
| テスト実施の準備 | **完了**。Windows の adb 手順書、Test A/B/C の手順と判定基準、結果記録テンプレートを用意 |
| 成果物 APK | **変更なし**（再ビルドしていない。Phase D/E の 4 本＋AAR 1 点をそのまま使用） |
| キット ZIP | **再生成**（旧 ZIP は検証完了まで保持し、差し替え後も evidence に退避） |

---

## 1. 環境調査（Phase 1）

実施した確認と結果:

1. **ツールチェーンの生存確認** — JDK 17.0.21 / aapt2 2.20 / apksigner 0.9 / zipalign / Gradle 8.13（`/opt/gradle/dist/gradle-8.13`）/
   Android SDK（`/opt/android-sdk`, platforms 34・36, build-tools 34・35・36）/ `/opt/tools`（apktool, jadx）→ **すべて生存**。
2. **adb の有無** — 当初 **未インストール**、`/dev/bus/usb` も**存在しない**。
   → 実機テストは原理的に不能。後に platform-tools（adb 1.0.41 / 37.0.1-15733141）を導入し、
     **`adb devices` の一覧が空であること＝接続実機 0 台**を実測して証拠化した
     （`recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`）。
3. **既存キット ZIP の検証** — 6,969,817 B、**473 エントリ（360 ファイル＋113 ディレクトリ）**、
   重複 0・絶対パス 0・`..` 参照 0・除外対象の漏れ込み 0・`testzip()` 異常なし・
   必須バイナリ 8 点のサイズ一致・展開後合計 20,693,345 B。
4. **矛盾箇所の洗い出し（grep）** — 「アンインストールせずに残す」系: `README.md`, `CHECKPOINT.md`（3 箇所）,
   `docs/DEVICE_TEST_GUIDE.md`, `docs/SIGNING_GUIDE.md`, `recovery/reports/PHASE_D_BUILD_VERIFICATION.md`（2 箇所）。
   「473 / 474」系: **誤記は `CHECKPOINT.md` の「474 ファイル」1 箇所のみ**（他の "473" はすべてハッシュ文字列の一部で、
   置換してはいけない）。`RESTORATION_GUIDE.md` は**存在しない**（指示書の想定ファイルは無し）。
5. **元 APK の保全確認** — `sha256sum -c` で 3 本とも OK、`chmod 444` 維持。
6. **APK 属性の再実測** — `aapt2 dump badging`（元 3 本＋再構築 4 本）と `apksigner verify --print-certs`（同 7 本）。

---

## 2. インストール手順の矛盾修正（Phase 2）

### 2.1 矛盾の中身

| 記述 | 正誤 |
|---|---|
| 「再構築 APK は元アプリへの上書き更新ができない（`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）」 | **正しい** |
| 「既存の元アプリはアンインストールせずに残す」 | **このままでは実機テストが不能**（同一 packageName は並存もできないため、再構築版を永久にインストールできない） |
| 「別アプリとして並存インストールになる」 | **誤り**（packageName 同一なので並存不可） |
| 「アンインストールすると受信側の実行時状態（保存設定など）は失われる」 | **不正確**（永続データを持つのは**送信側**。受信側に永続データは無い＝ソース実測） |

### 2.2 確定した方針（`docs/INSTALL_UNINSTALL_POLICY.md`）

1. **元 APK「ファイル」は必ず保存**（`recovery/input-apk/` chmod 444 ＋ SHA-256、キット ZIP 内にも複製。改変・削除・上書きなし）。
2. **同一 packageName の再構築版を入れるには端末上の元アプリのアンインストールが必要**。
   「ファイルの保存」と「インストール済みアプリの維持」は**別問題**。
3. アンインストールは**ユーザー承認済み**（条件＝元 APK が安全に保存されていること → **満たしている**）。
4. 実行前に**記録**（対象端末／アプリ／packageName／versionCode／署名／失われるデータ／バックアップの SHA-256／実行コマンド／結果／復元予定）。
5. テスト後は元 APK を `adb install -r` で**復元**し、versionCode とハッシュを確認。
6. **Test A では受信側をアンインストールしない**（元 receiver を使う試験のため）。
7. 対象端末は Astra（NP05J）と TAB-A05-BA1 のみ。

### 2.3 修正したファイル（**修正前の原文は `recovery/evidence/PHASE_F_docs_before_*/` に退避**）

| ファイル | 修正内容 |
|---|---|
| `docs/INSTALL_UNINSTALL_POLICY.md` | **新設**（確定方針・実測値・記録様式・復元手順・テスト別マトリクス・旧記述の訂正対応表） |
| `docs/DEVICE_TEST_GUIDE.md` | **全面改訂**（Test A / B / C の手順、PASS 判定基準、アンインストールの扱い、Windows コマンド） |
| `docs/ADB_SETUP_WINDOWS.md` | **新設**（Windows の adb 準備・ドライバ・無線 adb・LAN/ポート確認・コマンド集・エラー対処） |
| `README.md` | §2 のディレクトリ構成に新規ファイルを追加、§6「インストールと運用上の注意」を確定方針に沿って書き直し（4 項目 → 6 項目） |
| `CHECKPOINT.md` | §4.8 の署名証明書の項に訂正注記（証明書値・v2 のみ・並存不可）、Phase D 手順内の指示引用に注記、§8-5 の「アンインストールしない」を訂正、「474 ファイル」を修正、**Phase F 章を追記** |
| `docs/SIGNING_GUIDE.md` | §1 の証明書表をフルハッシュ（SHA-256 / SHA-1）で再掲、「アンインストールせずに残す」を確定方針に訂正、v1.0.10 / v1.0.11 の関係を明記 |
| `docs/KNOWN_ISSUES.md` | §C（未確認）に Test A/B/C と「インストール実行 0 件」を追加、**§E（ドキュメント整合性の問題 E-1〜E-9）を新設** |
| `recovery/reports/PHASE_D_BUILD_VERIFICATION.md` | **原文は改変せず**、冒頭・§0 サマリ・§3.2 に【Phase F 訂正】注記を追記。§3.2 に全 7 APK の再実測表（SHA-256 / SHA-1 / signer 数 / v1・v2）を追加 |
| `recovery/artifacts/CURRENT_ARTIFACTS.md` | 元 APK の表をフルハッシュ化、**Phase F 章を追加**（新規ファイル一覧と実機テスト状況） |
| `recovery/tests/`（新規ディレクトリ） | `README.md` ＋ `TEST_A_RESULT.md` / `TEST_B_RESULT.md` / `TEST_C_RESULT.md`（すべて **NOT TESTED** のテンプレート） |
| `scripts/32_build_kit_zip.sh` | **新設**（キット ZIP の再生成と 8 項目の自動検証、`--commit` で退避してから差し替え） |

---

## 3. ZIP の内容量の誤記修正（Phase 3）

- 誤記: `CHECKPOINT.md` の「配布用アーカイブ（約 7.0 MB / **474 ファイル**）」。
- 実測（Phase E 版 ZIP）: **473 ZIP エントリ = 360 通常ファイル + 113 ディレクトリエントリ**。
  → 「ファイル数」ではなく「**ZIP エントリ数**」であり、内訳を併記する形に修正した。
- **他の "473" はすべて SHA-256 ハッシュ文字列の一部**（例: `…36c2537cbca03473`）なので、機械的な置換は行っていない。
  grep で 1 件ずつ確認し、**内容量の記述として使われていたのは 1 箇所だけ**であることを確かめた上で修正した。
- 数え方の注意（`docs/KNOWN_ISSUES.md` §E-9 に記載）: **ZIP エントリ数 ≠ プロジェクトのファイル数 ≠ ソースのファイル数**。
  ディレクトリエントリを含むため必ず内訳を書く。ハッシュは「ZIP 全体」と「内部ファイル」を区別し、
  ZIP 自身のハッシュは ZIP の外（`KIT_SHA256.txt`）に置く（自己参照を避けるため）。
- Phase F で再生成した ZIP の実測内訳は `recovery/artifacts/KIT_INTEGRITY.md` に記載。

---

## 4. 実機テスト（Phase 5）— **実施していない**

| 項目 | 状態 | 根拠 |
|---|---|---|
| Test A（再構築 sender 2.0.21 ↔ 元 receiver v1.0.11） | **NOT TESTED / BLOCKED** | `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt` |
| Test B（元 sender v1.0.11 ↔ 再構築 receiver 2.0.21） | **NOT TESTED / BLOCKED** | 同上 |
| Test C（再構築同士、2.0.21 / 2.2.20 の比較） | **NOT TESTED / BLOCKED** | 同上 |
| インストール実行 | **0 件** | 実機なし |
| アンインストール実行 | **0 件**（記録様式のみ整備） | 実機なし |
| logcat の取得 | **0 件** | 実機なし |

- BLOCKED の実測根拠: `/dev/bus/usb` が存在しない（`ls: cannot access`）、`adb devices -l` の
  `List of devices attached` の下が空、接続デバイス数 **0**。adb 自体は正常動作（1.0.41 / 37.0.1-15733141）。
- **テスト用のログや端末情報を捏造していない。** テンプレートは空欄のまま（`recovery/tests/`）。
- ユーザー側で実施するための一式は揃えてある:
  `docs/ADB_SETUP_WINDOWS.md`（準備）→ `docs/DEVICE_TEST_GUIDE.md`（Test A → B → C の手順と PASS 判定）→
  `recovery/tests/TEST_*_RESULT.md`（記録）。
- テスト前に再確認した値（**過去レポートの転記ではなく実測**）:
  - ポート: TCP **47820** / UDP **47821**（`LiteScreen-Recovered/protocol/src/main/java/jp/litescreen/protocol/Proto.kt` L58-59。
    元 APK の DEX にも PROBE 文字列 `LITESCREEN?` と `tcpPort` を確認）
  - ログタグ: 受信 `LiteScreen`, `LiteScreen.Decoder`, `LiteScreen.Caps`, `LiteScreen.Net`, `LiteScreen.Discovery` /
    送信 `LiteScreen`, `LiteScreen.Capture`, `LiteScreen.Sender`, `LiteScreen.Service`, `LiteScreen.Activity`,
    `LiteScreen.NetInfo`, `LiteScreen.Discovery`（**元 APK 3 本・再構築 APK 4 本・現行ソースの 3 者で一致**）
  - 最初に使うビルド: **Kotlin 2.0.21 版**（2.2.20 版は削除も上書きもしていない）
  - Test B の基準: **元 sender v1.0.11**（v1.0.10 は packageName 同一・versionCode 違いの別物。使う場合は `-r -d` と別記が必要）

---

## 5. キット ZIP の再生成（Phase 4）

手順（**古い ZIP を消してから作らない**）:

1. 修正前のドキュメントと旧 ZIP を `recovery/evidence/PHASE_F_docs_before_*/` に退避（`BACKUP_NOTE.md` 付き）。
2. `scripts/32_build_kit_zip.sh` で**一時名**（`LiteScreen-Recovery-Kit.new.zip`）に生成。
3. 同スクリプト内の検証（8 項目）に合格することを確認:
   ① `testzip()` 破損なし ② 重複エントリなし ③ 絶対パス・`..` なし ④ 除外対象の漏れ込みなし・自己参照なし
   ⑤ 必須バイナリ 8 点のサイズと SHA-256 一致 ⑥ 主要ドキュメント/Wrapper/スクリプトの存在
   ⑦ ディスク実体との突合（取りこぼし・余分 0 件） ⑧ 旧 ZIP との増減内訳（削除 0 件）。
4. 合格後に `--commit` で差し替え（旧 ZIP は `recovery/evidence/PHASE_F_superseded_zip_*/` へ退避して**残す**）。
5. ZIP の外に `KIT_SHA256.txt`（新 ZIP の sha256 / サイズ / 生成時刻）を書き出す。

除外リスト（`scripts/32_build_kit_zip.sh` に明記）: `recovery/decompiled/`（78 MB・再生成可能）、
`*/build/`, `*/.gradle/`, `*/.kotlin/`, `local.properties`, `out/`, `dist/`, `target/`, `node_modules/`, `__pycache__/`,
`recovery/artifacts/LiteScreen-Recovery-Kit*.zip`（自己参照防止）, `recovery/artifacts/KIT_SHA256.txt`（ZIP 生成後に算出）,
`recovery/evidence/PHASE_F_docs_before_*/artifacts/*.zip`（旧 ZIP の複製＝自己参照になるため。ファイル自体はワークスペースに残る）。

**含めているもの**: 元 APK 3 本、再構築 APK 4 本＋AAR 1 点、`LiteScreen-Recovered/` のソース・リソース・
Gradle Wrapper（`gradlew`, `gradlew.bat`, `gradle-wrapper.jar/.properties`）、`docs/` 全 7 本、`scripts/` 全 19 本（＋ `scripts/difftest/`）、
`recovery/evidence/`・`recovery/reports/`・`recovery/tests/`・`recovery/build-check/`・`recovery/difftest/`、
`README.md`・`CHECKPOINT.md`・`SHA256SUMS.txt`・`APK_BUILD_LOG.md`・`CURRENT_ARTIFACTS.md`・`KIT_INTEGRITY.md`・本ファイル。

---

## 6. 実施していないこと（明示）

- **実機テスト（Test A / B / C）**: 未実施（実機接続なし）。
- **端末へのインストール／アンインストール**: 0 件。
- **logcat の取得**: 0 件。
- **成果物 APK の再ビルド**: していない（Phase D/E の成果物をそのまま使用。ハッシュ不変）。
- **元 APK の改変**: なし（作業前後で SHA-256 一致、chmod 444 維持）。
- **既存ファイルの削除**: なし（旧 ZIP・修正前ドキュメントはすべて退避して保持）。
- **Kotlin 2.2.20 版の削除・上書き**: なし。
