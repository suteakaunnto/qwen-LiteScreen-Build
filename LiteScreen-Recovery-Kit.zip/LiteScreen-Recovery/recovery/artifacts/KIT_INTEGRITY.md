# KIT_INTEGRITY — 配布用キット ZIP の実測内訳と検証結果

作成: 2026-10-30（Phase F） / 検証方法: `bash scripts/32_build_kit_zip.sh`（生成＋8 項目の自動検証）

> **数え方の注意**: 「ZIP エントリ数」≠「ファイル数」≠「プロジェクトのソース数」。
> ZIP には**ディレクトリエントリ**も含まれるため、必ず内訳を書く。
> 旧ドキュメントにあった「474 ファイル」はこの混同による誤記（実測は **473 ZIP エントリ＝360 ファイル＋113 ディレクトリ**）。

---

## 1. Phase F で再生成した ZIP（現行）

`recovery/artifacts/LiteScreen-Recovery-Kit.zip`

| 項目 | 実測値 |
|---|---|
| **ZIP エントリ総数** | **503** |
| ├ 通常ファイル | **385** |
| └ ディレクトリエントリ | **118** |
| 重複エントリ | 0 |
| 絶対パス / `..` を含むエントリ | 0 / 0 |
| `testzip()`（全エントリの CRC 検証） | 異常なし |
| 除外対象の漏れ込み（`build/`, `.gradle/`, `.kotlin/`, `decompiled/`, `local.properties`, `out/`, `dist/`, `target/`, `node_modules/`, `__pycache__/`） | 0 |
| 自己参照（ZIP 自身・`KIT_SHA256.txt`） | 0（含まない設計） |
| ディスク実体との突合 | 取りこぼし **0** 件・余分 **0** 件 |
| 必須バイナリ 8 点（元 APK 3 ＋ 再構築 APK 4 ＋ AAR 1） | すべて存在・**サイズと SHA-256 が一致** |
| 主要ドキュメント / Gradle Wrapper / スクリプト 26 点 | すべて存在 |
| ZIP のバイト数・展開後合計・**SHA-256** | **`recovery/artifacts/KIT_SHA256.txt` に記載**（ZIP の外。自己参照を避けるため ZIP 生成後に算出） |

### 1.1 旧 ZIP（Phase E 版）との比較

| | Phase E 版（旧） | Phase F 版（現行） |
|---|---|---|
| ZIP エントリ | 473 | **503** |
| 通常ファイル | 360 | **385**（+25） |
| ディレクトリエントリ | 113 | **118**（+5） |
| 削除されたエントリ | — | **0 件**（既存の内容は一切削除していない） |
| 追加されたエントリ | — | **30 件**（内訳は §1.2） |

旧 ZIP の実測値: 6,969,817 B / sha256 `9d61409a37073811cd4a615b498d4bbe80e1805da98d11b384e1a6d05a2983c9` /
473 エントリ（360 ファイル＋113 ディレクトリ）/ 展開後合計 20,693,345 B。
**旧 ZIP は削除していない**: `recovery/evidence/PHASE_F_docs_before_*/artifacts/LiteScreen-Recovery-Kit_prePhaseF.zip` と
`recovery/evidence/PHASE_F_superseded_zip_*/` に退避してある（新しい ZIP の検証が完了するまで本番も差し替えていない）。

### 1.2 追加された 30 エントリの内訳

| 区分 | 追加 |
|---|---|
| 新規ドキュメント | `docs/INSTALL_UNINSTALL_POLICY.md`, `docs/ADB_SETUP_WINDOWS.md` |
| 新規スクリプト | `scripts/32_build_kit_zip.sh`, `scripts/33_gen_sha256sums.sh` |
| 新規記録 | `recovery/artifacts/KIT_INTEGRITY.md`, `recovery/artifacts/WORK_LOG_PHASE_F.md` |
| 実機テスト記録欄 | `recovery/tests/`（ディレクトリ＋`README.md`, `TEST_A_RESULT.md`, `TEST_B_RESULT.md`, `TEST_C_RESULT.md`） |
| 新規証拠 | `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`（実機 0 台の実測）, `recovery/evidence/PHASE_F_logtags_ports_verification_*.txt`（タグ/ポートの実測） |
| 修正前の退避 | `recovery/evidence/PHASE_F_docs_before_*/`（ディレクトリ 4 ＋ ファイル 10。旧 ZIP の複製 `*.zip` は自己参照になるため**除外**し、ワークスペース側にのみ保持） |

**追加 30 件の内訳（実測）**: ディレクトリエントリ **5**（`recovery/tests/`、
`recovery/evidence/PHASE_F_docs_before_*/` とその `artifacts/`・`docs/`・`reports/`）＋ 通常ファイル **25**
（`docs/INSTALL_UNINSTALL_POLICY.md`, `docs/ADB_SETUP_WINDOWS.md`, `recovery/artifacts/KIT_INTEGRITY.md`,
`recovery/artifacts/WORK_LOG_PHASE_F.md`, `recovery/tests/{README,TEST_A_RESULT,TEST_B_RESULT,TEST_C_RESULT}.md`,
`recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`, `recovery/evidence/PHASE_F_logtags_ports_verification_*.txt`,
`scripts/32_build_kit_zip.sh`, `scripts/33_gen_sha256sums.sh`, 退避した修正前ドキュメント 10 点）。
**削除は 0 件**（既存の内容は一切失っていない）。
> 生成時の検証ログ（`recovery/evidence/PHASE_F_kit_zip_build_*.log`）と、退避した旧 ZIP
> （`PHASE_F_docs_before_*/artifacts/LiteScreen-Recovery-Kit_prePhaseF.zip`、`PHASE_F_superseded_zip_*/`）は
> **ZIP の外**に置く（自己参照と肥大化を避けるため。`KIT_SHA256.txt` と同じ扱い）。
> **いずれも削除せずワークスペースに保持している。**

### 1.3 内容が変化したファイル（Phase E 版 → Phase F 版、実測 8 件）

| ファイル | 変更の理由 |
|---|---|
| `README.md` | §2 の構成に新規ドキュメントを追加、§6「インストールと運用上の注意」を確定方針に書き直し、§8（実機テストの状況）・§9（キット ZIP）を追加 |
| `CHECKPOINT.md` | §4.8 の署名証明書の項に訂正注記、Phase D 手順の引用部に注記、§8-4 の ZIP 表記を訂正、§8-5 の「アンインストールしない」を訂正、**§9（Phase F 完了記録）を追記** |
| `SHA256SUMS.txt` | `scripts/33_gen_sha256sums.sh` でフル再生成（38 → **384 件**。新規ファイルを追加し、変更されたドキュメントのハッシュを更新＝**古い値を残さない**） |
| `docs/DEVICE_TEST_GUIDE.md` | 全面改訂（Test A / B / C の手順、PASS 判定基準、アンインストールの扱い、Windows コマンド） |
| `docs/SIGNING_GUIDE.md` | §1 の証明書表をフルハッシュ化（SHA-256 / SHA-1）、「アンインストールせずに残す」を確定方針に訂正、v1.0.10 / v1.0.11 の関係を明記 |
| `docs/KNOWN_ISSUES.md` | §C（未確認）に Test A/B/C と「インストール実行 0 件」を追加、**§E（ドキュメント整合性の問題 E-1〜E-9）を新設** |
| `recovery/artifacts/CURRENT_ARTIFACTS.md` | 元 APK の表をフルハッシュ化、Phase F 章（新規ファイル一覧と実機テスト状況）を追加 |
| `recovery/reports/PHASE_D_BUILD_VERIFICATION.md` | **原文は改変せず**、冒頭・§0 サマリ・§3.2 に【Phase F 訂正】注記を追記（§3.2 に全 7 APK の再実測表を追加） |

> **成果物 APK（元 3 本・再構築 4 本・AAR 1 点）は 1 バイトも変更していない**（Phase F では再ビルドしていない）。
> 検証: ZIP 内から取り出して SHA-256 を照合 → 8 点すべて一致（`scripts/32_build_kit_zip.sh` の項目 ⑤）。

---

## 2. 除外リスト（`scripts/32_build_kit_zip.sh` に明記）

| 除外 | 理由 |
|---|---|
| `recovery/decompiled/`（78 MB） | 元 APK の apktool / jadx 展開物。`scripts/02_decompile_all.sh` で再生成可能。キットを軽くするため |
| `*/build/`, `*/.gradle/`, `*/.kotlin/`, `local.properties` | ビルドキャッシュ・環境固有設定（配布物ではない。ワークスペースのスナップショット対象外でもある） |
| `*/out/`, `*/dist/`, `*/target/`, `*/node_modules/`, `*/__pycache__/` | 同上（成果物の唯一のコピーをこれらの名前のディレクトリに置かない方針） |
| `recovery/artifacts/LiteScreen-Recovery-Kit*.zip` | **自己参照**になるため |
| `recovery/artifacts/KIT_SHA256.txt` | ZIP のハッシュは ZIP 生成後にしか確定しない（自己参照回避）。ZIP の外に置く |
| `recovery/evidence/PHASE_F_docs_before_*/artifacts/*.zip`（旧 ZIP の複製）, `recovery/evidence/PHASE_F_superseded_zip_*/`（差し替えで退避した ZIP 一式）, `recovery/evidence/*kit_zip_build*.log`（ビルドログ） | いずれも**自己参照または ZIP 生成後に確定する内容**のため。旧 ZIP・ビルドログは**削除せずワークスペースに保持**する（キットに再同梱すると 7 MB ずつ肥大化し、再生成のたびに増える） |

**含めているもの**: 元 APK 3 本、再構築 APK 4 本＋AAR 1 点、`LiteScreen-Recovered/` のソース・リソース・
Gradle Wrapper（`gradlew` / `gradlew.bat` / `gradle-wrapper.jar` / `gradle-wrapper.properties`）、
`docs/` 全 7 本、`scripts/` 全 20 本、`recovery/evidence/`・`recovery/reports/`・`recovery/tests/`・
`recovery/build-check/`・`recovery/difftest/`、`README.md`・`CHECKPOINT.md`・`SHA256SUMS.txt`・
`APK_BUILD_LOG.md`・`CURRENT_ARTIFACTS.md`・`KIT_INTEGRITY.md`・`WORK_LOG_PHASE_F.md`。

---

## 3. 検証（`scripts/32_build_kit_zip.sh` が自動実施する 8 項目）

1. `testzip()` による全エントリの CRC 検証（破損なし）
2. エントリ内訳の計測（総数 / 通常ファイル / ディレクトリ）と展開後サイズの合計
3. 重複エントリ・絶対パス・`..` を含むパスの検出（いずれも 0 でなければならない）
4. 除外対象の漏れ込みと自己参照エントリの検出（0 でなければならない）
5. **必須バイナリ 8 点のサイズと SHA-256 の照合**（元 APK 3 本＝改変されていないこと、再構築 APK 4 本＋AAR＝正式成果物であること）
6. 主要ドキュメント 26 点（README / CHECKPOINT / docs 7 本 / tests 4 本 / artifacts 記録 / Gradle Wrapper / 元 APK の SHA256SUMS / reports 3 本 / script 32）の存在確認
7. **ディスク実体との突合**（除外ルールを適用した後の全ファイルを走査し、ZIP の取りこぼし・余分を検出）
8. **旧 ZIP との増減比較**（削除 0 件であること＝既存の成果物を失っていないことの確認）

1 つでも失敗すると exit 1 になり、`--commit`（本番差し替え）は行われない。
**手順は「一時名で生成 → 検証 → 合格後に旧 ZIP を退避して差し替え」**（古い ZIP を消してから作らない）。

### 3.1 ⚠ ZIP はビット単位では再現しない（ハッシュの扱い）

同じファイル集合から再生成しても、**ZIP の SHA-256 は一致しない**（実測済み）。理由は
①`zip -r` のエントリ順がディレクトリの走査順に依存する、②エントリに各ファイルの更新日時が記録される、ため。
したがって:

- **`KIT_SHA256.txt` のハッシュは「生成されたこの ZIP ファイル」の識別子**であり、再ビルド結果の期待値ではない。
- 中身の同一性を確かめたいときは **ZIP のハッシュではなく、内部ファイルのハッシュ一覧（`SHA256SUMS.txt`）と
  エントリ内訳（数・ファイル数・ディレクトリ数）で照合する**。`scripts/32_build_kit_zip.sh` の検証がこれを行う
  （項目 ⑤⑦⑧: 必須バイナリ 8 点の SHA-256、ディスク実体との突合、旧 ZIP との増減）。
- **成果物 APK / AAR は clean ビルドで再現する**（`APK_BUILD_LOG.md`・`CURRENT_ARTIFACTS.md` の「ビルド再現性」参照。
  ただし debug 署名は環境ごとに変わるため APK 全体のハッシュは環境依存）。

---

## 4. 検証コマンド（ユーザー側での確認方法）

```bash
cd LiteScreen-Recovery

# 内部ファイルのハッシュ照合（SHA256SUMS.txt 自身と ZIP・KIT_SHA256.txt は対象外）
sha256sum -c SHA256SUMS.txt

# 元 APK 3 本の照合（別リスト）
cd recovery/input-apk && sha256sum -c SHA256SUMS.txt && cd ../..

# 成果物ディレクトリごとの照合
cd recovery/artifacts/kotlin-2.0.21 && sha256sum -c SHA256SUMS.txt && cd ../../..
cd recovery/artifacts/kotlin-2.2.20 && sha256sum -c SHA256SUMS.txt && cd ../../..

# ZIP の健全性とハッシュ（Windows は certutil）
unzip -t recovery/artifacts/LiteScreen-Recovery-Kit.zip
sha256sum recovery/artifacts/LiteScreen-Recovery-Kit.zip
cat recovery/artifacts/KIT_SHA256.txt        # ← 期待値（ZIP の外に記録）
certutil -hashfile recovery\artifacts\LiteScreen-Recovery-Kit.zip SHA256

# エントリ数の内訳を数え直す（ディレクトリエントリは末尾が / ）
python3 - <<'PY'
import zipfile
z = zipfile.ZipFile('recovery/artifacts/LiteScreen-Recovery-Kit.zip')
n = [i.filename for i in z.infolist()]
print('entries', len(n), 'files', sum(1 for x in n if not x.endswith('/')), 'dirs', sum(1 for x in n if x.endswith('/')))
print('testzip:', z.testzip())
PY
```

- **ハッシュの区別**: `SHA256SUMS.txt`（および `recovery/*/SHA256SUMS.txt`）は**内部ファイルのハッシュ**。
  `KIT_SHA256.txt` は **ZIP 全体のハッシュ**。両者を混同しないこと。
  ZIP 全体のハッシュは ZIP の中身を変えるたびに変わり、**ZIP 自身には含められない**。
