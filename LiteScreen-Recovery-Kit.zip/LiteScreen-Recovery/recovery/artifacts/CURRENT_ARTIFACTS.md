# 現在有効な成果物（Phase D 完了・環境再構築後 / 2026-10-29 23:00、**Phase F 更新 / 2026-10-30**）

**このディレクトリ（`recovery/artifacts/`）が成果物の正式な置き場所。**
以前の置き場所 `out/phase-d/` は **ワークスペースのスナップショット対象外**（`out`, `build`, `dist` などの名前は無視される）
だったため、コンテナ再生成時に消失した。以後この名前を使わないこと。

ビルドの全履歴: `APK_BUILD_LOG.md`（row 1〜22 + 失敗 1 件）。

## 正式成果物（修正 #1〜#9 すべて反映・clean ビルド・exit 0）

### Kotlin 2.2.20（プロジェクトの既定値）→ `kotlin-2.2.20/`
| ファイル | サイズ(B) | sha256 | 台帳 |
|---|---|---|---|
| `protocol-debug_fix8-9.aar` | 5,786 | `ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25` | row 18（row 9/15 と**バイト一致**） |
| `receiver-debug_kotlin2.2.20_fix8-9.apk` | 2,616,008 | `93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5` | row 19 |
| `sender-debug_kotlin2.2.20_fix8-9.apk` | 2,625,017 | `4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116` | row 20 |

### Kotlin 2.0.21（元 APK と同じ版・忠実再現/実機検証の第一候補）→ `kotlin-2.0.21/`
| ファイル | サイズ(B) | sha256 | 台帳 | 元 APK との差 |
|---|---|---|---|---|
| `receiver-debug_kotlin2.0.21_fix8-9.apk` | 2,512,149 | `50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408` | row 21 | **−676 B** |
| `sender-debug_kotlin2.0.21_fix8-9.apk` | 2,521,242 | `d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd` | row 22 | **−120 B** |

各ディレクトリの `SHA256SUMS.txt` は `sha256sum -c` で検証可能。

## 元 APK（`recovery/input-apk/`, chmod 444, 変更禁止・**2026-10-30 にハッシュ再検証済み＝全 OK**）

| ファイル | サイズ(B) | sha256 |
|---|---|---|
| `litescreen-receiver-v1.0.11-debug.apk` | 2,512,825 | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` |
| `litescreen-sender-v1.0.11-debug.apk` | 2,521,362 | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` |
| `litescreen-sender-v1.0.10-debug.apk` | 2,518,766 | `b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc` |

- 3 本とも証明書は同一（SHA-256 `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf`）。
- **sender v1.0.10 と v1.0.11 は packageName が同じ `jp.litescreen.sender.debug` で versionCode だけ違う（10 / 11）別物。**
  同一視しないこと（`docs/INSTALL_UNINSTALL_POLICY.md` §2.1 / §3.3）。
- 再構築 APK 4 本の証明書は SHA-256 `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847`
  （2026-10-30 に `apksigner verify --print-certs` で実測。旧環境ビルドは `7a1fd7bb…27bd`）

## 環境消失（2026-10-29 22:30 頃）と内容の復元証明

コンテナ再生成により `out/` 配下の成果物とビルドキャッシュ（`*/build/`）、および
ツールチェーン（JDK / Android SDK / Gradle）が失われた。**ソース・evidence・元 APK・レポートは無傷**。

再導入後に再ビルドし、**消失前の成果物と内容が同一であることをエントリ単位ハッシュで証明した**
（証拠: `recovery/evidence/PHASE_D_zip_entries_*.txt` に消失前の全エントリ sha256 が残っていた）:

| 比較 | 結果 |
|---|---|
| receiver 2.2.20（row 19 vs row 16） | 41 エントリすべて**バイト一致**（相違 0） |
| sender 2.2.20（row 20 vs row 17） | 54 エントリすべて**バイト一致**（相違 0） |
| receiver 2.0.21（row 21 vs row 14） | 40/40 エントリ**バイト一致**（相違 0） |
| sender 2.0.21（row 22 vs row 8） | 53/53 エントリ**バイト一致**（相違 0） |
| protocol AAR（row 18 vs row 9/15） | **ファイル全体がバイト一致**（署名を含まないため） |

APK 全体の sha256 が変わるのは **debug keystore が環境ごとに自動生成されるため（署名ブロックのみ差）**。
sender 2.0.21 のサイズが −1,004 B なのも署名ブロック/パディングの差で、**dex・res・manifest は完全に同一**。

## ビルド再現性（重要な確認結果）
- 同一環境内での clean ビルド 2 回 → ソース未変更モジュールは**バイト一致**（protocol AAR, sender APK）。
- **環境を作り直した後でも** protocol AAR は**バイト一致**（row 9 = 15 = 18）。
- APK は署名鍵に依存するため全体ハッシュは変わるが、**署名以外の全エントリは一致**（上表）。
→ 復元プロジェクトのビルドは再現可能。

## ⚠ ビルド時の注意（実測に基づく）
1. **必ず clean ビルドを使う**。インクリメンタルだと zip パディングが増え、内容差 28 B に対して +96 KB 大きくなることがある（row 13）。
2. **RAM 1 GB 環境では一括ビルドが OOM する**（row — の失敗例）。
   `:module:compileDebugKotlin` → `:module:assembleDebug` の**2 段階に分ける**と成功する。
   `gradle.properties` の JVM 設定（`-Xmx384m -XX:MaxMetaspaceSize=224m …`）を変更しないこと。
3. Kotlin 版を切り替えたら**必ず clean**（`scripts/31_switch_kotlin_version.sh <ver> --build` が自動で行う）。


---

## Phase F（2026-10-30）で追加・更新したもの

| 種別 | パス | 内容 |
|---|---|---|
| **新規ドキュメント** | `docs/INSTALL_UNINSTALL_POLICY.md` | 元 APK ファイルの保存とアンインストールの**確定方針**（旧ドキュメントの矛盾を解消）。証明書実測値、失われるデータの実測、記録様式、復元手順、テスト別マトリクス、旧記述の訂正対応表 |
| **新規ドキュメント** | `docs/ADB_SETUP_WINDOWS.md` | Windows での adb 導入・ドライバ・無線 adb・LAN/ポート確認・インストール/アンインストール/logcat コマンド集・エラー別対処 |
| **全面改訂** | `docs/DEVICE_TEST_GUIDE.md` | **Test A / Test B / Test C** の手順を表形式で明文化（アンインストール記録 → インストール → 検索 → 配信 → 映像確認 → 証拠保存 → 復元）。**PASS 判定基準**（映像が実際に出たこと）を追加 |
| **新規（記録欄）** | `recovery/tests/README.md`, `TEST_A_RESULT.md`, `TEST_B_RESULT.md`, `TEST_C_RESULT.md` | 実機テストの結果記録テンプレート。**現状は 3 件とも NOT TESTED / BLOCKED** |
| **新規スクリプト** | `scripts/32_build_kit_zip.sh` | キット ZIP の再生成と**整合性検証**（破損・重複・絶対パス・除外漏れ・必須バイナリ 8 点のハッシュ・主要ファイルの存在・ディスク実体との突合・旧 ZIP との増減）。`--commit` で旧 ZIP を evidence に退避してから差し替え |
| **新規証拠** | `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt` | adb 1.0.41 は動作するが `/dev/bus/usb` が無く `adb devices` が空＝**接続実機 0 台**の実測記録（テスト不能の根拠） |
| **新規証拠** | `recovery/evidence/PHASE_F_logtags_ports_verification_*.txt` | 元 APK 3 本・再構築 APK 4 本の DEX と現行ソースから**ログタグとポートを再実測**した記録（TCP 47820 / UDP 47821、タグは受信 5 種・送信 7 種で元＝再構築が一致） |
| **新規証拠** | `recovery/evidence/PHASE_F_docs_before_*/` | Phase F で修正する前のドキュメント群と旧 ZIP の退避（**既存ファイルを破壊的に上書きしない**ため） |
| **新規記録** | `recovery/artifacts/KIT_INTEGRITY.md` | キット ZIP の実測内訳（エントリ数・ファイル数・ディレクトリ数・サイズ・検証結果）と除外リスト |
| **新規記録** | `recovery/artifacts/WORK_LOG_PHASE_F.md` | Phase F の作業ログ（実施したこと／していないこと） |
| **訂正** | `README.md` §6, `CHECKPOINT.md` §4.8・§8-5・Phase F 章, `docs/SIGNING_GUIDE.md` §1, `docs/KNOWN_ISSUES.md` §C・§E, `recovery/reports/PHASE_D_BUILD_VERIFICATION.md` 冒頭・§0・§3.2 | インストール手順の矛盾解消、証明書値の更新（フルハッシュ）、「474 ファイル」→「473 ZIP エントリ（360 ファイル＋113 ディレクトリ）」の修正ほか |

### Phase F 時点の実機テスト状況（**重要**）

| テスト | 状態 |
|---|---|
| Test A（再構築 sender 2.0.21 ↔ 元 receiver） | **NOT TESTED / BLOCKED** |
| Test B（元 sender v1.0.11 ↔ 再構築 receiver 2.0.21） | **NOT TESTED / BLOCKED** |
| Test C（再構築同士） | **NOT TESTED / BLOCKED** |
| 端末へのインストール／アンインストール実行 | **0 件** |

根拠: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`（実機接続なし）。
**成果物（APK）は Phase D/E から変更していない**（再ビルドしていない。ハッシュは上表のとおり不変）。
Phase F で行ったのはドキュメント整合性の修正・手順書の整備・キット ZIP の再生成のみ。
