# ビルド成果物ログ（追記専用）

再構築 APK は **元 APK と同一ではない**（署名鍵が異なるため上書き更新不可）。
すべてのビルドを時系列で記録する。ハッシュは sha256。

> **⚠ 2026-10-29 22:30 頃の環境消失について**
> 作業用コンテナが再生成され、`out/`（**スナップショット対象外のディレクトリ名**）配下に保存していた
> 成果物 APK/AAR・apktool 展開物・この台帳のファイル実体が失われた。
> **ソース・evidence（`recovery/evidence/`）・元 APK・CHECKPOINT・各レポートは無傷**。
> その後ツールチェーン（JDK17 / Android SDK 34・35・36 / Gradle 8.13）を再導入して**再ビルドし、
> 全エントリのバイト一致を確認して内容を復元した**（row 18 以降）。
> 以後、成果物は `recovery/artifacts/` に保存する（`out/`, `build/`, `dist/` は保存対象外なので使わない）。

| # | 日時 | Kotlin | モジュール | 状態 | サイズ(B) | sha256 | 備考 |
|---|---|---|---|---|---|---|---|
| 1 | 2026-10-29 16:09 | 2.2.20 | receiver | BUILD SUCCESSFUL (exit 0) | 2616104 | 284440de5fc92dcb881e8311dfd17d382b09b34a8e4bc3f6a1a909e8f1e80c9d | res=mipmap-anydpi-v21 に修正後（成果物消失） |
| 2 | 2026-10-29 16:15 | 2.2.20 | sender | BUILD SUCCESSFUL (exit 0) | 2626033 | c6f31c07bf40573bcad83a5dfbee167233ebedd00786b2f895aa68c2566485dd | 機能修正前（res は v26 のまま・消失） |
| 3 | 2026-10-29 16:55 | 2.2.20 | receiver | BUILD SUCCESSFUL (exit 0) | 2616104 | f0681ab7078a4ece06fa738103c1aac1821b11bb2590817fb78290cb03a48151 | 機能修正5件を反映（消失） |
| 4 | 2026-10-29 16:56 | 2.2.20 | sender | BUILD SUCCESSFUL (exit 0) | 2694282 | da0b75e09122595ff01c8f1bdf593682e1ff202c577d938c552171c47921f9d5 | 機能修正5件を反映（消失） |
| 5 | 2026-10-29 17:05 | 2.0.21 | receiver | BUILD SUCCESSFUL (exit 0) | 2512201 | 47b55cfe9bbd3bf2e4353198836b32664670fb290411976b481d1ba0cd331b9d | 構造修正2件より前（消失） |
| 6 | 2026-10-29 17:07 | 2.0.21 | sender | BUILD SUCCESSFUL (exit 0) | 2522246 | 557127c3328a20c6ad71d1f1bee1ddf9ea809d27d6f67addaf05ec21dc2e1019 | 構造修正2件より前（消失） |
| 7 | 2026-10-29 17:12 | 2.0.21 | receiver | BUILD SUCCESSFUL (exit 0) | 2512201 | 44e8b9049f6dbb2524cd9591c7fbcefff833b8ea6cc09b53d4f007d92440277a | markFatal のラムダ構造を元に合わせた（消失） |
| 8 | 2026-10-29 17:14 | 2.0.21 | sender | BUILD SUCCESSFUL (exit 0) | 2522246 | 4fdf559c4d73cd40e22a0a42d832673780fef7b65d7e2c8ade27c94b5ad947fd | callback を finally 外へ移動（クラス数 49=元と一致・消失） |
| 9 | 2026-10-29 17:23 | 2.2.20 | protocol | BUILD SUCCESSFUL (exit 0) | 5786 (aar) | ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25 | :protocol:assembleDebug（AAR・消失） |
| 10 | 2026-10-29 17:23 | 2.2.20 | receiver | BUILD SUCCESSFUL (exit 0) | 2615972 | d4808f48ec0130b6a3881b366436b32f042a4f41f6866bb8135462237ec37c7c | clean からのビルド（修正#7まで・消失） |
| 11 | 2026-10-29 17:25 | 2.2.20 | sender | BUILD SUCCESSFUL (exit 0) | 2625017 | 02d9fe481b1b35e4368cc4d5cb048558b248c290c4e176caf3f41593d92a55d9 | clean からのビルド（修正#7まで・消失） |
| 12 | 2026-10-29 17:50 | 2.0.21 | receiver | BUILD SUCCESSFUL (exit 0) | 2512121 | 186450fc5cd39ff9c365cbbb18288844b50cb9c4443021c0389e82074887cb92 | 修正#8（fps 448→0）のみ（消失） |
| 13 | 2026-10-29 17:56 | 2.0.21 | receiver | BUILD SUCCESSFUL (exit 0) | 2608682 | (未保存・検証用) | 修正#9 の検証。**インクリメンタルビルドは zip パディングで +96KB になる**ことを発見（消失） |
| 14 | 2026-10-29 18:02 | 2.0.21 | receiver | BUILD SUCCESSFUL (exit 0) | 2512149 | 6f5fe29f945a8bb26e7c848c5b0064f5f432f44a4371dda12b2de1ae8530c5ba | 修正#8+#9・clean ビルド（消失） |
| 15 | 2026-10-29 18:06 | 2.2.20 | protocol | BUILD SUCCESSFUL (exit 0) | 5786 (aar) | ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25 | row 9 とバイト一致＝再現性あり（消失） |
| 16 | 2026-10-29 18:07 | 2.2.20 | receiver | BUILD SUCCESSFUL (exit 0) | 2616008 | 5cba428d3385f06e219acd38e1804c574bb38861e828baf035a9ff08d33f99be | 修正#8+#9・clean ビルド（消失） |
| 17 | 2026-10-29 18:09 | 2.2.20 | sender | BUILD SUCCESSFUL (exit 0) | 2625017 | 02d9fe481b1b35e4368cc4d5cb048558b248c290c4e176caf3f41593d92a55d9 | row 11 とバイト一致＝再現性あり（消失） |
| 18 | 2026-10-29 22:38 | 2.2.20 | protocol | BUILD SUCCESSFUL (exit 0) | 5786 (aar) | ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25 | **環境再構築後の再ビルド。row 9/15 とバイト完全一致**（AAR は署名を含まないため環境非依存） |
| 19 | 2026-10-29 22:47 | 2.2.20 | receiver | BUILD SUCCESSFUL (exit 0) | 2616008 | 93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5 | サイズは row 16 と一致。**全 ZIP エントリ(41)が row 16 とバイト一致**（差は署名ブロックのみ＝新 debug keystore `530053f9…`） |
| 20 | 2026-10-29 22:50 | 2.2.20 | sender | BUILD SUCCESSFUL (exit 0) | 2625017 | 4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116 | サイズは row 17 と一致。**全 ZIP エントリ(54)が row 17 とバイト一致** |
| 21 | 2026-10-29 22:57 | 2.0.21 | receiver | BUILD SUCCESSFUL (exit 0) | 2512149 | 50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408 | サイズは row 14 と一致。**全エントリ(40/40)が row 14 とバイト一致** |
| 22 | 2026-10-29 22:59 | 2.0.21 | sender | BUILD SUCCESSFUL (exit 0) | 2521242 | d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd | row 8 より −1,004 B。**全エントリ(53/53)が row 8 とバイト一致**（差は署名ブロック/パディングのみ） |
| — | 2026-10-29 22:44 | 2.2.20 | receiver | **BUILD FAILED (exit 1)** | — | — | clean 直後の一括ビルドで **カーネル OOM**（`hs_err_pid2073.log` → `recovery/evidence/PHASE_E_hs_err_pid2073_receiver.log`）。→ `compileDebugKotlin` と `assembleDebug` に**分割して成功**（row 19/20） |

## 元 APK（参考・変更禁止・`recovery/input-apk/`, chmod 444）
| モジュール | サイズ(B) | sha256 |
|---|---|---|
| receiver v1.0.11 | 2512825 | 384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473 |
| sender v1.0.11 | 2521362 | 70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4 |
| sender v1.0.10 | 2518766 | b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc |

## 署名証明書（すべて v2 のみ・v1/v3/v3.1/v4 = false・signers = 1）
| | 証明書 DN | 証明書 SHA-256 |
|---|---|---|
| 元 APK | `C=US, O=Android, CN=Android Debug` | `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf` |
| 再構築（旧環境の debug keystore） | 同上（別鍵） | `7a1fd7bb1a40a6e6a4cdcfea6edae6608f80222c90a8e4ca09dbfc72aa3277bd` |
| 再構築（現環境の debug keystore） | 同上（別鍵） | `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847` |

> debug keystore は環境ごとに自動生成される（`~/.android/debug.keystore`）ため、
> **再構築 APK の署名は環境を変えるたびに変わる**。元 APK の鍵は復元不能。
> 配布・実機運用では**自分の keystore を作って署名すること**（`docs/SIGNING_GUIDE.md`）。
