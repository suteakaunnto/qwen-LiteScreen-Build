# 環境調査 (Phase A) — 2026-10-29T08:34:46+00:00

## pwd / workspace
/tmp/arena/tenants/dd5eb9e5-f102-43a8-a06f-64a8347df421/sessions/ff461a51-4af4-422d-8977-90288ef88ba4/workspace
total 20
drwxr-xr-x 5 root root 4096 Oct 29 08:34 .
drwxr-xr-x 6 root root 4096 Oct 29 08:34 ..
drwxr-xr-x 7 root root 4096 Oct 29 08:34 LiteScreen-Recovery
drwxr-xr-x 8 root root 4096 Oct 29 07:57 android-recovery
drwxr-xr-x 2 root root 4096 Oct 29 08:34 uploads

## user / os
uid=0(root) gid=0(root) groups=0(root)
root
Linux c-6ae2f999-01b29cc4-23d441e66d20 4.19.91-c8dfc93.al7.x86_64 #1 SMP Tue Sep 26 10:25:51 UTC 2023 x86_64 GNU/Linux
PRETTY_NAME="Debian GNU/Linux 12 (bookworm)"
NAME="Debian GNU/Linux"
VERSION_ID="12"
VERSION="12 (bookworm)"

## cpu / mem / disk
2
model name	: Intel(R) Xeon(R) Processor @ 2.50GHz
MemTotal:        1083460 kB
MemFree:          193720 kB
MemAvailable:     790528 kB
Filesystem                               Size  Used Avail Use% Mounted on
c-6ae2f999-01b29cc4-23d441e66d20-rootfs  9.9G  1.2G  8.3G  12% /
c-6ae2f999-01b29cc4-23d441e66d20-rootfs  9.9G  1.2G  8.3G  12% /
c-6ae2f999-01b29cc4-23d441e66d20-rootfs  9.9G  1.2G  8.3G  12% /

## tools
python3        /usr/bin/python3
java           /usr/bin/java
javac          /usr/bin/javac
keytool        /usr/bin/keytool
git            /usr/bin/git
curl           /usr/bin/curl
wget           NOT FOUND
unzip          /usr/bin/unzip
zip            /usr/bin/zip
tar            /usr/bin/tar
make           NOT FOUND
gcc            NOT FOUND
gradle         NOT FOUND
adb            NOT FOUND
sdkmanager     NOT FOUND
aapt2          NOT FOUND
apksigner      NOT FOUND
zipalign       NOT FOUND
d8             NOT FOUND
dexdump        NOT FOUND
apktool        /usr/local/bin/apktool
jadx           /usr/local/bin/jadx

## versions
Python 3.11.2
openjdk version "17.0.21" 2026-10-20
OpenJDK Runtime Environment (build 17.0.21+9-1-deb12u1-Debian)
git version 2.39.5
curl 7.88.1 (x86_64-pc-linux-gnu) libcurl/7.88.1 OpenSSL/3.0.22 zlib/1.2.13 brotli/1.0.9 zstd/1.5.4 libidn2/2.3.3 libpsl/0.21.2 (+libidn2/2.3.3) libssh2/1.10.0 nghttp2/1.52.0 librtmp/2.3 OpenLDAP/2.5.13
2.11.1
1.5.6

## Android SDK
ANDROID_HOME=/opt/android-sdk
build-tools
cmdline-tools
licenses
platforms
34.0.0
android-34

## network
https://raw.githubusercontent.com OK 200
https://github.com OK 200
https://dl.google.com OK 200
https://services.gradle.org OK 200
https://repo1.maven.org OK 200
https://pypi.org OK 200
