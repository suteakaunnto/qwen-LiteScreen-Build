# Phase F 修正前のドキュメント退避

退避日時(UTC): 2026-10-30 02:04:35
理由: ユーザー指示『LiteScreen-Recovery-Kit 最終整合性修正』により、インストール手順の矛盾修正・ZIP エントリ数の表記修正・
　　　実機テスト手順の整備を行う。**既存ファイルを破壊的に上書きしない**ため、修正前の状態をここに複製した。
対象（修正予定ファイル）:
- README.md / CHECKPOINT.md / SHA256SUMS.txt
- docs/DEVICE_TEST_GUIDE.md / docs/SIGNING_GUIDE.md / docs/KNOWN_ISSUES.md（参照追加のみも含む）
- recovery/reports/PHASE_D_BUILD_VERIFICATION.md（訂正注記の追記のみ。原文は改変しない）
- recovery/artifacts/CURRENT_ARTIFACTS.md / KIT_SHA256.txt / LiteScreen-Recovery-Kit.zip
ZIP: `LiteScreen-Recovery-Kit_prePhaseF.zip` = Phase F 開始時点の成果物 ZIP（sha256 9d61409a37073811cd4a615b498d4bbe80e1805da98d11b384e1a6d05a2983c9）。
　　　新しい ZIP の検証が完了するまで削除しない（検証完了後も証拠として保持）。
