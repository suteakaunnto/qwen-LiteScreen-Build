# SIGNING_GUIDE — 署名鍵の作り方と、なぜ元アプリへの上書き更新ができないのか

## 1. 現状の整理（重要）

| | 証明書 SHA-256 | 署名方式 | 備考 |
|---|---|---|---|
| 元 APK（sender / receiver v1.0.11） | `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf` | v2 のみ | DN `C=US, O=Android, CN=Android Debug`。**この秘密鍵は復元できない** |
| 再構築 APK | 環境ごとに変わる（実測 `7a1fd7bb…` → `530053f9…`） | v2 のみ（元と同じ） | debug keystore は `~/.android/debug.keystore` に**自動生成**される |

- APK に含まれているのは**公開鍵と証明書だけ**。秘密鍵は元の開発マシンの中にあり、取り出せない。
  （AOSP の testkey とも一致しないことを確認済み。）
- そのため **再構築 APK は元アプリの上書き更新ができない**（`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）。
  Android は「同じ applicationId でも署名が違うアプリ」への上書きインストールを拒否する。
- **既存の元アプリはアンインストールせずに残すこと。** テスト手順（退避と入れ直し）は
  `docs/DEVICE_TEST_GUIDE.md` §0 を参照。元 APK 3 本は `recovery/input-apk/` に保全してある。
- debug keystore は環境ごとに自動生成されるので、**「同じ debug APK」は別のマシンでは再現できない**。
  配布や継続開発には**自分の release 用 keystore を作って固定する**のが正解。

## 2. 自分の keystore を作る（一度だけ。必ずバックアップ）

```bash
# JDK の keytool を使う（有効期限 10000 日 ≒ 27 年）
keytool -genkeypair -v \
  -keystore litescreen-release.jks \
  -alias litescreen \
  -keyalg RSA -keysize 2048 \
  -validity 10000 \
  -dname "CN=YourName, OU=Dev, O=YourOrg, L=City, ST=State, C=JP"
# パスワードを聞かれる。keystore のパスワードと key のパスワードは同じにしておくと扱いやすい
```

**保管のルール**
- `litescreen-release.jks` とパスワードは**絶対に GitHub に上げない**（`.gitignore` に入れる）。
- 紛失すると**以後のアップデートを既存ユーザーに配れなくなる**（署名が変わると上書き更新不可）。
  オフラインのバックアップ（USB / パスワードマネージャ）を必ず作る。
- この復旧キットの ZIP にも**含めないこと**（キットは配布物）。

## 3. Gradle で署名する（推荐）

`LiteScreen-Recovered/keystore.properties`（**Git 管理外にする**）:
```properties
storeFile=/absolute/path/to/litescreen-release.jks
storePassword=xxxxxx
keyAlias=litescreen
keyPassword=xxxxxx
```

`sender/build.gradle.kts` と `receiver/build.gradle.kts` に追加:
```kotlin
import java.util.Properties

val keystoreProps = Properties().apply {
    val f = rootProject.file("keystore.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}

android {
    signingConfigs {
        create("release") {
            if (keystoreProps.isNotEmpty()) {
                storeFile = file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            // debug ビルドと applicationId を揃えたいなら suffix を外す:
            // applicationIdSuffix は debug 用の ".debug" が付いているので release では付かない
        }
    }
}
```

> ⚠ `java.util.Properties()` は **import が必要**（KTS では明示しないと解決できない）。
> ⚠ 復元プロジェクトは `applicationIdSuffix = ".debug"` を使っているので、
> 　release ビルドの applicationId は `jp.litescreen.sender` / `jp.litescreen.receiver` になる。
> 　**元アプリ（`.debug` 付き）とは別アプリとして並存する**ので、移行時はデータの引き継ぎ方法を考えること。

ビルド:
```bash
cd LiteScreen-Recovered
./gradlew clean
./gradlew :sender:assembleRelease :receiver:assembleRelease
# → sender/build/outputs/apk/release/sender-release.apk ほか
```

## 4. 手元で署名し直すだけの場合（apk 署名の上書き）

```bash
# 1) 既存の署名を落として zipalign
zipalign -f -p 4 in.apk aligned.apk
# 2) v2 で署名（元 APK と同じスキーム）
apksigner sign --ks litescreen-release.jks --ks-key-alias litescreen \
  --v1-signing-enabled false --v2-signing-enabled true \
  --out signed.apk aligned.apk
# 3) 確認
apksigner verify -v --print-certs signed.apk
```
（AGP のビルドで署名するのが確実。手動署名は配布前の最終調整用。）

## 5. GitHub へのアップロード（このエージェントは自動で書き込まない）

復旧キットを受け取ったら、自分のリポジトリを作って上げるのがおすすめ:
```bash
git init LiteScreen-Recovered && cd LiteScreen-Recovered
printf 'build/\n.gradle/\n.kotlin/\nlocal.properties\nkeystore.properties\n*.jks\n*.keystore\n' > .gitignore
git add . && git commit -m "LiteScreen: APK から復元したプロジェクト（Phase D まで検証済み）"
git remote add origin git@github.com:<your-account>/<repo>.git
git push -u origin main      # 既存リポジトリへの force push はしないこと
```
APK などのバイナリを上げたい場合は Git LFS か Releases を使う（リポジトリが重くなるのを防ぐ）。
**keystore とパスワードは絶対に含めない。**
