# KNOWN_ISSUES — 修正済み / 未修正 / 未確認

更新: 2026-10-29（Phase D 完了時点）。証拠は `recovery/evidence/`、解説は
`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`（ビルドと照合）と `recovery/reports/APK_FORENSICS.md`（APK 解析）。

---

## A. 修正済み（復元コードの誤りを見つけて直した。**計 9 件**）

Phase C の「文字列・メンバ一致」検証では見つからず、Phase D で smali の数値定数・`$default` マスク・
ラムダ構造と突き合わせて発見した。**すべて修正後に再ビルド（exit 0）し、再比較済み**。

| # | 場所 | 誤り → 修正 | smali の根拠 | 実害 |
|---|---|---|---|---|
| 1 | receiver `H264Decoder` | `THREAD_PRIORITY_BACKGROUND`(10) → **`THREAD_PRIORITY_URGENT_DISPLAY`(−8)** | `const/16 v0, -0x8` | デコードスレッドの優先度。遅延・カクつきに直結 |
| 2 | receiver `MirrorService` | `FLAG_ACTIVITY_CLEAR_TOP`(0x04000000) → **`FLAG_ACTIVITY_SINGLE_TOP`(0x20000000)** | `const 0x20000000` | 通知タップ時に Activity が再生成されてしまう |
| 3 | sender `SenderClient` | `% 1000L` → **`% 1000000`** | `rem-long … 0xf4240` | **プロトコルの sendMs 値。互換性に直結** |
| 4 | receiver `H264Decoder` | `contains(…, ignoreCase = true)` → **大文字小文字を区別** | `contains$default` mask `0x2` = 既定値(false) を使用 | CSD 判定ロジック |
| 5 | protocol `StreamConfig` | `port: Int = 47820` と既定値を付与 → **既定値なし** | 合成 ctor の mask は `0x4/0x8/0x10` のみ | API 形状と呼び出し側の codegen |
| 6 | receiver `H264Decoder` | ラムダ 2 個 → **単一ラムダ `markFatal$lambda$10(Listener,String)`** | `.line 402-403` | 構造（クラス数・ラムダ数） |
| 7 | receiver `ReceiverDiscovery` | callback が `finally` 内 → **`finally` の外** | cleanup ×3 / `sortedWith` ×1 | 構造。修正でクラス数が元と一致（49=49, 65=65） |
| 8 | receiver `DecoderCaps` | 失敗時 `Probe(fps = 448)` → **`fps = 0`** | `0x1c0`(=448) は合成 ctor の**既定値マスク**（第10引数）。fps は第4引数で `const/4 0x0` | `Probe` の fps 値（呼び出し側は `width>0` で判定するため表示上の実害は無いが事実として誤り）。修正で `0x1c0` が 6個→**3個（元と一致）** |
| 9 | receiver `DecoderCaps.diagnose()` | `${30L * mb}` → **`val fps = 30` + `${fps.toLong() * mb}`** | 元は `const/16 0x1e` → `int-to-long` → `mul-long`。`30L`/`30.toLong()` は 2.0.21 でも `const-wide/16` に畳み込まれる（実測） | codegen の形。修正で `int-to-long` 形が元と一致 |

### 修正作業で得られた教訓（次回、同じ罠を踏まないため）
1. **Android の定数は「名前」ではなく「値」で確認する**。
   `javap -classpath <android.jar>/android.jar -constants android.os.Process` で数値を出す。
   （THREAD_PRIORITY: AUDIO=−16, URGENT_AUDIO=−19, VIDEO=−10, URGENT_DISPLAY=−8, DISPLAY=−4,
   FOREGROUND=−2, DEFAULT=0, BACKGROUND=10, LOWEST=19 / Intent: NEW_TASK=0x10000000,
   SINGLE_TOP=0x20000000, CLEAR_TOP=0x04000000）
2. **`$default` / 合成コンストラクタの mask ビットは「その引数が既定値を使っている」印**。
   引数の位置は `invoke-*/range {vA .. vB}` の**レジスタ並び**で確定する
   （末尾 2 つは必ず `mask:Int, marker:DefaultConstructorMarker`）。mask `0x1c0` = bits 6,7,8。
   データクラスの既定値は**合成 ctor の mask ビットからだけ**復元する。
3. **数値リテラルの「型」も smali で確認する**（`30L` と `変数.toLong()` は生成命令が違う）。
4. **jadx 1.5.6 には描画バグがある**（`UByte.MAX_VALUE` を 255 ではなく −1 と出す 等）。
   ビット演算・符号・キャストは必ず smali で裏取りする → 一覧: `recovery/reports/JADX_ERRORS.md`。
5. `MediaCodec.CodecException.ERROR_UNSUPPORTED`（@hide）= `0x80010005`。
   ただし元アプリのユーザー向け文言 `"0x80001005"` は**原文のまま保持**（修正しない）。
6. 例外の catch 順: `SocketTimeoutException` → `ProtocolException` → `EOFException` → `IOException` → `Exception`。
7. `@Metadata` の d1（バイナリ）を解析するのは時間の無駄。d2（文字列）と smali を使う。

---

## B. 未修正（＝意図的な差、またはコンパイラ由来の良性差分）

### B-1. 意図的に入れた差（ユーザー決定あり）
| 内容 | 理由 |
|---|---|
| `MirrorService.startMirroring()` を private 関数として維持（元は `onStartCommand` のラムダ内に直書き） | 可読性。挙動は同一。ユーザー決定 "keep_function"（2026-10-29） |
| Kotlin 既定版を 2.2.20 にしている（元は 2.0.21） | 今後の開発を新しいコンパイラで続けるため。`scripts/31_switch_kotlin_version.sh` で 1 行切替 |
| アイコン res を `mipmap-anydpi-v21/` にしている | 元の APK 内パスに合わせるため（`v26` だとパスが変わる） |

### B-2. コンパイラ由来の良性差分（動作・通信に影響なし）
- `@Metadata mv`: 元 `{2,0,0}` / 2.2.20 ビルド `{2,2,0}`（**2.0.21 ビルドでは一致**）
- ラムダの連番: `$lambda$N`, `$r8$lambda$<hash>`, `$$ExternalSyntheticLambdaN` の振り方
  → `scripts/27` は**番号を除いた形状の multiset** で比較して一致を確認している
- プラットフォーム型の null チェック文言（`findViewById(...)` / `iterator(...)` / `getByName(...)` /
  `createInputSurface(...)` / `getDisplayMetrics(...)`）が再構築側に余分に出る
- `DecoderCaps` の定数個数差（`0x1e`×1, `0x320`(800)×2, `0x500`(1280)×2, `0x0`×5 が元だけ）
  ＝**レジスタ再利用（CSE）の差**。値の意味は同一。個数を合わせるためにソースを歪めないこと
- 2.2.20 のみ: 定数 `in IntRange` を直接比較に最適化（0x10000 / 0xffff）、インライン `run {}` の定数複製と
  `$i$a$-run-…` ローカル、`try-finally` 内 `continue` での finally 本体複製（2.0.21 は `sortedWith` ×1 を共有、
  2.2.20 はコンパレータ全体を ×3 複製）、冗長な `const/4 0x0` の削除
- sender の匿名クラス 3 個の連番、`ScreenCapturer$doStart$3/$4` ↔ `$2/$3` のスロットずれ
- 2.2.20 のみ ZIP エントリが **+1**（`kotlin/concurrent/atomics/atomics.kotlin_builtins`。Kotlin 2.1+ の stdlib 付属物）

### B-3. 任意の追加作業（やっていない）
- `AndroidManifest.xml` は**埋め込み行番号 `(line=NN)` 以外は完全に同一**（要素順・属性・値・リソース ID とも一致、
  サイズも receiver 3,212 B で同一）。元の行番号に揃えればバイト一致にできるが、
  マージ後マニフェストの行番号合わせ込みが必要でビルド反復を要するため**未実施**（機能影響なし）。

---

## C. 未確認（「できた」と報告してはいけないもの）

| 項目 | 状態 |
|---|---|
| 実機での動作（sender キャプチャ → receiver 表示） | **未検証**（実機が無い） |
| 通信互換（再構築 sender ↔ 元 receiver / 再構築 receiver ↔ 元 sender） | プロトコルのバイト列一致は確認済みなので**成立するはず**だが実測なし |
| 遅延・FPS・破棄率などの性能 | **未測定**。v1.0.11 で報告された「30〜60ms」等は `[旧報告]` であり実測未確認 |
| Android 9 / API 28 実機（チャレンジパッドNext）での動作 | minSdk 28 の宣言一致のみ確認。実機未検証 |
| Lint(NewApi) の単独実行 | 未実施（compileSdk 36 / minSdk 28 でのコンパイルは成功） |
| ユニットテスト | プロトコルの差分テスト（650 checks / 0 failures）と DEX 定数照合（37 / 0）は実施済み。JUnit 等のテストコードは元 APK に含まれておらず、新規作成もしていない |

→ 実機テストの手順は `docs/DEVICE_TEST_GUIDE.md`。

---

## D. 環境・ツール由来の既知の問題（作業を進める上での注意）

1. **RAM 1,083 MB / swap 無し**の環境では Gradle が OOM する。
   - `gradle.properties` の JVM 設定（`-Xmx384m -XX:MaxMetaspaceSize=224m -XX:ReservedCodeCacheSize=32m
     -XX:MaxDirectMemorySize=48m -XX:+UseSerialGC -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10
     -Dorg.gradle.internal.instrumentation.agent=false`）で安定。
   - それでも一括ビルドで OOM することがある → **`compileDebugKotlin` と `assembleDebug` に分ける**。
   - `--no-daemon` でも Gradle 8.13 は単発 daemon を fork する（避けられない）。
   - OOM 時は**無限リトライしない**。ログと `hs_err_pid*.log` を保存して原因を見る（実例:
     `recovery/evidence/PHASE_E_hs_err_pid2073_receiver.log`）。
2. **インクリメンタルビルドは APK のパディングが増える**（内容差 28 B に対し +96 KB の実測）。比較・配布用は clean ビルドで。
3. **成果物を `out/`, `build/`, `dist/`, `target/`, `node_modules/` などの名前のディレクトリに置かない**。
   ワークスペースのスナップショット対象外で、**実際に一度成果物が全消失した**（2026-10-29 22:30 頃）。
   正式な置き場所は `recovery/artifacts/`。経緯と復元証明: `PHASE_D_BUILD_VERIFICATION.md` §2.5。
4. **ツールチェーン（JDK/SDK/Gradle/apktool/jadx）もコンテナ再生成で消える**。
   `scripts/00_setup_env.sh` で再導入できるが、`platforms;android-36` / `build-tools;36.0.0` /
   `build-tools;35.0.0` は手動で追加が必要（スクリプトは 34.0.0 までしか入らない）。
5. **debug keystore は環境ごとに自動生成される**（`~/.android/debug.keystore`）ため、
   再構築 APK の証明書ハッシュは環境を変えるたびに変わる（実測: `7a1fd7bb…` → `530053f9…`）。
   全体ハッシュでの一致判定はできない。**エントリ単位ハッシュ（`scripts/30`）で内容を確認する**こと。
6. このコンテナには `strings`, `file`, `ps`, `free` が無い。`grep -a`, `python3`, `/proc` で代用する。
   `grep -c` は 0 件で exit 1 になるため `set -e` と組み合わせると落ちる。
7. `tee $LOG` は既存ログを truncate する。ビルドごとに別ログファイルにすること。
