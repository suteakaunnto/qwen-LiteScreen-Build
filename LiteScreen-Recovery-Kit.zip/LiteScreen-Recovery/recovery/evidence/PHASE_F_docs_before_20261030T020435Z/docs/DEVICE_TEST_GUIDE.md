# DEVICE_TEST_GUIDE — 実機テスト手順とログの見かた

**このテストはまだ実施されていない**（復旧作業を行った環境に実機が無いため）。
以下は「実機が用意できたらこの順で確認する」ための手順書。結果は必ず `CHECKPOINT.md` に反映すること。

## 0. どの APK をどの端末に入れるか

| 端末 | 入れる APK | 理由 |
|---|---|---|
| REDMAGIC Astra（Android 16 / API 36） | `recovery/artifacts/kotlin-2.0.21/sender-debug_kotlin2.0.21_fix8-9.apk` | 元 APK と最も近いビルド（stdlib DEX がバイト一致）。まずこれで元の挙動を再現する |
| チャレンジパッドNext TAB-A05-BA1（Android 9 / API 28） | `recovery/artifacts/kotlin-2.0.21/receiver-debug_kotlin2.0.21_fix8-9.apk` | 同上。**minSdk 28 なのでこの端末が下限**。API 28 実機での動作確認が最重要 |

比較用に Kotlin 2.2.20 版（`recovery/artifacts/kotlin-2.2.20/`）もある。
**まず 2.0.21 版で動かし、必要なら 2.2.20 版と挙動を比べる**のがおすすめ（差分はコンパイラ由来のみのはず）。

### ⚠ インストール前の注意（署名が違う）
再構築 APK は**元アプリと署名が異なる**ため、**上書き更新はできない**
（`INSTALL_FAILED_UPDATE_INCOMPATIBLE` / `adb install -r` も失敗する）。

1. **既存の元アプリはアンインストールせずに残す**こと（消すと比較できなくなる。設定も消える）。
2. 再構築版は applicationId が同じなので**並存インストールはできない**。
   テストするには「元アプリを退避 → 再構築版を入れる → 終わったら元に戻す」手順が必要:
   ```bash
   # 元 APK はこのキットに入っているので、いつでも入れ直せる
   adb install -r recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk
   ```
   **先に元 APK 3 本のバックアップ（このキットの `recovery/input-apk/`）があることを確認してから**作業すること。
3. 並存させたい場合は applicationId を変えた別ビルドを作る（`receiver/build.gradle.kts` の
   `applicationIdSuffix` を変える）。ただし**相手が discovery で見つけるアプリ名/ポートは同じ**なので通信は可能。

## 1. 事前準備

- 2 台を**同じ Wi-Fi（同一サブネット）**に接続する。
  学校・公共 Wi-Fi は端末間通信（AP アイソレーション）が遮断されることがあり、その場合は接続できない
  （アプリ内にも同じ注意書きがある）。
- PC に adb（platform-tools）を入れる。無線でも USB でもよい。
- 受信側アプリを起動して**「この端末のIPアドレス」**と**「受信ポート: 47820」**を確認する。
  IP は長押しでコピーできる。Wi-Fi 未接続なら「Wi-Fiに接続されていません。IPアドレスを取得できません。」が出る。

## 2. 基本テスト（再構築 sender ↔ 再構築 receiver）

1. 受信側: アプリを起動したままにする（画面に表示される IP を控える）。
2. 送信側: アプリ起動 →「**受信端末を検索**」→「見つかった受信端末」ダイアログに出る端末を選ぶ。
   見つからない場合は IP を手入力（ヒント表示「IPアドレス（例: 192.168.1.20）」、ポート既定値 47820）。
3. 「**接続して配信を開始**」をタップ → 「画面配信の許可」ダイアログを読む →
   Android の画面収録許可ダイアログで「**全画面**」を選んで許可。
   ※ **Android 14 以降では許可はセッションごとに必要**（アプリ内にも明記）。
4. 受信側の SurfaceView に送信側の画面が出ることを確認。
5. 停止は送信側で「**配信を停止**」。受信側の表示が止まること。

### 確認ポイント
- [ ] 検索（UDP 47821 の discovery）で受信端末が見つかる
- [ ] 手入力 IP でも接続できる
- [ ] 映像が出る／色がおかしくない（緑・紫のノイズは CSD/SPS/PPS 処理の誤り）
- [ ] 画面回転・解像度変更で追従する（受信側がデコーダーを作り直せるか）
- [ ] 停止→再開ができる（**古い世代のコールバックや buffer index を使っていないか**）
- [ ] 送信側の通知をタップしても Activity が複製されない（`FLAG_ACTIVITY_SINGLE_TOP` の確認・修正 #2）
- [ ] 静止画面でビットレートが下がり続けない（過負荷誤判定の確認）

## 3. 相互接続テスト（**最重要**。プロトコル互換の実証）

| 組合せ | 期待 |
|---|---|
| 再構築 sender（新） ↔ **元** receiver（v1.0.11） | 映ること |
| **元** sender（v1.0.11） ↔ 再構築 receiver（新） | 映ること |

これが両方成功すれば、**プロトコル（MAGIC `4C 53 43 01` / TCP 47820 / UDP 47821 / メッセージ 1..14 /
VIDEO ヘッダ / STATS v2 24B / sendMs = `currentTimeMillis() % 1000000`）の復元が正しいことが実証される**。
静的解析ではバイト列の一致まで確認済みだが、実測はまだ。

## 4. ログの見かた

受信側はアプリ内に**ローカルログ表示**がある（「ログを表示」／「ログを消去」。端末内のみ・外部送信なし、保持 200 行）。
PC からは logcat:

```bash
adb logcat -v time -s LiteScreen:V LiteScreen.Decoder:V LiteScreen.Caps:V LiteScreen.Net:V LiteScreen.Discovery:V
adb logcat -v time -s LiteScreen.Capture:V LiteScreen.Sender:V LiteScreen.Service:V LiteScreen.Activity:V LiteScreen.NetInfo:V
```

| タグ | 端末 | 内容 |
|---|---|---|
| `LiteScreen` | 受信 | LocalLog（アプリ内ログと同じ内容） |
| `LiteScreen.Decoder` | 受信 | H.264 デコーダの生成・再構成・エラー（**修正 #1 のスレッド優先度 −8、#4 の CSD 判定、#8 の能力 probe**） |
| `LiteScreen.Caps` | 受信 | デコーダー能力の判定（解像度/FPS/プロファイル/レベル） |
| `LiteScreen.Net` / `LiteScreen.Discovery` | 受信 | 受信ソケット / UDP 存在通知 |
| `LiteScreen.Capture` | 送信 | MediaProjection・VirtualDisplay の開始/停止（`virtualDisplay paused/resumed/stopped`、`MediaProjection onStop（…）`） |
| `LiteScreen.Sender` | 送信 | 送信クライアント・STATS・バックプレッシャ |
| `LiteScreen.Service` / `LiteScreen.Activity` | 送信 | MirrorService / UI |

### 正常系の目安
- 受信: デコーダー生成 → `csd` 受信 → 描画開始。fps 表示が上がる。
- 送信: `virtualDisplay` 生成 → フレーム送信 → STATS 受信。
- 「能力診断」を押すと、デコーダー名・HW/SW・対応サイズ・FPS・アラインメント・プロファイル対応・
  必要レベル・1920x1200 を要求した場合の自動縮小結果が一覧表示される（**修正 #8 #9 の確認に使える**。
  失敗時に fps=448 ではなく **fps=0 / width=0** で返るようになっていれば修正が効いている）。

### 異常系の見かた
| 症状 | 見るべきログ | 疑う箇所 |
|---|---|---|
| 接続できない | 送信 `LiteScreen.Discovery` / 受信 `LiteScreen.Net` | AP アイソレーション、ポート 47820/47821 のブロック、IP 違い |
| 繋がるが真っ黒 | 受信 `LiteScreen.Decoder` の `csd` 有無 | SPS/PPS（CSD）の二重送信・欠落、key frame 待ち |
| 色が壊れる／ブロックノイズ | 同上 | Annex-B 分割（`splitAnnexB`）、NAL 境界 |
| `MediaCodec.CodecException` | 受信 `LiteScreen.Decoder` | 能力不足（`LiteScreen.Caps` の診断結果と突き合わせる）。エラーコード `0x80010005` = ERROR_UNSUPPORTED（アプリ表示は原文どおり "0x80001005"） |
| 途中で止まる／復帰しない | 受信 `LiteScreen.Decoder` の再構成ログ | コールバック実行中の再構成（v1.0.11 で退避した設計）、古い buffer index の使用 |
| 送信側だけ停止 | 送信 `LiteScreen.Capture` の `MediaProjection onStop` | ユーザーが許可を取り消し／システムが停止 |

## 5. 性能（遅延・FPS）を測るとき

- **過去に報告された「遅延 30〜60ms」等は実測未確認**（`[旧報告]`）。比べるなら同じ条件で測り直すこと。
- 目安の測り方: 送信側に秒針付きのタイマーを表示し、受信側と一緒に撮影してフレーム差から遅延を出す。
- 受信側の STATS（v2, 24 バイト）には受信 fps / 破棄数などが入る。アプリ内ログに表示される値を使う。
- **静止画面で受信 fps が低いのは正常**（フレームが来ないだけ）。破棄率・キュー深さ・遅延と分けて判断すること。

## 6. テスト後に返してほしいもの

1. どの組合せ（再構築↔再構築 / 再構築↔元）で、映像が出たか・出なかったか。
2. `adb logcat -d -s LiteScreen*:V > log.txt` で保存したログ（送信側・受信側の両方）。
3. 受信側アプリの「ログを表示」画面のスクリーンショット（端末内ログ 200 行）。
4. 「能力診断」の結果スクリーンショット（デコーダー名・対応サイズ・必要レベル）。
5. 症状が出た場合の動画／写真と、そのときの操作手順。

これがあれば `CHECKPOINT.md` の「未確認」を「検証済」に更新し、次の修正に入れる。
