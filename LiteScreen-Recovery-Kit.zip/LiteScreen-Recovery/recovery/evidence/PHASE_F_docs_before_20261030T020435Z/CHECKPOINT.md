# CHECKPOINT — LiteScreen 復旧作業

> このファイルは「セッションが失われても再開できる」ことを目的とした現在地記録。
> 各フェーズ終了時に更新する。最新の状態は常にここを見る。

最終更新: 2026-10-29（Phase C 完了）／ 現在地: **Phase C ✅ 完了 — protocol ✅ / sender ✅ / receiver ✅（3モジュールとも復元・検証PASS）**
**★次は Phase D（Gradle 実ビルド）。詳細は末尾の「## 6. Phase C 完了記録」を見ること。**

---

## 0. 作業の前提

- 入力: 署名済み debug APK のみ。**元の Kotlin/Java ソースは存在しない**（GitHubリポジトリ直下は3 APKのみであることを API で確認済み）。
- 目標: 保守・再ビルド可能な Android プロジェクトを再構成し、今後のバグ修正を続けられる状態にする。
- 証拠レベルの区別（概要書 §9 に準拠）:
  - **[APK確認]** 現物APKの Manifest/DEX/リソース解析で確認
  - **[検証済]** この環境でコマンドを実行して結果を確認
  - **[旧報告]** 旧セッションの報告。現物では未確認
  - **[推定]** 証拠からの仮説
  - **[未確認]** 実機等がなく確認不能

## 1. 完了済みフェーズ

### Phase A — 環境と入力ファイルの保全 ✅ [検証済]

- 環境: Debian 12 / root / **CPU 2コア / RAM 約1.06GB(重要制約) / ディスク空き 7.9GB**
- ネットワーク: raw.githubusercontent.com, github.com, dl.google.com, services.gradle.org, repo1.maven.org, pypi.org すべて到達可能
- ツール: OpenJDK 17.0.21, apktool 2.11.1, jadx 1.5.6, build-tools **34.0.0 + 36.0.0**, platforms **android-34 + android-36**, cmdline-tools (apkanalyzer/retrace/lint/sdkmanager)
- **未取得**: gradle 本体（Wrapper で取得する）, platform-tools/adb, make/gcc
- APK 3本を `recovery/input-apk/` に **chmod 444** で保全

| ファイル | サイズ | SHA-256 |
|---|---:|---|
| litescreen-sender-v1.0.11-debug.apk | 2,521,362 | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` |
| litescreen-receiver-v1.0.11-debug.apk | 2,512,825 | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` |
| litescreen-sender-v1.0.10-debug.apk | 2,518,766 | `b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc` |

- Git blob SHA `54df19e4...4257` が master prompt 記載値と一致
- 記録: `recovery/evidence/ENVIRONMENT.md`, `recovery/evidence/INPUT_APK.md`

### Phase B — APK フォレンジック解析 ✅ [検証済]

**成果物: `recovery/reports/APK_FORENSICS.md`（詳細はこれを読むこと）**

要点だけ:

- **難読化なし**。独自クラスは全て原形の名前が残っている（1〜2文字クラス名 0 件）。jadx で送信側 4,250行 / 受信側 4,443行の Java を復元。独自クラスにデコンパイルエラー 0 件。
- **AndroidX 未使用**。依存は kotlin-stdlib のみ（`androidx.*` クラス数 = 0）。
- パッケージ: `jp.litescreen.sender.debug` / `jp.litescreen.receiver.debug`（**applicationIdSuffix ".debug"**）
- versionCode 11 / versionName `1.0.11-debug` / minSdk 28 / targetSdk 36 / compileSdk 36 / **AGP 8.13.2**
- 3 APK とも署名証明書が同一（`CN=Android Debug`, SHA-256 `bf068d16...fdaf`, v2署名のみ）。**AOSP公開testkeyとは不一致**（実際にDLして比較）→ 秘密鍵の復元は不可、再ビルドは新規鍵になる。
- **モジュール構成は protocol(Library) + sender(App) + receiver(App) の3モジュール**と推定。両APKの `jp.litescreen.protocol` は diff で完全一致。
- **プロトコル完全解明**: MAGIC `4C 53 43 01`、8バイトヘッダ(type 1B + len 3B BE)、TCP 47820、UDP 47821、PROBE `LITESCREEN?` / PROBE_ACK `LITESCREEN!`+JSON、メッセージID 1〜14、各ペイロードのフィールド順まで確定。
- **送信 v1.0.11 ↔ 受信 v1.0.11 は静的解析の範囲でプロトコル完全互換**（全メッセージの書込順と読取オフセットを1件ずつ照合）
- **送信 v1.0.10 → v1.0.11 の実差分は2ファイルのみ**: `ScreenCapturer`(+9行 = `max-bframes=0`) と `MirrorService`(+332行 = panelHz / LS-Startスレッド化 / floor警告throttling)。プロトコル・UI・探索は無変更。
- **v1.0.11 で報告された13項目のうち10項目が現物APKに入っていることを確認**（LS-Codecスレッド、描画ペーシング+`releaseOutputBuffer(index,false)`、統計分離、5秒ログ、AIMD overloadStreak>=2、静止画面を過負荷証拠にしない、パネルHz、max-bframes=0、エラー再構成の退避、CSD重複無視）。残り3項目（ビルド成功・Lint・実機性能）は確認不能/未確認。
- H.264 レベル表（9段）と縮小スケール表 `SCALES=[1.0,0.9,0.8,0.75,0.667,0.6,0.5,0.4,0.333,0.25]` を smali の `.array-data` から実数復元。
- **Smart Cast 非対応は APK 内の文言とコードの両方で確定**（Miracast/WifiDisplay/Cast SDK 参照ゼロ、`warning_not_smartcast` 文字列あり）
- 通信は**平文・無認証**（アプリ内文言でも明示）。TLS関連API参照ゼロ。
- `decompiled/` は **chmod a-w で読み取り専用化済み**（証拠保全）

## 2. 進行中 / 次やること

### Phase C — Androidプロジェクト再構成 🔄 進行中

#### C-1. Gradle 骨格 ✅ [検証済]
`LiteScreen-Recovered/` に以下を作成済み:
- `settings.gradle.kts`（include ":protocol", ":sender", ":receiver"）
- `build.gradle.kts`（AGP 8.13.2 = **APKから確認した値**、Kotlin 2.2.20）
- `gradle.properties`（**RAM 1GB 対応**: `-Xmx640m`, daemon=false, parallel=false, kotlin in-process）
- `gradlew` + `gradle/wrapper/`（Gradle 8.13、`gradle wrapper` で生成済み）
- `local.properties`（sdk.dir、配布ZIPには含めない）
- `protocol/build.gradle.kts` + `protocol/src/main/AndroidManifest.xml`
- Gradle 8.13 本体は `/opt/gradle/dist/gradle-8.13` に展開済み（Wrapper生成に使用）

#### C-2. protocol モジュール ✅ **完成・検証PASS** [検証済]
- `protocol/src/main/java/jp/litescreen/protocol/Proto.kt`（Proto + Framing + ProtocolException）
- **検証1: `scripts/10_diff_test_protocol.sh` → 650 checks / 0 failures / PASS**
  - 元APKの classes2.dex を jadx で Java 化 → javac → 「基準実装JAR」
  - 再構成 Proto.kt を kotlinc → 「再構成実装JAR」
  - `scripts/difftest/DiffTest.java` が両者を別ClassLoaderで読み、
    全定数・writeHeader 162組合せ・intBytes/longBytes/readInt/readLong・
    全メッセージ種別の往復・異常系の例外クラス名とメッセージ文字列・
    実APKのペイロード構造(HELLO/VIDEO_CONFIG/STATS/PROPOSE_ACK/VIDEO/CODEC_CONFIG)を比較
- **検証2: `scripts/11_verify_dex_constants.py` → 37 checks / 0 failures / PASS**
  - jadx を介さず **apktool の smali（DEX直接逆アセンブル）を正として**
    `.field ... = 0xNN` 25個、MAGIC の `.array-data`、PROBE/PROBE_ACK の `const-string`、
    `and-int 0xff` の使用有無、送信側/受信側 smali の同一性を照合
- ログ: `recovery/evidence/VERIFY_protocol.txt`

#### C-2b. リソースの移植（両アプリ） ✅ **完成・検証PASS** [検証済]

apktool が出力する `res/` は **ビルド済み（コンパイル後）の形式**なので、そのままでは
aapt2 のソースとして使えない。`scripts/03_convert_res.py`（冪等）で AAPT2 ソース形式に
逆変換した。

- 変換内容:
  - 値リソース（colors/strings/styles/dimens…）を 1 ファイル 1 エントリの XML に分解せず、
    `values/*.xml` として再構成（`public.xml` / `ids.xml` は**意図的に移植しない** —
    ID 数値を固定する必要がなく、aapt2 に任せた方が保守しやすいため）
  - コンパイル済み `<item>` の `@ref` 形式 → `@drawable/name` 等の参照形式に戻す
  - `$ic_launcher_background__0.xml` のような **AAPT2 インライン生成物**（9+2 個）は移植せず、
    元の `ic_launcher_background.xml` / `ic_launcher_foreground.xml` の `<gradient>` を復元
- 検証: 両モジュールとも `aapt2 compile --dir res` が **エラー 0** で通る
  （`recovery/build-check/{sender,receiver}/logs/aapt2-compile.log`）
- 棚卸し検証: `scripts/21_verify_res_inventory.py sender` → **PASS（全 8 type / 不足 0 件）**

| type | 元 APK | 復元 | 判定 |
|---|---:|---:|---|
| color | 11 | 11 | 一致 |
| drawable | 24 | 24 | 一致 |
| id | 13 | 13 | 一致 |
| layout | 1 | 1 | 一致 |
| mipmap | 1 | 1 | 一致 |
| string | 40 | 40 | 一致 |
| style | 13 | 13 | 一致 |
| xml | 1 | 1 | 一致 |

> 既知の無害差分: 元 APK の `R$id` には `activity_sender` が無い（`R$layout` にある）。
> リソース ID の**数値**は一致させていない（aapt2 の割り当て順に依存し、動作に影響しないため）。

#### C-2c. sender モジュール ✅ **完成・コンパイル検証PASS** [検証済]

**復元したファイル（7 / 7 — 元 APK の自前クラスを全て網羅）**

| 復元ファイル | 行数 | 元 APK の対応クラス | 主な内容 |
|---|---:|---|---|
| `core/StreamConfig.kt` | 93 | StreamConfig, StreamConfig$Companion | 配信設定 data class、解像度/fps/ビットレート選択肢、表示ラベル、`suggestBitrateKbps` |
| `core/NetInfo.kt` | 104 | NetInfo（+ inlined sortedBy） | IPv4 候補列挙（IF 優先度 wlan/p2p/other/rmnet）、`isIPv4`、ブロードキャスト先 |
| `core/ReceiverDiscovery.kt` | 125 | ReceiverDiscovery, $Found, $Companion | UDP 47821 へ PROBE、900ms 毎に再送、`LITESCREEN!` 応答を JSON 解析 |
| `core/SenderClient.kt` | 508 | SenderClient, $Listener, $Companion | TCP セッション。LS-Writer / LS-Reader / LS-Watchdog、PROPOSE 交渉、STATS v1/v2、バックプレッシャ |
| `core/ScreenCapturer.kt` | 616 | ScreenCapturer, $Listener, $Companion, doStart$3/$4 | MediaProjection → VirtualDisplay → H.264。4 段 variant フォールバック、Annex-B 分割、AIMD 用の統計 |
| `MirrorService.kt` | 548 | MirrorService, $Companion | FGS(mediaProjection)。LS-Start スレッド、能力ネゴシエーション、適応ビットレート、通知 |
| `SenderActivity.kt` | 432 | SenderActivity, $Companion, $statusTicker$1, $setupSpinner$2 | 設定 UI、受信側検索、権限、配信開始/停止 |

**ビルド定義（[再構成新規] — APK には含まれていなかったため新規作成。ただし値は APK 実測に一致させた）**

- `sender/build.gradle.kts` — applicationId `jp.litescreen.sender` + `applicationIdSuffix ".debug"`、
  versionCode 11、versionName "1.0.11" + `versionNameSuffix "-debug"`、minSdk 28 / target 36 / compileSdk 36、
  `buildConfig = false`（**DEX に BuildConfig が存在しないことを確認**）、依存は `:protocol` と kotlin-stdlib のみ
- `sender/src/main/AndroidManifest.xml` — 元 APK のマニフェストと**同一の権限・feature・component 属性**。
  `package` / `compileSdkVersion*` / `android:debuggable` / `android:extractNativeLibs` のみ Gradle 側に移した
  （理由はファイル冒頭のコメントに記載）
- `gradle.properties` の `android.nonFinalResIds=true` に修正
  （**[APK確認]** 元 APK の R は `public static int`＝非 final。AGP 8.x の既定と同じ）

**検証結果（`bash scripts/20_compile_module.sh sender`）**

```
==> sender: Kotlin ソース 7 ファイルをコンパイル
==> R クラスを aapt2 で生成
==>   R クラス生成完了 (9 classes)
==> kotlinc 実行 (jvm-target 17)
==> PASS: sender コンパイル成功 (errors=0 warnings=0 classes=24)
```

- ログ: `recovery/build-check/sender/logs/kotlinc.log`
- 証拠まとめ: **`recovery/evidence/VERIFY_sender.txt`**（コンパイル・リソース棚卸し・クラス棚卸しの全出力）

**これは「Gradle のビルド成功」ではない。** RAM 1GB の環境では AGP+Gradle の起動が不安定なため、
kotlinc + android.jar(36) + aapt2 compile/link + javac(R) だけの軽量検証を行っている。
Gradle の clean build は Phase D で別途実施し、その結果を区別して記録する。

**smali と突き合わせて確認した要点（jadx を信用しなかった箇所）**

| 箇所 | smali で確認した事実 |
|---|---|
| `ScreenCapturer.pickLevel` | レベル表は **7 行**（先頭 `3600/108000/512`、既定 `0x10000`=65536）。受信側 DecoderCaps の 9 行表（先頭 `1620/40500/256`）とは**別の表**。混同禁止 |
| `ScreenCapturer.splitAnnexB` | ループ条件は `i < data.size`。**jadx は `i >= data.length - 3` と誤表示**していた。4 バイト判定は `i + 3 < data.size` を別途チェック |
| `ScreenCapturer.maybeReportStats` | fps/kbps は Long 演算 → `.toInt()`（`mul-long 0x3b9aca00`） |
| `ScreenCapturer.densityFor` | `mul-float`/`div-float`/`float-to-int` → **Float 演算**。`coerceIn(0x78=120, 0x280=640)` |
| `ScreenCapturer.Companion.fitToLimit` | `(srcW*scale).toInt() / 16 * 16`（Int 除算＝切り捨て） |
| `createVirtualDisplay` flags | `0x10`=16 = `VirtualDisplay.FLAG_OWN_CONTENT_ONLY`。**公開 SDK に無い（@hide）**ためリテラル定数で定義 |
| `MirrorService.onStartCommand` | 既定値 port=`0xbacc`(47820) / maxLongEdge=`0x500`(1280) / fps=`0x1e`(30) / bitrate=`0x9c4`(2500)、floor=`max(0x5dc=1500, bitrate/3)`、`startForeground(…, 0x20)` |
| `MirrorService.onStats` | over 判定は `encodedFps > targetFps * 0xd / 0xa`（*13/10） |
| `SenderClient.negotiate$default` | 既定 timeoutMs = `0x1f40` = **8000** |
| `SenderActivity` | REQ_PROJECTION=`0x3e9`(1001) / REQ_NOTIFICATION=`0x3ea`(1002)、suggestedKbps 初期値=`0xfa0`(4000)、フィールド初期化順 handler→statusTicker→suggestedKbps |

**コンパイラ生成物の差分（機能に影響しない。`VERIFY_sender.txt` に一覧あり）**

- `$$ExternalSyntheticLambda*` は kotlinc 2.2.20 では生成されない（invokedynamic 化）
- 匿名クラスの通し番号がずれる（`setupSpinner$2`→`$1`、`doStart$3,$4`→`$2,$3`）
- `ReceiverDiscovery$search$lambda$7$$inlined$sortedBy$1` → `$lambda$0$$inlined$sortedBy$1..3`
  （復元側は host 順ソート＋重複排除を等価な形で記述したため、インライン展開数が違う）

**未確認事項**

- [未確認] 実機での動作・遅延・FPS（実機が無い。以後も「動いた」とは報告しない）
- [推定] ローカル変数名・改行位置は元ソースと異なる可能性がある（文字列リテラルと挙動は一致させた）
- [推定] `MirrorService.lastReceivedFps` は元コードでも**書き込むだけで読まれていない**（デッドフィールド）。
  忠実に残しているが、Phase D の Lint で警告が出る可能性がある

#### ⚠ 重大な発見: jadx 1.5.6 の `UByte.MAX_VALUE` 誤変換
**`recovery/reports/JADX_ERRORS.md` に詳細記録。**

jadx は Kotlin の `UByte.MAX_VALUE`（内部表現は byte = -1）を int 255 として解釈する Java を出す。
これをそのまま採用すると `b.toInt() and 0xFF` のはずが `b.toInt() and (-1)` になり、
**符号マスクが消えて全ての int フィールドが壊れる。**

差分テストで実際に観測された誤り:
```
readInt(47820)   → 期待 47820,   実際 -52
readInt(8388608) → 期待 8388608, 実際 -8388608
readHeader type=255 → 期待 255,  実際 -1
"payload too large: 8388609" → 実際 "payload too large: -8388607"
```
→ **smali を正として `and 0xFF` で再構成した結果、差分テストは 0 failures になった。**

**Phase C の残り作業での必須ルール:**
ビット演算・符号拡張・型変換を含むコードは **jadx 出力を信用せず必ず smali と突き合わせる。**
特に `and`/`ushr`/`shl`/`toByte()`/`toInt()` が絡む箇所。
（`UByte.MAX_VALUE` の誤出力は `protocol/Framing.java` の 6 箇所のみで、
アプリ側クラスに UByte/UInt/ULong の使用は無いことを確認済み）

#### C-2d. receiver モジュール 🔄 進行中

**ビルド定義（[再構成新規]・値は APK 実測に一致）** ✅

- `receiver/build.gradle.kts` — applicationId `jp.litescreen.receiver` + `applicationIdSuffix ".debug"`、
  versionCode 11 / versionName "1.0.11" + "-debug"、**minSdk 28（チャレンジパッドNext / Android 9）**、
  target 36 / compileSdk 36、`buildConfig = false`、依存は `:protocol` と kotlin-stdlib のみ
- `receiver/src/main/AndroidManifest.xml` — 元 APK と同一の権限・feature・component。
  **Service は 1 つも無い**（受信側は Activity 内でサーバを動かす）。
  `uses-feature android.hardware.touchscreen required="false"` が送信側との違い

**復元済みファイル**

| 復元ファイル | 元 APK の対応クラス | 状態 |
|---|---|---|
| `core/LocalLog.kt` | LocalLog（object, TAG="LiteScreen", MAX_LINES=200） | ✅ コンパイルPASS |
| `core/NetUtil.kt` | NetUtil **+ DiscoveryResponder**（両方 `.source "NetUtil.kt"`＝1ファイル同居） | ✅ コンパイルPASS |
| `core/DecoderCaps.kt` | DecoderCaps **+ DecoderCaps$Probe**（object, 19 メソッド） | ✅ コンパイルPASS |
| `core/H264Decoder.kt` | H264Decoder **+ $callback$1 + $Frame + $Listener + $Companion** | ✅ コンパイルPASS |
| `core/ReceiverServer.kt` | ReceiverServer **+ $Callbacks + $Callbacks$DefaultImpls** | ✅ コンパイルPASS |

検証: `bash scripts/20_compile_module.sh receiver` → **PASS (errors=0 warnings=0 classes=14)**
（R クラス 8 classes も aapt2 で生成できている＝receiver の res/ も link まで通る）

生成クラス名が **元 DEX のクラス名と一致**していることを確認済み:
`H264Decoder` / `H264Decoder$callback$1`（＝`private val callback = object : MediaCodec.Callback()` が
そのまま `$callback$1` になる）/ `H264Decoder$Frame` / `H264Decoder$Listener` / `H264Decoder$Companion`。
差分は `$$ExternalSyntheticLambda*` 4 個（R8/D8 の desugar 生成物。kotlinc 2.2.20 は
invokedynamic を使うため生成されない）のみ＝**挙動差なし**。

**`H264Decoder.kt` 復元で確定させた事実 [APK確認]（すべて smali と突き合わせ済み）**

- Companion 定数 6 個: `TAG="LiteScreen.Decoder"` / `MAX_PENDING=2` / `PTS_MAP_MAX=64` /
  `LATENCY_WINDOW=30` / `RENDER_MARGIN_NS=3_000_000`（0x2dc6c0）/ `DEFAULT_PERIOD_NS=16_666_666`（0xfe502a）
- `Listener.onStats(renderedFps:Int, dropped:Long, pending:Int, decodedFps:Int, avgLatencyMs:Int, skippedFps:Int)`
  （@Metadata d2 の引数名と、`onStats($fps, dropped.get(), $p, $dfps, $lat, $sfps)` の呼び出しで確定）
- **`configure()` の第1引数名は `spd`**（"sps" の誤記と思われるが APK 内の実名。smali `.param p1, "spd"`）
- 描画間引き: `due = lastRenderNs == 0L || now - lastRenderNs >= displayPeriodNs - RENDER_MARGIN_NS`
- `onError` の非対応判定: `errorCode == 0x80001005` **または** message に "0x80001005"（ignoreCase）
  - **`ERROR_UNSUPPORTED` は @hide**（android-34 の `javap` で公開定数が
    ERROR_MALFORMED/OEM/UNSUPPORTED(無)/INSUFFICIENT_RESOURCE/RECLAIMED のみと確認）→ リテラルで復元
- 回復可能エラー時の処理順: `handler.post { listener?.onFatalError("デコーダーエラー（再接続で回復します）: …"); softReset() }`
- `softReset()`: surface 有効 かつ csd 非空なら `releaseCodecOnly()` →
  `lastSize` が 0 超なら `configure(csd[0], csd.getOrNull(1), surface, w, h)`
- `cropSize()`: width/height は `getOrDefault(0)`、crop-left/top は `0`、**crop-right/bottom は `-1`**。
  `right<left || bottom<top || right<0 || bottom<0` なら (w,h)、そうでなければ (right-left+1, bottom-top+1)
- `offer()`: `pending.addLast(Frame(data, ptsUs, isKey, System.nanoTime()))` →
  `while (pending.size > MAX_PENDING)` で「**最初の非キーフレーム**」を破棄（無ければ先頭、それも無ければ break）→
  `dropCount>0` なら `needKeyFrameRequest=true` → `codec?.let { feedNext(it, codecGen) }`、戻り値は dropCount
- `feedNext()`: `freeInputs.poll()` が null なら **return**、pending が空なら index を戻して **return**、
  `getInputBuffer(index)==null` なら `runCatching { queueInputBuffer(index,0,0,0L,0) }`（＝空キュー）
- `rememberArrival` は **非 synchronized**、`recordLatency` の有効範囲 0..60000ms、
  `avgLatencyMs()` はサンプル無しで **-1**
- `consumeKeyFrameRequest()` の間引き **500_000_000ns（0x1dcd6500）**、`keyframeRequests` を加算
- `setDisplayRefreshRate(hz)`: `hz in 20.0f..241.0f` のとき `displayPeriodNs = (1e9 / hz).toLong()`
- `ensureCodecHandler()`: `HandlerThread("LS-Codec", Process.THREAD_PRIORITY_BACKGROUND /* -8 */)`、
  統計スレッドは `Thread(…, "LS-Stats")` + `isDaemon = true` + `Thread.sleep(1000)`
- **`release()` は `keyframeRequests` をリセットしない**（`AtomicLong.set(0)` が 4 回だけ）
- `Frame.equals` は data を **参照比較**（smali に `Arrays.equals` が無い）＝ data class 既定のまま。
  `hashCode`=`Arrays.hashCode`、`toString`=`Arrays.toString`（これらも data class 既定）
- 日本語・非日本語 const-string 51 個を自動照合 → 実質差分 0
  （残るのはコンパイラ生成の `checkNotNullExpressionValue` 用文字列と data class 既定 toString の部品のみ）

**`DecoderCaps.kt` 復元で確定させた事実 [APK確認]（すべて smali と突き合わせ済み）**

- メソッド一覧は smali の 19 個と **1:1 で一致**
  （findDecoder / queryDecoder / isSoftware / videoCaps / capsFor / alignOf / align /
  areSupported / maxFpsFor / probe / diagnose / macroBlocks / requiredLevel /
  pickProfileLevel / pickProfileLevelSingle / profileName / levelName / supportsAdaptive / logSummary）
- `probe()` のシグネチャは **`probe(reqW, reqH, reqFps)` の 3 引数のみ**（scale 引数は無い）。
  縮小倍率 SCALES の 10 段ループは probe() の**内部**にある（smali 5235 行で `sget-object SCALES`）
- `Probe` のコンストラクタ引数順は smali の `.param` 名で確定:
  `(ok, width, height, fps, decoder, detail, profile=0, level=0, adaptive=false)`
- ~~失敗時の fps は 0 ではなく 448（3 経路すべてで `const/16 0x1c0`）~~
  → **【2026-10-29 Phase D で訂正】失敗時の fps は 0。** `0x1c0`(=448) は `Probe` の合成コンストラクタ
    `<init>(ZIIILjava/lang/String;Ljava/lang/String;IIZILkotlin/jvm/internal/DefaultConstructorMarker;)V` の
    **第10引数＝既定値マスク**（bits 6,7,8 = profile/level/adaptive が既定値）。fps は第4引数で `const/4 0x0`。
    根拠: 元 smali `invoke-direct/range {v27 .. v38}` で v31(fps)=0x0, v37(mask)=0x1c0。
    → ソースは `fps = 0` に修正済み（Phase D 修正 #8）。修正前は再構築側に 0x1c0 が 6 個出ていた（元は 3 個）。
- 成功時の `ok` は「通ったか」ではなく **`unchanged`**（＝要求どおりのサイズ・fps でそのまま通ったか）。
  smali: `v33 = (w==reqW && h==reqH && (reqFps<=0 || fps>=reqFps))` が Probe の第1引数に入る
- `areSizeAndRateSupported(IID)` は第3引数が **double** → Kotlin では `fps.toDouble()` が必須
  （Int のままだとコンパイルエラー。実際にエラーが出て修正した）
- `AVCProfileBaseline` 等の定数は **`MediaCodecInfo.CodecProfileLevel`** のもの
  （`CodecCapabilities` 側には無い。jadx 出力を写すと unresolved reference になる → 修正済み）
- LEVEL_TABLE 9 行を `<clinit>` の `filled-new-array` から再デコードして一致確認:
  `{1620,40500,256} {3600,108000,512} {5120,216000,1024} {8192,245760,2048} {8192,245760,4096}
  {8704,522240,8192} {22080,589824,16384} {36864,983040,32768} {36864,2073600,65536}`
- SCALES 10 要素を `:array_0`（.array-data 8）から再デコードして一致確認
- 日本語文字列 **66 個すべて**が smali と一致することをスクリプトで自動照合（差分 0 件）
- **H.264 レベル表は 2 種類ある**（混同注意）: 受信側 DecoderCaps.LEVEL_TABLE は 9 行、
  送信側 ScreenCapturer.pickLevel は 7 行（default 65536）

**このステップで判明した重要事実 [APK確認]**

- **NIC 名の優先度表が送信側と受信側で違う**（smali の分岐をラベル単位で追って確定）
  - 受信側 `NetUtil`: 0=`wlan`,`wifi`,**`ap`** / 2=`rmnet`,`ccmni` / 1=`p2p`,`swlan` / 3=その他
  - 送信側 `NetInfo`: 0=`wlan`,`wifi` / 1=`p2p`,`swlan`,`ap` / 3=`rmnet`,`ccmni`,`cc` / 2=その他
  - → 受信側は "ap" を最優先（自分がソフト AP 側になり得るため）、"cc" は判定していない
- DiscoveryResponder の TAG は **companion object 内**の private const
  （DEX に `DiscoveryResponder$Companion` が存在することから確定）
- DiscoveryResponder の JSON 応答は UTF-8、PROBE/PROBE_ACK 自体は US_ASCII（protocol モジュール）
- `isIPv4`（送信側 NetInfo）は `Integer.parseInt(p) in 0..255` を使う形だった
  （`toIntOrNull` ではない。smali で確認 → 復元コードを修正済み）
- `broadcastTargets`（送信側 NetInfo）は `distinctBy { it.hostAddress }` だった（同上、修正済み）

**`ReceiverServer.kt` 復元で確定させた事実 [APK確認]（smali 4603 行と全数突き合わせ）**

- 公開状態は **プロパティ `isRunning` / `isConnected`**（smali のメソッド名が `isRunning()Z` /
  `isConnected()Z`。**jadx は `getRunning()` / `getConnected()` と誤表示する** → smali 優先）
- `@Volatile` の有無を smali の `.field private volatile` 指定どおりに復元。
  **非 volatile**: `decoder` / `framesSinceStats` / `bytesSinceStats` / `lastStatsNs` /
  `streamLogNs` / `logRendered` / `logDecoded` / `logSkipped` / `logDropped` / `out` / `client` /
  `serverSocket` / `acceptThread` / `readerThread`
- `start(port: Int = Proto.DEFAULT_TCP_PORT)` — `start$default` の `const p1, 0xbacc`（47820）で確定
- handleClient の HELLO 応答 = `intBytes(1)+intBytes(1)+intBytes(0)+intBytes(0xbacd)` を type=1 で送信
  （0xbacd = 47821 = `Proto.DEFAULT_UDP_PORT`）
- ソケット設定（smali 定数を実測）: tcpNoDelay=true / soTimeout=0x3a98=15000ms /
  receiveBufferSize=0x100000=1MB / sendBufferSize=0x10000=64KB / keepAlive=true /
  入力 BufferedInputStream 0x20000=128KB / 出力 DataOutputStream(BufferedOutputStream 64KB)
- スレッド名 **"LS-Accept"** / **"LS-Reader"**（どちらも daemon）
- `acceptLoop`: **SocketException → `return`（ループ脱出）**、IOException → 継続
  （smali: SocketException ハンドラ末尾が `return-void`、IOException ハンドラは `goto :goto_0`）
- `readLoop` の catch 順（smali の catch ハンドラ表どおり）:
  **SocketTimeoutException → ProtocolException → EOFException → IOException → Exception**
  （`ProtocolException : IOException` なので順序が意味を持つ）
- `readLoop` の第3引数 `remote` は **本体で未使用**（smali に p3 参照が `.param` 以外に無い）
- `readLoop` の packed-switch 表（.packed-switch 0x1）から **type 別の実処理の有無**を確定:
  1 HELLO / 2 VIDEO_CONFIG / 3 CODEC_CONFIG / 4 VIDEO / 6 PING / 9 BYE / 11 ERROR / 12 INFO /
  13 PROPOSE が実処理、**5, 7, 8, 10, 14, その他 → default（「未知のメッセージ」で破棄）**
- MSG_VIDEO: `payload.size >= 16` のみ処理。`pts=readLong(0)`, `flags=readInt(8)`,
  `sendMs=readInt(12)`, `isKey = flags and 1 != 0`, 本体 `copyOfRange(16, size)`
- MSG_VIDEO で **`callbacks.currentSurface()` を 2 回呼ぶ**（描画可否判定と初期化判定で別々。
  smali に `invoke-interface currentSurface()` が 2 箇所）→ 復元でも 2 回のまま
- MSG_VIDEO の fatal 通知は `writeMsg(output, MSG_ERROR, fatal.toByteArray(UTF_8))` →
  `closeClient("デコーダー致命的エラー: $fatal")` → `return`
- STATS(type=8): 間隔 `0x3b9aca00`=1e9ns、
  `kbps = (bytesSinceStats * 8 / ((now - lastStatsNs) / 0xf4240)).toInt()`、
  ペイロード順 `fps, kbps, lastSendMs, dropped.toInt(), pending, decoded.toInt()` = 24B
- `callbacks.onStreamStats(fps, kbps)` は **handler.post せず直接呼ぶ**（＝LS-Reader スレッドから）
- 統計ログ: 間隔 `0x12a05f200`=5e9ns、`dtMs = (dtNs/0xf4240).coerceAtLeast(1)`、
  各 fps = `(delta * 0x3e8) / dtMs`、遅延表示は `lat >= 0 ? "${lat}ms" : "-"`
- `tryInitDecoder()`: 既定サイズ `videoWidth>0 ? videoWidth : 0x500(1280)` /
  `videoHeight>0 ? videoHeight : 0x2d0(720)`、`DecoderCaps.areSupported(w, h, 0)` で事前判定、
  失敗時は `decoderInitFailed = true` にして**新しい csd が来るまで再試行しない**
- `decodeText()` = `String(payload, UTF_8).take(0x1000 = 4096)`、失敗時 `"(デコード失敗 N bytes)"`
- `sameCsd()` は `Arrays.equals`（smali に `Ljava/util/Arrays;->equals([B[B)Z`）
- `Callbacks.currentSurface()` の戻り型は **`Surface?`**（@Metadata d1 の戻り型フラグ
  `\u001a\u0004\u0018\u0001`＝nullable ＋ 呼び出し側の null 分岐で確定）
- `Callbacks` で既定実装（空本体）を持つのは **`onSenderInfo` / `onStreamStats` の 2 つだけ**
  （`ReceiverServer$Callbacks$DefaultImpls` に 2 メソッドのみ存在、.line 44 / .line 51）
- `closeClient()` の処理順・`stop()` の処理順を smali の iput/invoke 順どおりに復元
  （stop は `closeClient("stop")` → serverSocket.close → acceptThread.interrupt →
  decoder.release → decoder=null → `LocalLog.i("受信サーバ停止")`）
- 日本語・非日本語 const-string 72 個を自動照合 → 実質差分 0
  （残るのはコンパイラ生成の `"getBytes(...)"` のみ）

**未復元（receiver の残り）**

| 復元予定ファイル | 元 jadx 行数 | 備考 |
|---|---:|---|
| `ReceiverActivity.kt` | 813 | SurfaceView、ログ表示ダイアログ、描画間引き（panel Hz） |

#### C-3. 残りの作業（この順で）

1. ~~`scripts/02_decompile_all.sh`（再現用スクリプト化）を作る~~ ✅ 完了
2. ~~**`sender` モジュール** の復元~~ ✅ 完了（C-2b / C-2c 参照）
3. **`receiver` モジュール** 🔄 進行中（C-2d 参照）← **★次は `ReceiverActivity.kt`（receiver 最後の 1 ファイル）から**
   - 復元順（依存順）: `LocalLog.kt` ✅ → `NetUtil.kt`（`DiscoveryResponder` 同ファイル）✅ →
     `DecoderCaps.kt` ✅ → `H264Decoder.kt` ✅ → `ReceiverServer.kt` ✅ → **`ReceiverActivity.kt`**
   - `receiver/build.gradle.kts` + `receiver/src/main/AndroidManifest.xml`（元 APK から移植）
   - `res/` は変換済み・aapt2 compile PASS 済み（C-2b）
   - **注意: minSdk 28（チャレンジパッドNext / Android 9）互換を必ず守る。**
     受信側は `Theme.Material.NoActionBar.Fullscreen` + 素の `Activity`（AppCompat 不使用）
   - 1 ファイル書くごとに `bash scripts/20_compile_module.sh receiver` で検証する
4. Gradle の clean build: `:protocol:assembleRelease` → `:sender:assembleDebug` → `:receiver:assembleDebug`
   （**RAM 1GB なので必ず1モジュールずつ。OOM したら無制限リトライせず、
     ログを `recovery/build-check/gradle-*.log` に保存してメモリ設定／ビルド粒度を見直す**）
   - Gradle がどうしても動かない場合のフォールバック: `scripts/22_build_apk_manual.sh`
     （kotlinc → d8 → aapt2 link → apksigner の手動パイプライン）を作って検証する
5. 生成 APK と原本 APK を比較（package名 / 署名証明書 / 権限 / versionCode・versionName /
   クラス一覧 / strings / プロトコル互換性）→ `recovery/reports/REBUILD_COMPARISON.md`
   - **再ビルド APK を原本と同一扱いしない。** 署名は必ず別物になるため、
     既存インストール済み端末では uninstall が必要（ユーザーのアプリは勝手に削除しない）

### Phase D — Gradle 実ビルドと照合 ✅ 完了（2026-10-29）→ 詳細は §7
- ✅ protocol の差分テスト（650 checks / 0 failures）→ `recovery/evidence/VERIFY_protocol.txt`
- ✅ DEX 定数の独立照合（37 checks / 0 failures）→ 同上
- ✅ sender の kotlinc コンパイル検証（7 files / errors=0 / warnings=0）→ `recovery/evidence/VERIFY_sender.txt`
- ✅ sender のリソース棚卸し（8 type / 不足 0）→ 同上
- ✅ **Gradle clean build: 3モジュールとも BUILD SUCCESSFUL / exit 0**
      （Kotlin 2.2.20 と 2.0.21 の**両方**で確認。計 17 ビルド → `out/phase-d/APK_BUILD_LOG.md`）
- ✅ 再ビルド APK と元 APK の比較 → **`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`**
      （badging 差分ゼロ / クラス数 65=65, 49=49 / ZIP エントリ 2.0.21 では 41=41, 54=54）
- ✅ 復元バグ **9 件**を発見・修正（§7-3。kotlinc 検証では見つからなかった意味レベルの誤り）
- ✅ 元アプリの Kotlin バージョンを **2.0.21 と確定**（`classes.dex` = stdlib DEX がバイト一致）
- ⏳ Lint(NewApi) の単独実行 / API28 実機互換 / プロトコル単体テストのエラーケース網羅
- ❌ **実機テストは未実施（実機なし）**。遅延・FPS の数値は主張しない

### Phase E — 成果物（未着手）
README, docs/*, scripts/*, SHA256SUMS.txt, LiteScreen-Recovery-Kit.zip

## 2.5 追加で入手したツール
- **kotlinc 2.2.20** を `/opt/tools/kotlinc` に導入（`scripts/01_get_kotlinc.sh`）
  → Gradle を起動せずに単一モジュールを高速検証するために使用
- **platforms;android-36** と **build-tools;36.0.0** を追加導入（APK の compileSdk 36 に合わせた）
- **Gradle 8.13** を `/opt/gradle/dist/gradle-8.13` に展開（Wrapper 生成用）

## 3. 既知の制約・リスク

1. **RAM 1GB（最重要）** — AGP 8.13 + Kotlin は通常 2GB 以上を想定。Gradle が OOM する可能性が高い。
   対策: daemon無効 / -Xmx640m / 非並列 / モジュール単体ビルド。
   **それでも失敗した場合のフォールバック**: Gradle を使わず `javac`(android.jar に対して) + `d8` + `aapt2` + `apksigner` の手動パイプラインで APK を生成し、Gradle プロジェクトは「ソースの正」として納品する（ビルド検証は手動パイプラインで行ったと明記する）。
2. **元の署名鍵は復元不能** — 再ビルドは新規鍵。既存端末へは uninstall → install が必要（`docs/DEVICE_TEST_GUIDE.md` に記載予定）。
3. **実機が接続されていない** — 実機テストは一切実施していない。以後も「実機で成功」とは報告しない。
4. jadx 出力の Java はそのままではコンパイルできない（`Result.m8constructorimpl` 等の合成メソッド、重複した getter 定義を含む）。**Kotlin に書き戻す前提で読むこと。**

## 4. ディレクトリ構成

```
workspace/
├── uploads/                                  # ユーザー添付の指示書2本（原本・変更しない）
├── android-recovery/                         # 前ターンで作った汎用ツール群（参考・残置）
└── LiteScreen-Recovery/                      # ← 本作業のルート
    ├── CHECKPOINT.md                         # このファイル
    ├── recovery/
    │   ├── input-apk/                        # 原本APK 3本 (read-only 444)
    │   ├── evidence/                         # ENVIRONMENT.md, INPUT_APK.md, RAW_badging_signing.txt, jadx-*.log
    │   ├── decompiled/                       # 6ツリー (すべて read-only)
    │   │   ├── sender-v1.0.11-apktool/   sender-v1.0.11-jadx/
    │   │   ├── receiver-v1.0.11-apktool/ receiver-v1.0.11-jadx/
    │   │   └── sender-v1.0.10-apktool/   sender-v1.0.10-jadx/
    │   ├── reports/APK_FORENSICS.md          # ★Phase B の成果物（プロトコル仕様・クラス棚卸し）
    │   ├── reports/JADX_ERRORS.md            # jadx の誤変換と再構成ルール
    │   ├── build-check/                      # 軽量コンパイル検証の出力（classes/ R/ logs/ *.jar）
    │   └── evidence/
    │       ├── ENVIRONMENT.md  INPUT_APK.md  RAW_badging_signing.txt
    │       ├── SMALI_Framing_bitops.txt      # protocol のビット演算を smali で確認した記録
    │       ├── VERIFY_protocol.txt           # ★protocol 検証ログ（650/0, 37/0）
    │       └── VERIFY_sender.txt             # ★sender 検証ログ（コンパイル/リソース/クラス棚卸し）
    ├── LiteScreen-Recovered/                 # ★再構成した Gradle プロジェクト
    │   ├── settings.gradle.kts  build.gradle.kts  gradle.properties
    │   ├── gradlew  gradlew.bat  gradle/wrapper/  local.properties  .gitignore
    │   ├── protocol/  build.gradle.kts + src/main/AndroidManifest.xml
    │   │            + src/main/java/jp/litescreen/protocol/Proto.kt   ✅完成
    │   ├── sender/    build.gradle.kts + src/main/AndroidManifest.xml  ✅完成
    │   │            + src/main/res/（aapt2 ソース形式に変換済み）
    │   │            + src/main/java/jp/litescreen/sender/
    │   │                 ├── SenderActivity.kt   MirrorService.kt
    │   │                 └── core/{StreamConfig,NetInfo,ReceiverDiscovery,
    │   │                           SenderClient,ScreenCapturer}.kt
    │   └── receiver/  ✅ 完成（build.gradle.kts / AndroidManifest.xml /
    │                    res 16ファイル / Kotlin 6ファイル）
    │                    └── src/main/java/jp/litescreen/receiver/
    │                         ├── ReceiverActivity.kt
    │                         └── core/{LocalLog,NetUtil(DiscoveryResponder同梱),
    │                                   DecoderCaps,H264Decoder,ReceiverServer}.kt
    ├── docs/                                 # (空) Phase E で作る
    ├── scripts/
    │   ├── 00_setup_env.sh                   # 環境再構築（実行可能・冪等）
    │   ├── 01_get_kotlinc.sh                 # kotlinc 2.2.20 の取得
    │   ├── 02_decompile_all.sh               # apktool/jadx 再実行（冪等・証拠を保護）
    │   ├── 03_convert_res.py                 # ビルド済み res/ → AAPT2 ソース形式（冪等）
    │   ├── 10_diff_test_protocol.sh          # protocol の差分テスト（650 checks）
    │   ├── 11_verify_dex_constants.py        # DEX 定数の独立照合（37 checks）
    │   ├── 20_compile_module.sh              # ★Gradle を使わない軽量コンパイル検証
    │   ├── 21_verify_res_inventory.py        # ★リソース棚卸し照合（元 APK vs aapt2 生成 R）
    │   ├── 22_verify_const_strings.py        # 文字列照合（ソース水準。参考用）
    │   ├── 23_verify_string_constants_bytecode.py  # ★文字列定数をバイトコード水準で照合
    │   ├── 24_verify_class_members.py        # ★クラス/フィールド/メソッド構成を照合
    │   └── difftest/DiffTest.java            # 差分テストのドライバ
    └── out/                                  # (空) 再ビルドAPK・配布ZIP
```

## 5. 次のセッションで再開する方法

1. `CHECKPOINT.md`（このファイル）と `recovery/reports/APK_FORENSICS.md` を読む
2. ツールが失われていたら
   - `bash scripts/00_setup_env.sh`（apktool / jadx / Android SDK を再導入）
   - `sdkmanager "platforms;android-36" "build-tools;36.0.0"`
   - `bash scripts/01_get_kotlinc.sh`（kotlinc 2.2.20 → `/opt/tools/kotlinc`）
3. 原本 APK が失われていたら `recovery/evidence/INPUT_APK.md` の URL と SHA-256 を使って再取得し、ハッシュを照合
4. 逆コンパイル結果が失われていたら `bash scripts/02_decompile_all.sh`（原本 APK から再生成。既存の証拠は上書きしない）
5. **復元コードの一次資料**
   - 構造・文字列: `recovery/decompiled/*-jadx/sources/jp/litescreen/`
   - **ビット演算・定数・分岐: `recovery/decompiled/*-apktool/smali_classes*/`（jadx を信用しない）**
6. 復元済みコードの確認（3 モジュールとも PASS するはず）
   - `bash scripts/20_compile_module.sh protocol`   → errors=0 warnings=0 classes=3
   - `bash scripts/20_compile_module.sh sender`     → errors=0 warnings=0 classes=24
   - `bash scripts/20_compile_module.sh receiver`   → errors=0 warnings=0 classes=16
7. 忠実度の自動照合（すべて PASS するはず。sender の 24 だけ既知の差で FAIL 表示になる）
   - `python3 scripts/21_verify_res_inventory.py sender` / `receiver`      → PASS
   - `python3 scripts/23_verify_string_constants_bytecode.py sender` / `receiver` → 不足0 余分0
   - `python3 scripts/24_verify_class_members.py receiver`                 → PASS
   - `python3 scripts/24_verify_class_members.py sender`                   → 既知の差のみ（§6-4）
8. **続きは Phase D（Gradle 実ビルド）**。手順は §6-5 に書いた

---

## 6. Phase C 完了記録（2026-10-29）

### 6-1. 復元できたもの（全モジュール完了）

| モジュール | 状態 | コンパイル | 文字列定数 | リソース | クラス構成 |
|---|---|---|---|---|---|
| protocol | ✅ | 3 classes / 0 err / 0 warn | — | — | 差分テスト 650 checks PASS、DEX定数 37 checks PASS |
| sender   | ✅ | 24 classes / 0 err / 0 warn | 元350 / 不足0 / 余分0 | PASS | app 27クラス中24が完全一致（残りは §6-4 の既知差） |
| receiver | ✅ | 16 classes / 0 err / 0 warn | 元343 / 不足0 / 余分0 | PASS | **app 16クラスすべて完全一致（不足0/余分0）** |

- 実行ログ原本: `recovery/evidence/VERIFY_all_2026-10-29.log`
- 検証記録: `recovery/evidence/VERIFY_receiver.txt`（receiver 全体）
            `recovery/evidence/ADDENDUM_sender_deep_verify.txt`（sender の追加検証と修正）
            `recovery/evidence/VERIFY_sender.txt` / `VERIFY_protocol.txt`（前半の記録・未変更）

### 6-2. このフェーズで新たに判明した「ビルド設定」の事実（Phase D で必ず使う）

1. **[APK確認] jvm-default = disable**
   元 APK の DEX に `ReceiverServer$Callbacks$DefaultImpls`（@Metadata k=0x3）がある
   → 元ビルドは旧既定（disable）。`receiver/build.gradle.kts` に
   `freeCompilerArgs += listOf("-Xjvm-default=disable")` を追加済み。
   （kotlinc 2.2.20 のフラグ無し既定も disable 相当。`enable` は unknown mode でエラー）
2. **[APK確認] R フィールドは非 final**（`.field public static <name>:I = 0x7f..`）
   → AGP 8 既定の `android.nonFinalResIds=true` 相当。Gradle 側は既定で一致する見込み。
   検証スクリプトの aapt2 には `--non-final-ids` を追加済み。
3. **[APK確認] Kotlin モジュール名 = `sender_debug`**
   根拠: internal 宣言 `splitAnnexB$sender_debug` と @Metadata d2 末尾 `"sender_debug"`。
   → Phase D で Gradle ビルドした APK を解析し、同じ名前が出るか確認する。
     出ない場合は `kotlin { compilerOptions { moduleName.set("sender_debug") } }` 等で明示する。
   receiver / protocol は internal 宣言が元 APK に無く **観測できない**（[未確認]）。
4. **[APK確認] 元プロジェクトの Kotlin は 2.0.x**（@Metadata mv={2,0,0}）
   復元環境は kotlinc 2.2.20（mv={2,2,0}）。この差はラムダ/匿名クラスの **番号** と
   生成個数に出る（動作・通信には影響しない）。詳細は §6-4。
5. **[APK確認] ERROR_UNSUPPORTED の実値 = -0x7ffefffb = -2147418107 = 0x80010005**
   （旧メモの「0x80001005」は誤り。ただし元 APK のユーザー向け文言は
     "(ERROR_UNSUPPORTED 0x80001005)" なので、文言は原文どおり保持している）

### 6-3. このフェーズで入れた修正（元 APK に合わせた。根拠は各 evidence ファイル）

- receiver: DecoderCaps に未使用定数 `TAG="LiteScreen.Caps"` を追加／
  `FAIL_FPS`(448)・`SO_TIMEOUT_MS`(500)・`ERROR_UNSUPPORTED` を廃止してリテラル化／
  H264Decoder の 6 定数を `private val` → `private const val`（元は ConstantValue 付き）
- sender: SenderClient の negotiated*/lastRttMs/backpressureCount を **関数** 化し
  フィールド名を元どおり（ackOk 等、`*Value` 接尾辞を除去）／
  MirrorService の stateText を `private var` + `fun getStateText()` 化（@JvmStatic 廃止）、
  `state` エイリアス廃止（16箇所を setState() へ）、定数2つをインライン化／
  ScreenCapturer の FLAG_OWN_CONTENT_ONLY インライン化、`?: throw IllegalStateException`
  を `!!` に変更／ReceiverDiscovery の thread から @Volatile 除去
- 検証スクリプト: `-Xjvm-default=disable`、`--non-final-ids`、`-module-name` を追加

### 6-4. 既知の差（意図的 or コンパイラ由来。動作・通信互換には影響しない）

| # | 内容 | 種別 | 根拠 |
|---|---|---|---|
| 1 | `MirrorService.startMirroring()` が復元側に存在（元は onStartCommand 内のラムダ直書き、smali 1318行） | **意図的な差（確定）** | [APK確認] + ユーザー決定 2026-10-29「keep_function」→ 可読性優先で関数を維持。挙動は同一。`recovery/reports/PHASE_D_BUILD_VERIFICATION.md` §6 に記録 |
| 2 | 匿名クラス/ラムダの番号ずれ（setupSpinner$2↔$1、doStart$3/$4↔$2/$3、search$lambda$7↔$0） | コンパイラ差 | [検証済] 親クラス・メソッド・比較キーは一致 |
| 3 | sortedBy 由来 Comparator が元1個↔復元3個 | コンパイラ差 | [検証済] 3個とも同一の getHost() 比較 |
| 4 | `$$ExternalSyntheticLambda*`（sender 16 / receiver 37）が復元 .class に無い | D8 生成物 | Phase D で実 APK 側を確認 |
| 5 | R クラスの `<init>` 可視性(private↔public) と `<clinit>` の有無 | 生成器差 | Phase D で一致する見込み |

### 6-5. ★次の作業（Phase D: Gradle 実ビルド）

1. `LiteScreen-Recovered/` 直下に `settings.gradle.kts` / ルート `build.gradle.kts` /
   `gradle.properties` / `gradle/wrapper/` を作る（AGP 8.13.2 / Kotlin 2.2.20 / JVM 17）
2. メモリ制約（RAM 約1GB）に注意: `org.gradle.jvmargs=-Xmx768m`、`--no-daemon`、
   1モジュールずつビルド。**OOM したら無限リトライせずログを保存して設定を見直す**
   （ユーザー指示）。
3. `./gradlew :receiver:assembleDebug` → 実際の終了コードを確認。
   **exit 0 を見るまで BUILD SUCCESSFUL と報告しない**（ユーザー指示）。
4. 生成 APK を apktool で展開し、元 APK と比較する（ユーザー指示 5）:
   - パッケージ名 / versionCode / versionName / minSdk / targetSdk
   - 権限・feature・activity/service 宣言
   - 署名証明書（**元とは別物になる**。debug keystore は復元不可 →
     既存アプリはアンインストールせず残し、注意事项を報告する）
   - クラス構成（§6-4 の #4 #5 が解消するか）
   - `splitAnnexB$sender_debug` が出るか（§6-2 の 3）
5. 通信互換: 再ビルド sender ↔ **元の** receiver、再ビルド receiver ↔ **元の** sender
   の組み合わせで動くはず（プロトコルは MAGIC/ポート/メッセージ構成とも一致済み）だが、
   **実機が無いため未検証**。この点は必ず「未検証」と明記する。
6. Phase E: `docs/` に復旧手順書・差分一覧・既知の制限をまとめ、
   `out/LiteScreen-Recovery-Kit.zip` を作成する。

---

## 7. Phase D 完了記録（2026-10-29）

> §6-5 に書いた「次の作業（Phase D）」は**すべて実施済み**。
> 詳細レポート: **`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`**（418 行・全数値の根拠つき）。
> 成果物の「今使うもの」: **`out/phase-d/CURRENT_ARTIFACTS.md`**。ビルド全履歴: `out/phase-d/APK_BUILD_LOG.md`（17 行）。

### 7-1. ビルド結果（exit code を確認済み）[検証済]

| 対象 | Kotlin | 結果 | 所要 | ピーク RSS | ログ |
|---|---|---|---|---|---|
| `:protocol:assembleDebug` | 2.2.20 | **BUILD SUCCESSFUL / exit 0** | 44 s | 513 MB | `PHASE_D_final2_protocolassembleDebug.log` |
| `:receiver:assembleDebug` | 2.2.20 | **BUILD SUCCESSFUL / exit 0** | 1 m 34 s | 679 MB | `PHASE_D_final2_receiverassembleDebug.log` |
| `:sender:assembleDebug` | 2.2.20 | **BUILD SUCCESSFUL / exit 0** | 1 m 38 s | 687 MB | `PHASE_D_final2_senderassembleDebug.log` |
| `:receiver:assembleDebug` | 2.0.21 | **BUILD SUCCESSFUL / exit 0** | 1 m 28 s | 669 MB | `PHASE_D_build_k2021_fix89clean_receiver.log` |
| `:sender:assembleDebug` | 2.0.21 | **BUILD SUCCESSFUL / exit 0** | (row 8) | — | `PHASE_D_build_k2021_fix2_senderassembleDebug.log` |

- 環境: Debian 12 / 2 CPU / **MemTotal 1,083 MB・swap 無し** / JDK 17.0.21 / Gradle 8.13 / AGP 8.13.2。
- **OOM 対策（必須）**: `gradle.properties` に `-Xmx384m -XX:MaxMetaspaceSize=224m -XX:ReservedCodeCacheSize=32m
  -XX:MaxDirectMemorySize=48m -XX:+UseSerialGC -XX:MinHeapFreeRatio=5 -XX:MaxHeapFreeRatio=10
  -Dorg.gradle.internal.instrumentation.agent=false`、`parallel=false`, `workers.max=1`。
  これ以前の OOM 失敗ログ（`PHASE_D_build_receiver_attempt3.log`, `PHASE_D_hs_err_pid10607_attempt3.log`）も保存済み。
- **Kotlin 版の切替は `./scripts/31_switch_kotlin_version.sh 2.0.21|2.2.20 [--build]`**（1 行だけ書き換える。自動バックアップ付き）。
  切り替えたら**必ず clean**すること。
- ⚠ **インクリメンタルビルドは APK のパディングが増える**（dex 差 28 B なのに +96 KB になった実測あり・row 13）。
  比較・配布用は必ず clean ビルドを使う。
- ✅ **ビルド再現性あり**: clean ビルドを 2 回 → ソース未変更モジュールは**バイト一致**（protocol AAR, sender APK）。

### 7-2. 元 APK との照合結果 [検証済]

**一致（＝復元が正しいことの証拠）**
- `aapt2 dump badging` の**差分ゼロ**（package 名 / versionCode 11 / versionName 1.0.11-debug / compileSdk 36 /
  minSdk 28 / targetSdk 36 / 権限（receiver 3件・sender 7件）/ label / launchable-activity / debuggable /
  icon パス `res/mipmap-anydpi-v21/ic_launcher.xml` / feature-group / supports-screens）。4 組み合わせすべてで差分なし。
- クラス構成: receiver **65 = 65**、sender **49 = 49**（不足・余分ゼロ。sender の匿名クラス 3 個は連番の振り方だけ違う）。
- 合成ラムダクラスの**形状**: receiver 37/37、sender 14/14 一致。
- `AndroidManifest.xml`（バイナリ AXML）: `aapt2 dump xmltree` の出力が**埋め込み行番号 `(line=NN)` 以外まったく同じ**
  （サイズも receiver 3,212 B で同一）。要素順・属性・値・リソース ID は完全一致。
- ZIP エントリ構成: **2.0.21 ビルドでは完全一致**（receiver 41/41、sender 54/54。欠損0/余分0）。
- **`classes3.dex`（R クラスの DEX）が全 4 ビルドで元とバイト完全一致** → リソース ID の復元は完全。
- **2.0.21 では `classes.dex`（kotlin-stdlib 2,338,632 B / 1036 クラス・アプリのクラスは 0）が元とバイト完全一致**。
  ほか `app-metadata.properties`(57 B → **元も AGP 8.13.2**)、`kotlin/*.kotlin_builtins` 7 個、
  `res/drawable/{bg_card,bg_card_accent,bg_card_inset,bg_pill_status,dot_accent}.xml` も一致（計 15 エントリ）。
- 通常クラスの smali 完全一致数: receiver **23/28**、sender **24/32**（2.0.21）。2.2.20 は 9/28・10/32。

**不一致（＝同一物ではない証拠。ユーザー指示5に対応）**
- **署名証明書**: 元 `bf068d16…fdaf`（v2 のみ）/ 再構築 `7a1fd7bb…27bd`（v1+v2）。**debug keystore は復元不可**。
  → **既存アプリはアンインストールせず残す**。再構築 APK は上書き更新できず
    （`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）、別アプリとして並存インストールになる。
- ZIP エントリ数: 2.2.20 のみ **+1**（`kotlin/concurrent/atomics/atomics.kotlin_builtins`。Kotlin 2.1+ の stdlib 付属物）。
- DEX のサイズ・クラス数（例: receiver `classes.dex` の class_defs 1036 → 1088（2.2.20）/ 1036（2.0.21））。
- APK サイズ: receiver 2,512,825 → 2,616,008（2.2.20）/ **2,512,149（2.0.21, −676 B）**、
  sender 2,521,362 → 2,625,017（2.2.20）/ **2,522,246（2.0.21, +884 B）**。
  ※ **APK サイズは一致度の指標にならない**（パディングで変動する）。判定はエントリ単位ハッシュで行う。

### 7-3. Phase D で発見・修正した復元バグ **9 件**（Phase C の文字列/メンバ検証では検出できなかった）[検証済]

| # | 場所 | 誤 → 正 | 根拠（smali） |
|---|---|---|---|
| 1 | receiver `H264Decoder` | `THREAD_PRIORITY_BACKGROUND`(10) → **`THREAD_PRIORITY_URGENT_DISPLAY`(−8)** | `const/16 v0, -0x8` |
| 2 | receiver `MirrorService` | `FLAG_ACTIVITY_CLEAR_TOP`(0x04000000) → **`FLAG_ACTIVITY_SINGLE_TOP`(0x20000000)** | `const 0x20000000` |
| 3 | sender `SenderClient` | `% 1000L` → **`% 1000000`** | `rem-long … 0xf4240`（**プロトコル互換に直結**） |
| 4 | receiver `H264Decoder` | `contains(…, ignoreCase = true)` → **大文字小文字を区別** | `contains$default` mask `0x2` = 既定値(false) を使用 |
| 5 | protocol `StreamConfig` | `port: Int = 47820` → **既定値なし** | 合成 ctor の mask は `0x4/0x8/0x10` のみ（port ビット無し） |
| 6 | receiver `H264Decoder` | ラムダ 2 個 → **単一ラムダ `markFatal$lambda$10(Listener,String)`** | `.line 402-403` |
| 7 | receiver `ReceiverDiscovery` | callback が `finally` 内 → **`finally` の外** | cleanup ×3 / `sortedWith` ×1（修正でクラス数 49=49） |
| 8 | receiver `DecoderCaps` | 失敗時 `Probe(fps = 448)` → **`fps = 0`** | `0x1c0`(448) は合成 ctor の**既定値マスク**（第10引数）。fps は第4引数 `const/4 0x0`。修正で 0x1c0 が 6→**3 個（元と一致）** |
| 9 | receiver `DecoderCaps.diagnose()` | `${30L * mb}` → **`val fps = 30` + `${fps.toLong() * mb}`** | 元は `const/16 0x1e` → `int-to-long` → `mul-long`。`30L`/`30.toLong()` は 2.0.21 でも `const-wide/16` に畳み込まれる（実測） |

**教訓（次回以降の修正作業で必ず守る）**
1. Android の定数は**名前ではなく値**で確認する（`javap -classpath <android.jar> -constants <class>`）。
2. `$default` / 合成コンストラクタの **mask は「その引数が既定値」の印**。引数の位置は
   `invoke-*/range {vA .. vB}` の**レジスタ並び**で確定する（末尾 2 つは必ず `mask:Int, marker:DefaultConstructorMarker`）。
3. **数値リテラルの型も smali で確認**（`30L` と `変数.toLong()` は生成命令が違う）。
4. 定数の**個数**はレジスタ割り当て（CSE）に依存する。値の意味が同じなら codegen ノイズとして記録するだけで、
   個数を合わせるためにソースを歪めない。
5. jadx 1.5.6 の描画バグ（`UByte.MAX_VALUE` = −1 を 255 と出す 等）→ ビット演算・符号・キャストは必ず smali で裏取り
   （一覧: `recovery/reports/JADX_ERRORS.md`）。
6. `ERROR_UNSUPPORTED`（@hide）= `0x80010005`。ただし元アプリの表示文言 "0x80001005" は**原文のまま保持**。

### 7-4. 元アプリのビルド構成が確定 [検証済]

**Kotlin 2.0.21 + AGP 8.13.2 + Gradle 8.13（compileSdk 36 / minSdk 28 / targetSdk 36）**
根拠: ①`classes.dex`（stdlib DEX）が 2.0.21 ビルドでバイト一致 ②`app-metadata.properties` 一致（AGP 8.13.2）
③`@Metadata mv = {2,0,0}` 一致 ④builtins 7 個一致（2.2.20 では atomics が余分に増える）⑤通常クラス一致数 23/28・24/32。

**プロジェクトの既定は 2.2.20 のまま**（今後の修正を新しいコンパイラで続けるため／ユーザー決定 "try_both"）。
忠実再現・実機検証用には 2.0.21 の成果物も保存済み。切替は §7-1 のスクリプトで 1 行。

### 7-5. 意図的に入れた差（元と違うが意図的・ユーザー決定）

1. `MirrorService.startMirroring()` を**関数として維持**（元は onStartCommand 内ラムダ直書き）→ 決定 "keep_function"。
2. Kotlin 既定版を **2.2.20** にしている（2.0.21 にも 1 行で切替可）。
3. アイコン res を **`mipmap-anydpi-v21`** にしている（元の APK 内パスに合わせるため。`v26` だとパスが変わる）。

### 7-6. 残存する良性差分（動作・通信に影響なし）

- `@Metadata mv`（2.2.20 のみ。2.0.21 では一致）／ラムダの連番（`$lambda$N`, `$r8$lambda$<hash>`, `$$ExternalSyntheticLambdaN`）
- プラットフォーム型の null チェック文言（`findViewById(...)` / `iterator(...)` / `getByName(...)` /
  `createInputSurface(...)` / `getDisplayMetrics(...)`）が再構築側に余分に出る
- `DecoderCaps` の定数個数差（`0x1e`×1, `0x320`×2, `0x500`×2, `0x0`×5 が元だけ）＝レジスタ再利用の差
- 2.2.20 のみ: 定数 `in IntRange` を直接比較に最適化（`0x10000`/`0xffff`）、`run {}` の定数複製、
  `try-finally` 内 `continue` での finally 本体複製（インラインコンパレータ ×3。2.0.21 は `sortedWith` ×1 を共有）
- sender 匿名クラス 3 個の連番、`ScreenCapturer$doStart$3/$4` ↔ `$2/$3` のスロットずれ

### 7-7. このフェーズで作った/更新したもの

- スクリプト: `26_compare_apk.sh`（badging/署名/ZIP/dex）, `27_compare_rebuilt_smali.py`（クラス・ラムダ形状・定数）,
  `28_class_level_consts.py`（クラス単位定数）, `29_smali_ctx.py`（smali 文脈表示）,
  **`30_zip_entry_hashes.py`（エントリ単位 sha256 ← classes.dex/classes3.dex 一致を発見）**,
  **`31_switch_kotlin_version.sh`（Kotlin 版切替 + 再ビルド）**
- レポート: **`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`**（新規）
- 成果物: `out/phase-d/kotlin-2.2.20/`（正式: `*_fix8-9.*` + `SHA256SUMS-current.txt`）,
  `out/phase-d/kotlin-2.0.21/`（同上）, `out/phase-d/CURRENT_ARTIFACTS.md`, `out/phase-d/APK_BUILD_LOG.md`（17 行）
- evidence: `PHASE_D_{apk,smali,class_consts,zip_entries}_compare_*`（`-fix89` = 2.2.20 正式, `-k2021-fix8-9` = 2.0.21 正式,
  `-k2021` / 無印 = 修正#7までの履歴）, ビルドログ + `.rss`（メモリ実測）, `DECODERCAPS_before_fix89.kt.bak`（修正前ソース）
- ⚠ `out/phase-d/receiver-rebuilt-k2021-fix89-apktool/` は**インクリメンタル検証ビルド（row 13）の展開**。
  正式比較には `receiver-rebuilt-k2021-fix8-9-apktool/` を使うこと（対応表は `CURRENT_ARTIFACTS.md`）。

### 7-8. 未検証（絶対に「できた」と報告しないこと）

- **実機動作**（sender キャプチャ → receiver 表示）: 実機が無いため未実施。
- **通信互換**（再構築 sender ↔ 元 receiver / 再構築 receiver ↔ 元 sender）:
  プロトコルの MAGIC `4C 53 43 01`・TCP 47820・UDP 47821・メッセージ 1..14・VIDEO ヘッダ・STATS v2 24 B は
  バイト列レベルで一致確認済み[APK確認]なので**成立するはず**だが、実測はしていない。
- **遅延・FPS の改善**: 未測定。数値を主張しない。
- receiver の API 28 実機（チャレンジパッドNext TAB-A05-BA1）動作: minSdk 28 の宣言一致のみ確認。

### 7-9. ★次の作業（Phase E: 成果物パッケージ）

1. `LiteScreen-Recovered/README.md` — ビルド手順（JDK17 / SDK / Gradle 8.13 / **低メモリ設定**）、
   モジュール構成、Kotlin 版切替、署名の注意（既存アプリを消さない）、既知の差。
2. `out/phase-d/docs/`（現状空）に:
   - `RESTORATION_GUIDE.md`（APK 取得 → 解析 → 復元 → ビルド → 比較の再現手順。スクリプト 00〜31 の使い方）
   - `DIFF_AND_LIMITATIONS.md`（§7-5/§7-6 と署名・実機未検証の限制をまとめたもの）
   - `SIGNING_GUIDE.md`（自分の keystore 作成・署名・保管。debug 鍵は復元不可である旨）
3. `SHA256SUMS.txt`（元 APK 3 件 + 正式成果物 5 件）を生成。
4. **`out/LiteScreen-Recovery-Kit.zip`** を作成（docs / reports / scripts / LiteScreen-Recovered ソース /
   元 APK のハッシュ一覧。APK 実体は大きいため含めるかは要判断）。
5. 最後にユーザーへ「次のセッションで保存すべき 1〜2 ファイル」を案内する
   （候補: `CHECKPOINT.md` と `recovery/reports/PHASE_D_BUILD_VERIFICATION.md`）。

---

## 8. インシデント記録と Phase E 完了（2026-10-29 22:30〜23:20）

### 8-1. ⚠ 作業コンテナの再生成による成果物消失（と、その復元）

Phase D の報告書を書いている途中でコンテナが再生成され、次が失われた:

| 失われたもの | 原因 |
|---|---|
| `out/` 配下の全成果物（APK/AAR、apktool 展開物、`APK_BUILD_LOG.md`、`CURRENT_ARTIFACTS.md`、staging） | **`out` というディレクトリ名がワークスペースのスナップショット対象外**（同: `build`, `dist`, `target`, `node_modules`, `.gradle` など） |
| `LiteScreen-Recovered/*/build/` | 同上（`build`） |
| JDK 17 / Android SDK / Gradle 8.13 / apktool / jadx | ワークスペース外（`/opt`, `/usr/local`） |
| Gradle 依存キャッシュ `/root/.gradle`、debug keystore `/root/.android` | ワークスペース外 |

**無傷だったもの**（＝ワークスペース内の対象外でないパス）: 復元ソース一式、`recovery/evidence/`（120 ファイル）、
`recovery/decompiled/`（元の展開物 6 本）、`recovery/input-apk/`（元 APK 3 本・ハッシュ一致を確認）、
`recovery/reports/`、`scripts/`（18 本）、`CHECKPOINT.md`。

**再発防止（重要）**: 成果物は **`recovery/artifacts/`** に置く。`out/` `build/` `dist/` は絶対に使わない。

### 8-2. 環境の再構築と再ビルド（すべて exit 0）

1. `bash scripts/00_setup_env.sh` → JDK 17.0.21 / apktool 2.11.1 / jadx 1.5.6 / build-tools 34（46 秒）。
2. `sdkmanager "platforms;android-36" "build-tools;36.0.0" "build-tools;35.0.0"` を追加
   （**build-tools 35.0.0 が無いと `:protocol:extractDebugAnnotations` が "Failed to find Build Tools revision 35.0.0" で失敗する**）。
3. Gradle 8.13 を再取得（`/opt/gradle/dist/gradle-8.13`）。
4. `clean`（exit 0, 3m12s：依存の再ダウンロード込み）。
5. 一括ビルドは **カーネル OOM で失敗**（`hs_err_pid2073.log` / `hs_err_pid2167.log` →
   `recovery/evidence/PHASE_E_hs_err_pid*.log`）。→ ユーザー指示どおり**リトライせずビルド粒度を分割**:
   `:<module>:compileDebugKotlin` → `:<module>:assembleDebug` の 2 段階で**すべて BUILD SUCCESSFUL / exit 0**。

| モジュール | Kotlin | 結果 | サイズ(B) | sha256 |
|---|---|---|---|---|
| protocol (AAR) | 2.2.20 | exit 0 / 1m5s | 5,786 | `ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25` ← **消失前とバイト一致** |
| receiver | 2.2.20 | exit 0 / 1m13s + 49s | 2,616,008 | `93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5` |
| sender | 2.2.20 | exit 0 / 1m14s + 45s | 2,625,017 | `4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116` |
| receiver | 2.0.21 | exit 0 / 1m38s + 1m20s | 2,512,149 | `50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408` |
| sender | 2.0.21 | exit 0 / 1m14s + 51s | 2,521,242 | `d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd` |

### 8-3. 消失前の成果物と「内容が同一」であることの証明 [検証済]

消失前に作っていた**エントリ単位 sha256 の証拠**（`recovery/evidence/PHASE_D_zip_entries_*.txt`）が残っていたので、
それと新ビルドを突き合わせた:

| 比較 | 結果 |
|---|---|
| receiver 2.2.20（新 vs 消失前 row 16） | **41/41 エントリ バイト一致**（相違 0） |
| sender 2.2.20（新 vs 消失前 row 17） | **54/54 エントリ バイト一致**（相違 0） |
| receiver 2.0.21（新 vs 消失前 row 14） | **40/40 エントリ バイト一致**（相違 0） |
| sender 2.0.21（新 vs 消失前 row 8） | **53/53 エントリ バイト一致**（相違 0。サイズ −1,004 B は署名ブロック/パディング差） |
| protocol AAR（新 vs 消失前 row 9/15） | **ファイル全体がバイト一致** |

APK 全体の sha256 が変わるのは**署名ブロックだけ**。debug keystore が環境ごとに自動生成されるためで、
証明書は `7a1fd7bb…`（旧環境）→ **`530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847`**（現環境）に変わった。
署名スキームは元 APK と同じ **v2 のみ**（v1/v3/v3.1/v4 = false, signers = 1）。
> 訂正: `PHASE_D_BUILD_VERIFICATION.md` 初版で再構築側を「v1+v2」と書いたが、実測は **v2 のみ**（元と同じ）。同レポート §3.2 に訂正済み。

### 8-4. Phase E の成果物（今回作成）

| ファイル | 内容 |
|---|---|
| `README.md`（129 行） | 目的・構成・セットアップ・ビルド・検証・インストール注意・既知の問題 |
| `docs/PROJECT_OVERVIEW.md`（106 行） | アプリ仕様・プロトコル・確認済み事実（新セッション向け） |
| `docs/RECOVERY_LOG.md`（94 行） | Phase A→E の時系列、発見、変更、検証、インシデント |
| `docs/KNOWN_ISSUES.md`（112 行） | **修正済み 9 件 / 未修正（意図的差・コンパイラ差）/ 未確認（実機）/ 環境の罠** |
| `docs/DEVICE_TEST_GUIDE.md`（123 行） | どの APK をどの端末に、インストール注意、テスト手順、ログタグ、正常/異常の見かた、返してほしいもの |
| `docs/SIGNING_GUIDE.md`（116 行） | 自分の keystore 作成・Gradle 設定・手動署名・GitHub への上げ方 |
| `SHA256SUMS.txt`（45 行） | 入力 APK 3 / 出力 5 / ドキュメント・スクリプト。**`sha256sum -c` で 38 件すべて OK を確認** |
| `recovery/artifacts/APK_BUILD_LOG.md` | ビルド全履歴 row 1〜22 + OOM 失敗 1 件（消失した台帳を再構築し、追記） |
| `recovery/artifacts/CURRENT_ARTIFACTS.md` | 今使う成果物と apktool 展開物の対応表、再現性、ビルド注意 |
| `recovery/artifacts/LiteScreen-Recovery-Kit.zip` | **配布用アーカイブ**（約 7.0 MB / 474 ファイル。ハッシュは `KIT_SHA256.txt`）。ソース・docs・evidence・reports・scripts・元 APK 3 本・再構築 APK/AAR 5 点・Gradle Wrapper を含む。`recovery/decompiled/`（78 MB）と `*/build/`, `.gradle/`, `local.properties` は除外（展開物は `scripts/02_decompile_all.sh` で再生成可能） |

ZIP のハッシュ: `recovery/artifacts/KIT_SHA256.txt`（ZIP 作成後に生成するため ZIP 自身には含まれない）。
ZIP の中身は `unzip -l` で確認できる。整合性は `unzip -t` で検証済み（No errors detected）。

### 8-5. ★次の作業（＝ユーザー側でしかできないこと）

1. **実機テスト**（`docs/DEVICE_TEST_GUIDE.md`）。まず 2.0.21 版を入れ、
   「再構築 sender ↔ 元 receiver」「元 sender ↔ 再構築 receiver」の相互接続を確認する。
   → 成功すれば §7-8 の「未確認」を「検証済」に更新できる。
2. 自分の keystore を作って署名する（`docs/SIGNING_GUIDE.md`）。**既存アプリはアンインストールしない**。
3. テストで問題が出たら logcat（タグ `LiteScreen*`）と受信側のアプリ内ログを保存して持ち帰る。
4. 以後の修正は `LiteScreen-Recovered/` を編集 → §8-2 の 2 段階ビルド → `scripts/26`〜`30` で元 APK と比較、の順で。

### 8-6. 次のセッションで保存すべきファイル（1〜2 つ）

- **`CHECKPOINT.md`**（このファイル。作業の現在地・完了済み検証・次の手順・すべての決定事項）
- **`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`**（ビルドと照合の完全な記録。数値の根拠と証拠ファイル名つき）

この 2 つがあれば、環境が完全に失われていても `README.md` の手順で再構築・再検証に入れる。
