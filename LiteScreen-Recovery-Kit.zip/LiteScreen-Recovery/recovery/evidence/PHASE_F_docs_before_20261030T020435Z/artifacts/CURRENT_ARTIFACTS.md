# 現在有効な成果物（Phase D 完了・環境再構築後 / 2026-10-29 23:00）

**このディレクトリ（`recovery/artifacts/`）が成果物の正式な置き場所。**
以前の置き場所 `out/phase-d/` は **ワークスペースのスナップショット対象外**（`out`, `build`, `dist` などの名前は無視される）
だったため、コンテナ再生成時に消失した。以後この名前を使わないこと。

ビルドの全履歴: `APK_BUILD_LOG.md`（row 1〜22 + 失敗 1 件）。

## 正式成果物（修正 #1〜#9 すべて反映・clean ビルド・exit 0）

### Kotlin 2.2.20（プロジェクトの既定値）→ `kotlin-2.2.20/`
| ファイル | サイズ(B) | sha256 | 台帳 |
|---|---|---|---|
| `protocol-debug_fix8-9.aar` | 5,786 | `ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25` | row 18（row 9/15 と**バイト一致**） |
| `receiver-debug_kotlin2.2.20_fix8-9.apk` | 2,616,008 | `93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5` | row 19 |
| `sender-debug_kotlin2.2.20_fix8-9.apk` | 2,625,017 | `4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116` | row 20 |

### Kotlin 2.0.21（元 APK と同じ版・忠実再現/実機検証の第一候補）→ `kotlin-2.0.21/`
| ファイル | サイズ(B) | sha256 | 台帳 | 元 APK との差 |
|---|---|---|---|---|
| `receiver-debug_kotlin2.0.21_fix8-9.apk` | 2,512,149 | `50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408` | row 21 | **−676 B** |
| `sender-debug_kotlin2.0.21_fix8-9.apk` | 2,521,242 | `d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd` | row 22 | **−120 B** |

各ディレクトリの `SHA256SUMS.txt` は `sha256sum -c` で検証可能。

## 元 APK（`recovery/input-apk/`, chmod 444, 変更禁止・ハッシュ検証済み）
receiver v1.0.11 = 2,512,825 B `384662bc…3473` / sender v1.0.11 = 2,521,362 B `70c0a9a7…9ed4` /
sender v1.0.10 = 2,518,766 B `b070a194…0dfc`

## 環境消失（2026-10-29 22:30 頃）と内容の復元証明

コンテナ再生成により `out/` 配下の成果物とビルドキャッシュ（`*/build/`）、および
ツールチェーン（JDK / Android SDK / Gradle）が失われた。**ソース・evidence・元 APK・レポートは無傷**。

再導入後に再ビルドし、**消失前の成果物と内容が同一であることをエントリ単位ハッシュで証明した**
（証拠: `recovery/evidence/PHASE_D_zip_entries_*.txt` に消失前の全エントリ sha256 が残っていた）:

| 比較 | 結果 |
|---|---|
| receiver 2.2.20（row 19 vs row 16） | 41 エントリすべて**バイト一致**（相違 0） |
| sender 2.2.20（row 20 vs row 17） | 54 エントリすべて**バイト一致**（相違 0） |
| receiver 2.0.21（row 21 vs row 14） | 40/40 エントリ**バイト一致**（相違 0） |
| sender 2.0.21（row 22 vs row 8） | 53/53 エントリ**バイト一致**（相違 0） |
| protocol AAR（row 18 vs row 9/15） | **ファイル全体がバイト一致**（署名を含まないため） |

APK 全体の sha256 が変わるのは **debug keystore が環境ごとに自動生成されるため（署名ブロックのみ差）**。
sender 2.0.21 のサイズが −1,004 B なのも署名ブロック/パディングの差で、**dex・res・manifest は完全に同一**。

## ビルド再現性（重要な確認結果）
- 同一環境内での clean ビルド 2 回 → ソース未変更モジュールは**バイト一致**（protocol AAR, sender APK）。
- **環境を作り直した後でも** protocol AAR は**バイト一致**（row 9 = 15 = 18）。
- APK は署名鍵に依存するため全体ハッシュは変わるが、**署名以外の全エントリは一致**（上表）。
→ 復元プロジェクトのビルドは再現可能。

## ⚠ ビルド時の注意（実測に基づく）
1. **必ず clean ビルドを使う**。インクリメンタルだと zip パディングが増え、内容差 28 B に対して +96 KB 大きくなることがある（row 13）。
2. **RAM 1 GB 環境では一括ビルドが OOM する**（row — の失敗例）。
   `:module:compileDebugKotlin` → `:module:assembleDebug` の**2 段階に分ける**と成功する。
   `gradle.properties` の JVM 設定（`-Xmx384m -XX:MaxMetaspaceSize=224m …`）を変更しないこと。
3. Kotlin 版を切り替えたら**必ず clean**（`scripts/31_switch_kotlin_version.sh <ver> --build` が自動で行う）。
