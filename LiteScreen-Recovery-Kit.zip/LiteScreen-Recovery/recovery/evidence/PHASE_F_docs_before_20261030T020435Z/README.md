# LiteScreen 復旧キット（Recovery Kit）

**署名済みデバッグ APK だけが残っている状態から、Android アプリ「LiteScreen」の開発環境・ソースを復元し、
これからも修正・更新を続けられる Android プロジェクトを再構成した一式。**

元の Kotlin ソースは失われており、**これは APK から逆コンパイルして人手で再構成したコード**です。
「元のソースがそのまま復元された」ものではありません（区別は各ファイルのコメントと `docs/RECOVERY_LOG.md` に明記）。

- 作成日: 2026-10-29
- 入力: `litescreen-sender-v1.0.11-debug.apk` / `litescreen-receiver-v1.0.11-debug.apk`（+ 比較用 sender v1.0.10）
- 結果: **3 モジュール（protocol / receiver / sender）とも Gradle の clean ビルドが BUILD SUCCESSFUL（exit 0）**
- 詳細な検証結果: **`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`**
- 現在の作業状態と次の手順: **`CHECKPOINT.md`**（← 次のセッションではまずこれを読む）

---

## 1. アプリの概要

| | 送信側 (sender) | 受信側 (receiver) |
|---|---|---|
| 想定端末 | REDMAGIC Astra（Android 16 / API 36） | チャレンジパッドNext TAB-A05-BA1（Android 9 / API 28） |
| パッケージ名 | `jp.litescreen.sender.debug` | `jp.litescreen.receiver.debug` |
| 役割 | MediaProjection で画面を取得 → H.264 エンコード → TCP 送信 | TCP 受信 → MediaCodec でデコード → SurfaceView 表示 |
| アプリ名 | LiteScreen 送信 | LiteScreen 受信 |

**Miracast / Smart Cast の受信機ではありません**（APK を解析して確認済み。独自プロトコル・平文・認証なし）。
versionCode 11 / versionName `1.0.11-debug` / compileSdk 36 / minSdk 28 / targetSdk 36。
通信: TCP **47820**（映像・制御）/ UDP **47821**（受信側の存在通知）。MAGIC = `4C 53 43 01`（"LSC"+ver）。

## 2. ディレクトリ構成

```
LiteScreen-Recovery/
├── README.md                     ← これ
├── CHECKPOINT.md                 ← 作業の現在地・完了済み検証・次の手順（最重要）
├── docs/                         ← Phase E のドキュメント
│   ├── PROJECT_OVERVIEW.md         アプリ仕様・確認済み事実（新セッション向け）
│   ├── RECOVERY_LOG.md             何をどの順で実行し、何を見つけ、何を変えたか
│   ├── KNOWN_ISSUES.md             修正済み / 未修正 / 未確認の一覧
│   ├── DEVICE_TEST_GUIDE.md        実機テスト手順とログの見かた
│   └── SIGNING_GUIDE.md            自分の署名鍵の作り方（debug 鍵は復元不能）
├── LiteScreen-Recovered/         ← ★再構成した Android プロジェクト（ビルド可能）
│   ├── gradlew / gradle/wrapper/   Gradle Wrapper 8.13（自己完結）
│   ├── build.gradle.kts            Kotlin プラグイン版はここ 1 行（既定 2.2.20）
│   ├── gradle.properties           RAM 1GB 環境向けの JVM 設定（変更しないこと）
│   ├── protocol/                   通信プロトコル（Android ライブラリ → AAR）
│   ├── receiver/                   受信側アプリ
│   └── sender/                     送信側アプリ
├── recovery/
│   ├── input-apk/                元 APK 3 本（chmod 444・変更禁止）+ SHA256SUMS.txt
│   ├── decompiled/               元 APK の apktool / jadx 展開物（読み取り専用・証拠）
│   ├── evidence/                 検証ログ・比較レポート 120+ 本（すべて保存）
│   ├── reports/                  APK_FORENSICS.md / JADX_ERRORS.md / PHASE_D_BUILD_VERIFICATION.md
│   └── artifacts/                ★ビルド成果物（APK / AAR）と APK_BUILD_LOG.md, CURRENT_ARTIFACTS.md
└── scripts/                      再現可能な検証スクリプト 00〜31
```

> **成果物を `out/`, `build/`, `dist/` などの名前のディレクトリに置かないこと。**
> このワークスペースではそれらの名前がスナップショット対象外で、実際に一度成果物が消失した
> （`recovery/reports/PHASE_D_BUILD_VERIFICATION.md` §2.5）。正式な置き場所は `recovery/artifacts/`。

## 3. セットアップ（環境の再構築）

必要: JDK 17、Android SDK（platform 36 / build-tools 35・36）、Gradle 8.13（Wrapper が自動取得）、
apktool 2.11.1・jadx 1.5.6（APK 解析をやり直す場合のみ）、約 3 GB のディスク、curl / unzip / zip。

```bash
cd LiteScreen-Recovery
bash scripts/00_setup_env.sh          # apt + apktool + jadx + cmdline-tools + build-tools 34
# プロジェクトは compileSdk 36 なので追加で:
sdkmanager "platforms;android-36" "build-tools;36.0.0" "build-tools;35.0.0"
echo "sdk.dir=/opt/android-sdk" > LiteScreen-Recovered/local.properties   # 環境に合わせて書く
```

`scripts/01_get_kotlinc.sh` は kotlinc 単体での轻量検証用（Gradle ビルドには不要）。

## 4. ビルド

```bash
cd LiteScreen-Recovered
./gradlew clean
# RAM 1GB 前後の環境では、一括ビルドが OOM することがある。その場合は 2 段階に分ける:
./gradlew :protocol:assembleDebug                       # → protocol/build/outputs/aar/protocol-debug.aar
./gradlew :receiver:compileDebugKotlin && ./gradlew :receiver:assembleDebug
./gradlew :sender:compileDebugKotlin   && ./gradlew :sender:assembleDebug
# 出力: <module>/build/outputs/apk/debug/<module>-debug.apk
```

- **必ず clean ビルドを使う**（インクリメンタルだと zip パディングが増え、APK が +96KB 大きくなることがある）。
- `gradle.properties` の JVM 設定（`-Xmx384m -XX:MaxMetaspaceSize=224m -XX:+UseSerialGC` ほか）は
  RAM 1,083 MB / swap 無しの環境で実測調整したもの。余裕のあるマシンなら増やしてよい。
- 実測: protocol 44 s〜1 m 5 s / receiver 1 m 34 s（ピーク RSS 679 MB）/ sender 1 m 38 s（687 MB）。

### Kotlin バージョンの切り替え
元 APK は **Kotlin 2.0.21 + AGP 8.13.2** でビルドされていた（`classes.dex` = stdlib DEX がバイト一致して確定）。
プロジェクトの既定は **2.2.20**（今後の開発用）。切り替え:

```bash
./scripts/31_switch_kotlin_version.sh              # 現在値を表示
./scripts/31_switch_kotlin_version.sh 2.0.21 --build   # 切り替えて clean → 3モジュール再ビルド
```

## 5. 検証（元 APK と比べる）

```bash
./scripts/26_compare_apk.sh receiver <再構築APKの絶対パス> [サフィックス]   # badging/署名/ZIP/dex
python3 scripts/27_compare_rebuilt_smali.py receiver                        # クラス・ラムダ形状・定数
python3 scripts/28_class_level_consts.py receiver                          # クラス単位の数値/文字列定数
python3 scripts/30_zip_entry_hashes.py receiver <APK> [サフィックス]        # エントリ単位 sha256
python3 scripts/29_smali_ctx.py <smaliファイル> <行番号>                    # smali の文脈確認
```

27/28 は環境変数 `PHASE_D_VARIANT`（出力名のサフィックス）と `PHASE_D_APK_DIR`（APK の場所）で対象を切り替える。
**展開済みディレクトリがあれば再利用する**ので、別 APK を比べるときはサフィックスを変えること（取り違え防止）。

## 6. インストールと運用上の注意（重要）

1. **再構築 APK の署名は元 APK と別物**（debug keystore は復元不能、しかも環境ごとに自動生成される）。
   → **既存アプリはアンインストールせずに残す**こと。再構築版は上書き更新できず
   （`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）、別アプリとして並存する。
2. 配布・常用するには**自分の keystore を作って署名する**（`docs/SIGNING_GUIDE.md`）。鍵は必ずバックアップ。
3. **実機テストは未実施**（この環境に実機がない）。映像が実際に流れるか、遅延・FPS はどれくらいかは**未検証**。
   `docs/DEVICE_TEST_GUIDE.md` の手順で確認し、結果を `CHECKPOINT.md` に反映すること。
4. 通信は**平文・認証なし**（元アプリの設計どおり）。同一 LAN 内の前提。公開ネットワークで使わない。

## 7. 既知の問題

`docs/KNOWN_ISSUES.md` に **修正済み（9 件）/ 未修正（コンパイラ由来の良性差分）/ 未確認（実機関連）** を
分けて一覧化してある。復元作業で踏んだ罠（jadx の描画バグ、`$default` マスクの読み方など）も同じファイルに記録した。
