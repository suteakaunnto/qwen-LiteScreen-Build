# 入力APK 保全記録 (Phase A) — 2026-10-29T08:36:10+00:00

取得元: https://raw.githubusercontent.com/suteakaunnto/qwen-LiteScreen-Build/main/
取得方法: curl -sSL --retry 3

| ファイル | サイズ | SHA-256 | Git blob SHA | マスタープロンプト記載サイズ | 一致 |
|---|---:|---|---|---:|:--:|
| `litescreen-receiver-v1.0.11-debug.apk` | 2512825 | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` | `f03232dba23884647be92a6f57f6922a82d58a01` | 2512825 | OK |
| `litescreen-sender-v1.0.10-debug.apk` | 2518766 | `b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc` | `ea8c1128497d0ab3debafb5bd99ec81c6e15a5c8` | 2518766 | OK |
| `litescreen-sender-v1.0.11-debug.apk` | 2521362 | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` | `54df19e4013ea3f371491499ea38a3aee47e4257` | 2521362 | OK |

## 照合結果
- sender v1.0.11 の Git blob SHA = `54df19e4013ea3f371491499ea38a3aee47e4257` → マスタープロンプト記載値と**一致**（この環境で検証済み）
- 3ファイルすべてサイズが記載値と一致。ZIP magic `PK\x03\x04` を確認（HTMLエラーページではない）
- GitHub API `/contents/` の結果、リポジトリ直下は上記3 APKのみ。**ソースコードは含まれていない**ことを確認

## 保全措置
- 原本は読み取り専用 (chmod 444) に設定。以後このディレクトリのファイルを上書きしない。
- 解析はすべてコピーまたは読み取り専用参照で行う。

## ファイル種別
litescreen-receiver-v1.0.11-debug.apk: magic=b'PK\x03\x04' size=2512825
litescreen-sender-v1.0.10-debug.apk: magic=b'PK\x03\x04' size=2518766
litescreen-sender-v1.0.11-debug.apk: magic=b'PK\x03\x04' size=2521362
