// LiteScreen 復元プロジェクト — ルートビルドスクリプト
// 注意: このファイル群（build.gradle.kts / settings.gradle.kts / gradle.properties /
//       各モジュールの build.gradle.kts / gradle wrapper）は APK には含まれておらず、
//       復旧作業で新規に作成したものです（[再構成新規]）。
plugins {
    id("com.android.application") version "8.13.2" apply false
    id("com.android.library")     version "8.13.2" apply false
    id("org.jetbrains.kotlin.android") version "2.2.20" apply false
}
