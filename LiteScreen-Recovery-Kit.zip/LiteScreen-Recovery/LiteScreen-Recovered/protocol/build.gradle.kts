// [再構成新規] このビルドスクリプトは APK に含まれていなかったため復旧作業で作成した。
// ただし namespace / compileSdk / minSdk / targetSdk / AGPバージョン / AndroidX不使用 は
// すべて APK から確認した値に合わせてある（recovery/reports/APK_FORENSICS.md §2, §5 参照）。
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "jp.litescreen.protocol"
    compileSdk = 36

    defaultConfig {
        minSdk = 28
        consumerProguardFiles()
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = false
    }

    lint {
        abortOnError = true
        warningsAsErrors = false
    }
}

// Kotlin コンパイラ設定。
// [再構成新規] AGP 8.x + KGP 2.x では android { kotlinOptions { } } は非推奨のため、
//   トップレベルの kotlin { compilerOptions { } } を使う（機能は同一）。
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    // APK の DEX に androidx.* が 1 件も無かったため、依存は kotlin-stdlib のみ。
    testImplementation("junit:junit:4.13.2")
}
