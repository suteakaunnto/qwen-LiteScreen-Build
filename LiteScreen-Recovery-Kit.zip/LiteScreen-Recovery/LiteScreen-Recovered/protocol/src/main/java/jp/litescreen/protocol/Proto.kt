/*
 * Proto.kt — LiteScreen 共有プロトコル定義
 *
 * ■ 出典と信頼度
 *   [APKから復元] litescreen-sender-v1.0.11-debug.apk および
 *                 litescreen-receiver-v1.0.11-debug.apk の classes2.dex に含まれる
 *                 jp.litescreen.protocol.{Proto, Framing, ProtocolException} を
 *                 jadx 1.5.6 で逆コンパイルした Java 出力から Kotlin へ書き戻したもの。
 *
 *   両 APK のこの3クラスは jadx 出力が diff で完全一致であり（=同一ソースからビルドされている）、
 *   難読化もかかっていないため、定数値・分岐・ビット演算はすべて DEX から 1:1 で確定できる。
 *   → このファイルは復元コードの中で最も信頼度が高い。
 *
 * ■ 元ソースとの差異（復元できないもの）
 *   - コメント、空行、一部のローカル変数名は失われている（jadx が付けた名前を維持）
 *   - `KotlinVersion.MAX_COMPONENT_VALUE` として現れていた箇所は 0xFF 定数だったはずなので
 *     可読性のため 0xFF と書いた（生成バイト列は同一）
 *   - 元の Kotlin の型注釈・可視性修飾子は @Metadata の d2 配列から復元した
 *
 * ■ 検証
 *   protocol/src/test/.../ProtoFramingTest.kt に、この実装が APK 内の
 *   readHeader/writeHeader/intBytes/readInt/longBytes/readLong と
 *   ビット単位で一致することを確認する単体テストがある。
 */
package jp.litescreen.protocol

import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import kotlin.text.Charsets

/**
 * フレームMagic・メッセージID・既定ポートなどのプロトコル定数。
 *
 * フレーム形式（全メッセージ共通、HEADER_SIZE = 8 バイト）:
 * ```
 *   offset 0..3 : MAGIC (0x4C 0x53 0x43 0x01 = "LSC" + VERSION)
 *   offset 4    : type  (uint8, MSG_*)
 *   offset 5..7 : payloadLength (uint24, ビッグエンディアン)
 *   offset 8..  : payload
 * ```
 */
object Proto {
    /** "LSC" + 0x01。[APK確認] `byteArrayOf(76, 83, 67, 1)` */
    val MAGIC: ByteArray = byteArrayOf(0x4C, 0x53, 0x43, 0x01)

    /** プロトコルバージョン。HELLO の先頭 int32 に入る。 */
    const val VERSION = 1

    const val HEADER_SIZE = 8

    /** payloadLength は 3 バイトなので理論上限は 0xFFFFFF だが、実装は 8 MiB で制限している。 */
    const val MAX_PAYLOAD = 8_388_608

    /** MSG_ERROR / MSG_INFO のテキスト上限（バイト）。超過分は切り詰める。 */
    const val MAX_TEXT = 4096

    const val DEFAULT_TCP_PORT = 47820
    const val DEFAULT_UDP_PORT = 47821

    // ---- メッセージ種別 -------------------------------------------------
    const val MSG_HELLO = 1
    const val MSG_VIDEO_CONFIG = 2
    const val MSG_CODEC_CONFIG = 3
    const val MSG_VIDEO = 4
    const val MSG_KEYFRAME_REQUEST = 5
    const val MSG_PING = 6
    const val MSG_PONG = 7
    const val MSG_STATS = 8
    const val MSG_BYE = 9
    const val MSG_AUDIO_UNSUPPORTED = 10
    const val MSG_ERROR = 11
    const val MSG_INFO = 12
    const val MSG_PROPOSE = 13
    const val MSG_PROPOSE_ACK = 14

    /** MSG_VIDEO の flags: キーフレーム */
    const val FLAG_KEY_FRAME = 1

    /** MSG_VIDEO の flags: コーデック設定（現物では未使用。CSD は MSG_CODEC_CONFIG で送る） */
    const val FLAG_CODEC_CONFIG = 2

    /**
     * MSG_STATS の v2 ペイロード長。
     * int32 x6 = 24 バイト: recvFps, recvKbps, lastSendMs, dropped, pending, decoded
     * 受信側は常に 24 バイト書き、送信側は len>=24 なら v2、len>=8 なら旧式として読む。
     */
    const val STATS_V2_SIZE = 24

    /**
     * MSG_PROPOSE_ACK の v2 ヘッダ長。
     * int32 x6 = 24 バイト: ok, width, height, fps, profile, level。以降は UTF-8 の detail 文字列。
     * 送信側は len>=24 なら v2、len>=16 なら profile/level 無しの旧式として読む。
     */
    const val PROPOSE_ACK_V2_HEADER = 24

    /**
     * MediaCodec の ERROR_UNSUPPORTED を int にした値。
     * [APK確認] `-2147414011`。受信側 H264Decoder は CodecException の errorCode と
     * メッセージ文字列 "0x80001005" の両方で判定している。
     */
    const val CODEC_ERROR_UNSUPPORTED = -2147414011

    /** UDP 探索のリクエスト（素の UDP ペイロード、11 バイト ASCII）。 */
    val PROBE: ByteArray = "LITESCREEN?".toByteArray(Charsets.US_ASCII)

    /**
     * UDP 探索の応答プレフィックス（11 バイト ASCII）。
     * 受信側はこの直後に JSON(UTF-8) を連結して返す:
     * `{"proto":1,"app":"LiteScreen Receiver","tcpPort":47820,"android":28}`
     */
    val PROBE_ACK: ByteArray = "LITESCREEN!".toByteArray(Charsets.US_ASCII)
}

/**
 * フレームの読み書きと、ペイロード内の整数エンコード（すべてビッグエンディアン）。
 *
 * [APK確認] 送信側 SenderClient / 受信側 ReceiverServer の両方がこの object のみを使って
 * フレームを構成しており、書き込みは必ず 1 スレッド + writeLock に集約されている。
 */
object Framing {

    /** 8 バイトヘッダを書いて flush はしない。 */
    @Throws(IOException::class)
    fun writeHeader(out: OutputStream, type: Int, payloadLength: Int) {
        val h = byteArrayOf(
            Proto.MAGIC[0], Proto.MAGIC[1], Proto.MAGIC[2], Proto.MAGIC[3],
            type.toByte(),
            ((payloadLength ushr 16) and 0xFF).toByte(),
            ((payloadLength ushr 8) and 0xFF).toByte(),
            (payloadLength and 0xFF).toByte()
        )
        out.write(h)
    }

    /** ヘッダ + ペイロードを書いて flush する。空ペイロードでもヘッダは書く。 */
    @Throws(IOException::class)
    fun writeMessage(out: OutputStream, type: Int, payload: ByteArray) {
        writeHeader(out, type, payload.size)
        if (payload.isNotEmpty()) out.write(payload)
        out.flush()
    }

    /**
     * 8 バイトヘッダを読み、(type, payloadLength) を返す。
     *
     * [APK確認] MAGIC の検査は先頭 3 バイトのみ。4 バイト目（バージョン）は検査していない。
     * payloadLength が MAX_PAYLOAD を超える場合は [ProtocolException]。
     */
    @Throws(IOException::class)
    fun readHeader(input: InputStream): Pair<Int, Int> {
        val h = ByteArray(Proto.HEADER_SIZE)
        readFully(input, h, 0, Proto.HEADER_SIZE)
        if (h[0] != Proto.MAGIC[0] || h[1] != Proto.MAGIC[1] || h[2] != Proto.MAGIC[2]) {
            throw ProtocolException("magic mismatch")
        }
        val type = h[4].toInt() and 0xFF
        val len = ((h[5].toInt() and 0xFF) shl 16) or
            ((h[6].toInt() and 0xFF) shl 8) or
            (h[7].toInt() and 0xFF)
        if (len < 0 || len > Proto.MAX_PAYLOAD) {
            throw ProtocolException("payload too large: $len")
        }
        return type to len
    }

    /** len バイトのペイロードを読む。len==0 なら空配列。 */
    @Throws(IOException::class)
    fun readPayload(input: InputStream, len: Int): ByteArray {
        val b = ByteArray(len)
        if (len > 0) readFully(input, b, 0, len)
        return b
    }

    /**
     * 正確に len バイト読む。ストリーム末端に達したら [ProtocolException]。
     *
     * [APK確認] 例外型は IOException ではなく ProtocolException("unexpected end of stream")。
     * 受信側 ReceiverServer は IOException のメッセージに "unexpected end of stream" が
     * 含まれるかどうかで切断理由の文言を切り替えているため、**この文言は変更してはいけない**。
     */
    @Throws(IOException::class)
    fun readFully(input: InputStream, buf: ByteArray, off: Int, len: Int) {
        var done = 0
        while (done < len) {
            val n = input.read(buf, off + done, len - done)
            if (n < 0) throw ProtocolException("unexpected end of stream")
            done += n
        }
    }

    /** int32 → ビッグエンディアン 4 バイト。 */
    fun intBytes(v: Int): ByteArray = byteArrayOf(
        ((v ushr 24) and 0xFF).toByte(),
        ((v ushr 16) and 0xFF).toByte(),
        ((v ushr 8) and 0xFF).toByte(),
        (v and 0xFF).toByte()
    )

    /** int64 → ビッグエンディアン 8 バイト。 */
    fun longBytes(v: Long): ByteArray = byteArrayOf(
        ((v ushr 56) and 0xFF).toByte(),
        ((v ushr 48) and 0xFF).toByte(),
        ((v ushr 40) and 0xFF).toByte(),
        ((v ushr 32) and 0xFF).toByte(),
        ((v ushr 24) and 0xFF).toByte(),
        ((v ushr 16) and 0xFF).toByte(),
        ((v ushr 8) and 0xFF).toByte(),
        (v and 0xFF).toByte()
    )

    /** ビッグエンディアン 4 バイト → int32。 */
    fun readInt(b: ByteArray, off: Int): Int =
        ((b[off].toInt() and 0xFF) shl 24) or
            ((b[off + 1].toInt() and 0xFF) shl 16) or
            ((b[off + 2].toInt() and 0xFF) shl 8) or
            (b[off + 3].toInt() and 0xFF)

    /** ビッグエンディアン 8 バイト → int64。実装は readInt を2回使う形になっていた。 */
    fun readLong(b: ByteArray, off: Int): Long =
        ((readInt(b, off).toLong() and 0xFFFFFFFFL) shl 32) or
            (readInt(b, off + 4).toLong() and 0xFFFFFFFFL)
}

/**
 * プロトコル違反（magic 不一致、payload 長超過、ストリーム末端）。
 *
 * [APK確認] `ProtocolException.kt` ではなく **`Proto.kt` 内に定義されていた**
 * （jadx の "compiled from: Proto.kt" が3クラスすべてに付いている）。
 * java.net.ProtocolException ではなく独自クラス。
 */
class ProtocolException(message: String) : IOException(message)

// 補足: 元の宣言は `class ProtocolException(message: String) : IOException(message)` で、
// jadx 出力が `public final class` だったことから final（= Kotlin の通常の class）で確定。
