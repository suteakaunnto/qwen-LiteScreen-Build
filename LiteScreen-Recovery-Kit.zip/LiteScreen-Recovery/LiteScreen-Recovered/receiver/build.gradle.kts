/*
 * receiver/build.gradle.kts — 受信側アプリ（TCP 受信 → H.264 デコード → SurfaceView 描画）
 *
 * [再構成新規] このビルドスクリプトは APK に含まれていなかったため復旧作業で作成した。
 * ただし以下の値は **APK から実測して一致させている**（recovery/evidence/RAW_badging_signing.txt、
 * recovery/reports/APK_FORENSICS.md §2 / §5 参照）:
 *
 *   [APK確認] androidGradlePluginVersion=8.13.2
 *   [APK確認] applicationId = jp.litescreen.receiver.debug
 *   [APK確認] versionCode   = 11
 *   [APK確認] versionName   = 1.0.11-debug
 *   [APK確認] minSdk 28 / targetSdk 36 / compileSdk 36
 *             → 実機は **チャレンジパッドNext (TAB-A05-BA1) / Android 9 = API 28**。
 *               minSdk 28 は絶対に下げないこと（上げると実機に入らなくなる）。
 *   [APK確認] BuildConfig クラスが DEX に存在しない → buildConfig = false
 *   [APK確認] R クラスのフィールドが非 final → android.nonFinalResIds=true（gradle.properties）
 *   [APK確認] DEX に androidx.* が 1 件も無い → 依存は kotlin-stdlib と :protocol のみ。
 *             受信側は `android.app.Activity` + `Theme.Material.NoActionBar.Fullscreen`
 *             （AppCompatActivity ではない）なので、AppCompat 依存を追加してはいけない。
 *   [APK確認] assets/ なし、native library なし
 *
 * ■ 署名について
 *   送信側と同じ（sender/build.gradle.kts の冒頭コメントを参照）。
 *   元の debug 鍵は復元できないため、再ビルド APK は別の署名になり、
 *   既存インストール済み端末では uninstall が必要になる。
 */
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties().apply {
    if (keystorePropsFile.exists()) keystorePropsFile.inputStream().use { load(it) }
}

android {
    namespace = "jp.litescreen.receiver"
    compileSdk = 36

    defaultConfig {
        // debug ビルドタイプで ".debug" が付与され、最終的に jp.litescreen.receiver.debug になる
        applicationId = "jp.litescreen.receiver"
        minSdk = 28          // ← チャレンジパッドNext (Android 9)。下げないこと
        targetSdk = 36
        versionCode = 11
        versionName = "1.0.11"
    }

    signingConfigs {
        if (keystorePropsFile.exists()) {
            create("recovered") {
                storeFile = file(keystoreProps.getProperty("keystoreFile"))
                storePassword = keystoreProps.getProperty("keystorePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isMinifyEnabled = false
            if (keystorePropsFile.exists()) {
                signingConfig = signingConfigs.getByName("recovered")
            }
        }
        release {
            isMinifyEnabled = false
            if (keystorePropsFile.exists()) {
                signingConfig = signingConfigs.getByName("recovered")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = false   // [APK確認] BuildConfig が DEX に無い
        viewBinding = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    lint {
        abortOnError = true
        warningsAsErrors = false
    }
}

// Kotlin コンパイラ設定。
// [再構成新規] AGP 8.x + KGP 2.x では android { kotlinOptions { } } は非推奨のため、
//   トップレベルの kotlin { compilerOptions { } } を使う（機能は同一）。
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        // [APK確認] 元 APK の DEX には ReceiverServer$Callbacks$DefaultImpls
        //   (@Metadata k=0x3, smali_classes4/.../core/) が存在する。
        //   = 元ビルドは jvm-default 旧既定(disable)でコンパイルされている。
        //   KGP の既定値に依存せずクラス一覧を元 APK と一致させるため明示指定。
        //   ※将来 Kotlin が本オプションを削除した場合は all-compatibility で代替可
        //     (minSdk 28 では DefaultImpls 有無による動作差は無い)。
        freeCompilerArgs.add("-Xjvm-default=disable")
    }
}

dependencies {
    implementation(project(":protocol"))
}
