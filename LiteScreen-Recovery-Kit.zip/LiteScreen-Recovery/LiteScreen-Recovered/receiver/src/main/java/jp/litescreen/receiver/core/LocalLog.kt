/*
 * LocalLog.kt — 画面に表示するためのリングバッファ付きログ
 *
 * ■ 出典: [APKから復元] litescreen-receiver-v1.0.11-debug.apk classes4.dex
 *         jp.litescreen.receiver.core.LocalLog（元ファイル LocalLog.kt）
 *
 * ■ 確定情報（すべて DEX / smali から）
 *   - `object`（DEX: INSTANCE フィールド + private constructor、@Metadata k=1）
 *   - TAG = "LiteScreen"、MAX_LINES = 0xc8 = 200
 *   - lines: kotlin.collections.ArrayDeque<String>（static final）
 *   - fmt: SimpleDateFormat("HH:mm:ss", Locale.US)（static final）
 *   - i / w / e はすべて `@Synchronized`（smali の ACC_SYNCHRONIZED）
 *   - w(msg, t: Throwable? = null) / e(msg, t: Throwable? = null)
 *     → DEX に `w$default` / `e$default`（bitmask 2）が存在することから既定値 null を確認
 *   - 例外付きの表示文字列は "msg / SimpleName: message"
 *   - push() は "HH:mm:ss L msg" を末尾に追加し、200 行を超えたら先頭から削除
 *   - snapshot() は空なら ""、そうでなければ "\n" 区切り
 *
 * ■ 用途
 *   受信側アプリは logcat を見られない端末（チャレンジパッドNext）での利用を想定し、
 *   画面内のログ表示（ReceiverActivity の「ログ」ボタン → dialog_log）にこれを使う。
 */
package jp.litescreen.receiver.core

import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LocalLog {

    private const val TAG = "LiteScreen"
    private const val MAX_LINES = 200

    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun i(msg: String) {
        push("I", msg)
        Log.i(TAG, msg)
    }

    @Synchronized
    fun w(msg: String, t: Throwable? = null) {
        push("W", if (t == null) msg else "$msg / ${t.javaClass.simpleName}: ${t.message}")
        Log.w(TAG, msg, t)
    }

    @Synchronized
    fun e(msg: String, t: Throwable? = null) {
        push("E", if (t == null) msg else "$msg / ${t.javaClass.simpleName}: ${t.message}")
        Log.e(TAG, msg, t)
    }

    private fun push(level: String, msg: String) {
        lines.addLast("${fmt.format(Date())} $level $msg")
        while (lines.size > MAX_LINES) lines.removeFirst()
    }

    /** 溜まっているログを新しい順ではなく**古い順**に改行区切りで返す。 */
    @Synchronized
    fun snapshot(): String = if (lines.isEmpty()) "" else lines.joinToString("\n")

    @Synchronized
    fun clear() = lines.clear()
}
