package jp.litescreen.receiver

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import jp.litescreen.protocol.Proto
import jp.litescreen.receiver.core.DecoderCaps
import jp.litescreen.receiver.core.DiscoveryResponder
import jp.litescreen.receiver.core.H264Decoder
import jp.litescreen.receiver.core.LocalLog
import jp.litescreen.receiver.core.NetUtil
import jp.litescreen.receiver.core.ReceiverServer
import java.util.Locale
import kotlin.math.min

/**
 * 受信側アプリの唯一の Activity。
 * SurfaceView に映像を描画し、[ReceiverServer] / [H264Decoder] のコールバックを受けて表示を更新する。
 *
 * ## 復元について [APK確認]
 * `litescreen-receiver-v1.0.11-debug.apk` → `classes5.dex` の
 * `jp.litescreen.receiver.ReceiverActivity`（jadx 813 行 / smali 3243 行）から復元。
 * **定数・分岐・呼び出し順は smali と全数突き合わせ済み。** 主な確認項目:
 *
 * - 継承は **素の `android.app.Activity`**（AppCompat 不使用）。実装インターフェースは
 *   `ReceiverServer.Callbacks`, `H264Decoder.Listener`, `SurfaceHolder.Callback` の 3 つ（smali の
 *   `.implements` 順どおり）
 * - View フィールドはすべて **`lateinit var`**（smali に
 *   `Intrinsics.throwUninitializedPropertyAccessException("…")` がある 10 個）
 * - `handler = Handler(Looper.getMainLooper())`（フィールド初期化子）
 * - `onCreate` の `window.addFlags(0x80)` = **`FLAG_KEEP_SCREEN_ON`**（128）
 * - `enterImmersive()` は `root.systemUiVisibility = 0x1706`（= 5894）
 *   = IMMERSIVE_STICKY(0x1000) | LAYOUT_STABLE(0x100) | LAYOUT_HIDE_NAVIGATION(0x200) |
 *   LAYOUT_FULLSCREEN(0x400) | HIDE_NAVIGATION(0x2) | FULLSCREEN(0x4)
 * - `portText.text = getString(R.string.label_port, Proto.DEFAULT_TCP_PORT)`
 *   （smali: `const v3, 0xbacc` = 47820 を `Integer.valueOf` して可変長引数で渡す）
 * - `log_button` / `diag_button` は **TextView**（layout 側も TextView。`check-cast` で確定）
 * - IP 長押しコピー: `getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager`（非nullキャスト）、
 *   `ClipData.newPlainText("LiteScreen IP", ip)`、
 *   `Toast.makeText(this, "IPをコピーしました: $ip", Toast.LENGTH_SHORT)`、戻り値は常に `true`
 * - `getDisplayRefreshHz()`: `DisplayManager.getDisplay(0)?.refreshRate ?: 60.0f` を
 *   **20.0f..241.0f の範囲ならそのまま、範囲外／例外なら 60.0f**
 *   （H264Decoder.setDisplayRefreshRate の許容範囲と一致）
 * - **`applyVideoSize()` の scale 計算は「浮動小数点除算」**
 *   （smali: `int-to-float` → `div-float` → `Math.min(FF)F`）。
 *   **jadx は `Math.min(availW / w, availH / h)`（整数除算）と誤表示する** → smali 優先。
 *   整数除算で写すと scale が常に 0 か 1 になり映像が 1x1 px になる致命的バグになる
 * - `applyVideoSize()`: `availW <= 0 || availH <= 0` なら `root.post { applyVideoSize(w, h) }` して return。
 *   `targetW/H = (w/h * scale).toInt().coerceAtLeast(1)`、
 *   lp の幅か高さが変わるときだけ `videoContainer.layoutParams = lp`、
 *   最後に必ず `videoContainer.visibility = View.VISIBLE`
 * - `stopReceiver(reason)` の処理順（smali の invoke 順どおり）:
 *   `server?.stop()` → server=null → `decoder?.release()` → **`decoder?.setListener(null)`** →
 *   decoder=null → `discovery?.stop()` → discovery=null → surfaceValid=false → videoW=0 → videoH=0 →
 *   `handler.post { statsText.visibility = GONE; videoContainer.visibility = INVISIBLE }` →
 *   `LocalLog.i("受信停止 ($reason)")`
 * - `surfaceCreated`: surfaceValid=true → `LocalLog.i("Surface 生成")` →
 *   **`if (server?.isConnected == true) server?.onSurfaceRecreated()`**
 * - `surfaceDestroyed`: surfaceValid=false → `LocalLog.i("Surface 破棄")` → `decoder?.release()` →
 *   `videoContainer.visibility = View.INVISIBLE`
 * - `currentSurface()` は **`surfaceValid` が false なら null**、そうでなければ
 *   `surfaceView.holder.surface`
 * - `onStats()` の表示書式（smali の const-string をそのまま転記。**半角スペース 2 個区切り**）:
 *   `"%dx%d  受信:%dfps  デコード:%dfps  描画:%dfps  スキップ:%dfps  遅延:%s  待ち:%d  破棄:%d"` を
 *   `String.format(Locale.US, …, videoW, videoH, receivedFps, decodedFps, renderedFps, skippedFps, lat, pending, dropped)`
 *   （9 引数。`lat = if (avgLatencyMs >= 0) "${avgLatencyMs}ms" else "-"`）
 * - `startReceiver()` のログ:
 *   `String.format(Locale.US, "表示リフレッシュレート: %.1fHz（描画は最短 %.1fms 間隔でペーシング）", hz, 1000.0f / hz)`
 * - `startReceiver()` は `s.start(Proto.DEFAULT_TCP_PORT)` を**明示的に**呼ぶ
 *   （smali: `const v4, 0xbacc`。既定値任せではない）
 * - `DiscoveryResponder` の onLog は `handler.post { LocalLog.i(msg) }`（＝UI スレッド経由でログ）
 * - `showLocalAddresses()`: 候補が無ければ `ipText = getString(R.string.ip_unknown)` /
 *   `ipListText = getString(R.string.error_no_wifi)`。あれば `ipText = list[0]`、
 *   `ipListText = if (list.size > 1) "他の候補: " + list.drop(1).joinToString(", ") else ""`
 * - `runDiagnose()` は別スレッド **"LS-Diagnose"** で `DecoderCaps.diagnose()` を実行し、
 *   例外時は `LocalLog.e("能力診断に失敗", e)` → `"診断に失敗しました: ${SimpleName}: ${message}"`。
 *   結果は 1 行ずつ `LocalLog.i("診断| $line")`（空白行は除く）してから UI に反映。
 *   ダイアログが閉じていたら `"診断ダイアログは閉じられました。結果は「ログ」から確認できます"`
 * - `showLogDialog()` の中立ボタンは `R.string.action_clear_log` →
 *   `LocalLog.clear()` + `Toast.makeText(this, R.string.action_clear_log, Toast.LENGTH_SHORT).show()`
 *
 * ## API 28 互換
 * `setSystemUiVisibility` / `Display.getRefreshRate` / `AlertDialog` / `ClipboardManager` はいずれも
 * API 28 で利用可能（非推奨 API だが動作する）。API 29+ 限定 API は使っていない。
 */
class ReceiverActivity : Activity(), ReceiverServer.Callbacks, H264Decoder.Listener, SurfaceHolder.Callback {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var videoContainer: FrameLayout
    private lateinit var surfaceView: SurfaceView
    private lateinit var statusText: TextView
    private lateinit var infoPanel: View
    private lateinit var ipText: TextView
    private lateinit var ipListText: TextView
    private lateinit var portText: TextView
    private lateinit var statsText: TextView
    private lateinit var errorText: TextView

    private var server: ReceiverServer? = null
    private var decoder: H264Decoder? = null
    private var discovery: DiscoveryResponder? = null

    @Volatile
    private var surfaceValid = false

    @Volatile
    private var receivedFps = 0

    private var videoW = 0
    private var videoH = 0

    // ------------------------------------------------------------- ライフサイクル

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_receiver)

        root = findViewById(R.id.root)
        videoContainer = findViewById(R.id.video_container)
        surfaceView = findViewById(R.id.surface_view)
        statusText = findViewById(R.id.status_text)
        infoPanel = findViewById(R.id.info_panel)
        ipText = findViewById(R.id.ip_text)
        ipListText = findViewById(R.id.ip_list_text)
        portText = findViewById(R.id.port_text)
        statsText = findViewById(R.id.stats_text)
        errorText = findViewById(R.id.error_text)

        surfaceView.holder.addCallback(this)

        portText.text = getString(R.string.label_port, Proto.DEFAULT_TCP_PORT)
        showLocalAddresses()

        ipText.setOnLongClickListener {
            val ip = ipText.text.toString()
            if (ip.isNotEmpty() && ip != getString(R.string.ip_unknown)) {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("LiteScreen IP", ip))
                Toast.makeText(this, "IPをコピーしました: $ip", Toast.LENGTH_SHORT).show()
            }
            true
        }

        enterImmersive()

        findViewById<TextView>(R.id.log_button).setOnClickListener { showLogDialog() }
        findViewById<TextView>(R.id.diag_button).setOnClickListener { runDiagnose() }

        LocalLog.i("起動 Android ${Build.VERSION.SDK_INT} / ${Build.MODEL}")
        DecoderCaps.logSummary()
        startReceiver()
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        if (server?.isRunning != true) startReceiver()
        showLocalAddresses()
    }

    override fun onPause() {
        super.onPause()
        stopReceiver("onPause")
    }

    override fun onDestroy() {
        stopReceiver("onDestroy")
        discovery?.stop()
        discovery = null
        super.onDestroy()
    }

    // ------------------------------------------------------------- 受信の開始 / 停止

    private fun startReceiver() {
        if (server?.isRunning == true) return
        val d = H264Decoder(handler)
        d.setListener(this)
        val hz = getDisplayRefreshHz()
        d.setDisplayRefreshRate(hz)
        LocalLog.i(
            String.format(
                Locale.US,
                "表示リフレッシュレート: %.1fHz（描画は最短 %.1fms 間隔でペーシング）",
                hz, 1000.0f / hz,
            ),
        )
        decoder = d
        val s = ReceiverServer(handler, this)
        s.setDecoder(d)
        server = s
        s.start(Proto.DEFAULT_TCP_PORT)

        discovery?.stop()
        discovery = DiscoveryResponder(applicationContext, Proto.DEFAULT_TCP_PORT) { msg ->
            handler.post { LocalLog.i(msg) }
        }.also { it.start() }

        setStatus(getString(R.string.state_listening), true)
    }

    private fun stopReceiver(reason: String) {
        server?.stop()
        server = null
        decoder?.release()
        decoder?.setListener(null)
        decoder = null
        discovery?.stop()
        discovery = null
        surfaceValid = false
        videoW = 0
        videoH = 0
        handler.post {
            statsText.visibility = View.GONE
            videoContainer.visibility = View.INVISIBLE
        }
        LocalLog.i("受信停止 ($reason)")
    }

    private fun getDisplayRefreshHz(): Float = try {
        val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val r = dm.getDisplay(0)?.refreshRate ?: 60.0f
        if (r in 20.0f..241.0f) r else 60.0f
    } catch (e: Exception) {
        60.0f
    }

    // ------------------------------------------------------------- 表示

    private fun enterImmersive() {
        @Suppress("DEPRECATION")
        root.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_FULLSCREEN
            )
    }

    private fun showLocalAddresses() {
        val list = NetUtil.candidateIPv4Addresses()
        if (list.isEmpty()) {
            ipText.text = getString(R.string.ip_unknown)
            ipListText.text = getString(R.string.error_no_wifi)
            return
        }
        ipText.text = list[0]
        ipListText.text = if (list.size > 1) "他の候補: " + list.drop(1).joinToString(", ") else ""
    }

    private fun setStatus(text: String, showPanel: Boolean) {
        statusText.text = text
        statusText.visibility = View.VISIBLE
        infoPanel.visibility = if (showPanel) View.VISIBLE else View.GONE
    }

    private fun hideOverlay() {
        statusText.visibility = View.GONE
        infoPanel.visibility = View.GONE
        errorText.visibility = View.GONE
    }

    private fun showError(msg: String) {
        errorText.text = msg
        errorText.visibility = View.VISIBLE
    }

    /** 映像のアスペクト比を保ったまま root 内にフィットさせる。 */
    private fun applyVideoSize(w: Int, h: Int) {
        if (w <= 0 || h <= 0) return
        videoW = w
        videoH = h
        val availW = root.width
        val availH = root.height
        if (availW <= 0 || availH <= 0) {
            // レイアウト未確定 → 次のフレームで再試行
            root.post { applyVideoSize(w, h) }
            return
        }
        val scale = min(availW.toFloat() / w, availH.toFloat() / h)
        val targetW = (w * scale).toInt().coerceAtLeast(1)
        val targetH = (h * scale).toInt().coerceAtLeast(1)
        val lp = videoContainer.layoutParams as FrameLayout.LayoutParams
        if (lp.width != targetW || lp.height != targetH) {
            lp.width = targetW
            lp.height = targetH
            videoContainer.layoutParams = lp
        }
        videoContainer.visibility = View.VISIBLE
    }

    // ------------------------------------------------------------- ダイアログ

    private fun runDiagnose() {
        val v = layoutInflater.inflate(R.layout.dialog_log, null)
        val tv = v.findViewById<TextView>(R.id.log_text)
        tv.text = getString(R.string.diag_running)
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.diag_title)
            .setView(v)
            .setPositiveButton(R.string.action_close, null)
            .show()
        Thread({
            val report = try {
                DecoderCaps.diagnose()
            } catch (e: Exception) {
                LocalLog.e("能力診断に失敗", e)
                "診断に失敗しました: ${e.javaClass.simpleName}: ${e.message}"
            }
            for (line in report.lineSequence()) {
                if (line.isNotBlank()) LocalLog.i("診断| $line")
            }
            handler.post {
                tv.text = report
                (v as? ScrollView)?.scrollTo(0, 0)
                if (!dialog.isShowing) {
                    LocalLog.i("診断ダイアログは閉じられました。結果は「ログ」から確認できます")
                }
            }
        }, "LS-Diagnose").start()
    }

    private fun showLogDialog() {
        val v = layoutInflater.inflate(R.layout.dialog_log, null)
        val tv = v.findViewById<TextView>(R.id.log_text)
        val s = LocalLog.snapshot()
        tv.text = if (s.isEmpty()) getString(R.string.log_empty) else s
        AlertDialog.Builder(this)
            .setTitle(R.string.log_title)
            .setView(v)
            .setNeutralButton(R.string.action_clear_log) { _, _ ->
                LocalLog.clear()
                Toast.makeText(this, R.string.action_clear_log, Toast.LENGTH_SHORT).show()
            }
            .setPositiveButton(R.string.action_close, null)
            .show()
    }

    // ------------------------------------------------------------- ReceiverServer.Callbacks

    override fun onWaitingForConnection() {
        handler.post { setStatus(getString(R.string.state_listening), true) }
    }

    override fun onClientConnected(remote: String) {
        handler.post {
            setStatus(getString(R.string.state_connecting), false)
            errorText.visibility = View.GONE
        }
    }

    override fun onVideoConfig(width: Int, height: Int, fps: Int, bitrateKbps: Int) {
        handler.post {
            applyVideoSize(width, height)
            statsText.visibility = View.VISIBLE
            statsText.text = "${width}x${height} / ${fps}fps / ${bitrateKbps}kbps"
        }
    }

    override fun onFirstFrame() {
        handler.post {
            hideOverlay()
            statsText.visibility = View.VISIBLE
            if (videoW > 0) applyVideoSize(videoW, videoH)
        }
    }

    override fun onDisconnected(reason: String) {
        handler.post {
            videoContainer.visibility = View.INVISIBLE
            statsText.visibility = View.GONE
            setStatus(getString(R.string.state_idle) + "\n" + reason, true)
            showLocalAddresses()
        }
    }

    override fun onError(message: String) {
        handler.post {
            setStatus(getString(R.string.state_error), true)
            showError(message)
            showLocalAddresses()
        }
    }

    override fun onSenderInfo(text: String) {
        handler.post {
            statsText.visibility = View.VISIBLE
            statsText.text = text
        }
    }

    override fun onStreamStats(receivedFps: Int, receivedKbps: Int) {
        this.receivedFps = receivedFps
    }

    override fun currentSurface(): Surface? =
        if (!surfaceValid) null else surfaceView.holder.surface

    // ------------------------------------------------------------- H264Decoder.Listener

    override fun onFatalError(message: String) {
        showError(message)
        server?.onDecoderFatal(message)
    }

    override fun onVideoSize(width: Int, height: Int) {
        if (width <= 0 || height <= 0) return
        if (width != videoW || height != videoH) applyVideoSize(width, height)
    }

    override fun onStats(
        renderedFps: Int,
        dropped: Long,
        pending: Int,
        decodedFps: Int,
        avgLatencyMs: Int,
        skippedFps: Int,
    ) {
        val lat = if (avgLatencyMs >= 0) "${avgLatencyMs}ms" else "-"
        statsText.text = String.format(
            Locale.US,
            "%dx%d  受信:%dfps  デコード:%dfps  描画:%dfps  スキップ:%dfps  遅延:%s  待ち:%d  破棄:%d",
            videoW, videoH, receivedFps, decodedFps, renderedFps, skippedFps, lat, pending, dropped,
        )
    }

    // ------------------------------------------------------------- SurfaceHolder.Callback

    override fun surfaceCreated(holder: SurfaceHolder) {
        surfaceValid = true
        LocalLog.i("Surface 生成")
        if (server?.isConnected == true) {
            server?.onSurfaceRecreated()
        }
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
        surfaceValid = true
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        surfaceValid = false
        LocalLog.i("Surface 破棄")
        decoder?.release()
        videoContainer.visibility = View.INVISIBLE
    }
}
