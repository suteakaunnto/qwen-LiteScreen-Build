package jp.litescreen.receiver.core

import android.os.Handler
import android.view.Surface
import jp.litescreen.protocol.Framing
import jp.litescreen.protocol.Proto
import jp.litescreen.protocol.ProtocolException
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketException
import java.net.SocketTimeoutException

/**
 * TCP 受信サーバ。送信側（LiteScreen sender）と 1 対 1 で接続し、
 * フレームを [H264Decoder] に流し込み、統計を 1 秒間隔で送信側へ返す。
 *
 * ## 復元について [APK確認]
 * `litescreen-receiver-v1.0.11-debug.apk` → `classes4.dex` の
 * `jp.litescreen.receiver.core.ReceiverServer`（jadx 802 行）および
 * `ReceiverServer$Callbacks` / `ReceiverServer$Callbacks$DefaultImpls` から復元。
 * **定数・分岐・呼び出し順は smali
 * （`recovery/decompiled/receiver-v1.0.11-apktool/smali_classes4/.../ReceiverServer.smali` 4603 行）
 * と全数突き合わせ済み。** 主な確認項目:
 *
 * - `@Volatile` の有無を smali の `.field private volatile` 指定どおりに復元
 *   （volatile: running / connected / decoderReady / decoderInitFailed / fatalReported /
 *   firstFrameSeen / videoWidth / videoHeight / csd0 / csd1 / lastSenderError。
 *   **非 volatile: decoder / framesSinceStats / bytesSinceStats / lastStatsNs / streamLogNs /
 *   logRendered / logDecoded / logSkipped / logDropped / out / client / serverSocket /
 *   acceptThread / readerThread**）
 * - 公開状態は **プロパティ** `isRunning` / `isConnected`
 *   （smali のメソッド名が `isRunning()Z` / `isConnected()Z`。jadx は `getRunning()` /
 *   `getConnected()` と誤って表示する → **smali 優先**）
 * - `start(port: Int = Proto.DEFAULT_TCP_PORT)` — `start$default` の `const p1, 0xbacc`（=47820）で確定
 * - handleClient の HELLO 応答ペイロードは
 *   `intBytes(1) + intBytes(1) + intBytes(0) + intBytes(0xbacd /* 47821 = Proto.DEFAULT_UDP_PORT */)`
 *   を type=1（MSG_HELLO）で送信
 * - ソケット設定（smali の定数を実測）: `tcpNoDelay=true` / `soTimeout=0x3a98=15000ms` /
 *   `receiveBufferSize=0x100000=1MB` / `sendBufferSize=0x10000=64KB` / `keepAlive=true` /
 *   入力は `BufferedInputStream(…, 0x20000=128KB)` /
 *   出力は `DataOutputStream(BufferedOutputStream(…, 0x10000=64KB))`
 * - スレッド名: **"LS-Accept"**（accept ループ）/ **"LS-Reader"**（読み取りループ）。どちらも daemon
 * - `acceptLoop`: **SocketException なら `return`（ループ脱出）**、IOException なら継続
 *   （smali: SocketException ハンドラの末尾が `return-void`、IOException ハンドラは `goto :goto_0`）
 * - `readLoop` の catch 順は smali の catch ハンドラ表どおり:
 *   SocketTimeoutException → ProtocolException → EOFException → IOException → Exception
 *   （`ProtocolException` は `IOException` のサブクラスなので顺序が重要）
 * - `readLoop` の第3引数 `remote` は **本体で一切使われていない**（smali 内に p3 参照が
 *   `.param` 宣言以外に存在しない）＝元コードでも未使用
 * - MSG_VIDEO の処理は `payload.size >= 16` のときのみ。`isKey = flags and 1 != 0`、
 *   本体は `payload.copyOfRange(16, payload.size)`
 * - MSG_VIDEO で **`callbacks.currentSurface()` を 2 回呼ぶ**（描画可否判定と初期化判定で別々。
 *   smali に `invoke-interface currentSurface()` が 2 箇所）→ 復元でも 2 回のまま維持
 * - STATS(type=8) のペイロード順と算出式（smali の `.line 483`〜`.line 494`）:
 *   `kbps = (bytesSinceStats * 8 / ((now - lastStatsNs) / 1_000_000)).toInt()`、
 *   `intBytes(fps) + intBytes(kbps) + intBytes(lastSendMs) + intBytes(dropped.toInt()) +
 *   intBytes(pending) + intBytes(decoded.toInt())` = 24B（`Proto.STATS_V2_SIZE`）
 * - STATS 送信間隔 `0x3b9aca00` = 1_000_000_000ns、ログ出力間隔 `0x12a05f200` = 5_000_000_000ns、
 *   `dtMs = (dtNs / 0xf4240).coerceAtLeast(1)`、各 fps は `(delta * 0x3e8) / dtMs`
 * - `callbacks.onStreamStats(fps, kbps)` は **handler.post せず直接呼ぶ**
 *   （＝ LS-Reader スレッドから呼ばれる。smali に post が無いため元の挙動どおり維持）
 * - `tryInitDecoder()` の既定サイズは `videoWidth > 0 ? videoWidth : 0x500(1280)` /
 *   `videoHeight > 0 ? videoHeight : 0x2d0(720)`、`DecoderCaps.areSupported(w, h, 0)` で事前判定
 * - `decodeText()` は `String(payload, UTF_8).take(0x1000 = 4096)`、失敗時 `"(デコード失敗 N bytes)"`
 * - `closeClient()` の処理順（smali の iput 順どおり）:
 *   connected/firstFrameSeen=false, streamLogNs=0, decoderReady=false, decoderInitFailed=false,
 *   fatalReported=false → `try { writeMsg(out, MSG_BYE, ByteArray(0)) } catch (_: Exception) {}` →
 *   `runCatching { client?.close() }` → client=null, out=null → readerThread?.interrupt(),
 *   readerThread=null → decoder?.release() → `if (wasConnected) { log + post onDisconnected }` →
 *   lastSenderError=null
 * - `stop()` は `closeClient("stop")` を呼んだあと serverSocket / acceptThread / decoder を片付け、
 *   最後に `LocalLog.i("受信サーバ停止")`
 * - `sameCsd(a, b)` は `Arrays.equals`（smali に `Ljava/util/Arrays;->equals([B[B)Z`）
 * - `Callbacks.currentSurface()` の戻り型は **`Surface?`**（@Metadata d1 の戻り型フラグ
 *   `\u001a\u0004\u0018\u0001`＝nullable、および呼び出し側の null 分岐で確定）
 * - `Callbacks.onSenderInfo` / `onStreamStats` のみ既定実装（空本体）を持つ
 *   （`ReceiverServer$Callbacks$DefaultImpls` に 2 メソッドだけ存在）
 *
 * ## API 28 互換
 * 使用 API は `java.net` / `java.io` / `android.os.Handler` のみで、すべて API 1 系から存在する。
 */
class ReceiverServer(
    private val handler: Handler,
    private val callbacks: Callbacks,
) {

    /** UI への通知と Surface の受け渡し。`on*` は [handler] のスレッドから呼ばれる（例外は onStreamStats）。 */
    interface Callbacks {
        fun onWaitingForConnection()
        fun onClientConnected(remote: String)
        fun onVideoConfig(width: Int, height: Int, fps: Int, bitrateKbps: Int)
        fun onFirstFrame()
        fun onDisconnected(reason: String)
        fun onError(message: String)
        fun onSenderInfo(text: String) {}
        fun onStreamStats(receivedFps: Int, receivedKbps: Int) {}

        /** 現在の描画先 Surface。未準備なら null。 */
        fun currentSurface(): Surface?
    }

    private var serverSocket: ServerSocket? = null
    private var client: Socket? = null
    private var acceptThread: Thread? = null
    private var readerThread: Thread? = null
    private var out: DataOutputStream? = null
    private val writeLock = Any()

    /** 送信は必ず writeLock 下で行う（PING 応答・STATS・キーフレーム要求が別スレッドから出るため）。 */
    private fun writeMsg(o: DataOutputStream?, type: Int, payload: ByteArray) {
        if (o == null) return
        runCatching {
            synchronized(writeLock) {
                Framing.writeMessage(o, type, payload)
            }
        }
    }

    private var decoder: H264Decoder? = null

    @Volatile
    private var decoderReady = false

    @Volatile
    private var decoderInitFailed = false

    @Volatile
    private var running = false

    @Volatile
    private var connected = false

    @Volatile
    private var videoWidth = 0

    @Volatile
    private var videoHeight = 0

    @Volatile
    private var csd0: ByteArray? = null

    @Volatile
    private var csd1: ByteArray? = null

    @Volatile
    private var lastSenderError: String? = null

    @Volatile
    private var fatalReported = false

    @Volatile
    private var firstFrameSeen = false

    private var framesSinceStats = 0L
    private var bytesSinceStats = 0L
    private var lastStatsNs = 0L
    private var streamLogNs = 0L
    private var logRendered = 0L
    private var logDecoded = 0L
    private var logSkipped = 0L
    private var logDropped = 0L

    val isRunning: Boolean
        get() = running

    val isConnected: Boolean
        get() = connected

    fun setDecoder(d: H264Decoder?) {
        decoder = d
    }

    // ------------------------------------------------------------- 起動 / 停止

    fun start(port: Int = Proto.DEFAULT_TCP_PORT) {
        if (running) return
        try {
            val ss = ServerSocket()
            ss.reuseAddress = true
            ss.bind(InetSocketAddress(port))
            serverSocket = ss
            running = true
            LocalLog.i("受信待機開始 port=$port")
            handler.post { callbacks.onWaitingForConnection() }
            val thread = Thread({ acceptLoop(ss) }, "LS-Accept")
            thread.isDaemon = true
            thread.start()
            acceptThread = thread
        } catch (e: Exception) {
            running = false
            LocalLog.e("受信待機開始に失敗 port=$port", e)
            handler.post { callbacks.onError("ポート $port を開けませんでした（他のアプリが使用中の可能性があります）") }
        }
    }

    private fun acceptLoop(ss: ServerSocket) {
        while (running) {
            try {
                val s = ss.accept()
                if (connected) {
                    LocalLog.w("接続中のため新規接続を拒否: ${s.remoteSocketAddress}")
                    try {
                        s.close()
                    } catch (e: Exception) {
                    }
                } else {
                    handleClient(s)
                }
            } catch (e: SocketException) {
                if (running) LocalLog.w("accept 失敗", e)
                return
            } catch (e: IOException) {
                if (running) LocalLog.w("accept I/O", e)
            }
        }
    }

    private fun handleClient(s: Socket) {
        val remote = (s.remoteSocketAddress as? InetSocketAddress)
            ?.let { "${it.address.hostAddress}:${it.port}" } ?: "?"
        try {
            s.tcpNoDelay = true
            s.soTimeout = 15_000
            s.receiveBufferSize = 1_048_576
            s.sendBufferSize = 65_536
            s.keepAlive = true

            val input = BufferedInputStream(s.inputStream, 131_072)
            val output = DataOutputStream(BufferedOutputStream(s.outputStream, 65_536))
            client = s
            out = output
            connected = true
            firstFrameSeen = false
            lastStatsNs = System.nanoTime()

            LocalLog.i("接続: $remote")
            handler.post { callbacks.onClientConnected(remote) }

            // HELLO 応答: proto=1, videoSupport=1, audioSupport=0, udpPort
            val hello = Framing.intBytes(1) + Framing.intBytes(1) +
                Framing.intBytes(0) + Framing.intBytes(Proto.DEFAULT_UDP_PORT)
            writeMsg(output, Proto.MSG_HELLO, hello)

            val thread = Thread({ readLoop(input, output, remote) }, "LS-Reader")
            thread.isDaemon = true
            thread.start()
            readerThread = thread
        } catch (e: Exception) {
            LocalLog.e("接続処理失敗 $remote", e)
            handler.post { callbacks.onError("接続に失敗しました: ${e.message}") }
            closeClient("接続処理失敗")
        }
    }

    // ------------------------------------------------------------- 受信ループ

    private fun readLoop(input: BufferedInputStream, output: DataOutputStream, remote: String) {
        val closedBySender = "送信側が接続を閉じました（配信停止またはアプリ終了）"
        while (running && connected) {
            try {
                val (type, len) = Framing.readHeader(input)
                val payload = Framing.readPayload(input, len)
                when (type) {
                    Proto.MSG_HELLO -> {
                        val version = Framing.readInt(payload, 0)
                        LocalLog.i("sender hello: proto=$version")
                        if (version != 1) {
                            closeClient("プロトコルバージョン不一致 (sender=$version, receiver=1)")
                            return
                        }
                    }

                    Proto.MSG_VIDEO_CONFIG -> {
                        videoWidth = Framing.readInt(payload, 0)
                        videoHeight = Framing.readInt(payload, 4)
                        val fps = Framing.readInt(payload, 8)
                        val bitrate = Framing.readInt(payload, 12)
                        LocalLog.i("映像設定: ${videoWidth}x$videoHeight ${fps}fps ${bitrate}kbps")
                        handler.post { callbacks.onVideoConfig(videoWidth, videoHeight, fps, bitrate) }
                        decoder?.setExpectedSize(videoWidth, videoHeight)
                    }

                    Proto.MSG_CODEC_CONFIG -> {
                        val count = Framing.readInt(payload, 0)
                        var off = 4
                        val list = ArrayList<ByteArray>()
                        for (i in 0 until count.coerceAtMost(4)) {
                            if (off + 4 <= payload.size) {
                                val n = Framing.readInt(payload, off)
                                off += 4
                                if (n >= 0 && off + n <= payload.size) {
                                    list.add(payload.copyOfRange(off, off + n))
                                    off += n
                                }
                            }
                        }
                        val newCsd0 = list.getOrNull(0)
                        val newCsd1 = list.getOrNull(1)
                        if (decoderReady && sameCsd(newCsd0, csd0) && sameCsd(newCsd1, csd1)) {
                            LocalLog.i("同一のコーデック設定の再送 → 無視します（デコーダーは稼働中）")
                        } else {
                            csd0 = newCsd0
                            csd1 = newCsd1
                            LocalLog.i("コーデック設定受信: csd=" + list.map { it.size })
                            decoderInitFailed = false
                            tryInitDecoder()
                        }
                    }

                    Proto.MSG_VIDEO -> {
                        if (payload.size >= 16) {
                            val pts = Framing.readLong(payload, 0)
                            val flags = Framing.readInt(payload, 8)
                            val sendMs = Framing.readInt(payload, 12)
                            val isKey = flags and 1 != 0
                            val frame = payload.copyOfRange(16, payload.size)
                            bytesSinceStats += frame.size
                            framesSinceStats++

                            val dec = decoder
                            val fatal = dec?.fatalMessage
                            if (fatal != null && !fatalReported) {
                                fatalReported = true
                                LocalLog.e("デコーダーが致命的エラーのため受信を停止します: $fatal")
                                writeMsg(output, Proto.MSG_ERROR, fatal.toByteArray(Charsets.UTF_8))
                                closeClient("デコーダー致命的エラー: $fatal")
                                return
                            }
                            if (dec == null || dec.fatalMessage == null) {
                                if (dec != null && decoderReady && callbacks.currentSurface()?.isValid == true) {
                                    dec.offer(frame, pts, isKey)
                                    if (!firstFrameSeen) {
                                        firstFrameSeen = true
                                        handler.post { callbacks.onFirstFrame() }
                                    }
                                    if (dec.consumeKeyFrameRequest()) {
                                        writeMsg(output, Proto.MSG_KEYFRAME_REQUEST, ByteArray(0))
                                    }
                                    maybeSendStats(output, sendMs)
                                } else {
                                    // Surface がまだ生きていない／デコーダー未初期化 → 初期化を試みる
                                    if (callbacks.currentSurface()?.isValid == true && csd0 != null) {
                                        tryInitDecoder()
                                    }
                                }
                            }
                        }
                    }

                    Proto.MSG_PING -> writeMsg(output, Proto.MSG_PONG, payload)

                    Proto.MSG_BYE -> {
                        closeClient(
                            lastSenderError
                                ?: "送信側が切断しました（理由の通知なし。送信側のログを確認してください）",
                        )
                        return
                    }

                    Proto.MSG_ERROR -> {
                        val text = decodeText(payload)
                        lastSenderError = text
                        LocalLog.e("送信側エラー: $text")
                        handler.post { callbacks.onError("送信側エラー: $text") }
                    }

                    Proto.MSG_INFO -> {
                        val text = decodeText(payload)
                        LocalLog.i("送信側情報: $text")
                        handler.post { callbacks.onSenderInfo(text) }
                    }

                    Proto.MSG_PROPOSE -> {
                        val reqW = Framing.readInt(payload, 0)
                        val reqH = Framing.readInt(payload, 4)
                        val reqFps = Framing.readInt(payload, 8)
                        LocalLog.i("能力ネゴシエーション要求: ${reqW}x${reqH}@${reqFps}fps")
                        val probe = DecoderCaps.probe(reqW, reqH, reqFps)
                        val detail = probe.detail.toByteArray(Charsets.UTF_8)
                        val ack = Framing.intBytes(if (probe.ok) 1 else 0) +
                            Framing.intBytes(probe.width) +
                            Framing.intBytes(probe.height) +
                            Framing.intBytes(probe.fps) +
                            Framing.intBytes(probe.profile) +
                            Framing.intBytes(probe.level) +
                            detail
                        writeMsg(output, Proto.MSG_PROPOSE_ACK, ack)
                        if (probe.width > 0) {
                            videoWidth = probe.width
                            videoHeight = probe.height
                            decoder?.setExpectedSize(probe.width, probe.height)
                        } else {
                            LocalLog.e("対応可能なサイズがありません: ${probe.detail}")
                        }
                    }

                    else -> LocalLog.w("未知のメッセージ type=$type len=$len → 破棄")
                }
            } catch (e: SocketTimeoutException) {
                closeClient("受信タイムアウト（15秒無通信）")
                return
            } catch (e: ProtocolException) {
                closeClient("プロトコルエラー: ${e.message}")
                return
            } catch (e: EOFException) {
                closeClient(closedBySender)
                return
            } catch (e: IOException) {
                val reason = if (running && connected) {
                    if (e.message?.contains("unexpected end of stream") == true) {
                        closedBySender
                    } else {
                        "接続が切れました (${e.javaClass.simpleName}: ${e.message})"
                    }
                } else {
                    "切断"
                }
                closeClient(reason)
                return
            } catch (e: Exception) {
                LocalLog.e("読み取りループ例外", e)
                closeClient("内部エラー: ${e.message}")
                return
            }
        }
    }

    // ------------------------------------------------------------- デコーダー初期化

    @Synchronized
    private fun tryInitDecoder() {
        if (decoderInitFailed) return
        val sps = csd0 ?: return
        val surface = callbacks.currentSurface()
        if (surface == null) {
            LocalLog.w("Surface 未準備のためデコーダー初期化を保留")
            return
        }
        if (!surface.isValid) return
        val w = if (videoWidth > 0) videoWidth else 1280
        val h = if (videoHeight > 0) videoHeight else 720
        if (!DecoderCaps.areSupported(w, h, 0)) {
            val probe = DecoderCaps.probe(w, h, 0)
            decoderInitFailed = true
            val msg = "この端末のデコーダーは ${w}x$h に対応していません。${probe.detail}"
            LocalLog.e(msg)
            handler.post { callbacks.onError(msg) }
            return
        }
        val dec = decoder ?: return
        decoderReady = false
        dec.setExpectedSize(w, h)
        decoderReady = dec.configure(sps, csd1, surface, w, h)
        if (!decoderReady) {
            decoderInitFailed = true
            LocalLog.e("デコーダー初期化に失敗したため、新しいコーデック設定が届くまで再試行しません（${w}x$h）")
            handler.post { callbacks.onError("デコーダーを初期化できませんでした（${w}x$h）") }
        }
    }

    @Synchronized
    fun onDecoderFatal(message: String) {
        decoderReady = false
        decoderInitFailed = true
        decoder?.release()
    }

    private fun sameCsd(a: ByteArray?, b: ByteArray?): Boolean = when {
        a == null && b == null -> true
        a == null || b == null -> false
        else -> a.contentEquals(b)
    }

    private fun decodeText(payload: ByteArray): String = try {
        String(payload, Charsets.UTF_8).take(4096)
    } catch (e: Exception) {
        "(デコード失敗 ${payload.size} bytes)"
    }

    // ------------------------------------------------------------- 統計

    private fun maybeSendStats(output: DataOutputStream, lastSendMs: Int) {
        val now = System.nanoTime()
        if (now - lastStatsNs < 1_000_000_000L) return
        val kbps = (bytesSinceStats * 8 / ((now - lastStatsNs) / 1_000_000)).toInt()
        val fps = framesSinceStats.toInt()
        val dec = decoder
        val dropped = dec?.droppedTotal() ?: 0L
        val pending = dec?.pendingCount() ?: 0
        val decoded = dec?.decodedTotal() ?: 0L
        val payload = Framing.intBytes(fps) +
            Framing.intBytes(kbps) +
            Framing.intBytes(lastSendMs) +
            Framing.intBytes(dropped.toInt()) +
            Framing.intBytes(pending) +
            Framing.intBytes(decoded.toInt())
        writeMsg(output, Proto.MSG_STATS, payload)
        framesSinceStats = 0
        bytesSinceStats = 0
        lastStatsNs = now
        callbacks.onStreamStats(fps, kbps)
        maybeLogStreamStats(now, fps, kbps, dec)
    }

    private fun maybeLogStreamStats(now: Long, fps: Int, kbps: Int, dec: H264Decoder?) {
        if (dec == null || !dec.isRunning()) return
        if (streamLogNs == 0L) {
            streamLogNs = now
            logRendered = dec.renderedTotal()
            logDecoded = dec.decodedTotal()
            logSkipped = dec.renderSkippedTotal()
            logDropped = dec.droppedTotal()
            return
        }
        val dtNs = now - streamLogNs
        if (dtNs < 5_000_000_000L) return
        val dtMs = (dtNs / 1_000_000).coerceAtLeast(1)
        val r = dec.renderedTotal()
        val d = dec.decodedTotal()
        val sk = dec.renderSkippedTotal()
        val dr = dec.droppedTotal()
        val rfps = ((r - logRendered) * 1000 / dtMs).toInt()
        val dfps = ((d - logDecoded) * 1000 / dtMs).toInt()
        val skfps = ((sk - logSkipped) * 1000 / dtMs).toInt()
        val ddrop = dr - logDropped
        streamLogNs = now
        logRendered = r
        logDecoded = d
        logSkipped = sk
        logDropped = dr
        val lat = dec.avgLatencyMs()
        LocalLog.i(
            "ストリーム統計: 受信=${fps}fps ${kbps}kbps / デコード=${dfps}fps / 描画=${rfps}" +
                "fps / 描画スキップ=${skfps}fps / 破棄+${ddrop} / 待ち=${dec.pendingCount()}" +
                " / 遅延=${if (lat >= 0) "${lat}ms" else "-"}",
        )
    }

    fun requestKeyFrame() {
        writeMsg(out, Proto.MSG_KEYFRAME_REQUEST, ByteArray(0))
    }

    // ------------------------------------------------------------- ライフサイクル

    @Synchronized
    fun onSurfaceRecreated() {
        decoderReady = false
        firstFrameSeen = false
        decoder?.release()
        if (csd0 != null) tryInitDecoder()
        requestKeyFrame()
    }

    @Synchronized
    private fun closeClient(reason: String) {
        val wasConnected = connected
        connected = false
        firstFrameSeen = false
        streamLogNs = 0L
        decoderReady = false
        decoderInitFailed = false
        fatalReported = false
        try {
            writeMsg(out, Proto.MSG_BYE, ByteArray(0))
        } catch (e: Exception) {
        }
        runCatching { client?.close() }
        client = null
        out = null
        readerThread?.interrupt()
        readerThread = null
        decoder?.release()
        if (wasConnected) {
            LocalLog.i("切断: $reason")
            handler.post { callbacks.onDisconnected(reason) }
        }
        lastSenderError = null
    }

    @Synchronized
    fun stop() {
        running = false
        connected = false
        closeClient("stop")
        runCatching { serverSocket?.close() }
        serverSocket = null
        acceptThread?.interrupt()
        acceptThread = null
        decoder?.release()
        decoder = null
        LocalLog.i("受信サーバ停止")
    }
}
