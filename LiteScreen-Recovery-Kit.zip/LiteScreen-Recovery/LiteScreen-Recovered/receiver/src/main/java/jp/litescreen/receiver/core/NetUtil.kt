/*
 * NetUtil.kt — 自端末の IPv4 列挙（NetUtil）と UDP 検索応答（DiscoveryResponder）
 *
 * ■ 出典: [APKから復元] litescreen-receiver-v1.0.11-debug.apk classes4.dex
 *         jp.litescreen.receiver.core.NetUtil / jp.litescreen.receiver.core.DiscoveryResponder
 *         **両クラスとも `.source "NetUtil.kt"`** ＝ 1 ファイルに同居していた。[APK確認]
 *
 * ■ smali で確認した重要ポイント
 *   - NetUtil.TAG = "LiteScreen.Net"、DiscoveryResponder.TAG = "LiteScreen.Discovery"
 *     （DiscoveryResponder の TAG は **companion object 内**の private const。
 *       DEX に `DiscoveryResponder$Companion` が存在することから確定）
 *   - NIC 名の優先度は **送信側 NetInfo と違う**（重要）:
 *       受信側: 0 = wlan・wifi・ap / 2 = rmnet・ccmni / 1 = p2p・swlan / 3 = それ以外
 *       送信側: 0 = wlan・wifi     / 1 = p2p・swlan・ap / 3 = rmnet・ccmni・cc / 2 = それ以外
 *       （いずれも「前方一致」。受信側は "ap" を最優先＝自分がアクセスポイント側、
 *         かつ "cc" は判定していない。この非対称は元 APK どおりで、意図的と思われる）
 *   - スレッド名 "LS-Discovery"（daemon）
 *   - ソケット: `DatagramSocket(null)` → setReuseAddress(true) → setBroadcast(true)
 *     → setSoTimeout(0x1f4 = 500) → bind(InetSocketAddress(47821))
 *   - 受信バッファ 0x100 = 256 バイト
 *   - PROBE と完全一致（Arrays.equals）したときだけ PROBE_ACK + JSON を返信
 *     JSON = {"proto":1,"app":"LiteScreen Receiver","tcpPort":<port>,"android":<SDK_INT>}
 *     JSON 部分は UTF-8（PROBE/PROBE_ACK 自体は US_ASCII → protocol モジュールの Proto.kt 参照）
 *   - MulticastLock タグ "litescreen-discovery"、setReferenceCounted(false)
 *   - SocketTimeoutException は握りつぶしてループ継続
 *   - BindException → 「UDP 47821 を使用中のため検索応答を停止（手動IP入力は利用可）」
 *   - SocketException → running が true のときだけ「UDP ソケットが閉じられました: ...」
 *     （stop() で閉じた場合はログを出さないため）
 *   - finally 相当: `runCatching { socket?.close() }` → `socket = null` → `releaseLock()`
 *
 * ■ 未確認事項 [推定]
 *   - ローカル変数名・改行は元ソースと異なる可能性がある（文字列・挙動は同一）。
 */
package jp.litescreen.receiver.core

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import jp.litescreen.protocol.Proto
import java.net.BindException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.SocketException
import java.net.SocketTimeoutException
import java.util.Collections

/**
 * 自端末の IPv4 アドレス列挙。
 *
 * 送信側の `jp.litescreen.sender.core.NetInfo` とほぼ同じ役割だが、
 * **NIC 名の優先度表が異なる**（この端末＝受信側はタブレット/AP 側になり得るため）。
 */
object NetUtil {

    private const val TAG = "LiteScreen.Net"

    /**
     * 候補 IPv4 を「それっぽさ」の順に返す（重複除去済み）。
     *
     * [APK確認] 優先度（小さいほど先頭）:
     *  - 0: `wlan*` / `wifi*` / `ap*`      … Wi-Fi、または自分がソフト AP
     *  - 1: `p2p*` / `swlan*`              … Wi-Fi Direct 系
     *  - 2: `rmnet*` / `ccmni*`            … モバイル通信系
     *  - 3: それ以外
     *
     * down / loopback は除外し、アドレスは ループバックとリンクローカル(169.254/16) を除外する。
     */
    fun candidateIPv4Addresses(): List<String> {
        val result = mutableListOf<Pair<Int, String>>()
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces()?.let { Collections.list(it) }
                ?: return emptyList()
            for (iface in ifaces) {
                if (!iface.isUp || iface.isLoopback) continue
                val name = iface.name ?: continue
                val priority = when {
                    name.startsWith("wlan") || name.startsWith("wifi") || name.startsWith("ap") -> 0
                    name.startsWith("rmnet") || name.startsWith("ccmni") -> 2
                    name.startsWith("p2p") || name.startsWith("swlan") -> 1
                    else -> 3
                }
                for (addr in Collections.list(iface.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        val host = addr.hostAddress ?: continue
                        result.add(priority to host)
                    }
                }
            }
            return result.sortedBy { it.first }.map { it.second }.distinct()
        } catch (e: SocketException) {
            Log.w(TAG, "enumerate interfaces failed", e)
        }
        return emptyList()
    }

    /** 最も優先度が高い IPv4。無ければ null。 */
    fun primaryIPv4(): String? = candidateIPv4Addresses().firstOrNull()
}

/**
 * 送信側アプリの「受信側を検索」ボタンに応答する UDP リスナー。
 *
 * UDP 47821 で `LITESCREEN?`（[Proto.PROBE]）を待ち、
 * `LITESCREEN!`（[Proto.PROBE_ACK]）+ JSON を返す。
 *
 * @param tcpPort 応答 JSON に載せる、映像を受ける TCP ポート
 * @param onLog   UI のログ表示へ流すコールバック（メインスレッドとは限らないので呼び出し側で post する）
 */
class DiscoveryResponder(
    private val context: Context,
    private val tcpPort: Int,
    private val onLog: (String) -> Unit,
) {

    @Volatile
    private var running = false

    @Volatile
    private var socket: DatagramSocket? = null
    private var thread: Thread? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ runLoop() }, "LS-Discovery").apply {
            isDaemon = true
            start()
        }
    }

    fun stop() {
        running = false
        runCatching { socket?.close() }
        socket = null
        thread?.interrupt()
        thread = null
        releaseLock()
    }

    private fun acquireLock() {
        try {
            // Wi-Fi の省電力でマルチキャスト/ブロードキャストを捨てさせないためのロック
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return
            val lock = wm.createMulticastLock("litescreen-discovery") ?: return
            lock.setReferenceCounted(false)
            if (!lock.isHeld) lock.acquire()
            multicastLock = lock
        } catch (e: Exception) {
            Log.w(TAG, "multicast lock failed", e)
        }
    }

    private fun releaseLock() {
        try {
            multicastLock?.let { if (it.isHeld) it.release() }
        } catch (_: Exception) {
            // ロック解放の失敗は利用継続に影響しないため握りつぶす
        } finally {
            multicastLock = null
        }
    }

    private fun runLoop() {
        acquireLock()
        var s: DatagramSocket? = null
        try {
            val sock = DatagramSocket(null)
            sock.reuseAddress = true
            sock.broadcast = true
            sock.soTimeout = 500  // [APK確認] smali `const/16 0x1f4` = 500ms（定数フィールドは無い）
            sock.bind(InetSocketAddress(Proto.DEFAULT_UDP_PORT))
            s = sock
            socket = sock

            val buf = ByteArray(256)
            while (running) {
                val pkt = DatagramPacket(buf, buf.size)
                try {
                    sock.receive(pkt)
                    val data = pkt.data.copyOfRange(pkt.offset, pkt.offset + pkt.length)
                    if (data.contentEquals(Proto.PROBE)) {
                        val json = """{"proto":1,"app":"LiteScreen Receiver","tcpPort":$tcpPort,"android":${Build.VERSION.SDK_INT}}"""
                        val payload = Proto.PROBE_ACK + json.toByteArray(Charsets.UTF_8)
                        sock.send(DatagramPacket(payload, payload.size, pkt.address, pkt.port))
                        onLog("検索プローブに応答: ${pkt.address.hostAddress}")
                    }
                } catch (_: SocketTimeoutException) {
                    // soTimeout(500ms) での定期復帰。running を見直すだけ
                }
            }
            runCatching { sock.close() }
        } catch (e: BindException) {
            onLog("UDP 47821 を使用中のため検索応答を停止（手動IP入力は利用可）")
        } catch (e: SocketException) {
            if (running) onLog("UDP ソケットが閉じられました: ${e.message}")
        } catch (e: Exception) {
            if (running) Log.w(TAG, "discovery loop error", e)
        } finally {
            runCatching { s?.close() }
            socket = null
            releaseLock()
        }
    }

    companion object {
        private const val TAG = "LiteScreen.Discovery"
        // 注: SO_TIMEOUT は 500ms（smali `const/16 0x1f4`）。元 APK には定数フィールドが
        //     無いため、使用箇所(start() 内)にリテラルで記述している。
    }
}
