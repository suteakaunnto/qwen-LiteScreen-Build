/*
 * DecoderCaps.kt — 受信端末の H.264 デコード能力の判定と自動縮小
 *
 * ■ 出典: [APKから復元] litescreen-receiver-v1.0.11-debug.apk classes4.dex
 *         jp.litescreen.receiver.core.DecoderCaps（元ファイル DecoderCaps.kt, 約 32〜530 行）
 *         + 同ファイル内の data class `DecoderCaps$Probe`
 *
 * ■ 復元方針
 *   - 定数表（LEVEL_TABLE / SCALES）は **smali の `<clinit>` を 1 行ずつデコードして確定**させた。
 *   - 分岐・三項演算子・Elvis の形も smali のラベル構造で確認している。
 *
 * ■ smali で確定した定数（<clinit> の filled-new-array を解読）
 *   SCALES (Double[10], .line 32)
 *     = {1.0, 0.9, 0.8, 0.75, 0.667, 0.6, 0.5, 0.4, 0.333, 0.25}
 *   LEVEL_TABLE (IntArray[9], .line 372-381)  {maxMacroblocks, maxMBPS, level定数}
 *     1620 / 40500    / 256    (= 0x100  AVCLevel1b)
 *     3600 / 108000   / 512    (= 0x200  AVCLevel2)
 *     5120 / 216000   / 1024   (= 0x400  AVCLevel3)
 *     8192 / 245760   / 2048   (= 0x800  AVCLevel31)
 *     8192 / 245760   / 4096   (= 0x1000 AVCLevel32)
 *     8704 / 522240   / 8192   (= 0x2000 AVCLevel4)
 *     22080/ 589824   / 16384  (= 0x4000 AVCLevel41)
 *     36864/ 983040   / 32768  (= 0x8000 AVCLevel42)
 *     36864/ 2073600  / 65536  (= 0x10000 AVCLevel5)
 *   levelName() の対応: 256→"3.0" 512→"3.1" 1024→"3.2" 2048→"4.0" 4096→"4.1"
 *                       8192→"4.2" 16384→"5.0" 32768→"5.1" 65536→"5.2" 0→"不明"
 *     ※ 表示名は **LEVEL_TABLE の level 定数をそのまま引いたときの呼称**。
 *       H.264 規格の level_idc 表記（LEVEL_TABLE 右コメント）とは 1 段ずれて見えるが、
 *       これは元 APK の実装どおり（＝この 2 つの表は元からこの組み合わせで使われている）。
 *
 *   ★注意: **送信側 ScreenCapturer.pickLevel() の表はこれとは別の 7 行表**
 *     （先頭 3600/108000/512、既定 65536）。混同すると配信レベルが壊れる。
 *
 * ■ その他の確定事項
 *   - TAG="LiteScreen.Caps"、MIME="video/avc"
 *   - findDecoder() は一度だけ queryDecoder() して結果をキャッシュ（cachedDecoder + decoderProbed）
 *   - queryDecoder(): ハードウェア（!isSoftware）を優先し、無ければ先頭を返す
 *   - isSoftware(name) = startsWith("OMX.google.") || startsWith("c2.android.")（ignoreCase）
 *   - probe() は SCALES の 10 段で「そのままで通るサイズ」を探し、見つからなければ 0 を返す
 *   - alignOf() は `runCatching{...}.getOrDefault(2).coerceAtLeast(2)`（API21 の get*Alignment
 *     が端末によっては例外を投げるため）
 *   - pickProfileLevel() は profiles = {8(High), 2(Main), 1(Baseline)} の順に isFormatSupported を試し、
 *     **requiredLevel() が規格表で算出したレベル**を使う（isFormatSupported が true になった最小レベルを
 *     鵜呑みにしない＝v1.0.9 の修正が現物に入っている）
 *   - supportsAdaptive() = isFeatureSupported("adaptive-playback")
 *   - diagnose() の出力文面・String.format の書式（"  %4dx%-4d  ○ %s%s\n" 等）は 1 文字ずつ一致させた
 */
package jp.litescreen.receiver.core

import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.util.Range

/**
 * 受信端末のデコード能力を調べて「実際に流せるサイズ・fps・プロファイル・レベル」を決める。
 *
 * 送信側は PROPOSE に対してここが返した値を PROPOSE_ACK で受け取り、
 * その解像度・プロファイル・レベルでエンコードを開始する。
 */
object DecoderCaps {

    private const val MIME = "video/avc"

    // [APK確認] 元 APK の DecoderCaps には `private static final TAG = "LiteScreen.Caps"` が
    //   存在する（フィールドとして宣言されているのみで、コード内からの参照は確認できない）。
    //   クラス構成を元 APK と一致させるため、そのまま復元する。
    private const val TAG = "LiteScreen.Caps"

    /** 自動縮小の試行倍率。1.0（＝そのまま）から順に下げていく。 */
    private val SCALES = doubleArrayOf(1.0, 0.9, 0.8, 0.75, 0.667, 0.6, 0.5, 0.4, 0.333, 0.25)

    // 注（2026-10-29 訂正）: 失敗プローブの fps は **0**。
    //   旧メモは「smali の失敗 3 経路の `const/16 0x1c0`（=448）が fps 引数」としていたが、誤り。
    //   [APK確認] 0x1c0 は `Probe` の合成コンストラクタ
    //     `<init>(ZIIILjava/lang/String;Ljava/lang/String;IIZILkotlin/jvm/internal/DefaultConstructorMarker;)V`
    //   の **第10引数＝既定値マスク**（bits 6,7,8 = profile / level / adaptive が既定値）。
    //   fps は第4引数で、smali では `const/4 vN, 0x0` → **fps = 0**。
    //   根拠: 元 smali の invoke-direct/range {v27 .. v38} で v31(fps)=0x0, v37(mask)=0x1c0。
    //   448 を書くと再構築側に 0x1c0 が 6 個（元は 3 個）出て不一致になる（Phase D 修正 #8）。

    /** 判定結果。`ok == true` は「要求どおりのサイズで通る」ことを意味する。 */
    data class Probe(
        val ok: Boolean,
        val width: Int,
        val height: Int,
        val fps: Int,
        val decoder: String,
        val detail: String,
        val profile: Int = 0,
        val level: Int = 0,
        val adaptive: Boolean = false,
    )

    @Volatile
    private var cachedDecoder: MediaCodecInfo? = null

    @Volatile
    private var decoderProbed = false

    /** AVC デコーダーを探す（結果はキャッシュする）。無ければ null。 */
    fun findDecoder(): MediaCodecInfo? {
        cachedDecoder?.let { return it }
        if (decoderProbed) return null
        val found = queryDecoder()
        cachedDecoder = found
        decoderProbed = true
        return found
    }

    /** ハードウェアデコーダーを優先し、無ければ先頭の AVC デコーダーを返す。 */
    private fun queryDecoder(): MediaCodecInfo? {
        return try {
            val avc = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
                !info.isEncoder && info.supportedTypes.any { it.equals(MIME, ignoreCase = true) }
            }
            if (avc.isEmpty()) return null
            avc.firstOrNull { !isSoftware(it.name) } ?: avc.first()
        } catch (e: Exception) {
            LocalLog.e("MediaCodecList の取得に失敗", e)
            null
        }
    }

    /** Google 提供のソフトウェアコーデックかどうか（低速なので診断文で明示する）。 */
    fun isSoftware(name: String): Boolean =
        name.startsWith("OMX.google.", ignoreCase = true) ||
            name.startsWith("c2.android.", ignoreCase = true)

    private fun videoCaps(info: MediaCodecInfo): MediaCodecInfo.VideoCapabilities? {
        return try {
            info.getCapabilitiesForType(MIME)?.videoCapabilities
        } catch (e: Exception) {
            LocalLog.w("VideoCapabilities の取得に失敗: ${info.name}", e)
            null
        }
    }

    private fun capsFor(info: MediaCodecInfo): MediaCodecInfo.CodecCapabilities? {
        return try {
            info.getCapabilitiesForType(MIME)
        } catch (e: Exception) {
            LocalLog.w("CodecCapabilities の取得に失敗: ${info.name}", e)
            null
        }
    }

    /**
     * 幅・高さのアラインメント（多くの端末は 2 か 16）。
     * [APK確認] API 21 の get*Alignment() は端末によって例外を投げるため
     *           `runCatching { ... }.getOrDefault(2)` した上で 2 以上にクランプしている。
     */
    private fun alignOf(caps: MediaCodecInfo.VideoCapabilities): Pair<Int, Int> {
        val wa = runCatching { caps.widthAlignment }.getOrDefault(2).coerceAtLeast(2)
        val ha = runCatching { caps.heightAlignment }.getOrDefault(2).coerceAtLeast(2)
        return wa to ha
    }

    /** アラインメントに切り捨て。0 以下になったら 1 アラインメント分に戻す。 */
    private fun align(v: Int, a: Int): Int {
        val r = v / a * a
        return if (r <= 0) a else r
    }

    /** そのサイズ・fps をデコーダーが公称サポートしているか。 */
    fun areSupported(w: Int, h: Int, fps: Int): Boolean {
        val info = findDecoder() ?: return false
        val caps = videoCaps(info) ?: return false
        return try {
            if (fps > 0) caps.areSizeAndRateSupported(w, h, fps.toDouble()) else caps.isSizeSupported(w, h)
        } catch (e: Exception) {
            LocalLog.w("areSizeAndRateSupported 失敗", e)
            false
        }
    }

    /** そのサイズでサポートされる最大 fps。分からなければ 0。 */
    fun maxFpsFor(w: Int, h: Int): Int {
        val info = findDecoder() ?: return 0
        val caps = videoCaps(info) ?: return 0
        return try {
            caps.getSupportedFrameRatesFor(w, h)?.upper?.toInt() ?: 0
        } catch (e: Exception) {
            0
        }
    }

    /**
     * 要求サイズを実際にデコードできるか判定し、ダメなら自動縮小した結果を返す。
     *
     * 戻り値の [Probe.ok] が true なのは「要求どおりのサイズ・fps で通る」場合のみ。
     * width/height/fps には **実際に使うべき値**が入る（見つからなければ全て 0）。
     */
    fun probe(reqW: Int, reqH: Int, reqFps: Int): Probe {
        val info = findDecoder()
            ?: return Probe(
                ok = false, width = 0, height = 0, fps = 0, decoder = "(none)",      // [APK確認] 失敗時の fps は 0（smali const/4 0x0）
                detail = "この端末に H.264(AVC) デコーダーが見つかりませんでした",
            )
        val caps = videoCaps(info)
            ?: return Probe(
                ok = false, width = 0, height = 0, fps = 0, decoder = info.name,     // [APK確認] 失敗時の fps は 0（smali const/4 0x0）
                detail = "デコーダー ${info.name} の能力情報を取得できませんでした",
            )

        val (wa, ha) = alignOf(caps)
        val sw = runCatching { caps.supportedWidths }.getOrNull()
        val sh = runCatching { caps.supportedHeights }.getOrNull()
        val rangeText = if (sw == null || sh == null) {
            "align ${wa}x$ha"
        } else {
            "対応幅 ${sw.lower}-${sw.upper} / 対応高さ ${sh.lower}-${sh.upper} / align ${wa}x$ha"
        }
        val kind = if (isSoftware(info.name)) "ソフトウェア" else "ハードウェア"
        LocalLog.i("デコーダー: ${info.name} ($kind) / $rangeText")

        val maxW = sw?.upper ?: 0
        val maxH = sh?.upper ?: 0
        val rejectReason = when {
            maxH in 1 until reqH -> "高さ $reqH がデコーダー上限 $maxH を超えています"
            maxW in 1 until reqW -> "幅 $reqW がデコーダー上限 $maxW を超えています"
            else -> "サイズは対応範囲内ですが、この解像度での ${reqFps}fps に対応していません"
        }

        for (scale in SCALES) {
            val w = align((reqW * scale).toInt(), wa)
            val h = align((reqH * scale).toInt(), ha)
            if (w <= 0 || h <= 0) continue

            val sizeOk = try {
                caps.isSizeSupported(w, h)
            } catch (e: Exception) {
                LocalLog.w("isSizeSupported($w,$h) 失敗", e)
                false
            }
            if (!sizeOk) continue

            val upper = try {
                caps.getSupportedFrameRatesFor(w, h)?.upper?.toInt() ?: 0
            } catch (e: Exception) {
                0
            }
            val fps = if (reqFps <= 0 || upper <= 0) reqFps else minOf(reqFps, upper)

            val rateOk = if (fps > 0) {
                try {
                    caps.areSizeAndRateSupported(w, h, fps.toDouble())
                } catch (e: Exception) {
                    false
                }
            } else {
                true
            }
            if (!rateOk) continue

            val unchanged = w == reqW && h == reqH && (reqFps <= 0 || fps >= reqFps)

            val achievable = try {
                caps.getAchievableFrameRatesFor(w, h)
            } catch (e: Exception) {
                null
            }
            val achLow = achievable?.lower?.toInt() ?: 0
            val achHigh = achievable?.upper?.toInt() ?: 0
            val fpsNote = when {
                achHigh <= 0 -> ""
                fps > achHigh -> " ⚠ 要求fpsが実測能力上限 $achHigh を超えています"
                fps > achLow -> "（実測能力 $achLow〜${achHigh}fps の範囲内）"
                else -> "（実測能力 $achLow〜${achHigh}fps で余裕あり）"
            }

            val (prof, lv) = pickProfileLevel(w, h, fps)
            val adaptive = supportsAdaptive()
            val profText = if (prof != 0) " / プロファイル=${profileName(prof)} レベル=${levelName(lv)}" else ""

            val detail = buildString {
                if (unchanged) {
                    append("${w}x${h}@${fps}fps は $kind デコーダー ${info.name} で対応可能")
                } else {
                    append("要求 ${reqW}x${reqH}@${reqFps}fps は非対応（理由: $rejectReason）")
                    append(" → ${w}x${h}@${fps}fps に自動縮小（$kind: ${info.name}）")
                }
                append(fpsNote)
                append(profText)
                if (adaptive) append(" / adaptive再生=対応")
                append(" / ").append(rangeText)
            }
            LocalLog.i("能力判定: $detail")
            return Probe(unchanged, w, h, fps, info.name, detail, prof, lv, adaptive)
        }

        val detail = "要求 ${reqW}x${reqH}@${reqFps}fps に対応するサイズが見つかりませんでした。" +
            "デコーダー ${info.name} ($kind) の対応範囲: $rangeText"
        LocalLog.e(detail)
        return Probe(false, 0, 0, 0, info.name, detail)  // [APK確認] 失敗時の fps は 0
    }

    /** 画面に表示する診断テキストを作る（ReceiverActivity の「診断」ボタンが呼ぶ）。 */
    fun diagnose(): String {
        val info = findDecoder()
            ?: return "H.264(AVC) デコーダーが見つかりませんでした。この端末では映像を表示できません。"
        val caps = videoCaps(info)
            ?: return "デコーダー ${info.name} の能力情報を取得できませんでした。"

        val kind = if (isSoftware(info.name)) "ソフトウェア（低速）" else "ハードウェア"
        val (wa, ha) = alignOf(caps)

        val sb = StringBuilder()
        sb.append("デコーダー: ${info.name}\n")
        sb.append("種別: $kind\n")
        runCatching { caps.supportedWidths }.getOrNull()?.let {
            sb.append("対応幅: ${it.lower} 〜 ${it.upper}\n")
        }
        runCatching { caps.supportedHeights }.getOrNull()?.let {
            sb.append("対応高さ: ${it.lower} 〜 ${it.upper}\n")
        }
        runCatching { caps.supportedFrameRates }.getOrNull()?.let {
            sb.append("対応fps: ${it.lower} 〜 ${it.upper}\n")
        }
        runCatching { caps.bitrateRange }.getOrNull()?.let {
            sb.append("対応ビットレート: ${it.lower / 1000} 〜 ${it.upper / 1000} kbps\n")
        }
        sb.append("アラインメント: ${wa}x$ha\n")

        sb.append("\n【サイズ別の対応状況】\n")
        val sizes = listOf(
            2560 to 1600, 1920 to 1200, 1920 to 1080, 1600 to 1000, 1440 to 900,
            1280 to 800, 1280 to 720, 1152 to 720, 1024 to 640, 960 to 600,
            854 to 480, 800 to 500, 640 to 400, 640 to 360,
        )
        for ((w, h) in sizes) {
            val sizeOk = runCatching { caps.isSizeSupported(w, h) }.getOrDefault(false)
            if (!sizeOk) {
                sb.append(String.format(java.util.Locale.US, "  %4dx%-4d  × 非対応\n", w, h))
            } else {
                val rates = runCatching { caps.getSupportedFrameRatesFor(w, h) }.getOrNull()
                val achievable = runCatching { caps.getAchievableFrameRatesFor(w, h) }.getOrNull()
                val rateTxt = if (rates != null) {
                    "${rates.lower.toDouble().toInt()}〜${rates.upper.toDouble().toInt()}fps"
                } else {
                    "fps不明"
                }
                val achTxt = if (achievable != null) {
                    " (実測能力 ${achievable.lower.toDouble().toInt()}〜${achievable.upper.toDouble().toInt()})"
                } else {
                    ""
                }
                sb.append(String.format(java.util.Locale.US, "  %4dx%-4d  ○ %s%s\n", w, h, rateTxt, achTxt))
            }
        }

        sb.append("\n【プロファイル対応状況（1280x800@30fps 基準）】\n")
        val mb = macroBlocks(1280, 800)
        // [APK確認] 元 smali は `const/16 0x1e` → `int-to-long` → `mul-long` の順で、
        // 直後の requiredLevel(1280,800,30) / pickProfileLevel(1280,800,30) でも同じレジスタを再利用している。
        // つまり元ソースは 30 を**ローカル変数**にして `fps.toLong() * mb` と書いていた
        // （リテラル `30L` や `30.toLong()` だと Kotlin 2.0.21 でも const-wide/16 に畳み込まれ、
        //   元と異なる codegen になる。実測済み → Phase D 修正 #9）。
        val fps = 30
        sb.append("  1280x800 = $mb マクロブロック/フレーム、@30fps = ${fps.toLong() * mb} マクロブロック/秒\n")
        sb.append("  規格上必要な最小レベル: ${levelName(requiredLevel(1280, 800, fps))}\n")
        val (prof, lv) = pickProfileLevel(1280, 800, fps)
        sb.append("  最適: " + (if (prof != 0) "${profileName(prof)} / Level ${levelName(lv)}" else "判定不能") + "\n")
        for (pn in listOf(8, 2, 1)) {
            // [APK確認] 元 smali はこのループ内で `const/16 0x1e` を**再ロード**している
            // （= 直前の fps レジスタを流用していない）。よってここは変数ではなくリテラル 30。
            val r = pickProfileLevelSingle(pn, 1280, 800, 30)
            val txt = if (r != 0) "○ Level ${levelName(r)}" else "× 非対応"
            sb.append("  ${profileName(pn)}: $txt\n")
        }
        sb.append("  adaptive再生: " + (if (supportsAdaptive()) "○ 対応" else "× 非対応") + "\n")

        sb.append("\n【1920x1200 を要求した場合の自動縮小結果】\n")
        for (fps in intArrayOf(60, 30, 24, 15)) {
            val pr = probe(1920, 1200, fps)
            sb.append("  要求 1920x1200@${fps}fps → ")
            sb.append(if (pr.width > 0) "${pr.width}x${pr.height}@${pr.fps}fps" else "対応サイズなし")
            sb.append(if (pr.ok) "（そのまま可）" else "").append("\n")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------- level / profile

    private fun macroBlocks(w: Int, h: Int): Long = ((w + 15) / 16).toLong() * ((h + 15) / 16).toLong()

    /**
     * 規格表から必要な H.264 レベル定数を算出する。
     * 該当が無ければ 0（＝レベル制限を超える）。
     */
    fun requiredLevel(w: Int, h: Int, fps: Int): Int {
        val mb = macroBlocks(w, h)
        val mbps = (if (fps > 0) fps else 30).toLong() * mb
        for (row in LEVEL_TABLE) {
            if (mb <= row[0] && mbps <= row[1]) return row[2]
        }
        return 0
    }

    /**
     * この端末が実際に受けられる (profile, level) を選ぶ。
     * High(8) → Main(2) → Baseline(1) の順に試し、どれもダメなら (0, 0)。
     *
     * [APK確認] レベルは `requiredLevel()`（規格表）で決め、
     *           `isFormatSupported` が true になった最小レベルを鵜呑みにしていない。
     */
    fun pickProfileLevel(w: Int, h: Int, fps: Int): Pair<Int, Int> {
        val info = findDecoder() ?: return 0 to 0
        val full = capsFor(info) ?: return 0 to 0
        val level = requiredLevel(w, h, fps)
        if (level == 0) {
            LocalLog.w("${w}x${h}@${fps}fps は H.264 のレベル制限を超えるためプロファイルを判定できません")
            return 0 to 0
        }
        val profiles = intArrayOf(8, 2, 1)
        for (prof in profiles) {
            val f = MediaFormat.createVideoFormat(MIME, w, h)
            f.setInteger("profile", prof)
            f.setInteger("level", level)
            if (fps > 0) f.setInteger("frame-rate", fps)
            val ok = runCatching { full.isFormatSupported(f) }.getOrDefault(false)
            if (ok) return prof to level
        }
        LocalLog.w("${w}x${h}@${fps}fps / level=${levelName(level)} に対応するプロファイルが見つかりません")
        return 0 to 0
    }

    /** 指定プロファイル 1 個だけを試す（診断用）。対応レベルを返し、ダメなら 0。 */
    fun pickProfileLevelSingle(profile: Int, w: Int, h: Int, fps: Int): Int {
        val info = findDecoder() ?: return 0
        val full = capsFor(info) ?: return 0
        val level = requiredLevel(w, h, fps)
        if (level == 0) return 0
        val f = MediaFormat.createVideoFormat(MIME, w, h)
        f.setInteger("profile", profile)
        f.setInteger("level", level)
        if (fps > 0) f.setInteger("frame-rate", fps)
        return if (runCatching { full.isFormatSupported(f) }.getOrDefault(false)) level else 0
    }

    fun profileName(p: Int): String = when (p) {
        0 -> "不明"
        MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline -> "Baseline"          // 1
        MediaCodecInfo.CodecProfileLevel.AVCProfileMain -> "Main"                  // 2
        MediaCodecInfo.CodecProfileLevel.AVCProfileHigh -> "High"                  // 8
        MediaCodecInfo.CodecProfileLevel.AVCProfileConstrainedBaseline -> "ConstrainedBaseline" // 65536
        MediaCodecInfo.CodecProfileLevel.AVCProfileConstrainedHigh -> "ConstrainedHigh"         // 524288
        else -> "profile=$p"
    }

    fun levelName(l: Int): String = when (l) {
        0 -> "不明"
        256 -> "3.0"
        512 -> "3.1"
        1024 -> "3.2"
        2048 -> "4.0"
        4096 -> "4.1"
        8192 -> "4.2"
        16384 -> "5.0"
        32768 -> "5.1"
        65536 -> "5.2"
        else -> "level=$l"
    }

    /** adaptive 再生（解像度変更をデコーダー再初期化なしで扱う機能）の対応有無。 */
    fun supportsAdaptive(): Boolean {
        val info = findDecoder() ?: return false
        val full = capsFor(info) ?: return false
        return runCatching { full.isFeatureSupported(MediaCodecInfo.CodecCapabilities.FEATURE_AdaptivePlayback) }
            .getOrDefault(false)
    }

    /** 起動時に能力を 1 行でログに残す。 */
    fun logSummary() {
        val info = findDecoder()
        if (info == null) {
            LocalLog.w("H.264 デコーダーが見つかりません")
            return
        }
        val caps = videoCaps(info) ?: return
        val kind = if (isSoftware(info.name)) "SW" else "HW"
        val w = runCatching { caps.supportedWidths }.getOrNull()
        val h = runCatching { caps.supportedHeights }.getOrNull()
        val fr = runCatching { caps.supportedFrameRates }.getOrNull()
        val align = alignOf(caps)
        LocalLog.i(
            "デコーダー能力: ${info.name} [$kind] width=${w?.lower}..${w?.upper}" +
                " height=${h?.lower}..${h?.upper} fps=${fr?.lower}..${fr?.upper}" +
                " align=${align.first}x${align.second}"
        )
    }

    /**
     * H.264 のレベル表（{最大マクロブロック数/フレーム, 最大マクロブロック数/秒, レベル定数}）。
     * [APK確認] smali `<clinit>` の .line 372-381 から 9 行すべてを復元。
     */
    private val LEVEL_TABLE = arrayOf(
        intArrayOf(1620, 40500, 256),      // AVCLevel1b
        intArrayOf(3600, 108000, 512),     // AVCLevel2
        intArrayOf(5120, 216000, 1024),    // AVCLevel3
        intArrayOf(8192, 245760, 2048),    // AVCLevel31
        intArrayOf(8192, 245760, 4096),    // AVCLevel32
        intArrayOf(8704, 522240, 8192),    // AVCLevel4
        intArrayOf(22080, 589824, 16384),  // AVCLevel41
        intArrayOf(36864, 983040, 32768),  // AVCLevel42
        intArrayOf(36864, 2073600, 65536), // AVCLevel5
    )
}
