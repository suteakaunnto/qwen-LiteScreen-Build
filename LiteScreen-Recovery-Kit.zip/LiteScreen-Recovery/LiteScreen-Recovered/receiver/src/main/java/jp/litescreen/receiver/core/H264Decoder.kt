package jp.litescreen.receiver.core

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.view.Surface
import java.nio.ByteBuffer
import java.util.ArrayDeque
import java.util.ArrayList
import java.util.LinkedHashMap
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * H.264(AVC) の非同期デコーダー。
 *
 * ## 復元について [APK確認]
 * `litescreen-receiver-v1.0.11-debug.apk` の
 * `classes4.dex` → `jp.litescreen.receiver.core.H264Decoder`（jadx 796 行）および
 * `H264Decoder$callback$1`（同 143 行）から復元した。
 * **定数・分岐条件・呼び出し順はすべて smali
 * （`recovery/decompiled/receiver-v1.0.11-apktool/smali_classes4/.../H264Decoder.smali`,
 * `H264Decoder$callback$1.smali`, `H264Decoder$Frame.smali`, `H264Decoder$Companion.smali`）
 * と突き合わせて確認済み。** 確認した主な項目:
 *
 * - Companion 定数 6 個（`H264Decoder$Companion.smali` の @Metadata d2 が
 *   TAG / MAX_PENDING / PTS_MAP_MAX / LATENCY_WINDOW / RENDER_MARGIN_NS / DEFAULT_PERIOD_NS
 *   の順で並ぶこと、および `H264Decoder.smali` の `.field private static final` 値から確定）
 *   - `DEFAULT_PERIOD_NS = 0xfe502a` = 16,666,666 ns（60fps 相当）
 *   - `RENDER_MARGIN_NS = 0x2dc6c0` = 3,000,000 ns
 *   - `LATENCY_WINDOW = 0x1e` = 30 / `MAX_PENDING = 2` / `PTS_MAP_MAX = 0x40` = 64
 * - `Listener.onStats` の引数名と順（@Metadata d2）:
 *   `(renderedFps, dropped, pending, decodedFps, avgLatencyMs, skippedFps)`
 *   ※ dropped だけが Long。`startStatsLoop$lambda$19$lambda$18` の
 *   `onStats($fps, dropped.get(), $p, $dfps, $lat, $sfps)` で確定
 * - `Frame(data: ByteArray, ptsUs: Long, isKey: Boolean, arrivalNs: Long)` は private data class。
 *   `equals` は **data を参照比較**（smali に `Arrays.equals` が無く
 *   `Intrinsics.areEqual` のみ）＝ data class 既定のまま。`hashCode` は `Arrays.hashCode`、
 *   `toString` は `Arrays.toString`（こちらも data class 既定）
 * - `configure()` の第1引数名は **"spd"**（"sps" のタイプミスと思われるが APK 内の実名そのまま）。
 *   smali の `.param p1, "spd"` と `const-string v0, "spd"`（checkNotNullParameter）で確定
 * - `color-format = 0x7f000789` = 2130708361 = `COLOR_FormatSurface`、`priority = 0`（リアルタイム）
 * - `ensureCodecHandler()` の HandlerThread 名 **"LS-Codec"** / 優先度 **-8**
 *   （= `Process.THREAD_PRIORITY_URGENT_DISPLAY`。smali `const/4 v4, -0x8`）
 *   ※ Phase D で判明: `THREAD_PRIORITY_BACKGROUND` は **10** であり -8 ではない。
 *     android.jar の実値: BACKGROUND=10, DEFAULT=0, FOREGROUND=-2, DISPLAY=-4,
 *     URGENT_DISPLAY=-8, VIDEO=-10, AUDIO=-16, URGENT_AUDIO=-19。
 * - 統計スレッド名 **"LS-Stats"**、daemon、`Thread.sleep(1000)`、`InterruptedException` で return
 * - `consumeKeyFrameRequest()` の間引き **0x1dcd6500 = 500,000,000 ns（500ms）**
 * - `setDisplayRefreshRate()` の許容範囲 **20.0f..241.0f**（smali の 0x41a00000 / 0x43710000）
 * - `recordLatency()` の有効範囲 **0..60000 ms**（0xea60）
 * - `onOutputBufferAvailable()` の描画判定
 *   `due = lastRenderNs == 0L || now - lastRenderNs >= displayPeriodNs - RENDER_MARGIN_NS`
 *   （smali: `const-wide/32 v9, 0x2dc6c0` を displayPeriodNs から **引いてから** 比較）
 * - `onError()` の非対応判定 `errorCode == -0x7ffefffb`（smali `const v1, -0x7ffefffb`
 *   = -2147418107 = 0x80010005）**または** メッセージに "0x80001005" を含む
 *   （**大文字小文字を区別する**。[APK確認] 元 smali は `contains$default(..., 0x2, ...)`
 *     = ignoreCase を既定値 false のまま呼んでいる。Phase D で判明・修正済み）
 *   ※ユーザー向け文言の "0x80001005" は元 APK の文字列定数と完全一致させるため原文どおり保持。
 *     判定に使う実値は 0x80010005 で、文言表記とは 1 桁異なる（元 APK 側も同じ表記）。
 * - `release()` がリセットするのは dropped / rendered / decoded / renderSkipped の 4 つのみで
 *   **keyframeRequests はリセットしない**（smali の `AtomicLong->set(J)` 呼び出しが 4 回だけ）
 * - `softReset()` / `release()` / `configure()` は `@Synchronized`
 *   （smali `declared-synchronized`）、`rememberArrival` は非同期（`.method private final`）
 *
 * ## API 28（チャレンジパッドNext / Android 9）互換
 * 使用 API はすべて API 28 以前から存在するもののみ
 * （`getInputBuffer` 21+, `setCallback(Callback, Handler)` 23+, `MediaCodecList(int)` 21+,
 * `HandlerThread.quitSafely()` 18+）。API 29+ 限定 API は使っていない。
 */
class H264Decoder(private val handler: Handler) {

    /** 受信した 1 フレーム（Annex-B 形式の NALU 群）。 */
    private data class Frame(
        val data: ByteArray,
        val ptsUs: Long,
        val isKey: Boolean,
        val arrivalNs: Long,
    )

    /** デコーダーイベントの受け口（すべて [handler] のスレッド＝UIスレッドで呼ばれる）。 */
    interface Listener {
        fun onFatalError(message: String)
        fun onVideoSize(width: Int, height: Int)
        fun onStats(
            renderedFps: Int,
            dropped: Long,
            pending: Int,
            decodedFps: Int,
            avgLatencyMs: Int,
            skippedFps: Int,
        )
    }

    companion object {
        // [APK確認] 元 APK では以下すべて `static final` フィールドに ConstantValue が付く
        //   (= Kotlin の `const val`)。`val` にすると <clinit> での初期化と
        //   access$getXxx$cp() が生成され、クラス構成が元 APK とずれるため const で宣言する。
        //   smali 実値: TAG="LiteScreen.Decoder" / MAX_PENDING=0x2 / PTS_MAP_MAX=0x40 /
        //              LATENCY_WINDOW=0x1e / RENDER_MARGIN_NS=0x2dc6c0L(3_000_000) /
        //              DEFAULT_PERIOD_NS=0xfe502aL(16_666_666)
        private const val TAG = "LiteScreen.Decoder"
        private const val MAX_PENDING = 2
        private const val PTS_MAP_MAX = 64
        private const val LATENCY_WINDOW = 30
        private const val RENDER_MARGIN_NS = 3_000_000L
        private const val DEFAULT_PERIOD_NS = 16_666_666L
        // 注: MediaCodec.CodecException.ERROR_UNSUPPORTED(@hide, smali 実値 -0x7ffefffb
        //     = 0x80010005) は定数フィールドを持たず、元 APK 同様に使用箇所でリテラルを直書きする。
    }

    @Volatile
    private var lastSize: Pair<Int, Int> = 0 to 0

    @Volatile
    private var codec: MediaCodec? = null

    @Volatile
    private var surface: Surface? = null

    @Volatile
    private var listener: Listener? = null

    private var codecThread: HandlerThread? = null
    private var codecHandler: Handler? = null

    @Volatile
    private var displayPeriodNs: Long = DEFAULT_PERIOD_NS

    @Volatile
    private var lastRenderNs: Long = 0L

    private val pending = ArrayDeque<Frame>()
    private val running = AtomicBoolean(false)
    private val freeInputs = LinkedBlockingQueue<Int>()

    @Volatile
    private var codecGen = 0

    private val csd = ArrayList<ByteArray>()

    @Volatile
    private var configured = false

    private val arrivalByPts = LinkedHashMap<Long, Long>()
    private val latencySamples = ArrayDeque<Long>()

    private val rendered = AtomicLong(0)
    private val decoded = AtomicLong(0)
    private val dropped = AtomicLong(0)
    private val renderSkipped = AtomicLong(0)
    private val keyframeRequests = AtomicLong(0)

    private var statsThread: Thread? = null
    private var lastKeyframeRequestNs = 0L

    @Volatile
    var needKeyFrameRequest = false
        private set

    @Volatile
    var fatalMessage: String? = null
        private set

    /** MediaCodec の非同期コールバック（専用スレッド "LS-Codec" 上で呼ばれる）。 */
    private val callback = object : MediaCodec.Callback() {

        override fun onInputBufferAvailable(codec: MediaCodec, index: Int) {
            if (!running.get() || fatalMessage != null) return
            val gen = codecGen
            freeInputs.offer(index)
            feedNext(codec, gen)
        }

        override fun onOutputBufferAvailable(codec: MediaCodec, index: Int, info: MediaCodec.BufferInfo) {
            if (!running.get()) {
                runCatching { codec.releaseOutputBuffer(index, false) }
                return
            }
            try {
                if (info.size > 0) {
                    decoded.incrementAndGet()
                    // 表示間引き: パネルのリフレッシュ周期より RENDER_MARGIN_NS だけ早く描画を許可する
                    val now = System.nanoTime()
                    val due = lastRenderNs == 0L || now - lastRenderNs >= displayPeriodNs - RENDER_MARGIN_NS
                    if (due) {
                        codec.releaseOutputBuffer(index, true)
                        lastRenderNs = now
                        rendered.incrementAndGet()
                        recordLatency(info.presentationTimeUs)
                    } else {
                        codec.releaseOutputBuffer(index, false)
                        renderSkipped.incrementAndGet()
                    }
                } else {
                    codec.releaseOutputBuffer(index, false)
                }
            } catch (e: Exception) {
                LocalLog.e("releaseOutputBuffer 失敗", e)
            }
        }

        override fun onError(codec: MediaCodec, e: MediaCodec.CodecException) {
            LocalLog.e("MediaCodec error (recoverable=${e.isRecoverable})", e)
            if (!running.get()) return
            // ERROR_UNSUPPORTED は @hide（公開 SDK に定数が無いためリテラルで指定）。
            // [APK確認] smali: `const v1, -0x7ffefffb`（= -2147418107 = 0x80010005）。
            //   元 APK にもこの定数のフィールドは無く、比較はリテラルで行われている。
            val unsupported = e.errorCode == -0x7ffefffb ||
                e.message?.contains("0x80001005") == true
            if (e.isRecoverable && !unsupported) {
                handler.post {
                    listener?.onFatalError("デコーダーエラー（再接続で回復します）: ${e.message}")
                    softReset()
                }
            } else {
                val reason = if (unsupported) {
                    "この端末のデコーダーがこの映像に対応していません (ERROR_UNSUPPORTED 0x80001005)。" +
                        "送信側で解像度とフレームレートを下げてください。"
                } else {
                    "デコーダー致命的エラー: ${e.javaClass.simpleName}: ${e.message}"
                }
                markFatal(reason, null)
            }
        }

        override fun onOutputFormatChanged(codec: MediaCodec, format: MediaFormat) {
            val (cw, ch) = cropSize(format)
            if (cw > 0 && ch > 0) {
                handler.post { listener?.onVideoSize(cw, ch) }
            }
            LocalLog.i("onOutputFormatChanged: ${cw}x$ch")
        }
    }

    // ------------------------------------------------------------- 公開 API

    fun setListener(l: Listener?) {
        listener = l
    }

    fun isRunning(): Boolean = running.get()

    /** パネルのリフレッシュレートに合わせて描画間引き周期を設定する（範囲外は無視）。 */
    fun setDisplayRefreshRate(hz: Float) {
        if (hz in 20.0f..241.0f) {
            displayPeriodNs = (1_000_000_000.0 / hz).toLong()
        }
    }

    /**
     * デコーダーを生成・起動する。
     * @param spd SPS（csd-0）。※ 引数名は元 APK 準拠（"sps" の誤記と思われるがそのまま維持）
     * @param pps PPS（csd-1）。null または空なら設定しない
     * @return 起動できれば true
     */
    @Synchronized
    fun configure(spd: ByteArray, pps: ByteArray?, targetSurface: Surface, width: Int, height: Int): Boolean {
        if (!targetSurface.isValid) return false
        if (configured) release()
        surface = targetSurface
        csd.clear()
        csd.add(spd)
        if (pps != null && pps.isNotEmpty()) csd.add(pps)
        return try {
            val format = MediaFormat.createVideoFormat("video/avc", width, height)
            format.setInteger("color-format", MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            for (i in 0 until csd.size) {
                format.setByteBuffer("csd-$i", ByteBuffer.wrap(csd[i]))
            }
            format.setInteger("priority", 0) // リアルタイム
            val c = MediaCodec.createDecoderByType("video/avc")
            codec = c
            freeInputs.clear()
            codecGen++
            c.setCallback(callback, ensureCodecHandler())
            c.configure(format, targetSurface, null, 0)
            lastRenderNs = 0L
            running.set(true)
            configured = true
            c.start()
            startStatsLoop()
            val sizeOk = isSizeSupported(c, width, height)
            LocalLog.i("デコーダー初期化 OK ${width}x$height / ${decoderName(c)} / sizeSupported=$sizeOk")
            true
        } catch (e: Exception) {
            LocalLog.e("デコーダー初期化失敗", e)
            release()
            val msg = "デコーダーを初期化できませんでした (${e.javaClass.simpleName}: ${e.message})"
            handler.post { listener?.onFatalError(msg) }
            false
        }
    }

    /** 送信側が期待しているサイズを記録する（softReset 時の再 configure に使う）。 */
    fun setExpectedSize(w: Int, h: Int) {
        lastSize = w to h
    }

    /**
     * 1 フレームを投入する。
     * @return この呼び出しで破棄したフレーム数（0 以上）
     */
    fun offer(data: ByteArray, ptsUs: Long, isKey: Boolean): Int {
        if (!running.get() || fatalMessage != null) return 0
        var dropCount = 0
        synchronized(pending) {
            pending.addLast(Frame(data, ptsUs, isKey, System.nanoTime()))
            // 溜まりすぎたら「一番古い非キーフレーム」を捨てる（無ければ先頭）
            while (pending.size > MAX_PENDING) {
                val victim = pending.firstOrNull { !it.isKey } ?: pending.firstOrNull() ?: break
                pending.remove(victim)
                dropCount++
                dropped.incrementAndGet()
            }
            if (dropCount > 0) needKeyFrameRequest = true
            codec?.let { feedNext(it, codecGen) }
        }
        return dropCount
    }

    /** キーフレーム再送要求を出すべきなら true を返し、要求フラグを消費する（500ms 間引き）。 */
    fun consumeKeyFrameRequest(): Boolean {
        if (!needKeyFrameRequest) return false
        val now = System.nanoTime()
        if (now - lastKeyframeRequestNs < 500_000_000L) return false
        lastKeyframeRequestNs = now
        needKeyFrameRequest = false
        keyframeRequests.incrementAndGet()
        return true
    }

    // ------------------------------------------------------------- 統計

    fun droppedTotal(): Long = dropped.get()

    fun decodedTotal(): Long = decoded.get()

    fun renderedTotal(): Long = rendered.get()

    fun renderSkippedTotal(): Long = renderSkipped.get()

    fun pendingCount(): Int = synchronized(pending) { pending.size }

    /** 直近 [LATENCY_WINDOW] 件の平均遅延（ms）。サンプルが無ければ -1。 */
    fun avgLatencyMs(): Int = synchronized(latencySamples) {
        if (latencySamples.isEmpty()) -1
        else (latencySamples.sum() / latencySamples.size).toInt()
    }

    fun statsText(): String =
        "rendered=${rendered.get()} decoded=${decoded.get()} skipped=${renderSkipped.get()}" +
            " dropped=${dropped.get()} keyReq=${keyframeRequests.get()}"

    // ------------------------------------------------------------- 内部処理

    private fun ensureCodecHandler(): Handler {
        val existing = codecHandler
        val t = codecThread
        if (existing != null && t != null && t.isAlive) return existing
        val nt = HandlerThread("LS-Codec", Process.THREAD_PRIORITY_URGENT_DISPLAY)
        nt.start()
        codecThread = nt
        val nh = Handler(nt.looper)
        codecHandler = nh
        return nh
    }

    private fun decoderName(c: MediaCodec): String = try {
        c.name
    } catch (e: Exception) {
        "unknown"
    }

    private fun isSizeSupported(c: MediaCodec, width: Int, height: Int): Boolean = try {
        val list = MediaCodecList(MediaCodecList.REGULAR_CODECS)
        val name = c.name
        val info = list.codecInfos.firstOrNull { it.name == name }
        val caps = info?.getCapabilitiesForType("video/avc")?.videoCapabilities
            ?: return false
        caps.isSizeSupported(width, height)
    } catch (e: Exception) {
        false
    }

    /** 空き入力バッファに pending のフレームを流し込む。codec が入れ替わったら中断する。 */
    private fun feedNext(c: MediaCodec, gen: Int) {
        if (fatalMessage != null) return
        while (gen == codecGen && c === codec) {
            val index = freeInputs.poll() ?: return
            val frame = synchronized(pending) { pending.pollFirst() }
            if (frame == null) {
                freeInputs.offer(index)
                return
            }
            try {
                val buf = c.getInputBuffer(index)
                if (buf == null) {
                    runCatching { c.queueInputBuffer(index, 0, 0, 0L, 0) }
                } else {
                    buf.clear()
                    buf.put(frame.data)
                    rememberArrival(frame.ptsUs, frame.arrivalNs)
                    c.queueInputBuffer(index, 0, frame.data.size, frame.ptsUs, 0)
                }
            } catch (e: Exception) {
                markFatal("入力バッファの投入に失敗しました (${e.javaClass.simpleName}: ${e.message})", e)
                return
            }
        }
    }

    private fun rememberArrival(ptsUs: Long, arrivalNs: Long) {
        synchronized(arrivalByPts) {
            arrivalByPts[ptsUs] = arrivalNs
            while (arrivalByPts.size > PTS_MAP_MAX) {
                val it = arrivalByPts.entries.iterator()
                if (!it.hasNext()) break
                it.next()
                it.remove()
            }
        }
    }

    private fun recordLatency(ptsUs: Long) {
        val arrival = synchronized(arrivalByPts) { arrivalByPts.remove(ptsUs) } ?: return
        val ms = (System.nanoTime() - arrival) / 1_000_000L
        if (ms < 0 || ms > 60_000L) return
        synchronized(latencySamples) {
            latencySamples.addLast(ms)
            while (latencySamples.size > LATENCY_WINDOW) latencySamples.removeFirst()
        }
    }

    /** 致命的エラーを記録し、UI スレッドで [Listener.onFatalError] を通知する（2 回目以降は無視）。 */
    private fun markFatal(reason: String, t: Throwable?) {
        if (fatalMessage != null) return
        fatalMessage = reason
        running.set(false)
        if (t != null) LocalLog.e(reason, t) else LocalLog.e(reason)
        // [APK確認] 元 smali (markFatal, .line 402-403) は
        //   `val l = listener` → `if (l != null) handler.post { l.onFatalError(reason) }`
        // の形で、ラムダは **1 段**（合成メソッド名 markFatal$lambda$10(Listener,String)V）。
        // `listener?.let { l -> handler.post { ... } }` と書くとラムダが 2 段になり
        // markFatal$lambda$N$lambda$M という別名になるため、Phase D 検証で元の形に修正した。
        val l = listener
        if (l != null) handler.post { l.onFatalError(reason) }
    }

    /** コーデックだけを作り直す（回復可能なエラーからの復帰用）。 */
    @Synchronized
    private fun softReset() {
        val s = surface
        if (s != null && s.isValid && csd.isNotEmpty()) {
            val (w, h) = lastSize
            releaseCodecOnly()
            if (w > 0 && h > 0) {
                configure(csd[0], csd.getOrNull(1), s, w, h)
            }
        }
    }

    /** 出力フォーマットから実際の表示サイズ（crop 込み）を得る。crop が無ければ width/height。 */
    private fun cropSize(f: MediaFormat): Pair<Int, Int> {
        val w = runCatching { f.getInteger("width") }.getOrDefault(0)
        val h = runCatching { f.getInteger("height") }.getOrDefault(0)
        val left = runCatching { f.getInteger("crop-left") }.getOrDefault(0)
        val top = runCatching { f.getInteger("crop-top") }.getOrDefault(0)
        val right = runCatching { f.getInteger("crop-right") }.getOrDefault(-1)
        val bottom = runCatching { f.getInteger("crop-bottom") }.getOrDefault(-1)
        return if (right < left || bottom < top || right < 0 || bottom < 0) {
            w to h
        } else {
            (right - left + 1) to (bottom - top + 1)
        }
    }

    private fun startStatsLoop() {
        stopStatsLoop()
        val thread = Thread({
            var lastRendered = 0L
            var lastDecoded = 0L
            var lastSkipped = 0L
            while (running.get()) {
                try {
                    Thread.sleep(1000L)
                    val r = rendered.get()
                    val d = decoded.get()
                    val sk = renderSkipped.get()
                    val fps = (r - lastRendered).toInt()
                    val dfps = (d - lastDecoded).toInt()
                    val sfps = (sk - lastSkipped).toInt()
                    val p = synchronized(pending) { pending.size }
                    val lat = avgLatencyMs()
                    handler.post { listener?.onStats(fps, dropped.get(), p, dfps, lat, sfps) }
                    lastRendered = r
                    lastDecoded = d
                    lastSkipped = sk
                } catch (e: InterruptedException) {
                    return@Thread
                }
            }
        }, "LS-Stats")
        thread.isDaemon = true
        thread.start()
        statsThread = thread
    }

    private fun stopStatsLoop() {
        statsThread?.interrupt()
        statsThread = null
    }

    private fun releaseCodecOnly() {
        running.set(false)
        codecGen++
        freeInputs.clear()
        stopStatsLoop()
        try {
            codec?.setCallback(null)
        } catch (e: Exception) {
        }
        try {
            codec?.stop()
        } catch (e: Exception) {
        }
        try {
            codec?.release()
        } catch (e: Exception) {
        }
        codec = null
        configured = false
        lastRenderNs = 0L
        synchronized(pending) { pending.clear() }
        val t = codecThread
        codecThread = null
        codecHandler = null
        t?.quitSafely()
    }

    @Synchronized
    fun release() {
        releaseCodecOnly()
        fatalMessage = null
        synchronized(arrivalByPts) { arrivalByPts.clear() }
        synchronized(latencySamples) { latencySamples.clear() }
        csd.clear()
        surface = null
        dropped.set(0)
        rendered.set(0)
        decoded.set(0)
        renderSkipped.set(0)
    }
}
