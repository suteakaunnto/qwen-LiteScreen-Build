/*
 * sender/build.gradle.kts — 送信側アプリ（画面キャプチャ → H.264 → TCP 送信）
 *
 * [再構成新規] このビルドスクリプトは APK に含まれていなかったため復旧作業で作成した。
 * ただし以下の値は **APK から実測して一致させている**（recovery/evidence/RAW_badging_signing.txt、
 * recovery/reports/APK_FORENSICS.md §2 / §5 参照）:
 *
 *   [APK確認] androidGradlePluginVersion=8.13.2
 *             （META-INF/com/android/build/gradle/app-metadata.properties）
 *   [APK確認] applicationId = jp.litescreen.sender.debug
 *   [APK確認] versionCode   = 11
 *   [APK確認] versionName   = 1.0.11-debug
 *   [APK確認] minSdk 28 / targetSdk 36 / compileSdk 36
 *   [APK確認] BuildConfig クラスが DEX に存在しない → buildConfig = false
 *   [APK確認] R クラスのフィールドが非 final（`public static int ...`）
 *             → android.nonFinalResIds=true（gradle.properties 参照）
 *   [APK確認] DEX に androidx.* が 1 件も無い → 依存は kotlin-stdlib と :protocol のみ
 *   [APK確認] assets/ なし、jniLibs（native library）なし
 *
 * ■ 署名について（重要）
 *   元の APK の署名証明書は `C=US,O=Android,CN=Android Debug`
 *   （SHA-256: bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf, v2 のみ）で、
 *   これは開発者の `~/.android/debug.keystore` にあったもの。
 *   **秘密鍵は APK から復元できない** ため、ここでビルドした APK は必ず別の署名になる。
 *   結果として、既存の端末にインストール済みのアプリは **アンインストールしないと更新できない**
 *   （INSTALL_FAILED_UPDATE_INCOMPATIBLE）。
 *   → 運用方針: 新しく keystore を作って `keystore.properties` に置き、
 *     以後はそれを必ずバックアップすること（2 回目以降の更新は上書きインストールできる）。
 *     このファイルは `keystore.properties` があればそれを使い、無ければ AGP 既定の debug 鍵を使う。
 */
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// 任意: keystore.properties（keystoreFile / keystorePassword / keyAlias / keyPassword）
val keystorePropsFile = rootProject.file("keystore.properties")
val keystoreProps = Properties().apply {
    if (keystorePropsFile.exists()) keystorePropsFile.inputStream().use { load(it) }
}

android {
    // R クラスのパッケージ。元の APK では jp.litescreen.sender.R が classes3.dex に、
    // jp.litescreen.sender.debug.R が classes.dex に存在した（後者は applicationId 由来の自動生成）。[APK確認]
    namespace = "jp.litescreen.sender"
    compileSdk = 36

    defaultConfig {
        // debug ビルドタイプで ".debug" が付与され、最終的に jp.litescreen.sender.debug になる
        applicationId = "jp.litescreen.sender"
        minSdk = 28
        targetSdk = 36
        versionCode = 11
        versionName = "1.0.11"
    }

    signingConfigs {
        if (keystorePropsFile.exists()) {
            create("recovered") {
                storeFile = file(keystoreProps.getProperty("keystoreFile"))
                storePassword = keystoreProps.getProperty("keystorePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            // 元の APK と同じ applicationId / versionName を再現する
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            isMinifyEnabled = false
            if (keystorePropsFile.exists()) {
                signingConfig = signingConfigs.getByName("recovered")
            }
        }
        release {
            isMinifyEnabled = false
            if (keystorePropsFile.exists()) {
                signingConfig = signingConfigs.getByName("recovered")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = false   // [APK確認] BuildConfig が DEX に無い
        viewBinding = false
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }

    lint {
        abortOnError = true
        warningsAsErrors = false
    }
}

// Kotlin コンパイラ設定。
// [再構成新規] AGP 8.x + KGP 2.x では android { kotlinOptions { } } は非推奨のため、
//   トップレベルの kotlin { compilerOptions { } } を使う（機能は同一）。
kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
    }
}

dependencies {
    implementation(project(":protocol"))
    // kotlin-stdlib は Kotlin プラグインが自動で付与する。
    // [APK確認] 元 APK の DEX にも kotlin.* と jp.litescreen.* しか入っていない。
}
