/*
 * ScreenCapturer.kt — MediaProjection → VirtualDisplay → H.264 ハードウェアエンコード
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk classes5.dex
 *         jp.litescreen.sender.core.ScreenCapturer（元ファイル ScreenCapturer.kt）
 *
 * ■ 復元方針
 *   - jadx の Java 出力を Kotlin に戻し、**分岐・定数・ビット演算は smali と突き合わせて確認**した。
 *     （jadx は Kotlin の `?:` / `runCatching` / 循環 while を壊れた形に展開するため、
 *       構造は smali のラベル構造を基準にしている）
 *   - smali で確認した重要ポイント:
 *       * pickLevel() のレベル表は 7 行（先頭 3600/108000/512 … 末尾 36864/983040/32768）、
 *         既定値 0x10000 = 65536。
 *         ※ 受信側 DecoderCaps の LEVEL_TABLE は 9 行（先頭 1620/40500/256）で**別の表**。混同注意。
 *       * splitAnnexB() のループ条件は `i < data.size`（jadx は `i >= data.length - 3` と誤表示）。
 *         4 バイトスタートコード判定は `i + 3 < data.size` を内側で別途チェックしている。
 *       * maybeReportStats() の fps/kbps は Long 演算 → .toInt()
 *         （fps = statFrames*1_000_000_000L/dt、kbps = statBytes*8L*1_000_000_000L/dt/1000L）
 *       * currentBitrate の初期値 = config.bitrateKbps * 1000（mul-int/lit16 0x3e8）
 *       * buildFormat() は variant = "full" / "no-profile-level" / "minimal" / "bare" の
 *         4 段フォールバック。max-bframes=0 は runCatching で包まれている（v1.0.11 で追加）。
 *       * createVirtualDisplay の flags = 16（VirtualDisplay.FLAG_OWN_CONTENT_ONLY）
 *       * releaseOutputBuffer(index, false) は runCatching（= 描画しない。レンダリング間隔制御は受信側の担当）
 *
 * ■ 未確認事項 [推定]
 *   - ローカル変数名・ログ出力の正確な行数は元ソースと異なる可能性がある（意味は同一）。
 *   - `@Volatile` は smali の `.field private volatile` から確定。プロパティに直接付ける形
 *     （Kotlin ではフィールドに @Volatile が付く）で復元している。
 */
package jp.litescreen.sender.core

import android.content.Context
import android.graphics.Point
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Surface
import android.media.projection.MediaProjection

/**
 * 画面キャプチャ + H.264 エンコード。
 *
 * 出力は [Listener.onEncodedFrame] に Annex-B 形式の NAL 列として渡される。
 * エンコーダが CODEC_CONFIG（SPS/PPS）を出力したら [Listener.onCodecConfig] で通知する。
 */
class ScreenCapturer(
    private val context: Context,
    private val projection: MediaProjection,
    private val config: StreamConfig,
    private val listener: Listener,
    private val forcedWidth: Int = 0,
    private val forcedHeight: Int = 0,
    private val forcedProfile: Int = 0,
    private val forcedLevel: Int = 0,
) {

    interface Listener {
        fun onEncodedFrame(data: ByteArray, ptsUs: Long, isKey: Boolean)
        fun onCodecConfig(csd: List<ByteArray>)
        fun onStreamSize(width: Int, height: Int)
        fun onInfo(text: String)
        fun onError(message: String, fatal: Boolean)
        fun onStats(encodedFps: Int, kbps: Int)
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var encoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null

    @Volatile
    private var running = false
    private var drainThread: Thread? = null

    private var streamW = 0
    private var streamH = 0

    private var currentBitrate = config.bitrateKbps * 1000

    private var statFrames = 0
    private var statBytes = 0L
    private var statLastNs = 0L

    /**
     * 送信あふれ（キュー満杯）後に立てる再同期フラグ。
     * true の間は非キーフレームを捨て、次のキーフレーム送出で false に戻す。
     */
    @Volatile
    var resyncPending = false

    @Volatile
    private var sentCsdHash = 0

    // ---------------------------------------------------------------- start

    /** [APK確認] 起動。例外は握りつぶさず fatal エラーとして listener に流して false を返す。 */
    fun start(): Boolean {
        return try {
            doStart()
        } catch (e: Throwable) {
            val msg = "配信開始中に予期しない例外: ${e.javaClass.simpleName}: ${e.message}"
            Log.e(TAG, msg, e)
            listener.onError(msg, true)
            release()
            false
        }
    }

    private fun doStart(): Boolean {
        val screen = Companion.realScreenSize(context)

        // 受信側が PROPOSE_ACK で能力を返してきた場合はそれを最優先する
        val (w, h) = if (forcedWidth > 0 && forcedHeight > 0) {
            val pair = forcedWidth to forcedHeight
            Log.i(TAG, "受信側の能力に合わせて配信サイズを確定: ${pair.first}x${pair.second}")
            pair
        } else {
            Companion.fitToLimit(screen.x, screen.y, config.maxLongEdge)
        }
        streamW = w
        streamH = h
        Log.i(TAG, "画面=${screen.x}x${screen.y} -> 配信=${w}x${h} @${config.fps}fps ${config.bitrateKbps}kbps")

        // 端末ごとの MediaCodec 実装差を吸収するため、設定を段階的に緩めて試す
        val variants = listOf("full", "no-profile-level", "minimal", "bare")
        val errors = ArrayList<String>()
        var usedVariant = ""
        var codec: MediaCodec? = null
        for (variant in variants) {
            try {
                // [APK確認] 元 APK は `!!`（smali: `Intrinsics.checkNotNull(Object)V` @ .line 202）。
                //   独自の例外メッセージは元 APK に存在しないため使わない。
                val c = MediaCodec.createEncoderByType(MIME)!!
                try {
                    c.configure(buildFormat(w, h, variant), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                    codec = c
                    usedVariant = variant
                    Log.i(TAG, "configure 成功 (variant=$variant)")
                    break
                } catch (e: Exception) {
                    errors.add("$variant: configure -> ${e.javaClass.simpleName}: ${e.message}")
                    Log.w(TAG, "configure 失敗 ($variant) → 設定を緩めて再試行します", e)
                    runCatching { c.release() }
                }
            } catch (e: Exception) {
                errors.add("$variant: createEncoderByType -> ${e.javaClass.simpleName}: ${e.message}")
                Log.w(TAG, "createEncoderByType 失敗 ($variant)", e)
            }
        }
        if (codec == null) {
            val detail = errors.joinToString(" / ")
            listener.onError("H.264エンコーダーを初期化できませんでした（${w}x${h}）。試行: $detail", true)
            return false
        }
        encoder = codec

        try {
            val surface = codec.createInputSurface()
            inputSurface = surface
            try {
                codec.start()
            } catch (e: Exception) {
                listener.onError("エンコーダー起動に失敗: ${e.javaClass.simpleName}: ${e.message}", true)
                release()
                return false
            }

            // Android 14 以降は createVirtualDisplay より前に Callback 登録が必須
            try {
                projection.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        Log.i(TAG, "MediaProjection onStop（ユーザーが許可を取り消した／システムが停止した）")
                        listener.onError("画面共有がシステムによって停止されました", true)
                        stop()
                    }
                }, mainHandler)
            } catch (e: Exception) {
                Log.w(TAG, "MediaProjection.registerCallback に失敗（配信は継続します）", e)
            }

            try {
                virtualDisplay = projection.createVirtualDisplay(
                    "LiteScreen",
                    w,
                    h,
                    densityFor(w),
                    16, // VirtualDisplay.FLAG_OWN_CONTENT_ONLY [APK確認] smali `const/16 0x10`
                    surface,
                    object : VirtualDisplay.Callback() {
                        override fun onPaused() {
                            Log.i(TAG, "virtualDisplay paused")
                        }

                        override fun onResumed() {
                            Log.i(TAG, "virtualDisplay resumed")
                        }

                        override fun onStopped() {
                            Log.i(TAG, "virtualDisplay stopped")
                        }
                    },
                    mainHandler,
                )
                running = true
                statLastNs = System.nanoTime()
                drainThread = Thread({ drainLoop() }, "LS-EncodeDrain").apply {
                    isDaemon = true
                    start()
                }
                listener.onStreamSize(w, h)
                listener.onInfo(
                    "送信側: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE}" +
                        "(API ${Build.VERSION.SDK_INT}) / encoder=${safeCodecName(codec)} / variant=$usedVariant" +
                        " / profile=${profileLabel()} / ${w}x${h}@${config.fps}fps ${config.bitrateKbps}kbps"
                )
                emitCodecConfigFromFormat()
                return true
            } catch (e: IllegalStateException) {
                listener.onError(
                    "VirtualDisplay の作成に失敗（IllegalStateException: ${e.message}）。" +
                        "Android 14以降は createVirtualDisplay の前に MediaProjection.Callback の登録が必須です。",
                    true,
                )
                release()
                return false
            } catch (e: SecurityException) {
                listener.onError(
                    "画面キャプチャを開始できませんでした（SecurityException: ${e.message}）。" +
                        "Android 14以降では foregroundServiceType=mediaProjection のサービスを起動した「後」に " +
                        "getMediaProjection/createVirtualDisplay を呼ぶ必要があり、" +
                        "createVirtualDisplay はトークン1個につき1回だけです。",
                    true,
                )
                release()
                return false
            } catch (e: Exception) {
                listener.onError("VirtualDisplay の作成に失敗: ${e.javaClass.simpleName}: ${e.message}", true)
                release()
                return false
            }
        } catch (e: Exception) {
            listener.onError("エンコーダーの入力Surface作成に失敗: ${e.javaClass.simpleName}: ${e.message}", true)
            release()
            return false
        }
    }

    private fun safeCodecName(c: MediaCodec): String = runCatching { c.name }.getOrNull() ?: "unknown"

    /** [APK確認] forcedProfile の値 → 表示用ラベル。0 は「受信側からの指定なし」。 */
    private fun profileLabel(): String = when (forcedProfile) {
        0 -> "Baseline(CAVLC・受信側からの指定なし)"
        1 -> "Baseline(CAVLC)"
        2 -> "Main(CABAC)"
        8 -> "High(CABAC)"
        else -> "profile=$forcedProfile"
    }

    // ------------------------------------------------------------ codec config

    /**
     * 起動直後（および output format 変更時）に outputFormat から csd-0/csd-1 を取り出して通知する。
     * 同一内容の csd は再送しない（sentCsdHash で判定）。
     */
    private fun emitCodecConfigFromFormat() {
        val c = encoder ?: return
        try {
            val f = c.outputFormat
            val list = ArrayList<ByteArray>()
            for (key in listOf("csd-0", "csd-1")) {
                val bb = runCatching { f.getByteBuffer(key) }.getOrNull()
                if (bb != null && bb.remaining() > 0) {
                    val arr = ByteArray(bb.remaining())
                    bb.get(arr)
                    list.add(arr)
                }
            }
            if (list.isEmpty()) {
                Log.w(TAG, "outputFormat に csd が無い。CODEC_CONFIG バッファから取得します")
                return
            }
            val h = csdHash(list)
            if (h == sentCsdHash) {
                Log.i(TAG, "同一の csd は送信済みなのでスキップします")
            } else {
                sentCsdHash = h
                listener.onCodecConfig(list)
            }
        } catch (e: Exception) {
            Log.w(TAG, "outputFormat からの csd 取得に失敗。CODEC_CONFIG バッファから取得します", e)
        }
    }

    private fun csdHash(list: List<ByteArray>): Int {
        var h = 1
        for (b in list) h = h * 31 + b.contentHashCode()
        return h
    }

    // ------------------------------------------------------------ MediaFormat

    /**
     * [APK確認] variant ごとにキーを増やす 4 段フォールバック。
     *   bare            : color-format / bitrate / frame-rate のみ
     *   minimal         : + i-frame-interval=2
     *   no-profile-level: + priority=0 / bitrate-mode / latency=1 / operating-rate / max-bframes=0
     *   full            : + profile / level
     */
    private fun buildFormat(w: Int, h: Int, variant: String): MediaFormat {
        val f = MediaFormat.createVideoFormat(MIME, w, h)
        f.setInteger("color-format", MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface) // 2130708361
        f.setInteger("bitrate", currentBitrate)
        f.setInteger("frame-rate", config.fps)
        if (variant == "bare") return f

        f.setInteger("i-frame-interval", 2)
        if (variant == "minimal") return f

        f.setInteger("priority", 0) // realtime
        pickBitrateMode()?.let { f.setInteger("bitrate-mode", it) }
        runCatching { f.setInteger("latency", 1) }
        runCatching { f.setInteger("operating-rate", config.fps) }
        // B フレームは遅延と受信側の並べ替え負荷を増やすため明示的に禁止（v1.0.11 で追加）
        runCatching { f.setInteger("max-bframes", 0) }
        if (variant == "no-profile-level") return f

        val profile = if (forcedProfile != 0) forcedProfile else 1
        val level = if (forcedLevel != 0) forcedLevel else pickLevel(w, h)
        f.setInteger("profile", profile)
        f.setInteger("level", level)
        Log.i(TAG, "エンコード設定: profile=$profile level=$level (variant=$variant)")
        return f
    }

    /** CBR(=2) をサポートしていれば指定する。分からなければ null（＝キーを省略）。 */
    private fun pickBitrateMode(): Int? {
        return try {
            val info = findEncoderInfo() ?: return null
            val caps = info.getCapabilitiesForType(MIME).encoderCapabilities ?: return null
            if (caps.isBitrateModeSupported(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)) 2 else null
        } catch (e: Exception) {
            Log.w(TAG, "ビットレートモードの能力取得に失敗（指定を省略します）", e)
            null
        }
    }

    /**
     * [APK確認] H.264 レベルをマクロブロック数 / MBPS から算出する。
     * 表は 7 行（level 3 から）。条件を満たす最小のレベルを返し、無ければ 65536 (= level 5.2)。
     */
    private fun pickLevel(w: Int, h: Int): Int {
        val mbFrame = ((w + 15) / 16) * ((h + 15) / 16)
        val mbps = mbFrame.toLong() * config.fps.toLong()
        val table = arrayOf(
            intArrayOf(3600, 108000, 512),      // level 3
            intArrayOf(5120, 216000, 1024),     // level 3.1
            intArrayOf(8192, 245760, 2048),     // level 4
            intArrayOf(8192, 245760, 4096),     // level 4.1 相当
            intArrayOf(8704, 522240, 8192),     // level 5
            intArrayOf(22080, 589824, 16384),   // level 5.1
            intArrayOf(36864, 983040, 32768),   // level 5.2 相当
        )
        for (row in table) {
            if (mbFrame <= row[0] && mbps <= row[1]) return row[2]
        }
        return 65536
    }

    private fun findEncoderInfo(): MediaCodecInfo? {
        val infos = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        for (info in infos) {
            if (info.isEncoder && info.supportedTypes.any { it.equals(MIME, ignoreCase = true) }) {
                return info
            }
        }
        return null
    }

    /**
     * 配信解像度に合わせた VirtualDisplay 用の density（120..640 にクランプ）。
     * [APK確認] smali は mul-float / div-float / float-to-int（＝Float 演算）で、
     *           `real.x <= 0` のときだけ端末の densityDpi をそのまま返す。
     */
    private fun densityFor(widthPx: Int): Int {
        val dm: DisplayMetrics = context.resources.displayMetrics
        val real = Companion.realScreenSize(context)
        if (real.x <= 0) return dm.densityDpi
        return (dm.densityDpi.toFloat() * widthPx.toFloat() / real.x.toFloat()).toInt().coerceIn(120, 640)
    }

    // ---------------------------------------------------------------- drain

    private fun drainLoop() {
        val c = encoder ?: return
        val info = MediaCodec.BufferInfo()
        while (running) {
            try {
                val index = c.dequeueOutputBuffer(info, 20_000L)
                if (index >= 0) {
                    try {
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            // SPS/PPS。Annex-B の NAL 単位に分割して送る
                            val buf = c.getOutputBuffer(index)
                            if (buf != null && info.size > 0) {
                                val arr = ByteArray(info.size)
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                buf.get(arr)
                                val nalus = splitAnnexB(arr)
                                if (nalus.isNotEmpty()) listener.onCodecConfig(nalus)
                            }
                        } else if (info.size > 0 && !resyncPending) {
                            val buf = c.getOutputBuffer(index)
                            if (buf != null) {
                                val arr = ByteArray(info.size)
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                buf.get(arr)
                                statFrames++
                                statBytes += arr.size.toLong()
                                val isKey = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                                listener.onEncodedFrame(arr, info.presentationTimeUs, isKey)
                            }
                        }
                        // 再同期待ちの間はキーフレームの送出を待ってフラグを下ろす
                        if (resyncPending && info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0) {
                            resyncPending = false
                            Log.i(TAG, "キーフレームを送出し再同期しました")
                        }
                        runCatching { c.releaseOutputBuffer(index, false) }
                    } catch (e: Exception) {
                        Log.e(TAG, "出力バッファ処理失敗", e)
                        runCatching { c.releaseOutputBuffer(index, false) }
                    }
                    maybeReportStats()
                } else if (index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = runCatching { c.outputFormat }.getOrNull()
                    Log.i(TAG, "encoder output format changed: $f")
                    emitCodecConfigFromFormat()
                }
            } catch (e: IllegalStateException) {
                Log.e(TAG, "dequeueOutputBuffer 失敗", e)
                listener.onError("エンコーダーが異常終了しました: ${e.message}", true)
                return
            } catch (e: Exception) {
                Log.e(TAG, "dequeueOutputBuffer で予期しない例外", e)
                listener.onError("エンコード処理で例外: ${e.javaClass.simpleName}: ${e.message}", true)
                return
            }
        }
    }

    /** [APK確認] 1 秒ごとにエンコード FPS / kbps を listener へ通知する。 */
    private fun maybeReportStats() {
        val now = System.nanoTime()
        val dt = now - statLastNs
        if (dt < 1_000_000_000L) return
        val fps = (statFrames.toLong() * 1_000_000_000L / dt).toInt()
        val kbps = (statBytes * 8L * 1_000_000_000L / dt / 1000L).toInt()
        statFrames = 0
        statBytes = 0L
        statLastNs = now
        listener.onStats(fps, kbps)
    }

    /**
     * Annex-B バイト列を NAL 単位（スタートコードを含む）に分割する。
     * [APK確認] 走査は `i < data.size`。4 バイトスタートコード (00 00 00 01) を優先し、
     *           無ければ 3 バイト (00 00 01) を判定する。
     */
    internal fun splitAnnexB(data: ByteArray): List<ByteArray> {
        val out = ArrayList<ByteArray>()
        var i = 0
        var start = -1
        while (i < data.size) {
            val isStart4 = i + 3 < data.size &&
                data[i] == 0.toByte() && data[i + 1] == 0.toByte() &&
                data[i + 2] == 0.toByte() && data[i + 3] == 1.toByte()
            val isStart3 = !isStart4 &&
                data[i] == 0.toByte() && data[i + 1] == 0.toByte() && data[i + 2] == 1.toByte()
            if (isStart4 || isStart3) {
                if (start >= 0) out.add(data.copyOfRange(start, i))
                start = i
                i += if (isStart4) 4 else 3
            } else {
                i++
            }
        }
        if (start >= 0) out.add(data.copyOfRange(start, data.size))
        return out
    }

    // ------------------------------------------------------------- control

    /** エンコーダに即時 IDR を要求する。 */
    fun requestSyncFrame() {
        val c = encoder ?: return
        try {
            val p = Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }
            c.setParameters(p)
            resyncPending = false
        } catch (e: Exception) {
            Log.w(TAG, "requestSyncFrame 失敗", e)
        }
    }

    /**
     * 送信キューがあふれたときに呼ぶ。次のキーフレームまで送出を止め、
     * 受信側のデコーダが参照フレームを失っても映像が破綻しないようにする。
     */
    fun enterResync() {
        if (!resyncPending) {
            resyncPending = true
            requestSyncFrame()
            Log.w(TAG, "送信あふれ → 次のキーフレームまで待って再同期します")
        }
    }

    /** 実行中のビットレートを変更する（非対応エンコーダでは警告のみ）。 */
    fun setBitrate(bps: Int) {
        val c = encoder ?: return
        currentBitrate = bps
        try {
            val p = Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, bps) }
            c.setParameters(p)
            Log.i(TAG, "ビットレート変更: ${bps / 1000}kbps")
        } catch (e: Exception) {
            Log.w(TAG, "ビットレート変更に非対応のエンコーダーです", e)
        }
    }

    fun stop() {
        running = false
        drainThread?.interrupt()
        drainThread = null
        release()
    }

    private fun release() {
        running = false
        sentCsdHash = 0
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { inputSurface?.release() }
        inputSurface = null
        val c = encoder
        encoder = null
        if (c != null) {
            runCatching { c.stop() }
            runCatching { c.release() }
        }
        Log.i(TAG, "キャプチャ解放完了")
    }

    fun streamWidth(): Int = streamW
    fun streamHeight(): Int = streamH

    companion object {
        private const val TAG = "LiteScreen.Capture"
        private const val MIME = "video/avc"

        // 注: createVirtualDisplay の flags = 16 は VirtualDisplay.FLAG_OWN_CONTENT_ONLY。
        //   [APK確認] smali では `const/16 v?, 0x10` が直接渡されており、元 APK にこの定数の
        //   フィールドは存在しない。意味: この VirtualDisplay には自分（ミラー用）のコンテンツ
        //   だけを映し、他アプリのダイアログ等を取り込まない（@hide のため公開定数としても参照不可）。

        /** 実画面サイズ（ナビゲーションバー等を含む物理解像度）。 */
        @Suppress("DEPRECATION")
        fun realScreenSize(context: Context): Point {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            return if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                Point(b.width(), b.height())
            } else {
                val dm = DisplayMetrics()
                wm.defaultDisplay.getRealMetrics(dm)
                Point(dm.widthPixels, dm.heightPixels)
            }
        }

        /**
         * 長辺が [maxLongEdge] を超えないよう縮小し、**16 の倍数に切り捨てる**。
         * 画面サイズが取得できなかった場合は 1280x720 を返す。
         */
        fun fitToLimit(srcW: Int, srcH: Int, maxLongEdge: Int): Pair<Int, Int> {
            val iMax = maxOf(srcW, srcH)
            val iMin = minOf(srcW, srcH)
            if (iMax <= 0 || iMin <= 0) return 1280 to 720
            val scale = if (iMax > maxLongEdge) maxLongEdge.toFloat() / iMax.toFloat() else 1.0f
            // [APK確認] smali: float-to-int → div-int/lit8 0x10 → mul-int/lit8 0x10（Int 同士の割り算＝切り捨て）
            var w = (srcW * scale).toInt() / 16 * 16
            var h = (srcH * scale).toInt() / 16 * 16
            if (w <= 0) w = 16
            if (h <= 0) h = 16
            return w to h
        }

        /** UI から「この設定で配信すると何 x 何になるか」を出すための補助。 */
        fun computeStreamSize(context: Context, config: StreamConfig): Pair<Int, Int> {
            val screen = realScreenSize(context)
            return fitToLimit(screen.x, screen.y, config.maxLongEdge)
        }
    }
}
