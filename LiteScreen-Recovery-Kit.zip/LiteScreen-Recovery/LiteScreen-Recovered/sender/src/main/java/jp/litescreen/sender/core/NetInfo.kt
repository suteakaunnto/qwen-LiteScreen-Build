/*
 * NetInfo.kt — 自端末の IPv4 アドレス列挙とブロードキャスト先算出（送信側）
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk classes5.dex
 *         jp.litescreen.sender.core.NetInfo（元ファイル NetInfo.kt）
 *
 * ■ 確定情報
 *   - candidateIPv4Addresses() の NIC 名による優先度付け（0..3）とソート、distinct
 *   - isIPv4() の検証ロジック（4要素・各1〜3桁・全て数字・parseInt が 0..255）
 *   - broadcastTargets() の "255.255.255.255" + 各 /24 の .255、`distinctBy { hostAddress }`
 *   - 例外時は Log.w(TAG, "enumerate failed", e)
 */
package jp.litescreen.sender.core

import android.util.Log
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketException

object NetInfo {

    private const val TAG = "LiteScreen.NetInfo"

    /**
     * この端末が持っている候補 IPv4 アドレスを、可能性の高い順に返す。
     *
     * 優先度（小さいほど先頭）:
     *  - 0: `wlan*` / `wifi*`   … 通常の Wi-Fi
     *  - 1: `p2p*` / `swlan*` / `ap*` … Wi-Fi Direct / ソフトAP
     *  - 2: 上記以外（`rmnet*` `ccmni*` `cc*` を除く）
     *  - 3: `rmnet*` / `ccmni*` / `cc*` … モバイル通信系
     *
     * ループバックとリンクローカル(169.254/16)は除外する。
     */
    fun candidateIPv4Addresses(): List<String> {
        val result = mutableListOf<Pair<Int, String>>()
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces()?.toList() ?: return emptyList()
            for (iface in ifaces) {
                if (!iface.isUp || iface.isLoopback) continue
                val name = iface.name ?: continue
                val priority = when {
                    name.startsWith("wlan") || name.startsWith("wifi") -> 0
                    name.startsWith("p2p") || name.startsWith("swlan") || name.startsWith("ap") -> 1
                    name.startsWith("rmnet") || name.startsWith("ccmni") || name.startsWith("cc") -> 3
                    else -> 2
                }
                for (addr in iface.inetAddresses.toList()) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && !addr.isLinkLocalAddress) {
                        val host = addr.hostAddress ?: continue
                        result.add(priority to host)
                    }
                }
            }
            return result.sortedBy { it.first }.map { it.second }.distinct()
        } catch (e: SocketException) {
            Log.w(TAG, "enumerate failed", e)
        }
        return emptyList()
    }

    /**
     * "192.168.1.20" のようなドット区切り4オクテット形式かどうかの簡易検証。
     *
     * [APK確認] smali の元ソースは `parts.all { ... }` 形（`.line 47/48`）。
     *   各要素の条件は「空でない」「3 文字以下」「全て数字」「Integer.parseInt(p) が 0..255」。
     *   数字チェックを先に通しているため parseInt は例外を投げない（toIntOrNull ではない）。
     */
    fun isIPv4(s: String): Boolean {
        val parts = s.split(".")
        if (parts.size != 4) return false
        return parts.all { p ->
            p.isNotEmpty() && p.length <= 3 && p.all { it.isDigit() } &&
                Integer.parseInt(p) in 0..255
        }
    }

    /**
     * UDP 探索でプローブを投げる宛先一覧。
     *
     * [APK確認] 実装は次のとおり:
     *  1. まず `255.255.255.255`（限定ブロードキャスト）を追加（失敗は無視）
     *  2. 各候補 IPv4 の最後のオクテットを `.255` に置換したサブネットブロードキャストを追加
     *     （自分の IP と同じ文字列になる場合は追加しない）
     *  3. `hostAddress` をキーに重複排除（順序は維持）
     *
     * ルーターが AP 分離（クライアント間通信遮断）していると届かないため、
     * UI 側で IP 手入力のフォールバックを案内している（strings.xml `hint_search_fallback`）。
     */
    fun broadcastTargets(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        runCatching { list.add(InetAddress.getByName("255.255.255.255")) }
        for (ip in candidateIPv4Addresses()) {
            val idx = ip.lastIndexOf('.')
            if (idx > 0) {
                val bcast = ip.substring(0, idx) + ".255"
                if (bcast != ip) {
                    runCatching { list.add(InetAddress.getByName(bcast)) }
                }
            }
        }
        // [APK確認] smali は distinctBy { it.hostAddress } をインライン展開した形だった
        return list.distinctBy { it.hostAddress }
    }
}
