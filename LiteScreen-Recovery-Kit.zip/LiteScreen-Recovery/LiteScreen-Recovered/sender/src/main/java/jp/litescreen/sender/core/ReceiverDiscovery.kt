/*
 * ReceiverDiscovery.kt — UDP ブロードキャストによる受信端末探索（送信側）
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk classes5.dex
 *         jp.litescreen.sender.core.ReceiverDiscovery（元ファイル ReceiverDiscovery.kt）
 *
 * ■ 確定情報（すべて DEX から）
 *   - スレッド名 "LS-DiscoveryClient"、daemon
 *   - running.getAndSet(true) が true なら探索中なので即 return
 *   - DatagramSocket: setBroadcast(true), setSoTimeout(500)
 *   - プローブは「前回送信から 900ms 以上経っていたら」全 broadcastTargets へ再送
 *   - 応答は先頭が "LITESCREEN!" のものだけ採用、substring(11) を JSON パース
 *   - tcpPort は optInt("tcpPort", DEFAULT_TCP_PORT)、app は optString("app", "")
 *   - 同一 host の重複応答は無視（none での判定）
 *   - ログ: Log.i(TAG, "found receiver $from:$port ($app)") / Log.w(TAG, "discovery error", e)
 *   - finally: runCatching { socket?.close() }; running.set(false); callback(found.sortedBy { it.host })
 *
 * ■ 元ソースと異なる可能性のある点
 *   - found.none { it.host == from } は元の書き方（none / any / find）が不明。動作は同一。
 */
package jp.litescreen.sender.core

import android.util.Log
import jp.litescreen.protocol.Proto
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 受信側アプリ（LiteScreen 受信）を LAN 内から探す。
 *
 * 仕組み: [Proto.DEFAULT_UDP_PORT] (47821) 宛に [Proto.PROBE] ("LITESCREEN?") を
 * ブロードキャストし、[Proto.PROBE_ACK] ("LITESCREEN!") + JSON で応答した端末を収集する。
 *
 * 注意: ルーターの AP 分離（クライアント間通信遮断）が有効だと届かない。
 * その場合は UI 側で IP 手入力を案内する（strings.xml `hint_search_fallback`）。
 */
class ReceiverDiscovery {

    /** 見つかった受信端末。 */
    data class Found(
        val host: String,
        val tcpPort: Int,
        val label: String
    )

    private val running = AtomicBoolean(false)
    // [APK確認] 元 APK のフィールドは `private thread:Ljava/lang/Thread;`（volatile 無し）
    private var thread: Thread? = null

    /** 探索を中止する。コールバックは呼び出されない（進行中のループが抜けた時点で終了）。 */
    fun stop() {
        running.set(false)
        thread?.interrupt()
        thread = null
    }

    /**
     * 探索を開始する。既に実行中なら何もしない。
     *
     * @param timeoutMs 探索を続ける時間。この時間が経過するか [stop] されるまで応答を集める。
     * @param callback  完了時に **ワーカースレッドから** host 順にソートした一覧を渡す。
     *                   見つからなかった場合は空リスト（UI 側でスレッド切り替えが必要）。
     */
    fun search(timeoutMs: Long, callback: (List<Found>) -> Unit) {
        if (running.getAndSet(true)) return
        val t = Thread({
            val found = mutableListOf<Found>()
            var socket: DatagramSocket? = null
            try {
                val s = DatagramSocket()
                s.broadcast = true
                s.soTimeout = 500
                socket = s

                val targets: List<InetAddress> = NetInfo.broadcastTargets()
                val deadline = System.currentTimeMillis() + timeoutMs
                var sent = 0L
                while (running.get() && System.currentTimeMillis() < deadline) {
                    // 900ms ごとにプローブを再送する（初回は sent=0 なので即送信される）
                    if (System.currentTimeMillis() >= sent + 900L) {
                        sent = System.currentTimeMillis()
                        for (t2 in targets) {
                            runCatching {
                                s.send(DatagramPacket(Proto.PROBE, Proto.PROBE.size, t2, Proto.DEFAULT_UDP_PORT))
                            }
                        }
                    }
                    val buf = ByteArray(1024)
                    val pkt = DatagramPacket(buf, buf.size)
                    try {
                        s.receive(pkt)
                    } catch (e: SocketTimeoutException) {
                        continue
                    }
                    val from = pkt.address?.hostAddress ?: continue
                    if (found.any { it.host == from }) continue
                    val body = String(pkt.data, pkt.offset, pkt.length, Charsets.UTF_8)
                    if (!body.startsWith("LITESCREEN!")) continue
                    val json = body.substring(11)
                    val port = runCatching { JSONObject(json).optInt("tcpPort", Proto.DEFAULT_TCP_PORT) }
                        .getOrDefault(Proto.DEFAULT_TCP_PORT)
                    val app = runCatching { JSONObject(json).optString("app", "") }.getOrDefault("")
                    found.add(Found(from, port, app))
                    Log.i(TAG, "found receiver $from:$port ($app)")
                }
            } catch (e: Exception) {
                Log.w(TAG, "discovery error", e)
            } finally {
                runCatching { socket?.close() }
                running.set(false)
            }
            // [APK確認] callback は **finally の外**。元 smali では
            //   `DatagramSocket.close()` と `AtomicBoolean.set(false)` が 3 コピー
            //   （finally の複製）あるのに対し、`CollectionsKt.sortedWith` は 1 か所だけ。
            //   finally 内に書くと sortedBy の合成 Comparator クラスが 3 個生成され
            //   クラス数が元 APK(49) より増える(51)ため、Phase D 検証で元の形に修正した。
            callback(found.sortedBy { it.host })
        }, "LS-DiscoveryClient")
        t.isDaemon = true
        t.start()
        thread = t
    }

    companion object {
        private const val TAG = "LiteScreen.Discovery"
    }
}
