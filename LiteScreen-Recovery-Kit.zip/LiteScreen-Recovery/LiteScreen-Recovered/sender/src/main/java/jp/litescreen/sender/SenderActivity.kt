/*
 * SenderActivity.kt — 送信側アプリのメイン画面（接続先設定・受信側検索・配信開始/停止）
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk classes4.dex
 *         jp.litescreen.sender.SenderActivity（元ファイル SenderActivity.kt, 約 34〜826 行相当）
 *
 * ■ 復元方針
 *   - jadx の Java 出力を Kotlin に戻した。UI 部はビット演算・符号拡張が無いので jadx の構造をそのまま採用。
 *   - smali で確認したポイント:
 *       * 親クラスは **android.app.Activity**（AppCompatActivity ではない。DEX に androidx が 1 件も無い）
 *       * リクエストコード REQ_PROJECTION=0x3e9(1001), REQ_NOTIFICATION=0x3ea(1002)
 *       * フィールド初期化順 = handler → statusTicker → suggestedKbps(0xfa0=4000)
 *       * statusTicker は 1000ms ごとに自己再 post（MirrorService.getStateText() を表示し、
 *         stateText.startsWith("配信中") で 開始/停止 ボタンの活性を切り替える）
 *       * onActivityResult には @Deprecated(message="AndroidX を使わないため従来の
 *         onActivityResult を使用（全 API レベルで動作）") が付いていた
 *       * SharedPreferences 名 "litescreen"、キー host/port/res_pos/fps_pos/bitrate_pos
 *       * MulticastLock のタグは "litescreen-search"（受信側アプリの "litescreen-discovery" とは別）
 *       * Toast の length は 1(LENGTH_LONG) / 0(LENGTH_SHORT) で呼び分け
 *
 * ■ 未確認事項 [推定]
 *   - ローカル変数名・改行は元ソースと異なる可能性がある（文字列リソース ID と挙動は同一）。
 *   - findViewById 呼び出しは元の形（`findViewById(R.id.x)` の型推論）を維持している。
 *     `lateinit var` への代入順も jadx の出力順どおり。
 */
package jp.litescreen.sender

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import jp.litescreen.sender.core.NetInfo
import jp.litescreen.sender.core.ReceiverDiscovery
import jp.litescreen.sender.core.StreamConfig

class SenderActivity : Activity() {

    private lateinit var hostInput: EditText
    private lateinit var portInput: EditText
    private lateinit var statusText: TextView
    private lateinit var myIpText: TextView
    private lateinit var resolutionSpinner: Spinner
    private lateinit var fpsSpinner: Spinner
    private lateinit var bitrateSpinner: Spinner
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var searchButton: Button
    private lateinit var qualityWarning: TextView
    private lateinit var bitrateHint: TextView

    private val handler = Handler(Looper.getMainLooper())

    /** 1 秒ごとにサービスの状態文字列を反映し、ボタン活性を切り替える。 */
    private val statusTicker = object : Runnable {
        override fun run() {
            statusText.text = MirrorService.getStateText()
            val streaming = MirrorService.getStateText().startsWith("配信中")
            startButton.isEnabled = !streaming
            stopButton.isEnabled = streaming
            handler.postDelayed(this, 1000L)
        }
    }

    private var discovery: ReceiverDiscovery? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var pendingConfig: StreamConfig? = null

    private var suggestedKbps = 4000
    private var suggestedIndex = 0

    // --------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sender)

        hostInput = findViewById(R.id.host_input)
        portInput = findViewById(R.id.port_input)
        statusText = findViewById(R.id.status_text)
        myIpText = findViewById(R.id.my_ip_text)
        resolutionSpinner = findViewById(R.id.resolution_spinner)
        fpsSpinner = findViewById(R.id.fps_spinner)
        bitrateSpinner = findViewById(R.id.bitrate_spinner)
        startButton = findViewById(R.id.start_button)
        stopButton = findViewById(R.id.stop_button)
        searchButton = findViewById(R.id.search_button)
        qualityWarning = findViewById(R.id.quality_warning)
        bitrateHint = findViewById(R.id.bitrate_hint)

        setupSpinner(resolutionSpinner, StreamConfig.RESOLUTION_CHOICES.map { StreamConfig.resolutionLabel(it) }, 0)
        setupSpinner(fpsSpinner, StreamConfig.FPS_CHOICES.map { "$it fps" }, StreamConfig.FPS_CHOICES.indexOf(30).coerceAtLeast(0))
        setupSpinner(bitrateSpinner, StreamConfig.BITRATE_CHOICES.map { StreamConfig.bitrateLabel(it) }, StreamConfig.BITRATE_CHOICES.indexOf(4000).coerceAtLeast(0))

        // ビットレートの推奨値ヒントは「タップしたときだけ」選択値に反映する
        // （ユーザーが明示的に選んだ値を勝手に上書きしないため。v1.0.10 の修正）
        bitrateHint.setOnClickListener {
            applyBitrateSuggestion()
            updateQualityWarning()
        }

        val prefs = getSharedPreferences("litescreen", MODE_PRIVATE)
        hostInput.setText(prefs.getString(MirrorService.EXTRA_HOST, ""))
        portInput.setText(prefs.getString(MirrorService.EXTRA_PORT, "47820"))
        prefs.getInt("res_pos", -1).takeIf { it in 0 until StreamConfig.RESOLUTION_CHOICES.size }
            ?.let { resolutionSpinner.setSelection(it) }
        prefs.getInt("fps_pos", -1).takeIf { it in 0 until StreamConfig.FPS_CHOICES.size }
            ?.let { fpsSpinner.setSelection(it) }
        prefs.getInt("bitrate_pos", -1).takeIf { it in 0 until StreamConfig.BITRATE_CHOICES.size }
            ?.let { bitrateSpinner.setSelection(it) }

        updateQualityWarning()

        searchButton.setOnClickListener { onSearch() }
        startButton.setOnClickListener { onStartStreaming() }
        stopButton.setOnClickListener { onStopStreaming() }

        refreshMyIp()
        statusText.text = MirrorService.getStateText()
    }

    override fun onResume() {
        super.onResume()
        refreshMyIp()
        handler.post(statusTicker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(statusTicker)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        discovery?.stop()
        releaseMulticastLock()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ spinner

    private fun setupSpinner(spinner: Spinner, labels: List<String>, defaultIndex: Int) {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter
        spinner.setSelection(defaultIndex.coerceIn(0, labels.size - 1))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                updateQualityWarning()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // no-op
            }
        }
    }

    /**
     * 現在の解像度・fps から推奨ビットレートを計算してヒントに表示する。
     * [APK確認] 想定アスペクト比は 2400x1504（= REDMAGIC Astra 級の実画面）で、
     *           w = min(res, 2400)、h = res>=2400 ? 1504 : res*1504/2400 として
     *           StreamConfig.suggestBitrateKbps(w, h, fps) を呼ぶ。
     */
    private fun updateBitrateHint() {
        if (!::bitrateHint.isInitialized) return

        val res = StreamConfig.RESOLUTION_CHOICES.getOrElse(resolutionSpinner.selectedItemPosition) { 1280 }
        val fps = StreamConfig.FPS_CHOICES.getOrElse(fpsSpinner.selectedItemPosition) { 30 }
        val w = if (res >= 2400) 2400 else res
        val h = if (res >= 2400) 1504 else (res * 1504) / 2400

        suggestedKbps = StreamConfig.suggestBitrateKbps(w, h, fps)
        suggestedIndex = indexOfNearestBitrate(suggestedKbps)
        val mbps = suggestedKbps / 1000
        val frac = (suggestedKbps % 1000) / 100

        val curPos = bitrateSpinner.selectedItemPosition
        val curKbps = StreamConfig.BITRATE_CHOICES.getOrElse(curPos) { 0 }
        bitrateHint.text = if (suggestedIndex == curPos) {
            getString(R.string.hint_bitrate_applied, mbps, frac, w, h, fps)
        } else {
            getString(R.string.hint_bitrate_suggest, mbps, frac, w, h, fps, StreamConfig.bitrateLabel(curKbps))
        }
        bitrateHint.visibility = View.VISIBLE
    }

    private fun indexOfNearestBitrate(kbps: Int): Int {
        var bestIdx = 0
        var bestDiff = Int.MAX_VALUE
        for (i in StreamConfig.BITRATE_CHOICES.indices) {
            val diff = Math.abs(StreamConfig.BITRATE_CHOICES[i] - kbps)
            if (diff < bestDiff) {
                bestDiff = diff
                bestIdx = i
            }
        }
        return bestIdx
    }

    private fun applyBitrateSuggestion() {
        if (!::bitrateSpinner.isInitialized) return
        if (suggestedIndex in 0 until StreamConfig.BITRATE_CHOICES.size) {
            bitrateSpinner.setSelection(suggestedIndex)
        }
    }

    /** 高負荷になりがちな組み合わせのときだけ警告を表示する。 */
    private fun updateQualityWarning() {
        if (!::qualityWarning.isInitialized) return
        updateBitrateHint()

        val res = StreamConfig.RESOLUTION_CHOICES.getOrElse(resolutionSpinner.selectedItemPosition) { 1280 }
        val fps = StreamConfig.FPS_CHOICES.getOrElse(fpsSpinner.selectedItemPosition) { 30 }
        val kbps = StreamConfig.BITRATE_CHOICES.getOrElse(bitrateSpinner.selectedItemPosition) { 2500 }

        val text = when {
            fps >= 60 -> getString(R.string.warn_quality_60fps)
            res >= 1920 || kbps >= 4000 -> getString(R.string.warn_quality_high)
            else -> null
        }
        if (text == null) {
            qualityWarning.visibility = View.GONE
        } else {
            qualityWarning.text = text
            qualityWarning.visibility = View.VISIBLE
        }
    }

    // --------------------------------------------------------------------- info

    private fun refreshMyIp() {
        val list = NetInfo.candidateIPv4Addresses()
        myIpText.text = if (list.isEmpty()) {
            "${getString(R.string.label_my_ip)}: 取得できません（Wi-Fi未接続）"
        } else {
            "${getString(R.string.label_my_ip)}: ${list.joinToString(", ")}"
        }
    }

    private fun persistSettings() {
        getSharedPreferences("litescreen", MODE_PRIVATE).edit()
            .putString(MirrorService.EXTRA_HOST, hostInput.text.toString().trim())
            .putString(MirrorService.EXTRA_PORT, portInput.text.toString().trim())
            .putInt("res_pos", resolutionSpinner.selectedItemPosition)
            .putInt("fps_pos", fpsSpinner.selectedItemPosition)
            .putInt("bitrate_pos", bitrateSpinner.selectedItemPosition)
            .apply()
    }

    /** 入力欄から配信設定を作る。IP / ポートが不正なら Toast を出して null。 */
    private fun currentConfig(): StreamConfig? {
        val host = hostInput.text.toString().trim()
        if (!NetInfo.isIPv4(host)) {
            Toast.makeText(this, R.string.toast_invalid_ip, Toast.LENGTH_LONG).show()
            return null
        }
        val port = portInput.text.toString().trim().toIntOrNull()
        if (port == null || port !in 1..65535) {
            Toast.makeText(this, R.string.toast_invalid_ip, Toast.LENGTH_LONG).show()
            return null
        }
        return StreamConfig(
            host = host,
            port = port,
            maxLongEdge = StreamConfig.RESOLUTION_CHOICES[resolutionSpinner.selectedItemPosition],
            fps = StreamConfig.FPS_CHOICES[fpsSpinner.selectedItemPosition],
            bitrateKbps = StreamConfig.BITRATE_CHOICES[bitrateSpinner.selectedItemPosition],
        )
    }

    // ----------------------------------------------------------------- discovery

    private fun onSearch() {
        searchButton.isEnabled = false
        searchButton.setText(R.string.action_searching)
        acquireMulticastLock()
        discovery?.stop()
        val d = ReceiverDiscovery()
        discovery = d
        d.search(2500L) { found ->
            handler.post {
                searchButton.isEnabled = true
                searchButton.setText(R.string.action_search)
                releaseMulticastLock()
                if (found.isEmpty()) {
                    Toast.makeText(this, R.string.toast_search_none, Toast.LENGTH_LONG).show()
                } else {
                    showDiscoveryResult(found)
                }
            }
        }
    }

    private fun showDiscoveryResult(found: List<ReceiverDiscovery.Found>) {
        val labels = found.map { "${it.host}  (port ${it.tcpPort})" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_discovery_title)
            .setItems(labels) { _, which ->
                hostInput.setText(found[which].host)
                portInput.setText(found[which].tcpPort.toString())
                Toast.makeText(this, getString(R.string.toast_search_found, found[which].host), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** 検索ではブロードキャストだけでなくマルチキャスト応答も拾えるようにロックを取る。 */
    private fun acquireMulticastLock() {
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as? WifiManager ?: return
            val lock = wm.createMulticastLock("litescreen-search")
            lock.setReferenceCounted(false)
            if (!lock.isHeld) lock.acquire()
            multicastLock = lock
        } catch (e: Exception) {
            Log.w(TAG, "multicast lock", e)
        }
    }

    private fun releaseMulticastLock() {
        runCatching {
            multicastLock?.let { if (it.isHeld) it.release() }
        }
        multicastLock = null
    }

    // ----------------------------------------------------------------- streaming

    private fun onStartStreaming() {
        val config = currentConfig() ?: return
        persistSettings()

        // Android 13 以降は通知権限が無いとフォアグラウンド通知が出せない
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATION)
            Toast.makeText(this, R.string.toast_need_notification_permission, Toast.LENGTH_LONG).show()
            return
        }

        AlertDialog.Builder(this)
            .setTitle(R.string.dialog_permission_title)
            .setMessage(R.string.dialog_permission_body)
            .setPositiveButton(R.string.dialog_ok) { _, _ -> requestProjection(config) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun requestProjection(config: StreamConfig) {
        pendingConfig = config
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    /**
     * AndroidX を使わないため従来の onActivityResult を使用する（全 API レベルで動作）。
     * 元のソースにも同じ message の @Deprecated が付いていた。[APK確認]
     */
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    @Deprecated("AndroidX を使わないため従来の onActivityResult を使用（全 API レベルで動作）")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJECTION) return
        val config = pendingConfig
        pendingConfig = null
        if (resultCode != RESULT_OK || data == null || config == null) {
            statusText.setText(R.string.status_stopped)
            Toast.makeText(this, R.string.status_stopped, Toast.LENGTH_SHORT).show()
            return
        }
        startMirrorService(config, resultCode, data)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        @Suppress("DEPRECATION")
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATION) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
            if (!granted) {
                Toast.makeText(this, R.string.toast_need_notification_permission, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startMirrorService(config: StreamConfig, resultCode: Int, data: Intent) {
        val intent = Intent(this, MirrorService::class.java)
            .setAction(MirrorService.ACTION_START)
            .putExtra(MirrorService.EXTRA_RESULT_CODE, resultCode)
            .putExtra(MirrorService.EXTRA_RESULT_DATA, data)
            .putExtra(MirrorService.EXTRA_HOST, config.host)
            .putExtra(MirrorService.EXTRA_PORT, config.port)
            .putExtra(MirrorService.EXTRA_MAX_LONG_EDGE, config.maxLongEdge)
            .putExtra(MirrorService.EXTRA_FPS, config.fps)
            .putExtra(MirrorService.EXTRA_BITRATE_KBPS, config.bitrateKbps)
        startForegroundService(intent)
        startButton.isEnabled = false
        stopButton.isEnabled = true
        statusText.setText(R.string.status_connecting)
    }

    private fun onStopStreaming() {
        val intent = Intent(this, MirrorService::class.java).setAction(MirrorService.ACTION_STOP)
        startForegroundService(intent)
        startButton.isEnabled = true
        stopButton.isEnabled = false
        statusText.setText(R.string.status_stopped)
    }

    companion object {
        // [APK確認] 元の DEX の static フィールドはこの 3 つだけ
        //   TAG="LiteScreen.Activity" / REQ_PROJECTION=0x3e9(1001) / REQ_NOTIFICATION=0x3ea(1002)
        private const val TAG = "LiteScreen.Activity"
        private const val REQ_PROJECTION = 1001
        private const val REQ_NOTIFICATION = 1002
    }
}
