/*
 * SenderClient.kt — 受信側との TCP セッション（送信側）
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk classes5.dex
 *         jp.litescreen.sender.core.SenderClient（元ファイル SenderClient.kt）
 *
 * ■ negotiated* / lastRttMs / backpressureCount は「プロパティ」ではなく「関数」
 *   [APK確認] smali に `.method public final negotiatedOk()Z` 等があり、
 *     `getNegotiatedOk()` は存在しない → 元ソースは `fun negotiatedOk(): Boolean = ackOk` 形。
 *   [APK確認] バックエンドフィールドは `private volatile ackOk/ackW/ackH/ackFps/ackProfile/
 *     ackLevel/ackDetail/backpressureCount/lastRttMs`（`*Value` のような接尾辞は無い）。
 *   [APK確認] @Metadata d2 の宣言順 = negotiatedOk, negotiatedProfile, negotiatedLevel,
 *     negotiatedWidth, negotiatedHeight, negotiatedFps, negotiatedDetail。
 *     d2 末尾に "sender_debug" があり、Kotlin モジュール名は sender_debug
 *     （internal 宣言 `splitAnnexB$sender_debug` とも一致）。
 *   → 復元コードもフィールド名・関数名・宣言順をこれに合わせた。
 *
 * ■ 確定情報（すべて DEX から）
 *   - 定数 CONNECT_TIMEOUT_MS=8000, PING_INTERVAL_MS=3000, QUEUE_CAPACITY=40,
 *     STALL_TIMEOUT_MS=15000, TAG="LiteScreen.Sender"
 *   - スレッド名 LS-Writer / LS-Reader / LS-Watchdog（すべて daemon）
 *   - 送信は LS-Writer の 1 スレッド + writeLock に集約（フレーム混在が起きない）
 *   - 各メッセージのペイロード構成（recovery/reports/APK_FORENSICS.md §8.4）
 *   - 日本語のエラーメッセージ文字列（1 文字ずつ一致）
 */
package jp.litescreen.sender.core

import android.util.Log
import jp.litescreen.protocol.Framing
import jp.litescreen.protocol.Proto
import jp.litescreen.protocol.ProtocolException
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 受信側アプリとの TCP 接続を担当する。
 *
 * - 接続: [connect]（受信側が ServerSocket を開いて待っている所へこちらから繋ぐ）
 * - 能力ネゴシエーション: [negotiate]（MSG_PROPOSE を送り MSG_PROPOSE_ACK を待つ）
 * - 映像送出: [sendFrame]（内部キュー経由、キュー満杯時は VIDEO を落として背圧通知）
 * - 制御: [sendVideoConfig] / [sendCodecConfig] / [sendInfo] / [sendError] / [sendBye]
 *
 * スレッド構成:
 * ```
 *   LS-Writer   … ArrayBlockingQueue(40) から取り出して write + flush する唯一の書き込み手
 *   LS-Reader   … 受信ループ（HELLO 応答待ち、PING/PONG、STATS、PROPOSE_ACK、BYE …）
 *   LS-Watchdog … 3 秒ごとに PING を送り、15 秒無応答なら切断
 * ```
 */
class SenderClient(
    private val config: StreamConfig,
    private val listener: Listener
) {

    interface Listener {
        fun onConnected(remote: String, receiverAudioSupport: Boolean)
        fun onKeyFrameRequested()
        fun onReceiverStats(fps: Int, kbps: Int, droppedTotal: Long, pending: Int)
        fun onBackpressure()
        fun onDisconnected(reason: String)
        fun onError(message: String)
    }

    private var socket: Socket? = null
    private var out: DataOutputStream? = null
    private var writerThread: Thread? = null
    private var readerThread: Thread? = null
    private var watchdogThread: Thread? = null

    private val queue = ArrayBlockingQueue<ByteArray>(QUEUE_CAPACITY)
    private val writeLock = Any()
    private val running = AtomicBoolean(false)
    private val connected = AtomicBoolean(false)

    @Volatile private var lastRttMs: Int = -1
    @Volatile private var rttSamples: Long = 0
    @Volatile private var lastRecvNs: Long = System.nanoTime()
    @Volatile private var backpressureCount: Long = 0

    // --- 能力ネゴシエーションの結果（MSG_PROPOSE_ACK で埋まる） ---
    @Volatile private var ackLatch: CountDownLatch? = null
    @Volatile private var ackOk: Boolean = false
    @Volatile private var ackW: Int = 0
    @Volatile private var ackH: Int = 0
    @Volatile private var ackFps: Int = 0
    @Volatile private var ackProfile: Int = 0
    @Volatile private var ackLevel: Int = 0
    @Volatile private var ackDetail: String = ""

    val isConnected: Boolean get() = connected.get()

    // [APK確認] 元 APK ではこれらはプロパティ(getter)ではなく **関数**。
    //   同名の private フィールド(backpressureCount / lastRttMs)と関数を共存させるのは
    //   Kotlin で可能（フィールドアクセスは getfield になり再帰しない）。

    /** キュー満杯で VIDEO フレームを落とした累計回数。 */
    fun backpressureCount(): Long = backpressureCount

    /** 直近の RTT（ミリ秒）。まだ計測できていなければ -1。 */
    fun lastRttMs(): Int = lastRttMs

    fun negotiatedOk(): Boolean = ackOk
    fun negotiatedProfile(): Int = ackProfile
    fun negotiatedLevel(): Int = ackLevel
    fun negotiatedWidth(): Int = ackW
    fun negotiatedHeight(): Int = ackH
    fun negotiatedFps(): Int = ackFps
    /** 受信側が返した人間可読な判定理由（UI にそのまま表示できる日本語）。 */
    fun negotiatedDetail(): String = ackDetail

    /**
     * 受信側へ接続し、HELLO を交換してワーカー3本を起動する。
     *
     * [APK確認] 手順:
     *  1. Socket を作って TCP_NODELAY / SO_SNDBUF=512KiB / SO_RCVBUF=64KiB / KEEPALIVE を設定
     *  2. 8 秒タイムアウトで connect
     *  3. soTimeout=8000 にして **受信側からの HELLO を待つ**（受信側が先に送る）
     *  4. version != 1 なら ProtocolException
     *  5. こちらの HELLO(16B: version=1, audioSupport=1, 0, 0) を即座に同期書き込み
     *  6. soTimeout=0（無限）に戻して LS-Writer / LS-Reader / LS-Watchdog を起動
     */
    fun connect(): Boolean {
        if (running.get()) return false
        try {
            val s = Socket()
            s.tcpNoDelay = true
            s.sendBufferSize = 524288
            s.receiveBufferSize = 65536
            s.keepAlive = true
            s.connect(InetSocketAddress(config.host, config.port), CONNECT_TIMEOUT_MS)
            socket = s
            out = DataOutputStream(BufferedOutputStream(s.getOutputStream(), 65536))
            running.set(true)

            val input = BufferedInputStream(s.getInputStream(), 65536)

            // 受信側が accept 直後に HELLO を送ってくるので、それを読む
            s.soTimeout = CONNECT_TIMEOUT_MS
            val (type, len) = Framing.readHeader(input)
            val payload = Framing.readPayload(input, len)
            s.soTimeout = 0

            if (type != Proto.MSG_HELLO) {
                throw ProtocolException("HELLO ではなく type=$type が届いた")
            }
            val version = Framing.readInt(payload, 0)
            val audioSupport = Framing.readInt(payload, 8) != 0
            if (version != Proto.VERSION) {
                throw ProtocolException("プロトコルバージョン不一致 (receiver=$version, sender=${Proto.VERSION})")
            }

            // 送信側の HELLO: version=1, audioSupport=1, 予約=0, 予約=0
            val hello = Framing.intBytes(1) + Framing.intBytes(1) +
                Framing.intBytes(0) + Framing.intBytes(0)
            Framing.writeMessage(out!!, Proto.MSG_HELLO, hello)

            connected.set(true)
            lastRecvNs = System.nanoTime()

            val remote = (s.remoteSocketAddress as? InetSocketAddress)
                ?.let { "${it.address.hostAddress}:${it.port}" }
                ?: config.host
            Log.i(TAG, "接続完了 $remote / receiver audioSupport=$audioSupport")
            listener.onConnected(remote, audioSupport)

            writerThread = Thread({ writeLoop() }, "LS-Writer").apply { isDaemon = true; start() }
            readerThread = Thread({ readLoop(input) }, "LS-Reader").apply { isDaemon = true; start() }
            watchdogThread = Thread({ watchdogLoop() }, "LS-Watchdog").apply { isDaemon = true; start() }
            return true
        } catch (e: SocketTimeoutException) {
            fail("接続タイムアウト（8秒）。受信側アプリが起動しているか、IP/ポートが正しいか確認してください")
            return false
        } catch (e: ProtocolException) {
            fail(e.message ?: "プロトコルエラー")
            return false
        } catch (e: IOException) {
            fail("接続失敗: ${e.javaClass.simpleName} ${e.message}")
            return false
        } catch (e: Exception) {
            fail("接続処理中の例外: ${e.message}")
            return false
        }
    }

    private fun fail(msg: String) {
        Log.w(TAG, msg)
        listener.onError(msg)
        close("接続失敗")
    }

    /** MSG_VIDEO_CONFIG(2): width, height, fps, bitrateKbps（各 int32 BE, 計16バイト） */
    fun sendVideoConfig(width: Int, height: Int, fps: Int, bitrateKbps: Int) {
        val payload = Framing.intBytes(width) + Framing.intBytes(height) +
            Framing.intBytes(fps) + Framing.intBytes(bitrateKbps)
        enqueue(Proto.MSG_VIDEO_CONFIG, payload, important = true)
    }

    /**
     * MSG_CODEC_CONFIG(3): count, {len, data}*count
     * [APK確認] csd が空なら何も送らない（早期 return）。
     */
    fun sendCodecConfig(csd: List<ByteArray>) {
        if (csd.isEmpty()) return
        var payload = Framing.intBytes(csd.size)
        for (b in csd) {
            payload = payload + Framing.intBytes(b.size) + b
        }
        enqueue(Proto.MSG_CODEC_CONFIG, payload, important = true)
    }

    /**
     * MSG_VIDEO(4): ptsUs(int64), flags(int32), sendMs(int32), H.264 Annex-B 本体
     *
     * sendMs は `System.currentTimeMillis() % 1000000`（RTT 計測用のエコー値）。
     *   [APK確認] 元 smali: `const v5, 0xf4240`(=1000000) → `int-to-long` → `rem-long`。
     *   Int リテラルのまま書くこと（`1000000L` にすると `const-wide` になり
     *   元 APK と命令列が変わる。Phase D 検証で判明・修正済み）。
     * @return キューに積めたか。false ならこのフレームは落ちた（背圧）。
     */
    fun sendFrame(data: ByteArray, ptsUs: Long, isKey: Boolean): Boolean {
        if (!connected.get()) return false
        val payload = Framing.longBytes(ptsUs) +
            Framing.intBytes(if (isKey) 1 else 0) +
            Framing.intBytes((System.currentTimeMillis() % 1000000).toInt()) +
            data
        return enqueue(Proto.MSG_VIDEO, payload, important = false)
    }

    /**
     * ヘッダ付きの完成形フレームを作ってキューに積む。
     *
     * [APK確認] キュー満杯時の挙動:
     *  - important=false（= VIDEO）: 積まずに捨てて backpressureCount++ と onBackpressure()
     *  - important=true（= 制御メッセージ）: 先頭を 1 件 poll してから押し込む。
     *    それでも積めなければ false。backpressureCount は増加させる。
     */
    private fun enqueue(type: Int, payload: ByteArray, important: Boolean): Boolean {
        val o = out ?: return false
        val msg = ByteArray(payload.size + Proto.HEADER_SIZE)
        msg[0] = Proto.MAGIC[0]
        msg[1] = Proto.MAGIC[1]
        msg[2] = Proto.MAGIC[2]
        msg[3] = Proto.MAGIC[3]
        msg[4] = type.toByte()
        msg[5] = ((payload.size ushr 16) and 0xFF).toByte()
        msg[6] = ((payload.size ushr 8) and 0xFF).toByte()
        msg[7] = (payload.size and 0xFF).toByte()
        System.arraycopy(payload, 0, msg, Proto.HEADER_SIZE, payload.size)

        if (!queue.offer(msg)) {
            if (!important) {
                backpressureCount++
                listener.onBackpressure()
                return false
            }
            queue.poll() ?: return false
            backpressureCount++
            if (!queue.offer(msg)) return false
        }
        return true
    }

    /** 唯一の書き込みスレッド。writeLock で排他しつつ write + flush。 */
    private fun writeLoop() {
        val o = out ?: return
        while (running.get()) {
            try {
                val msg = queue.poll(200, TimeUnit.MILLISECONDS)
                if (msg != null) {
                    synchronized(writeLock) {
                        o.write(msg)
                        o.flush()
                    }
                }
            } catch (e: InterruptedException) {
                return
            } catch (e: IOException) {
                if (running.get()) {
                    Log.w(TAG, "write 失敗", e)
                    listener.onError("送信に失敗しました: ${e.message}")
                    close("write失敗")
                }
                return
            }
        }
    }

    /** 受信ループ。1 メッセージ処理するごとに lastRecvNs を更新する。 */
    private fun readLoop(input: BufferedInputStream) {
        while (running.get()) {
            try {
                val (type, len) = Framing.readHeader(input)
                val payload = Framing.readPayload(input, len)
                lastRecvNs = System.nanoTime()
                when (type) {
                    Proto.MSG_KEYFRAME_REQUEST -> listener.onKeyFrameRequested()

                    Proto.MSG_PING -> {
                        if (out != null) enqueue(Proto.MSG_PONG, payload, important = true)
                    }

                    Proto.MSG_PONG -> {
                        if (payload.size >= 8) {
                            val sentMs = Framing.readLong(payload, 0)
                            val rtt = System.currentTimeMillis() - sentMs
                            if (rtt in 0..60000) {
                                lastRttMs = rtt.toInt()
                                rttSamples++
                            }
                        }
                    }

                    Proto.MSG_STATS -> {
                        if (payload.size >= 8) {
                            val fps = Framing.readInt(payload, 0)
                            val kbps = Framing.readInt(payload, 4)
                            val dropped: Long
                            val pending: Int
                            if (payload.size >= Proto.STATS_V2_SIZE) {
                                // v2: off8=lastSendMs(エコー), off12=dropped, off16=pending, off20=decoded
                                dropped = Framing.readInt(payload, 12).toLong() and 0xFFFFFFFFL
                                pending = Framing.readInt(payload, 16)
                            } else {
                                dropped = -1L
                                pending = 0
                            }
                            listener.onReceiverStats(fps, kbps, dropped, pending)
                        }
                    }

                    Proto.MSG_BYE -> {
                        close("受信側が切断しました")
                        return
                    }

                    Proto.MSG_AUDIO_UNSUPPORTED ->
                        Log.i(TAG, "受信側が音声非対応を通知（想定どおり。音声は送っていない）")

                    Proto.MSG_PROPOSE_ACK -> {
                        if (payload.size >= Proto.PROPOSE_ACK_V2_HEADER) {
                            ackOk = Framing.readInt(payload, 0) == 1
                            ackW = Framing.readInt(payload, 4)
                            ackH = Framing.readInt(payload, 8)
                            ackFps = Framing.readInt(payload, 12)
                            ackProfile = Framing.readInt(payload, 16)
                            ackLevel = Framing.readInt(payload, 20)
                            ackDetail = String(payload, 24, payload.size - 24, Charsets.UTF_8)
                        } else if (payload.size >= 16) {
                            // 旧式（profile / level なし）
                            ackOk = Framing.readInt(payload, 0) == 1
                            ackW = Framing.readInt(payload, 4)
                            ackH = Framing.readInt(payload, 8)
                            ackFps = Framing.readInt(payload, 12)
                            ackProfile = 0
                            ackLevel = 0
                            ackDetail = String(payload, 16, payload.size - 16, Charsets.UTF_8)
                        } else {
                            ackOk = false
                            ackDetail = "PROPOSE_ACK が短すぎます (${payload.size} bytes)"
                        }
                        Log.i(TAG, "PROPOSE_ACK ok=$ackOk ${ackW}x${ackH}@${ackFps}" +
                            " profile=$ackProfile level=$ackLevel : $ackDetail")
                        ackLatch?.countDown()
                    }

                    // MSG_ERROR(11) / MSG_INFO(12) / MSG_PROPOSE(13) は送信側では未処理 → default へ
                    else -> Log.w(TAG, "未知のメッセージ type=$type len=$len → 破棄")
                }
            } catch (e: SocketTimeoutException) {
                close("受信タイムアウト")
                return
            } catch (e: ProtocolException) {
                listener.onError("プロトコルエラー: ${e.message}")
                close("プロトコルエラー")
                return
            } catch (e: IOException) {
                if (running.get()) close("受信側との接続が切れました")
                return
            } catch (e: Exception) {
                Log.w(TAG, "read loop", e)
                if (running.get()) close("受信処理エラー: ${e.message}")
                return
            }
        }
    }

    /** 3 秒ごとに PING を送り、15 秒無応答なら切断する。 */
    private fun watchdogLoop() {
        while (running.get()) {
            try {
                Thread.sleep(PING_INTERVAL_MS)
                if (!running.get()) return
                val idle = (System.nanoTime() - lastRecvNs) / 1_000_000L
                if (idle > STALL_TIMEOUT_MS) {
                    Log.w(TAG, "受信側からの応答が ${idle}ms ないため切断します")
                    listener.onError("受信側からの応答がなくなりました（${idle / 1000}秒）")
                    close("無通信タイムアウト")
                    return
                }
                if (out != null) {
                    enqueue(Proto.MSG_PING, Framing.longBytes(System.currentTimeMillis()), important = true)
                }
            } catch (e: InterruptedException) {
                return
            }
        }
    }

    /**
     * 能力ネゴシエーション。MSG_PROPOSE(w,h,fps) を送り、MSG_PROPOSE_ACK を待つ。
     *
     * @return 応答が時間内に届いたか。**false でも [negotiatedDetail] に理由が入る**ので
     *         呼び出し側はそれを UI に出せる。
     */
    fun negotiate(w: Int, h: Int, fps: Int, timeoutMs: Long = 8000L): Boolean {
        if (!connected.get()) {
            ackDetail = "未接続のため能力ネゴシエーションを行えません"
            return false
        }
        val latch = CountDownLatch(1)
        ackLatch = latch
        ackOk = false
        ackW = 0
        ackH = 0
        ackFps = 0
        ackProfile = 0
        ackLevel = 0
        ackDetail = ""

        val payload = Framing.intBytes(w) + Framing.intBytes(h) + Framing.intBytes(fps)
        if (!enqueue(Proto.MSG_PROPOSE, payload, important = true)) {
            ackDetail = "提案メッセージを送れませんでした"
            ackLatch = null
            return false
        }
        val got = try {
            latch.await(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            false
        }
        ackLatch = null
        if (got) return true
        ackDetail = "受信側からの能力回答が ${timeoutMs}ms 以内に届きませんでした（受信側アプリが古いバージョンの可能性があります）"
        Log.w(TAG, ackDetail)
        return false
    }

    /**
     * キューを飛ばして即時送信する（MSG_ERROR / MSG_INFO 用）。
     * [APK確認] テキストは 4096 バイトで切り詰める。例外は握りつぶす。
     */
    fun sendTextImmediate(type: Int, text: String) {
        val o = out ?: return
        var payload = text.toByteArray(Charsets.UTF_8)
        if (payload.size > Proto.MAX_TEXT) payload = payload.copyOf(Proto.MAX_TEXT)
        try {
            synchronized(writeLock) {
                Framing.writeMessage(o, type, payload)
                o.flush()
            }
        } catch (_: Throwable) {
        }
    }

    fun sendError(text: String) = sendTextImmediate(Proto.MSG_ERROR, text)
    fun sendInfo(text: String) = sendTextImmediate(Proto.MSG_INFO, text)

    /** MSG_BYE(9) を即時送信する。 */
    fun sendBye() {
        val o = out ?: return
        try {
            synchronized(writeLock) {
                Framing.writeMessage(o, Proto.MSG_BYE, ByteArray(0))
                o.flush()
            }
        } catch (_: Throwable) {
        }
    }

    /**
     * 切断してリソースを解放する。何回呼ばれても安全（冪等）。
     * [APK確認] 元の実装は `if (!running.compareAndSet(true,false) && !connected.get()) { queue.clear(); return }`
     */
    fun close(reason: String) {
        if (!running.compareAndSet(true, false) && !connected.get()) {
            queue.clear()
            return
        }
        val wasConnected = connected.getAndSet(false)
        running.set(false)
        queue.clear()
        runCatching { socket?.shutdownOutput() }
        runCatching { socket?.close() }
        socket = null
        out = null
        writerThread?.interrupt(); writerThread = null
        readerThread?.interrupt(); readerThread = null
        watchdogThread?.interrupt(); watchdogThread = null
        Log.i(TAG, "切断: $reason")
        if (wasConnected) listener.onDisconnected(reason)
    }

    companion object {
        private const val TAG = "LiteScreen.Sender"
        private const val CONNECT_TIMEOUT_MS = 8000
        private const val PING_INTERVAL_MS = 3000L
        private const val QUEUE_CAPACITY = 40
        private const val STALL_TIMEOUT_MS = 15000L
    }
}
