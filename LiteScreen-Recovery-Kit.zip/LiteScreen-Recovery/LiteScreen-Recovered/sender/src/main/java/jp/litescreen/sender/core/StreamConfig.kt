/*
 * StreamConfig.kt — 送信側の配信設定
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk
 *         classes5.dex / jp.litescreen.sender.core.StreamConfig を
 *         jadx で逆コンパイルした出力と smali から Kotlin へ書き戻した。
 *         元ファイル名は StreamConfig.kt（jadx の "compiled from" で確認）。
 *
 * ■ 確定できる情報（すべて DEX から直接）
 *   - data class のプロパティ名・型・順序・デフォルト値
 *     (@Metadata の d2 配列と copy$default の合成メソッドから確定)
 *   - RESOLUTION_CHOICES / FPS_CHOICES / BITRATE_CHOICES の全要素
 *   - suggestBitrateKbps の計算式と coerceIn の範囲
 *   - resolutionLabel / bitrateLabel が返す日本語文字列（1文字ずつ一致）
 *
 * ■ 元ソースと異なる可能性のある点
 *   - コメント・空行・ローカル変数名
 *   - resolutionLabel / bitrateLabel が when 式か if 式かは不明（動作は同一）
 */
package jp.litescreen.sender.core

/**
 * 配信設定。[jp.litescreen.sender.MirrorService] へ Intent extras として渡される。
 *
 * @param host         受信側の IP アドレス
 * @param port         受信側の TCP ポート（**既定値なし**。[APK確認] 元 smali の合成
 *                     コンストラクタに mask 0x2 の分岐が存在しない＝port に既定値はない。
 *                     既定値があるのは maxLongEdge=1280 / fps=30 / bitrateKbps=2500 の3つ）
 * @param maxLongEdge  長辺の最大ピクセル数（1280 / 1600 / 1920）
 * @param fps          目標フレームレート（15 / 24 / 30 / 60）
 * @param bitrateKbps  目標ビットレート kbps（2500 / 4000 / 8000 / 12000 / 16000）
 */
data class StreamConfig(
    val host: String,
    val port: Int,
    val maxLongEdge: Int = 1280,
    val fps: Int = 30,
    val bitrateKbps: Int = 2500
) {
    companion object {
        /** [APK確認] intArrayOf(1280, 1600, 1920) */
        val RESOLUTION_CHOICES = intArrayOf(1280, 1600, 1920)

        /** [APK確認] intArrayOf(15, 24, 30, 60) */
        val FPS_CHOICES = intArrayOf(15, 24, 30, 60)

        /** [APK確認] intArrayOf(2500, 4000, 8000, 12000, 16000) */
        val BITRATE_CHOICES = intArrayOf(2500, 4000, 8000, 12000, 16000)

        /**
         * 解像度スピナーの表示文言。
         * [APK確認] 文字列は DEX から 1 文字ずつ一致させている。
         * 受信側（チャレンジパッドNext / OMX.MTK.VIDEO.DECODER.AVC）の実測能力に基づく文言。
         */
        fun resolutionLabel(v: Int): String = when (v) {
            1280 -> "1280px → 1280x800 (実測:余裕あり・推奨)"
            1600 -> "1600px → 1600x1000 (実測:対応・高画質)"
            1920 -> "1920px → 1728x1080 に自動縮小 (高さ上限1088)"
            else -> "${v}px"
        }

        /**
         * ビットレートスピナーの表示文言。[APK確認]
         */
        fun bitrateLabel(v: Int): String = when (v) {
            2500 -> "2.5 Mbps (1280px/30fps 向け)"
            4000 -> "4.0 Mbps (1600px/30fps 向け・推奨)"
            8000 -> "8.0 Mbps (1600px/60fps・1920px/30fps 向け)"
            12000 -> "12 Mbps (1920px/60fps 向け)"
            16000 -> "16 Mbps (最高画質・LAN帯域をフルに使う)"
            else -> "$v kbps"
        }

        /**
         * 解像度・フレームレートからの推奨ビットレート（kbps）。
         *
         * [APK確認] 元の計算は次のとおり（smali で命令順まで確認済み）:
         * ```
         *   pixels = w.toLong() * h.toLong()
         *   kbps   = (fps.toLong() * pixels * 7L / 100L) / 1000L
         *   return kbps.toInt().coerceIn(2000, 20000)
         * ```
         * 概ね「1ピクセル1フレームあたり 0.07 bit」の経験則。
         *
         * 注意: これは **推奨値のヒント** であり、v1.0.10 の修正により
         * ユーザーが明示的に選んだ値を勝手に上書きしてはならない。
         * 適用は [jp.litescreen.sender.SenderActivity] 側でタップ時のみ行う。
         */
        fun suggestBitrateKbps(w: Int, h: Int, fps: Int): Int {
            val pixels = w.toLong() * h.toLong()
            val kbps = (fps.toLong() * pixels * 7L / 100L) / 1000L
            return kbps.toInt().coerceIn(2000, 20000)
        }
    }
}
