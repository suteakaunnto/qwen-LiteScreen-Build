/*
 * MirrorService.kt — 画面ミラー配信のフォアグラウンドサービス（送信側の中核）
 *
 * ■ 出典: [APKから復元] litescreen-sender-v1.0.11-debug.apk classes4.dex
 *         jp.litescreen.sender.MirrorService（元ファイル MirrorService.kt）
 *
 * ■ 復元方針
 *   - jadx の Java 出力を Kotlin に戻し、定数・ビット演算・分岐は smali と突き合わせて確認した。
 *     smali: recovery/decompiled/sender-v1.0.11-apktool/smali_classes4/jp/litescreen/sender/MirrorService.smali
 *   - smali で確認した重要ポイント:
 *       * START_NOT_STICKY(=2) を常に返す
 *       * startForeground は API>=29 で foregroundServiceType=32
 *         (ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) を渡す
 *       * StreamConfig の既定値: port=0xbacc(47820), maxLongEdge=0x500(1280),
 *         fps=0x1e(30), bitrateKbps=0x9c4(2500)
 *       * floorBitrateKbps = max(0x5dc=1500, bitrateKbps/3)
 *       * panelHz は DisplayManager.getDisplay(0)?.refreshRate ?: 0f（try/catch Exception）
 *       * negotiate は既定 timeoutMs=0x1f40(8000) で呼ぶ（bitmask 8）
 *       * onStats の over 判定 = encodedFps > targetFps * 0xd / 0xa（*13/10）
 *       * AIMD: 過負荷 2 回連続で currentBitrate = max(current*3/4, floor)、
 *               健全 6 回連続で current = min(current + max(target/10,100), target)
 *       * 下限到達時の警告は 30000ms スロットル、状態表示の更新は 1500ms スロットル
 *       * stopEverything は AtomicBoolean の compareAndSet(false,true) で多重実行を防止し、
 *         最後で stopping.set(false)
 *       * stopForeground(1) = STOP_FOREGROUND_REMOVE、PendingIntent flags 0x0c000000
 *         = FLAG_IMMUTABLE|FLAG_UPDATE_CURRENT、openIntent の 0x20000000 = FLAG_ACTIVITY_CLEAR_TOP
 *
 * ■ v1.0.10 → v1.0.11 の差分（このファイル） [APK確認]
 *   - panelHz（パネルリフレッシュレート）の取得と INFO メッセージへの付記
 *   - 起動処理を専用スレッド "LS-Start" に分離
 *   - 下限到達時の「帯域ではない可能性」警告（30 秒スロットル）
 *
 * ■ 未確認事項 [推定]
 *   - ローカル変数名・改行位置は元ソースと異なる可能性がある（意味・文字列は同一）。
 */
package jp.litescreen.sender

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import jp.litescreen.protocol.Proto
import jp.litescreen.sender.R
import jp.litescreen.sender.core.ScreenCapturer
import jp.litescreen.sender.core.SenderClient
import jp.litescreen.sender.core.StreamConfig
import java.util.concurrent.atomic.AtomicBoolean

/**
 * MediaProjection のトークンを受け取り、受信側への接続 → 能力ネゴシエーション →
 * キャプチャ開始 → 適応ビットレート制御までを一括で行うサービス。
 *
 * 状態文字列は [Companion.stateText] に保持され、SenderActivity が表示に流用する。
 */
class MirrorService : Service(), ScreenCapturer.Listener, SenderClient.Listener {

    // -------------------------------------------------------------- lifecycle

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopEverything("ユーザーが停止しました")
                return START_NOT_STICKY
            }
            ACTION_START -> Unit // 下記で処理
            else -> {
                stopSelf()
                return START_NOT_STICKY
            }
        }
        if (started) return START_NOT_STICKY

        val notification = buildNotification(getString(R.string.status_connecting))
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, notification, 32)  // 32 = FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            } else {
                startForeground(NOTIF_ID, notification)
            }

            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
            @Suppress("DEPRECATION")
            val data: Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA)
            if (resultCode == 0 || data == null) {
                setState("画面共有の許可が得られていません")
                stopEverything("許可なし")
                return START_NOT_STICKY
            }

            val config = StreamConfig(
                host = intent.getStringExtra(EXTRA_HOST) ?: "",
                port = intent.getIntExtra(EXTRA_PORT, Proto.DEFAULT_TCP_PORT),
                maxLongEdge = intent.getIntExtra(EXTRA_MAX_LONG_EDGE, 1280),
                fps = intent.getIntExtra(EXTRA_FPS, 30),
                bitrateKbps = intent.getIntExtra(EXTRA_BITRATE_KBPS, 2500),
            )
            targetBitrateKbps = config.bitrateKbps
            currentBitrateKbps = config.bitrateKbps
            floorBitrateKbps = maxOf(1500, config.bitrateKbps / 3)
            overloadStreak = 0
            healthyStreak = 0
            lastDroppedTotal = -1L
            statsCalls = 0
            sentCaptureInfo = false
            lastNotBandwidthWarnMs = 0L
            lastReceivedFps = 0
            targetFps = config.fps

            if (config.host.isBlank()) {
                setState("受信側のIPアドレスが指定されていません")
                stopEverything("設定不足")
                return START_NOT_STICKY
            }

            started = true
            // Android 14 以降は「サービス起動後」に getMediaProjection を呼ぶ必要があるため、
            // startForeground が確実に効いた後の別スレッドで初期化する（v1.0.11 の変更点）
            Thread({ startMirroring(resultCode, data, config) }, "LS-Start").start()
            return START_NOT_STICKY
        } catch (e: Exception) {
            Log.e(TAG, "startForeground 失敗", e)
            setState("フォアグラウンドサービスを開始できませんでした: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }
    }

    /**
     * LS-Start スレッドで実行される初期化本体。
     * どこで失敗しても [stopEverything] を呼び、状態文字列に理由を残す。
     */
    private fun startMirroring(resultCode: Int, data: Intent, config: StreamConfig) {
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp: MediaProjection? = try {
                mpm.getMediaProjection(resultCode, data)
            } catch (e: Exception) {
                Log.e(TAG, "getMediaProjection 失敗", e)
                val msg = "画面共有トークンの取得に失敗: ${e.javaClass.simpleName}: ${e.message}"
                setState(msg)
                stopEverything(msg)
                return
            }
            if (mp == null) {
                val msg = "画面共有トークンを取得できませんでした（getMediaProjection が null を返した）"
                setState(msg)
                stopEverything(msg)
                return
            }
            projection = mp

            val c = SenderClient(config, this)
            client = c
            setState("接続中… ${config.host}:${config.port}")
            if (!c.connect()) {
                stopEverything("受信側への接続に失敗しました（${config.host}:${config.port}）")
                return
            }

            // パネルのリフレッシュレート（設定 fps を超えるフレームが生成される原因の説明に使う）
            panelHz = try {
                val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                dm.getDisplay(0)?.refreshRate ?: 0f
            } catch (e: Exception) {
                0f
            }

            val panelText = if (panelHz > 0f) " / パネル=${panelHz.toInt()}Hz" else ""
            c.sendInfo(
                "接続確立: ${Build.MANUFACTURER} ${Build.MODEL} / Android ${Build.VERSION.RELEASE} " +
                    "(API ${Build.VERSION.SDK_INT}) / 設定=${config.maxLongEdge}px@${config.fps}fps " +
                    "${config.bitrateKbps}kbps$panelText"
            )

            val (sw, sh) = ScreenCapturer.computeStreamSize(applicationContext, config)
            setState("受信側のデコード能力を確認中… ${sw}x${sh}@${config.fps}fps")

            if (!c.negotiate(sw, sh, config.fps)) {
                stopEverything("受信側との能力ネゴシエーションに失敗しました: ${c.negotiatedDetail()}")
                return
            }

            val ackW = c.negotiatedWidth()
            val ackH = c.negotiatedHeight()
            val ackFps = if (c.negotiatedFps() > 0) c.negotiatedFps() else config.fps
            if (ackW <= 0 || ackH <= 0) {
                stopEverything("受信側のデコーダーが対応できるサイズがありません: ${c.negotiatedDetail()}")
                return
            }
            c.sendInfo("能力ネゴシエーション結果: ${c.negotiatedDetail()}")
            if (!(c.negotiatedOk() && ackW == sw && ackH == sh && ackFps == config.fps)) {
                Log.w(TAG, "受信側の能力に合わせて設定を変更: ${sw}x${sh}@${config.fps}fps -> ${ackW}x${ackH}@${ackFps}fps")
            }

            val effectiveConfig = config.copy(fps = ackFps)
            targetFps = ackFps
            setState("受信側が対応: ${ackW}x${ackH}@${ackFps}fps → キャプチャ開始中…")

            val cap = ScreenCapturer(
                applicationContext,
                mp,
                effectiveConfig,
                this,
                ackW,
                ackH,
                c.negotiatedProfile(),
                c.negotiatedLevel(),
            )
            capturer = cap
            if (!cap.start()) {
                Log.w(TAG, "ScreenCapturer.start() が false を返した")
            }
        } catch (t: Throwable) {
            val msg = "送信側で予期しない例外: ${t.javaClass.simpleName}: ${t.message}"
            Log.e(TAG, msg, t)
            setState(msg)
            stopEverything(msg)
        }
    }

    // ------------------------------------------------- ScreenCapturer.Listener

    override fun onCodecConfig(csd: List<ByteArray>) {
        client?.sendCodecConfig(csd)
    }

    override fun onStreamSize(width: Int, height: Int) {
        client?.sendVideoConfig(width, height, targetFps, currentBitrateKbps)
        val text = "配信中 ${width}x${height} @${targetFps}fps"
        setState(text)
        updateNotification(text)
    }

    override fun onEncodedFrame(data: ByteArray, ptsUs: Long, isKey: Boolean) {
        client?.sendFrame(data, ptsUs, isKey)
    }

    override fun onInfo(text: String) {
        Log.i(TAG, "info: $text")
        client?.sendInfo(text)
    }

    override fun onError(message: String, fatal: Boolean) {
        Log.w(TAG, "capturer error fatal=$fatal: $message")
        if (fatal) {
            setState(message)
            stopEverything(message)
        }
    }

    override fun onStats(encodedFps: Int, kbps: Int) {
        val rtt = client?.lastRttMs() ?: -1
        val rttText = if (rtt >= 0) " RTT:${rtt}ms" else ""
        setState("配信中 ${capturer?.streamWidth()}x${capturer?.streamHeight()} 送信:${encodedFps}fps ${kbps}kbps$rttText")

        statsCalls++
        // 3 回目の統計（≒配信開始から 3 秒）でエンコード実測値を受信側に一度だけ通知する
        if (statsCalls == 3 && !sentCaptureInfo) {
            sentCaptureInfo = true
            val over = encodedFps > (targetFps * 13) / 10
            client?.sendInfo(
                "エンコード実測: ${encodedFps}fps ${kbps}kbps（設定 ${targetFps}fps" +
                    (if (panelHz > 0f) " / パネル ${panelHz.toInt()}Hz" else "") + "）" +
                    if (over) {
                        " ★設定fpsを超過: 高リフレッシュレート端末は画面更新に応じて設定以上のフレームを生成します。" +
                            "受信側は全フレームをデコードし描画だけを表示レートに間引く設計ですが、" +
                            "破棄が続く場合は解像度を 1280px に下げると安定します。"
                    } else {
                        ""
                    }
            )
        }
    }

    // -------------------------------------------------- SenderClient.Listener

    override fun onConnected(remote: String, receiverAudioSupport: Boolean) {
        Log.i(TAG, "receiver connected: $remote audioSupport=$receiverAudioSupport")
    }

    override fun onKeyFrameRequested() {
        capturer?.requestSyncFrame()
    }

    /**
     * 受信側からの STATS を受けた適応ビットレート制御（AIMD 風）。
     *
     * [APK確認] 判定式:
     *   arrived     = max(fps + droppedDelta, 1)
     *   dropPct     = 100 * droppedDelta / arrived
     *   overloaded  = (droppedDelta >= 2 && dropPct >= 5) || pending >= 2
     *   減少: 2 回連続で overloaded → current = max(current * 3 / 4, floor)
     *   回復: 6 回連続で健全かつ current < target → current = min(current + max(target/10, 100), target)
     */
    override fun onReceiverStats(fps: Int, kbps: Int, droppedTotal: Long, pending: Int) {
        val droppedDelta = if (lastDroppedTotal < 0 || droppedTotal < lastDroppedTotal) 0L else droppedTotal - lastDroppedTotal
        if (droppedTotal >= 0) lastDroppedTotal = droppedTotal
        lastReceivedFps = fps

        val arrived = (fps.toLong() + droppedDelta).coerceAtLeast(1L)
        val dropPct = 100L * droppedDelta / arrived
        val overloaded = (droppedDelta >= 2 && dropPct >= 5) || pending >= 2

        if (!overloaded) {
            overloadStreak = 0
            if (currentBitrateKbps < targetBitrateKbps) {
                healthyStreak++
                if (healthyStreak >= 6) {
                    healthyStreak = 0
                    val step = (targetBitrateKbps / 10).coerceAtLeast(100)
                    val before = currentBitrateKbps
                    currentBitrateKbps = (currentBitrateKbps + step).coerceAtMost(targetBitrateKbps)
                    if (currentBitrateKbps != before) {
                        applyBitrate("負荷が落ち着いたため画質を回復")
                        Log.i(TAG, "適応制御(回復): ${before}kbps -> ${currentBitrateKbps}kbps")
                    }
                }
            } else {
                healthyStreak = 0
            }
            return
        }

        healthyStreak = 0
        overloadStreak++
        if (overloadStreak >= 2 && currentBitrateKbps > floorBitrateKbps) {
            val before = currentBitrateKbps
            currentBitrateKbps = ((currentBitrateKbps * 3) / 4).coerceAtLeast(floorBitrateKbps)
            overloadStreak = 0
            applyBitrate("受信側が過負荷（受信${fps}fps 破棄+${droppedDelta}=${dropPct}% 待ち${pending}）")
            Log.w(TAG, "適応制御: ${before}kbps -> ${currentBitrateKbps}kbps")
        } else if (currentBitrateKbps <= floorBitrateKbps) {
            // 既に下限まで下げても破棄が続く＝帯域ではなく受信側の処理能力が原因の可能性を通知する
            val now = System.currentTimeMillis()
            if (now - lastNotBandwidthWarnMs > 30000) {
                lastNotBandwidthWarnMs = now
                client?.sendInfo(
                    "注意: ビットレートは下限 ${floorBitrateKbps}kbps まで低下済みですが破棄" +
                        "（+${droppedDelta}/秒, ${dropPct}%）が続いています。帯域ではなく受信側の処理能力が" +
                        "入力フレームレートに追いついていない可能性があります。" +
                        "解像度（例: 1280px）またはフレームレート（例: 30fps）を下げてみてください。"
                )
            }
        }
    }

    private fun applyBitrate(reason: String) {
        capturer?.setBitrate(currentBitrateKbps * 1000)
        client?.let { c ->
            c.sendVideoConfig(capturer?.streamWidth() ?: 0, capturer?.streamHeight() ?: 0, targetFps, currentBitrateKbps)
        }
        client?.sendInfo("適応ビットレート: ${currentBitrateKbps}kbps（${reason}）")
        val now = System.currentTimeMillis()
        if (now - lastAdaptiveLogMs > 1500) {
            lastAdaptiveLogMs = now
            setState("配信中 ${capturer?.streamWidth()}x${capturer?.streamHeight()} ${currentBitrateKbps}kbps")
        }
    }

    override fun onBackpressure() {
        capturer?.enterResync()
    }

    override fun onDisconnected(reason: String) {
        setState("切断: $reason")
        stopEverything(reason)
    }

    /** SenderClient 側の非致命エラー。状態表示だけ更新する。 */
    override fun onError(message: String) {
        Log.w(TAG, "sender client error: $message")
        setState(message)
    }

    // ------------------------------------------------------------------ stop

    /** 停止処理。多重呼び出し（capturer と client の両方からの通知）を 1 回に集約する。 */
    private fun stopEverything(reason: String) {
        if (!stopping.compareAndSet(false, true)) {
            Log.i(TAG, "stopEverything は実行中のためスキップ: $reason")
            return
        }
        Log.i(TAG, "stopEverything: $reason")
        started = false

        runCatching { capturer?.stop() }
        capturer = null
        runCatching { client?.sendError(reason) }
        runCatching { client?.sendBye() }
        runCatching { client?.close(reason) }
        client = null
        runCatching { projection?.stop() }
        projection = null

        setState("停止: $reason")
        stopForegroundCompat()
        stopSelf()
        stopping.set(false)
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopEverything("タスクが削除されました")
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        if (started) {
            stopping.set(false)
            stopEverything("サービス破棄")
        }
        super.onDestroy()
    }

    // -------------------------------------------------------------- notification

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            val ch = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW,
            )
            ch.setShowBadge(false)
            nm.createNotificationChannel(ch)
        }
    }

    @Suppress("DEPRECATION")
    private fun stopForegroundCompat() {
        runCatching { stopForeground(STOP_FOREGROUND_REMOVE) }
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, MirrorService::class.java).setAction(ACTION_STOP)
        val pi = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        // [APK確認] 元 smali: `const/high16 v4, 0x20000000` = FLAG_ACTIVITY_SINGLE_TOP。
        //   （Phase D 検証で CLEAR_TOP(0x04000000) になっていたのを修正）
        val openIntent = Intent(this, SenderActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val openPi = PendingIntent.getActivity(
            this, 1, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(openPi)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(Notification.Action.Builder(null, getString(R.string.notification_action_stop), pi).build())
            .build()
    }

    private fun updateNotification(text: String) {
        runCatching {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NOTIF_ID, buildNotification(text))
        }
    }

    // ------------------------------------------------------------------ state

    private var capturer: ScreenCapturer? = null
    private var client: SenderClient? = null
    private var projection: MediaProjection? = null
    private var started = false

    private val stopping = AtomicBoolean(false)

    private var targetBitrateKbps = 2500
    private var currentBitrateKbps = 2500
    private var targetFps = 30
    private var floorBitrateKbps = 1500
    private var overloadStreak = 0
    private var healthyStreak = 0
    private var lastDroppedTotal = -1L

    @Volatile private var lastAdaptiveLogMs = 0L
    @Volatile private var panelHz = 0f
    private var statsCalls = 0

    @Volatile private var sentCaptureInfo = false

    @Volatile private var lastNotBandwidthWarnMs = 0L

    @Volatile private var lastReceivedFps = 0

    companion object {
        private const val TAG = "LiteScreen.Service"
        private const val CHANNEL_ID = "litescreen_mirror"
        private const val NOTIF_ID = 1001

        const val ACTION_START = "jp.litescreen.sender.action.START"
        const val ACTION_STOP = "jp.litescreen.sender.action.STOP"

        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        const val EXTRA_HOST = "host"
        const val EXTRA_PORT = "port"
        const val EXTRA_MAX_LONG_EDGE = "maxLongEdge"
        const val EXTRA_FPS = "fps"
        const val EXTRA_BITRATE_KBPS = "bitrateKbps"

        // 注: 以下の 2 値は元 APK に定数フィールドが存在しない（コンパイル時定数が
        //   使用箇所へ畳み込まれている）ため、復元コードでも定数化せずインラインで書く。
        //   [APK確認] PendingIntent flags = `const/high16 0xc000000`
        //             (= FLAG_IMMUTABLE or FLAG_UPDATE_CURRENT)
        //   [APK確認] startForeground の type = `const/16 0x20` (= 32)
        //             (ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION。API 29 追加のため
        //              minSdk 28 では参照せずリテラル 32 を使う)

        /**
         * 最新の状態文字列。サービスインスタンスが無くても参照できるため、
         * SenderActivity が UI 更新に流用する（`startsWith("配信中")` で配信中判定）。
         *
         * [APK確認] 元 APK の形は「公開プロパティ」ではなく以下である:
         *   - MirrorService 側に `private static volatile stateText:Ljava/lang/String;`
         *     （= companion の private var のバッキングフィールド）
         *   - MirrorService$Companion に `public final getStateText()Ljava/lang/String;`
         *     （= 明示的な関数。`private set` 付きプロパティなら setStateText() が出るが
         *       元 APK に setStateText は存在しない）
         *   - MirrorService に `access$getStateText$cp()` / `access$setStateText$cp()`
         *     （companion からの private static フィールドアクセス用ブリッジ）
         *   - 呼び出し側(SenderActivity)は `MirrorService$Companion.getStateText()` を呼ぶ
         *     → @JvmStatic では無い（@JvmStatic だと MirrorService 側に static
         *       getStateText() が生成され、元 APK と構成がずれる）
         */
        @Volatile
        private var stateText: String = "停止中"

        /** 状態文字列の参照（SenderActivity が UI 更新に使う）。 */
        fun getStateText(): String = stateText

        /** 状態を更新する（内部用。ログも同時に出す）。 */
        private fun setState(s: String) {
            stateText = s
            Log.i(TAG, "state: $s")
        }
    }
}
