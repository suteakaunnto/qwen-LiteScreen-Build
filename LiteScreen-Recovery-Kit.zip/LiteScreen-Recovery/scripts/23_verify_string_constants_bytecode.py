#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
23_verify_string_constants_bytecode.py
  復元コードをコンパイルした .class の「String 定数(constant pool tag=8)」と、
  元 APK の smali「const-string」を **バイトコード水準** で照合する。

なぜソース文字列比較(22_verify_const_strings.py)では不十分か:
  - Kotlin の文字列テンプレートはコンパイル時に断片へ分割される
  - Context.CLIPBOARD_SERVICE 等の compile-time 定数は const-string にインライン化される
  - data class の toString() / lateinit プロパティ名 / Intrinsics の引数名は
    コンパイラが自動生成する(ソースには存在しない)
  → 双方を「コンパイル結果の文字列定数」に揃えれば、これら全ての差が消える。
     残った差だけが実装差(または Kotlin バージョン差)として意味を持つ。

入力:
  元 APK 側 : recovery/decompiled/<apk>-apktool/**/jp/litescreen/<mod>/**/*.smali
              (.source 単位で束ねる)
  復元側    : recovery/build-check/<mod>/classes/**/*.class
              (SourceFile 属性単位で束ねる)

終了コード: 不足 0 件なら 0、1 件以上なら 1。

使い方:
  python3 scripts/23_verify_string_constants_bytecode.py receiver
  python3 scripts/23_verify_string_constants_bytecode.py sender --verbose
"""
from __future__ import annotations

import re
import struct
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DECOMPILED = ROOT / "recovery" / "decompiled"
BUILD_CHECK = ROOT / "recovery" / "build-check"

APK_TAG = {"receiver": "receiver-v1.0.11-apktool", "sender": "sender-v1.0.11-apktool"}
PKG = {"receiver": "jp/litescreen/receiver", "sender": "jp/litescreen/sender"}

CONST_STRING_RE = re.compile(r'^\s*const-string(?:/jumbo)?\s+[vp]\d+,\s*"(.*)"\s*$')
SOURCE_RE = re.compile(r'^\.source\s+"(.*)"\s*$')
# static final String フィールド(ConstantValue)は smali では const-string にならず
# `.field ... :Ljava/lang/String; = "値"` の形で表れる。こちらも文字列定数として扱う。
FIELD_STRING_RE = re.compile(r'^\.field\s+.*:Ljava/lang/String;\s*=\s*"(.*)"\s*$')

# Intrinsics.checkNotNullExpressionValue 等に渡される「式記述」文字列。
# ソースには書かれず、コンパイラが式の見かけ(例: "list(...)", "iterator(...)")から生成する。
# Kotlin のバージョンによって検査の挿入位置が変わるため(例: 元APK=list(...) / 2.2.20=iterator(...))、
# 実装差ではなくコンパイラ差として別枠に集計する。
GENERATED_EXPR_RE = re.compile(r'^[A-Za-z_][A-Za-z0-9_]*(\(\.\.\.\))+$')
GENERATED_PREFIX = (
    "null cannot be cast to non-null type",
    "Parameter specified as non-null is null",
    "Required value was null",
    "Check failed.",
)


def is_generated(s: str) -> bool:
    return bool(GENERATED_EXPR_RE.match(s)) or s.startswith(GENERATED_PREFIX)


# --------------------------------------------------------------- smali 側 ---

def unescape_smali(s: str) -> str:
    out: list[str] = []
    i, n = 0, len(s)
    while i < n:
        c = s[i]
        if c != "\\" or i + 1 >= n:
            out.append(c)
            i += 1
            continue
        x = s[i + 1]
        mp = {"n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f",
              '"': '"', "'": "'", "\\": "\\"}
        if x in mp:
            out.append(mp[x])
            i += 2
        elif x == "u" and i + 6 <= n:
            try:
                out.append(chr(int(s[i + 2:i + 6], 16)))
                i += 6
            except ValueError:
                out.append(c)
                i += 1
        else:
            out.append(x)
            i += 2
    return "".join(out)


def collect_smali_strings(module: str) -> dict[str, set[str]]:
    base = DECOMPILED / APK_TAG[module]
    per_file: dict[str, set[str]] = {}
    for p in sorted(base.rglob("*.smali")):
        posix = p.as_posix()
        if PKG[module] not in posix:
            continue
        if "ExternalSyntheticLambda" in p.name or re.match(r"^R(\$|\.smali$)", p.name):
            continue
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        src = next((SOURCE_RE.match(l).group(1) for l in lines if SOURCE_RE.match(l)),
                   p.stem + ".kt")
        bucket = per_file.setdefault(src, set())
        for line in lines:
            m = CONST_STRING_RE.match(line) or FIELD_STRING_RE.match(line)
            if m:
                v = unescape_smali(m.group(1))
                if v:
                    bucket.add(v)
    return per_file


# ------------------------------------------------------------- class 側 ---

def parse_class_strings(data: bytes) -> tuple[str | None, set[str]]:
    """class ファイルを直接パースし (SourceFile, 文字列定数の集合) を返す。

    収集対象:
      1) constant pool の CONSTANT_String (tag=8) … ldc で使われる文字列リテラル
         (Kotlin の文字列テンプレート断片、indy 連結レシピを含む)
      2) フィールドの ConstantValue 属性が指す文字列 … `static final String TAG = "..."`
         のようなコンパイル時定数(tag=8 のエントリを作らないため 1) では取れない)
    """
    if data[:4] != b"\xca\xfe\xba\xbe":
        raise ValueError("not a class file")
    off = 8
    cp_count = struct.unpack_from(">H", data, off)[0]
    off += 2
    utf8: dict[int, str] = {}
    string_idx: list[int] = []          # tag=8 が指す utf8 index
    cp_string: dict[int, int] = {}      # cp index -> utf8 index (tag=8 のみ)
    i = 1
    while i < cp_count:
        tag = data[off]
        off += 1
        if tag == 1:                                   # Utf8
            ln = struct.unpack_from(">H", data, off)[0]
            off += 2
            utf8[i] = data[off:off + ln].decode("utf-8", errors="replace")
            off += ln
        elif tag in (7, 8, 16, 19, 20):                # Class/String/MethodType/Module/Package
            idx = struct.unpack_from(">H", data, off)[0]
            off += 2
            if tag == 8:
                string_idx.append(idx)
                cp_string[i] = idx
        elif tag == 15:                                # MethodHandle
            off += 3
        elif tag in (3, 4, 9, 10, 11, 12, 17, 18):      # 4 bytes
            off += 4
        elif tag in (5, 6):                             # Long/Double (2 slots)
            off += 8
            i += 1
        else:
            raise ValueError(f"unknown constant pool tag {tag} at {off-1}")
        i += 1

    strings = {utf8[k] for k in string_idx if k in utf8 and utf8[k]}

    access, this_c, super_c = struct.unpack_from(">HHH", data, off)
    off += 6
    ifc = struct.unpack_from(">H", data, off)[0]
    off += 2 + 2 * ifc

    def walk_members(off: int, collect_constants: bool) -> int:
        cnt = struct.unpack_from(">H", data, off)[0]
        off += 2
        for _ in range(cnt):
            off += 6                                  # access, name_index, descriptor_index
            ac = struct.unpack_from(">H", data, off)[0]
            off += 2
            for _ in range(ac):
                aname, alen = struct.unpack_from(">HI", data, off)
                off += 6
                if collect_constants and alen == 2 and utf8.get(aname) == "ConstantValue":
                    ci = struct.unpack_from(">H", data, off)[0]
                    if ci in cp_string:
                        v = utf8.get(cp_string[ci])
                        if v:
                            strings.add(v)
                off += alen
        return off

    off = walk_members(off, True)                     # fields
    off = walk_members(off, False)                    # methods

    source_file = None
    ac = struct.unpack_from(">H", data, off)[0]
    off += 2
    for _ in range(ac):
        name_idx, ln = struct.unpack_from(">HI", data, off)
        off += 6
        if utf8.get(name_idx) == "SourceFile" and ln >= 2:
            source_file = utf8.get(struct.unpack_from(">H", data, off)[0])
        off += ln
    return source_file, strings


RECIPE_SPLIT_RE = re.compile("[\u0001\u0002]")


def expand_recipes(strings: set[str]) -> set[str]:
    """invokedynamic(StringConcatFactory) のレシピ定数を断片へ展開する。

    Kotlin 2.x は jvm-target 9+ で文字列テンプレートを
    `invokedynamic makeConcatWithConstants` にコンパイルする。レシピは
    \u0001 をプレースホルダとする 1 本の String 定数になるため、
    D8 通過後(StringBuilder へ desugar 済み)の元 APK smali とは形が異なる。
    ここではレシピを断片へ分割し、双方を同一水準で比較できるようにする。
    """
    out: set[str] = set()
    for s in strings:
        if "\u0001" in s or "\u0002" in s:
            for part in RECIPE_SPLIT_RE.split(s):
                if part:
                    out.add(part)
        else:
            out.add(s)
    return out


def collect_class_strings(module: str, expand: bool = True) -> dict[str, set[str]]:
    base = BUILD_CHECK / module / "classes"
    per_file: dict[str, set[str]] = {}
    for p in sorted(base.rglob("*.class")):
        src, strings = parse_class_strings(p.read_bytes())
        if src is None:
            src = p.name.split("$")[0] + ".kt"
        per_file.setdefault(src, set()).update(expand_recipes(strings) if expand else strings)
    return per_file


def normalize(s: str) -> str:
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s)).strip()


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] not in APK_TAG:
        print(__doc__)
        return 2
    module = argv[1]
    verbose = "--verbose" in argv

    orig = collect_smali_strings(module)
    new = collect_class_strings(module)
    files = sorted(set(orig) | set(new))

    tot_o = tot_missing = tot_extra = tot_gen = 0
    print(f"対象モジュール : {module}")
    print(f"元 APK 側      : {APK_TAG[module]} の smali const-string (.source 単位)")
    print(f"復元側         : recovery/build-check/{module}/classes の String 定数 (SourceFile 単位)")
    print(f"照合水準       : バイトコード(文字列定数) — テンプレート分割・SDK定数・生成toString を吸収")
    print()
    print(f"{'source file':<26} {'元':>5} {'復元':>5} {'一致':>5} {'不足':>5} {'余分':>5} {'compiler生成':>13}  判定")
    print("-" * 90)

    for f in files:
        o_all = {normalize(x) for x in orig.get(f, set())}
        n_all = {normalize(x) for x in new.get(f, set())}
        gen = {x for x in (o_all | n_all) if is_generated(x)}
        o, n = o_all - gen, n_all - gen
        missing = sorted(o - n)
        extra = sorted(n - o)
        tot_o += len(o_all)
        tot_gen += len(gen)
        tot_missing += len(missing)
        tot_extra += len(extra)
        print(f"{f:<26} {len(o_all):>5} {len(n_all):>5} {len(o & n):>5} {len(missing):>5} "
              f"{len(extra):>5} {len(gen):>13}  {'OK' if not missing else 'NG'}")
        if verbose and gen:
            for x in sorted(gen):
                where = "元+復元" if x in o_all and x in n_all else ("元のみ" if x in o_all else "復元のみ")
                print(f"    [compiler生成/{where}] {x!r}")
        if verbose or missing:
            for s in missing:
                print(f"    [不足] {s!r}")
        if verbose:
            for s in extra:
                print(f"    [余分] {s!r}")

    print("-" * 90)
    print(f"合計: 元 {tot_o} / 不足 {tot_missing} / 余分 {tot_extra} / compiler生成(別枠) {tot_gen}")
    if tot_missing == 0:
        print(f"\nPASS: {module} の文字列定数は元 APK のバイトコードと一致(不足 0 件)")
        if tot_extra:
            print(f"      余分 {tot_extra} 件は復元側だけの文字列定数(--verbose で一覧表示)。")
        if tot_gen:
            print(f"      compiler生成 {tot_gen} 件は Intrinsics 用の式記述等で、")
            print(f"      Kotlin のバージョンにより検査位置(=文言)が変わるため別枠集計。")
        return 0
    print(f"\nFAIL: {module} に不足 {tot_missing} 件 → 実装差の疑い(個別確認要)")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
