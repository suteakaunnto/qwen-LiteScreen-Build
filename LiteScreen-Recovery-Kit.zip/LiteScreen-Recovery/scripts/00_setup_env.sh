#!/usr/bin/env bash
# 00_setup_env.sh — LiteScreen 復旧環境の再構築
# セッション/コンテナが失われた後に、これを1本実行すれば解析ツールが揃う。
# 既にインストール済みなら各段階はスキップされる（冪等）。
set -uo pipefail

log(){ printf '\033[1;36m==>\033[0m %s\n' "$*"; }

export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"

# --- 1) システムパッケージ -------------------------------------------------
need_pkg=()
command -v curl  >/dev/null || need_pkg+=(curl)
command -v unzip >/dev/null || need_pkg+=(unzip)
command -v zip   >/dev/null || need_pkg+=(zip)
command -v java  >/dev/null || need_pkg+=(openjdk-17-jdk-headless)
if [ ${#need_pkg[@]} -gt 0 ]; then
  log "apt-get install ${need_pkg[*]}"
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq "${need_pkg[@]}"
else
  log "システムパッケージは導入済み"
fi

# --- 2) apktool ------------------------------------------------------------
if [ ! -f /opt/tools/apktool.jar ]; then
  log "apktool 2.11.1 取得"
  mkdir -p /opt/tools
  curl -sSL -o /opt/tools/apktool.jar \
    https://github.com/iBotPeaches/Apktool/releases/download/v2.11.1/apktool_2.11.1.jar
fi
[ -f /usr/local/bin/apktool ] || { printf '#!/bin/sh\nexec java -jar /opt/tools/apktool.jar "$@"\n' > /usr/local/bin/apktool; chmod +x /usr/local/bin/apktool; }

# --- 3) jadx ---------------------------------------------------------------
if [ ! -x /opt/tools/jadx/bin/jadx ]; then
  log "jadx 1.5.6 取得"
  mkdir -p /opt/tools
  curl -sSL -o /opt/tools/jadx.zip \
    https://github.com/skylot/jadx/releases/download/v1.5.6/jadx-1.5.6.zip
  mkdir -p /opt/tools/jadx && (cd /opt/tools/jadx && unzip -qo ../jadx.zip)
fi
[ -f /usr/local/bin/jadx ] || { printf '#!/bin/sh\nexec /opt/tools/jadx/bin/jadx "$@"\n' > /usr/local/bin/jadx; chmod +x /usr/local/bin/jadx; }

# --- 4) Android SDK --------------------------------------------------------
if [ ! -d "$ANDROID_HOME/cmdline-tools/latest" ]; then
  log "Android commandline-tools 取得"
  mkdir -p "$ANDROID_HOME/cmdline-tools"
  curl -sSL -o /tmp/cmdtools.zip \
    https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  rm -rf /tmp/cmdx && mkdir -p /tmp/cmdx && unzip -q /tmp/cmdtools.zip -d /tmp/cmdx
  mv /tmp/cmdx/cmdline-tools "$ANDROID_HOME/cmdline-tools/latest"
fi
if [ ! -d "$ANDROID_HOME/build-tools/34.0.0" ]; then
  log "build-tools;34.0.0 / platforms;android-34 取得"
  yes | "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null 2>&1
  "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" "build-tools;34.0.0" "platforms;android-34" >/dev/null
fi

BT="$ANDROID_HOME/build-tools/34.0.0"
for t in aapt aapt2 apksigner zipalign d8 dexdump split-select; do
  [ -f "$BT/$t" ] && ln -sf "$BT/$t" "/usr/local/bin/$t"
done
for t in apkanalyzer sdkmanager retrace lint; do
  [ -f "$ANDROID_HOME/cmdline-tools/latest/bin/$t" ] && ln -sf "$ANDROID_HOME/cmdline-tools/latest/bin/$t" "/usr/local/bin/$t"
done

grep -q ANDROID_HOME /root/.bashrc 2>/dev/null || cat >> /root/.bashrc <<EOF
export ANDROID_HOME=$ANDROID_HOME
export PATH=\$PATH:$BT:$ANDROID_HOME/cmdline-tools/latest/bin
EOF

log "セットアップ完了"
printf '%-14s %s\n' java "$(java -version 2>&1|head -1)"
printf '%-14s %s\n' apktool "$(apktool --version 2>&1)"
printf '%-14s %s\n' jadx "$(jadx --version 2>&1)"
printf '%-14s %s\n' aapt2 "$(aapt2 version 2>&1)"
printf '%-14s %s\n' apksigner "$(apksigner --version 2>&1|head -1)"
