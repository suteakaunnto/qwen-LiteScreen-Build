#!/usr/bin/env bash
# =============================================================================
# 25_gradle_build.sh — RAM 1.06GB の検証環境で Gradle ビルドを完走させるための
#                      低メモリ実行ラッパ（Phase D）
#
# 背景:
#   - attempt 2: `org.gradle.jvmargs=-Xmx640m -XX:MaxMetaspaceSize=384m` の daemon が
#     RSS 735MB に達して kernel OOM killer に kill された
#     (dmesg: `Killed process 9953 (java) anon-rss:735868kB`)。
#   - `--no-daemon` でも、Gradle は「JVM 設定を反映するため」として必ず
#     single-use daemon(2 つ目の JVM)を fork する（launcher の引数と完全一致させても
#     fork することを実験で確認済み）。
#   - 実測内訳: launcher ≈ 100MB / daemon = 本体。
#     → launcher は既定の -Xmx64m のまま薄く保ち、daemon 側の上限を下げる
#       (gradle.properties: -Xmx512m -XX:MaxMetaspaceSize=224m …) 方針に変更した。
#   - swap は追加不可（sandbox では `swapon: Operation not permitted`）。
#   - 実行は scripts/25_gradle_build.sh 経由で行い、RSS を 2 秒間隔で記録する。
#
# 使い方:
#   ./scripts/25_gradle_build.sh <gradle-task> <log-basename>
#   例) ./scripts/25_gradle_build.sh :receiver:assembleDebug PHASE_D_build_receiver_attempt3
#
# 出力:
#   recovery/evidence/<log-basename>.log   … Gradle の全出力
#   recovery/evidence/<log-basename>.rss   … 2 秒間隔の RSS サンプル (epoch kB)
#   末尾に `GRADLE_EXIT_CODE=<n>` を記録（0 以外は BUILD SUCCESSFUL と主張しない）
# =============================================================================
set -u

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROJ="$ROOT/LiteScreen-Recovered"
EVID="$ROOT/recovery/evidence"
GRADLE_BIN="${GRADLE_BIN:-/opt/gradle/dist/gradle-8.13/bin/gradle}"

TASK="${1:-:receiver:assembleDebug}"
BASE="${2:-PHASE_D_build_$(date +%Y%m%d_%H%M%S)}"
LOG="$EVID/$BASE.log"
RSS="$EVID/$BASE.rss"

mkdir -p "$EVID"

# ---- 低メモリ JVM 設定 -------------------------------------------------------
#   * 実測: launcher JVM は約 100MB、実際にビルドする single-use daemon が本体。
#   * `org.gradle.jvmargs` を launcher の JVM 引数と一致させない限り
#     `--no-daemon` でも必ず daemon が fork される（実験で確認済み: CASE1/CASE2
#     ともに "a single-use Daemon process will be forked"）。
#   * よって launcher 側(GRADLE_OPTS)には **ヒープ指定を入れない**（既定 -Xmx64m のまま
#     薄く保つ）ことで、daemon 側(gradle.properties の org.gradle.jvmargs=-Xmx512m …)
#     と合計しても空き 791MB に収まるようにする。
export GRADLE_OPTS="${GRADLE_OPTS:--Dfile.encoding=UTF-8}"
export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"

cd "$PROJ" || { echo "ERROR: project dir not found: $PROJ" >&2; exit 90; }

{
  echo "==================================================================="
  echo " Gradle build attempt"
  echo "==================================================================="
  echo "date          : $(date -Is)"
  echo "task          : $TASK"
  echo "gradle bin    : $GRADLE_BIN"
  echo "project       : $PROJ"
  echo "GRADLE_OPTS   : $GRADLE_OPTS"
  echo "gradle props  : $(grep -v '^#' "$PROJ/gradle.properties" | grep -v '^$' | tr '\n' ' ')"
  echo "MemTotal      : $(awk '/MemTotal/{print $2" kB"}' /proc/meminfo)"
  echo "MemAvailable  : $(awk '/MemAvailable/{print $2" kB"}' /proc/meminfo)"
  echo "kernel        : $(uname -r)"
  echo "==================================================================="
} | tee "$LOG"

# ---- RSS サンプラ（OOM 診断用）---------------------------------------------
: > "$RSS"
(
  while :; do
    for p in /proc/[0-9]*; do
      pid="${p#/proc/}"
      # java プロセスだけ拾う（/proc/pid/comm が無い場合もある）
      comm="$(cat "$p/comm" 2>/dev/null || true)"
      case "$comm" in
        java*)
          rss="$(awk '/^VmRSS:/{print $2}' "$p/status" 2>/dev/null || true)"
          [ -n "$rss" ] && echo "$(date +%s) pid=$pid rss_kB=$rss" >> "$RSS"
          ;;
      esac
    done
    sleep 2
  done
) &
SAMPLER=$!

# ---- 本体 -------------------------------------------------------------------
"$GRADLE_BIN" --no-daemon --max-workers=1 --console=plain --stacktrace "$TASK" >>"$LOG" 2>&1
RC=$?

kill "$SAMPLER" 2>/dev/null || true
wait "$SAMPLER" 2>/dev/null || true

{
  echo "-------------------------------------------------------------------"
  echo "GRADLE_EXIT_CODE=$RC"
  echo "finished_at=$(date -Is)"
  echo "MemAvailable_after=$(awk '/MemAvailable/{print $2" kB"}' /proc/meminfo)"
  if [ -s "$RSS" ]; then
    echo "peak_rss_kB=$(awk '{print $3}' "$RSS" | sed 's/rss_kB=//' | sort -n | tail -1)"
    echo "rss_samples=$(wc -l < "$RSS")"
  fi
  # JVM が致命エラーで落ちた場合は hs_err_pid*.log が生成される → 証拠として保全
  for f in "$PROJ"/hs_err_pid*.log "$PROJ"/*.hprof; do
    [ -f "$f" ] || continue
    cp -p "$f" "$EVID/$BASE.$(basename "$f")"
    echo "jvm_crash_log_saved=$EVID/$BASE.$(basename "$f")"
    rm -f "$f"   # プロジェクト直下を汚さない（コピー済みのものを削除するだけ）
  done
  echo "dmesg_oom_tail=$( (dmesg 2>/dev/null | grep -i 'out of memory' | tail -3) || echo '(dmesg not readable)')"
  echo "-------------------------------------------------------------------"
} | tee -a "$LOG"

exit "$RC"
