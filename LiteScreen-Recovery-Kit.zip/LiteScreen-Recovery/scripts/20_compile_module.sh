#!/usr/bin/env bash
# =====================================================================
# 20_compile_module.sh — Gradle を使わない軽量コンパイル検証
#
# 【目的】
#   RAM 1GB の環境では Gradle + AGP の起動自体が不安定なため、
#   各モジュールの Kotlin ソースが **本当にコンパイルできるか** を
#   kotlinc + android.jar だけで高速に検証する。
#
#   これは「ビルド成功」の代替ではない。Phase D で Gradle の
#   clean build を別途実行し、両方の結果を記録する。
#
# 【検証できること】
#   - 構文エラー、型エラー、未解決参照
#   - Android SDK の API に対するコンパイル（compileSdk 36 の android.jar）
#   - protocol モジュールへの依存解決
#
# 【検証できないこと】
#   - リソース(Rクラス)の解決 → R クラスを aapt2 で別途生成して classpath に渡す
#   - Lint / NewApi 検査 → Phase D で Gradle lint を実行
#   - DEX 化・APK 梱包・署名 → scripts/21_build_apk_manual.sh で行う
#
# 【実行】
#   bash scripts/20_compile_module.sh protocol
#   bash scripts/20_compile_module.sh sender
#   bash scripts/20_compile_module.sh receiver
# =====================================================================
set -euo pipefail

export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
PLATFORM="${PLATFORM:-$ANDROID_HOME/platforms/android-36/android.jar}"
[ -f "$PLATFORM" ] || PLATFORM="$ANDROID_HOME/platforms/android-34/android.jar"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJ="$ROOT/LiteScreen-Recovered"
WORK="$ROOT/recovery/build-check"
STDLIB="${STDLIB:-/opt/tools/kotlinc/lib/kotlin-stdlib.jar}"
KOTLINC_JAR="${KOTLINC_JAR:-/opt/tools/kotlinc/lib/kotlin-compiler.jar}"
ANNOT="${ANNOT:-/opt/tools/kotlinc/lib/annotations-13.0.jar}"
BT="$ANDROID_HOME/build-tools/36.0.0"
[ -d "$BT" ] || BT="$ANDROID_HOME/build-tools/34.0.0"

MOD="${1:?usage: $0 <protocol|sender|receiver>}"
[ -d "$PROJ/$MOD" ] || { echo "[x] モジュールがありません: $MOD"; exit 1; }

# Kotlin モジュール名（internal 宣言の JVM 名マングリング `foo$<module>` に影響する）
#   [APK確認] sender は `splitAnnexB$sender_debug` かつ @Metadata d2 末尾が "sender_debug"
#             → 元ビルドの sender モジュール名は "sender_debug"。
#   [推定]    receiver / protocol には internal 宣言が元 APK に存在せず観測できないため、
#             sender と同じ命名規則(<モジュール名>_<buildType>)を想定する。
#             実ビルド(Phase D)で生成 DEX を確認して確定させること。
case "$MOD" in
  protocol) MODULE_NAME="protocol" ;;
  *)        MODULE_NAME="${MOD}_debug" ;;
esac

log(){ printf '\033[1;36m==>\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

[ -f "$STDLIB" ] || die "kotlin-stdlib がありません: $STDLIB (01_get_kotlinc.sh を実行)"
[ -f "$PLATFORM" ] || die "android.jar がありません: $PLATFORM"

OUT="$WORK/$MOD"
rm -rf "$OUT"; mkdir -p "$OUT/classes" "$OUT/r" "$OUT/logs"

SRCS=$(find "$PROJ/$MOD/src/main/java" -name '*.kt' 2>/dev/null | sort)
[ -n "$SRCS" ] || die "Kotlin ソースがありません: $PROJ/$MOD/src/main/java"
NSRC=$(echo "$SRCS" | wc -l)
log "$MOD: Kotlin ソース $NSRC ファイルをコンパイル"
echo "$SRCS" | sed "s|$PROJ/||" | sed 's/^/    /'

# --- classpath の組み立て -------------------------------------------------
CP="$STDLIB:$ANNOT:$PLATFORM"
case "$MOD" in
  protocol) ;;
  sender|receiver)
    # protocol を先にコンパイルして JAR 化しておく
    if [ ! -f "$WORK/protocol/protocol.jar" ]; then
      log "依存モジュール protocol を先にビルド"
      bash "$0" protocol
    fi
    CP="$CP:$WORK/protocol/protocol.jar"
    # R クラスを aapt2 で生成（リソース参照の解決に必要）
    RES="$PROJ/$MOD/src/main/res"
    MANIFEST="$PROJ/$MOD/src/main/AndroidManifest.xml"
    if [ -d "$RES" ] && [ -f "$MANIFEST" ]; then
      # --non-final-ids: [APK確認] 元 APK の R フィールドは
      #   `.field public static <name>:I = 0x7f..`（final なし）＝ AGP 8 既定の
      #   android.nonFinalResIds=true 相当。aapt2 の既定(final)だと構成がずれるため明示。
      log "R クラスを aapt2 で生成 (--non-final-ids)"
      rm -rf "$OUT/r"; mkdir -p "$OUT/r/zip" "$OUT/r/gen" "$OUT/r/classes"
      "$BT/aapt2" compile --dir "$RES" -o "$OUT/r/zip/res.zip" > "$OUT/logs/aapt2-compile.log" 2>&1 \
        || { cat "$OUT/logs/aapt2-compile.log"; die "aapt2 compile 失敗"; }
      # 復元プロジェクトの AndroidManifest.xml には package 属性を書かない
      # （AGP 8 では namespace を使うため）。aapt2 は package を要求するので、
      # 検証用にだけ package 属性を注入した一時マニフェストを作って渡す。
      case "$MOD" in
        sender)   NS="jp.litescreen.sender" ;;
        receiver) NS="jp.litescreen.receiver" ;;
        *)        NS="jp.litescreen.$MOD" ;;
      esac
      python3 - "$MANIFEST" "$OUT/r/AndroidManifest.xml" "$NS" <<'PYEOF'
import sys
src, dst, pkg = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(src, encoding="utf-8").read()
i = s.index("<manifest")          # 最初の実タグ（コメント内の言及は無視される）
j = s.index(">", i)
tag = s[i:j]
if "package=" not in tag:
    s = s[:j] + ' package="%s"' % pkg + s[j:]
open(dst, "w", encoding="utf-8").write(s)
PYEOF
      "$BT/aapt2" link -o "$OUT/r/base.apk" \
          -I "$PLATFORM" \
          --manifest "$OUT/r/AndroidManifest.xml" \
          --auto-add-overlay \
          --non-final-ids \
          --java "$OUT/r/gen" \
          "$OUT/r/zip/res.zip" > "$OUT/logs/aapt2-link.log" 2>&1 \
        || { cat "$OUT/logs/aapt2-link.log"; die "aapt2 link 失敗"; }
      RJAVA=$(find "$OUT/r/gen" -name '*.java')
      if [ -n "$RJAVA" ]; then
        javac -nowarn -encoding UTF-8 -cp "$PLATFORM" -d "$OUT/r/classes" $RJAVA \
          > "$OUT/logs/r-javac.log" 2>&1 || { cat "$OUT/logs/r-javac.log"; die "R.java のコンパイル失敗"; }
        CP="$CP:$OUT/r/classes"
        log "  R クラス生成完了 ($(find "$OUT/r/classes" -name '*.class' | wc -l) classes)"
      fi
    fi
    ;;
esac

# --- kotlinc --------------------------------------------------------------
log "kotlinc 実行 (jvm-target 17, module-name=$MODULE_NAME, jvm-default=disable)"
set +e
java -Xmx512m -cp "$KOTLINC_JAR" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
     -no-stdlib -classpath "$CP" \
     -d "$OUT/classes" \
     -jvm-target 17 \
     -module-name "$MODULE_NAME" \
     -Xjvm-default=disable \
     $SRCS 2>&1 | tee "$OUT/logs/kotlinc.log" | grep -vE '^warning: ' | head -60
rc=${PIPESTATUS[0]}
set -e

echo
NERR=$(grep -cE '^.*: error: ' "$OUT/logs/kotlinc.log" || true)
NWARN=$(grep -cE '^warning: ' "$OUT/logs/kotlinc.log" || true)
NCLASS=$(find "$OUT/classes" -name '*.class' 2>/dev/null | wc -l)

if [ "$rc" -eq 0 ]; then
  (cd "$OUT/classes" && jar cf "$OUT/$MOD.jar" .)
  log "PASS: $MOD コンパイル成功 (errors=$NERR warnings=$NWARN classes=$NCLASS)"
  log "  成果物: $OUT/$MOD.jar"
  exit 0
else
  log "FAIL: $MOD コンパイル失敗 (exit=$rc errors=$NERR)"
  log "  ログ: $OUT/logs/kotlinc.log"
  echo "--- エラー一覧 ---"
  grep -E ': error: ' "$OUT/logs/kotlinc.log" | head -40
  exit 1
fi
