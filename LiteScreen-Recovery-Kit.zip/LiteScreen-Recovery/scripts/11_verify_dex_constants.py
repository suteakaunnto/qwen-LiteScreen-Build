#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
11_verify_dex_constants.py — [再構成新規] 復旧作業で作成した検証プログラム

【目的】
  jadx を一切介さず、apktool が DEX から直接逆アセンブルした smali を正として、
  再構成した Kotlin (Proto.kt) の定数・配列が元 APK と一致するかを機械検証する。

【なぜ必要か】
  scripts/10_diff_test_protocol.sh の基準実装は「jadx出力をjavacしたもの」なので、
  jadx 自体の誤り（UByte.MAX_VALUE → int 255 問題, recovery/reports/JADX_ERRORS.md 参照）を
  検出できない。このスクリプトは smali の `.field ... = 0xNN` と
  `.array-data` を直接読むため、jadx の誤りの影響を受けない独立経路になる。

【検証内容】
  1. Proto.smali の `.field public static final NAME:I = VALUE` を全て抽出し、
     Proto.kt の `const val NAME = VALUE` と突き合わせる（10進/16進/負値を正規化して比較）
  2. MAGIC の `.array-data 1` を読み、Proto.kt の byteArrayOf(...) と比較
  3. <clinit> 内の `const-string` から PROBE / PROBE_ACK の文字列を読み、
     Proto.kt の "LITESCREEN?" / "LITESCREEN!" と比較
  4. Framing.smali のビット演算（and-int 0xff / ushr / shl）の出現箇所を数え、
     Proto.kt が `and 0xFF` / `ushr` / `shl` を同じだけ使っているかを確認
  5. 送信側APKと受信側APKの Proto.smali / Framing.smali が同一かを比較

【実行】 python3 scripts/11_verify_dex_constants.py
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEC = os.path.join(ROOT, "recovery", "decompiled")
SMALI_SENDER = os.path.join(DEC, "sender-v1.0.11-apktool", "smali_classes2", "jp", "litescreen", "protocol")
SMALI_RECEIVER = os.path.join(DEC, "receiver-v1.0.11-apktool", "smali_classes2", "jp", "litescreen", "protocol")
PROTO_KT = os.path.join(ROOT, "LiteScreen-Recovered", "protocol", "src", "main", "java",
                        "jp", "litescreen", "protocol", "Proto.kt")

checks = 0
failures = []


def eq(label, expected, actual):
    global checks
    checks += 1
    if expected != actual:
        failures.append(f"{label}: smali={expected!r} kotlin={actual!r}")
        print(f"  [FAIL] {label}: smali={expected!r} kotlin={actual!r}")
    else:
        print(f"  [ ok ] {label} = {actual!r}")


def norm_int(tok):
    """smali の整数リテラルを Python int にする。0xNN / -0xNN / NN / NNNt に対応"""
    tok = tok.strip().rstrip("tL")
    neg = tok.startswith("-")
    if neg:
        tok = tok[1:]
    v = int(tok, 16) if tok.lower().startswith("0x") else int(tok, 0)
    return -v if neg else v


def parse_smali_fields(path):
    """.field public static final NAME:I = VALUE を dict で返す"""
    out = {}
    txt = open(path, encoding="utf-8").read()
    for m in re.finditer(r"^\.field public static final ([A-Z0-9_]+):I = (-?0x[0-9a-fA-F]+|-?\d+)$",
                         txt, re.M):
        out[m.group(1)] = norm_int(m.group(2))
    return out


def parse_array_data(txt, label):
    """:label の .array-data 1 の要素を byte リストで返す"""
    m = re.search(r":" + label + r"\s+\.array-data\s+1\s*(.*?)\.end array-data", txt, re.S)
    if not m:
        return None
    return [norm_int(x) for x in re.findall(r"(-?0x[0-9a-fA-F]+t?)\b", m.group(1))]


def parse_kotlin_consts(path):
    """Proto.kt の const val NAME = 式 を dict で返す（10進・16進・アンダースコア対応）"""
    out = {}
    txt = open(path, encoding="utf-8").read()
    for m in re.finditer(r"const val ([A-Z0-9_]+)\s*=\s*(-?0x[0-9A-Fa-f_]+|-?[\d_]+)", txt):
        lit = m.group(2).replace("_", "")
        out[m.group(1)] = int(lit, 16) if lit.lower().lstrip("-").startswith("0x") else int(lit, 10)
    return out


def parse_kotlin_byte_array(path, name):
    """val NAME: ByteArray = byteArrayOf(...) の要素を byte リストで返す"""
    txt = open(path, encoding="utf-8").read()
    m = re.search(name + r"[^=]*=\s*byteArrayOf\(([^)]*)\)", txt)
    if not m:
        return None
    vals = []
    for tok in m.group(1).split(","):
        tok = tok.strip().replace("_", "")
        if not tok:
            continue
        v = int(tok, 16) if tok.lower().lstrip("-").startswith("0x") else int(tok, 10)
        vals.append(v - 256 if v > 127 else v)
    return vals


def parse_kotlin_string(path, name):
    txt = open(path, encoding="utf-8").read()
    m = re.search(name + r'[^=]*=\s*"([^"]*)"\.toByteArray', txt)
    return m.group(1) if m else None


def main():
    for p in (SMALI_SENDER, PROTO_KT):
        if not os.path.exists(p):
            print(f"[x] 必要なファイルがありません: {p}", file=sys.stderr)
            return 2

    proto_smali = open(os.path.join(SMALI_SENDER, "Proto.smali"), encoding="utf-8").read()
    framing_smali = open(os.path.join(SMALI_SENDER, "Framing.smali"), encoding="utf-8").read()
    kt = open(PROTO_KT, encoding="utf-8").read()

    print("=== 1. Proto の int 定数 (smali .field  vs  Proto.kt const val) ===")
    smali_fields = parse_smali_fields(os.path.join(SMALI_SENDER, "Proto.smali"))
    kt_consts = parse_kotlin_consts(PROTO_KT)
    print(f"  smali から {len(smali_fields)} 個、Proto.kt から {len(kt_consts)} 個の定数を抽出")
    missing_in_kt = sorted(set(smali_fields) - set(kt_consts))
    extra_in_kt = sorted(set(kt_consts) - set(smali_fields))
    eq("smali にあって Proto.kt に無い定数", [], missing_in_kt)
    eq("Proto.kt にあって smali に無い定数", [], extra_in_kt)
    for name in sorted(set(smali_fields) & set(kt_consts)):
        eq(f"Proto.{name}", smali_fields[name], kt_consts[name])

    print()
    print("=== 2. MAGIC バイト列 (smali .array-data 1  vs  Proto.kt byteArrayOf) ===")
    eq("Proto.MAGIC", parse_array_data(proto_smali, "array_0"),
       parse_kotlin_byte_array(PROTO_KT, r"val MAGIC"))

    print()
    print("=== 3. PROBE / PROBE_ACK 文字列 (smali <clinit> const-string  vs  Proto.kt) ===")
    clinit = re.search(r"\.method static constructor <clinit>\(\)V(.*?)\.end method",
                       proto_smali, re.S).group(1)
    strings = re.findall(r'const-string v\d+, "([^"]*)"', clinit)
    # 最初の2つが PROBE, PROBE_ACK（3番目は Intrinsics の "getBytes(...)"）
    probes = [s for s in strings if s.startswith("LITESCREEN")]
    eq("smali の LITESCREEN* 文字列数", 2, len(probes))
    eq("Proto.PROBE", probes[0] if probes else None, parse_kotlin_string(PROTO_KT, r"val PROBE"))
    eq("Proto.PROBE_ACK", probes[1] if len(probes) > 1 else None,
       parse_kotlin_string(PROTO_KT, r"val PROBE_ACK"))

    print()
    print("=== 4. Framing のビット演算（smali の命令数 vs Proto.kt の演算子数） ===")
    # smali 側: 0xff マスク、論理右シフト、左シフト
    smali_and_ff = len(re.findall(r"and-int(?:/lit16|/lit8)? v\d+, (?:v\d+|p\d+), 0xff\b", framing_smali))
    smali_ushr = len(re.findall(r"ushr-(?:int|long)(?:/lit8|/2addr)? ", framing_smali))
    smali_shl = len(re.findall(r"shl-(?:int|long)(?:/lit8|/2addr)? ", framing_smali))
    # Kotlin 側
    kt_and_ff = len(re.findall(r"and 0xFF", kt))
    kt_ushr = len(re.findall(r"ushr", kt))
    kt_shl = len(re.findall(r"\bshl\b", kt))
    print(f"  smali : and 0xff = {smali_and_ff}, ushr = {smali_ushr}, shl = {smali_shl}")
    print(f"  Proto.kt: and 0xFF = {kt_and_ff}, ushr = {kt_ushr}, shl = {kt_shl}")
    # 数は完全一致しなくてもよい（Kotlinは式をまとめるため）。
    # 重要なのは「Proto.kt に `and 0xFF` が存在し、smali の 0xff マスク数を下回らない」こと。
    eq("Proto.kt に 0xFF マスクが存在する", True, kt_and_ff > 0)
    global checks
    checks += 1
    if kt_and_ff < 15:
        failures.append(f"and 0xFF の数が少なすぎる: {kt_and_ff} (smali は {smali_and_ff})")
        print(f"  [FAIL] and 0xFF の数が少なすぎる: {kt_and_ff}")
    else:
        print(f"  [ ok ] and 0xFF の数 {kt_and_ff} (jadx誤変換を採用していない)")
    # UByte.MAX_VALUE を採用していないことの確認
    eq("Proto.kt に UByte.MAX_VALUE が残っていない", False, "UByte.MAX_VALUE" in kt)

    print()
    print("=== 5. 送信側APK と 受信側APK の protocol smali が同一か ===")
    for fn in ("Proto.smali", "Framing.smali", "ProtocolException.smali"):
        a = os.path.join(SMALI_SENDER, fn)
        b = os.path.join(SMALI_RECEIVER, fn)
        if not os.path.exists(b):
            print(f"  [skip] {fn}: 受信側に見つからない")
            continue
        same = open(a, encoding="utf-8").read() == open(b, encoding="utf-8").read()
        eq(f"{fn} sender==receiver", True, same)

    print()
    print("-" * 58)
    print(f"総チェック数 : {checks}")
    print(f"不一致       : {len(failures)}")
    if failures:
        print("---- 失敗詳細 ----")
        for f in failures:
            print("  " + f)
        return 1
    print("結果: PASS — Proto.kt の定数・配列・ビット演算は DEX(smali) と一致")
    return 0


if __name__ == "__main__":
    sys.exit(main())
