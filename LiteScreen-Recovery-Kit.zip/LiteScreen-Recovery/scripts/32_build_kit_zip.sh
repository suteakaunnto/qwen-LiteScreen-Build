#!/usr/bin/env bash
# scripts/32_build_kit_zip.sh — 配布用キット ZIP の再生成と整合性検証（Phase F 追加）
#
# 使い方:
#   bash scripts/32_build_kit_zip.sh                 # 一時名で生成 → 検証（本番 ZIP は差し替えない）
#   bash scripts/32_build_kit_zip.sh --commit        # 検証に合格したら本番 ZIP を差し替える（旧 ZIP は退避して残す）
#
# 設計上の注意（ユーザー指示より）:
#   - 新しい ZIP の検証が終わるまで **古い ZIP を削除しない**（--commit 時も evidence 配下へ退避する）。
#   - ビルドキャッシュ（*/build/, */.gradle/, out/, dist/, target/, node_modules/, __pycache__/）は除外。
#   - 元 APK 3 本・再構築 APK/AAR・ソース・Gradle Wrapper・docs・evidence・reports・scripts・tests はすべて含める。
#   - `recovery/decompiled/`（78 MB）は除外（`scripts/02_decompile_all.sh` で再生成可能）。
#   - ZIP 自身のハッシュは ZIP に含められない（自己参照）ため `recovery/artifacts/KIT_SHA256.txt`（ZIP の外）に書く。
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"      # .../LiteScreen-Recovery
WORK="$(cd "$ROOT/.." && pwd)"                                # ワークスペース直下
BASE="$(basename "$ROOT")"                                    # LiteScreen-Recovery
ART="$ROOT/recovery/artifacts"
FINAL="$ART/LiteScreen-Recovery-Kit.zip"
TMP="$ART/LiteScreen-Recovery-Kit.new.zip"
COMMIT=0
[ "${1:-}" = "--commit" ] && COMMIT=1

cd "$WORK"
rm -f "$TMP"

# ---- 除外パターン（zip -x 用） ----
EXCLUDES=(
  "$BASE/recovery/decompiled/*"
  "$BASE/recovery/artifacts/LiteScreen-Recovery-Kit*.zip"
  "$BASE/recovery/artifacts/KIT_SHA256.txt"
  "$BASE/recovery/evidence/PHASE_F_docs_before_*/artifacts/*.zip"
  "$BASE/recovery/evidence/PHASE_F_superseded_zip_*"
  "$BASE/recovery/evidence/*kit_zip_build*.log"
  "*/build" "*/build/*"
  "*/.gradle" "*/.gradle/*"
  "*/.kotlin" "*/.kotlin/*"
  "*/local.properties"
  "*/out/*" "*/dist/*" "*/target/*" "*/node_modules/*" "*/__pycache__/*"
  "*.tmp" "*.swp" "*.bak.zip"
)

echo "[1/4] ZIP を生成します（一時名: $(basename "$TMP")）"
zip -r -X -9 -q "$TMP" "$BASE" -x "${EXCLUDES[@]}"
ls -l "$TMP"

echo "[2/4] 整合性を検証します"
python3 - "$TMP" "$FINAL" "$BASE" <<'PY'
import sys, zipfile, hashlib, os, collections
tmp, final, base = sys.argv[1], sys.argv[2], sys.argv[3]
z = zipfile.ZipFile(tmp)
infos = z.infolist()
names = [i.filename for i in infos]

fail = []
# 1) 破損チェック
bad = z.testzip()
if bad: fail.append(f"testzip() が破損を検出: {bad}")

# 2) エントリ内訳
dirs  = [n for n in names if n.endswith('/')]
files = [n for n in names if not n.endswith('/')]
print(f"  ZIP エントリ総数 : {len(names)}")
print(f"    通常ファイル   : {len(files)}")
print(f"    ディレクトリ   : {len(dirs)}")
print(f"  展開後サイズ合計 : {sum(i.file_size for i in infos):,} B")
print(f"  ZIP サイズ       : {os.path.getsize(tmp):,} B")

# 3) 重複・絶対パス・親ディレクトリ参照
dup = [n for n, c in collections.Counter(names).items() if c > 1]
if dup: fail.append(f"重複エントリ {len(dup)} 件: {dup[:5]}")
abs_p = [n for n in names if n.startswith('/') or (len(n) > 1 and n[1] == ':')]
if abs_p: fail.append(f"絶対パス {len(abs_p)} 件: {abs_p[:5]}")
dotdot = [n for n in names if '/../' in n or n.startswith('../')]
if dotdot: fail.append(f"親ディレクトリ参照 {len(dotdot)} 件: {dotdot[:5]}")

# 4) 除外すべきものの漏れ込み
leak_pat = ['/build/', '/.gradle/', '/.kotlin/', '/decompiled/', 'local.properties',
            '/node_modules/', '/__pycache__/', '/out/', '/dist/', '/target/']
leaks = [n for n in names if any(p in n for p in leak_pat)]
if leaks: fail.append(f"除外対象の漏れ込み {len(leaks)} 件: {leaks[:5]}")
# 自己参照になるのは「現行の」ZIP と KIT_SHA256.txt だけ（evidence 配下の退避コピーは証拠として許可）
live_self = [f"{base}/recovery/artifacts/LiteScreen-Recovery-Kit.zip",
             f"{base}/recovery/artifacts/LiteScreen-Recovery-Kit.new.zip",
             f"{base}/recovery/artifacts/KIT_SHA256.txt"]
selfref = [n for n in names if n in live_self]
if selfref: fail.append(f"自己参照エントリ（ZIP に含めてはならない）: {selfref}")

# 5) 必須バイナリ 8 点の存在・サイズ・SHA-256
must = {
 f"{base}/recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk": (2512825, "384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473"),
 f"{base}/recovery/input-apk/litescreen-sender-v1.0.11-debug.apk":   (2521362, "70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4"),
 f"{base}/recovery/input-apk/litescreen-sender-v1.0.10-debug.apk":   (2518766, "b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc"),
 f"{base}/recovery/artifacts/kotlin-2.0.21/receiver-debug_kotlin2.0.21_fix8-9.apk": (2512149, "50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408"),
 f"{base}/recovery/artifacts/kotlin-2.0.21/sender-debug_kotlin2.0.21_fix8-9.apk":   (2521242, "d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd"),
 f"{base}/recovery/artifacts/kotlin-2.2.20/receiver-debug_kotlin2.2.20_fix8-9.apk": (2616008, "93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5"),
 f"{base}/recovery/artifacts/kotlin-2.2.20/sender-debug_kotlin2.2.20_fix8-9.apk":   (2625017, "4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116"),
 f"{base}/recovery/artifacts/kotlin-2.2.20/protocol-debug_fix8-9.aar": (5786, "ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25"),
}
print("  必須バイナリ 8 点:")
for n, (size, sha) in must.items():
    if n not in names:
        fail.append(f"必須ファイルが無い: {n}"); print(f"    MISSING  {n}"); continue
    data = z.read(n)
    ok_s = len(data) == size
    ok_h = hashlib.sha256(data).hexdigest() == sha
    print(f"    {'OK ' if (ok_s and ok_h) else 'NG '} {n.split('/')[-1]}  {len(data):,} B  sha256 {'一致' if ok_h else '不一致'}")
    if not (ok_s and ok_h): fail.append(f"必須ファイルの内容不一致: {n}")

# 6) Gradle Wrapper / 主要ドキュメントの存在
need_docs = [f"{base}/README.md", f"{base}/CHECKPOINT.md", f"{base}/SHA256SUMS.txt",
             f"{base}/docs/INSTALL_UNINSTALL_POLICY.md", f"{base}/docs/DEVICE_TEST_GUIDE.md",
             f"{base}/docs/ADB_SETUP_WINDOWS.md", f"{base}/docs/SIGNING_GUIDE.md",
             f"{base}/docs/KNOWN_ISSUES.md", f"{base}/docs/PROJECT_OVERVIEW.md", f"{base}/docs/RECOVERY_LOG.md",
             f"{base}/recovery/tests/README.md", f"{base}/recovery/tests/TEST_A_RESULT.md",
             f"{base}/recovery/tests/TEST_B_RESULT.md", f"{base}/recovery/tests/TEST_C_RESULT.md",
             f"{base}/recovery/artifacts/APK_BUILD_LOG.md", f"{base}/recovery/artifacts/CURRENT_ARTIFACTS.md",
             f"{base}/recovery/artifacts/KIT_INTEGRITY.md",
             f"{base}/LiteScreen-Recovered/gradlew", f"{base}/LiteScreen-Recovered/gradlew.bat",
             f"{base}/LiteScreen-Recovered/gradle/wrapper/gradle-wrapper.jar",
             f"{base}/LiteScreen-Recovered/gradle/wrapper/gradle-wrapper.properties",
             f"{base}/recovery/input-apk/SHA256SUMS.txt",
             f"{base}/recovery/reports/APK_FORENSICS.md", f"{base}/recovery/reports/JADX_ERRORS.md",
             f"{base}/recovery/reports/PHASE_D_BUILD_VERIFICATION.md",
             f"{base}/scripts/32_build_kit_zip.sh"]
missing_docs = [n for n in need_docs if n not in names]
if missing_docs: fail.append(f"主要ファイルの欠落 {len(missing_docs)} 件: {missing_docs}")
print(f"  主要ドキュメント/Wrapper {len(need_docs)} 点: {'すべて存在' if not missing_docs else '欠落 ' + str(missing_docs)}")

# 7) ワークスペース実体との突合（取りこぼし検出）
on_disk = set()
for dirpath, dirnames, filenames in os.walk(base):
    dirnames[:] = [d for d in dirnames if d not in
                   ('build', '.gradle', '.kotlin', 'decompiled', 'node_modules', '__pycache__', 'out', 'dist', 'target')]
    for fn in filenames:
        p = os.path.join(dirpath, fn)
        # 除外は「現行の成果物ディレクトリ直下」の ZIP / KIT_SHA256.txt のみ（退避コピーは含める）
        if p.replace(os.sep, '/') in (f"{base}/recovery/artifacts/LiteScreen-Recovery-Kit.zip",
                                      f"{base}/recovery/artifacts/LiteScreen-Recovery-Kit.new.zip",
                                      f"{base}/recovery/artifacts/KIT_SHA256.txt"): continue
        if 'PHASE_F_docs_before_' in p and p.endswith('.zip'): continue
        if 'PHASE_F_superseded_zip_' in p: continue  # 退避した旧 ZIP は再同梱しない（実体はワークスペースに保持）
        if 'kit_zip_build' in p and p.endswith('.log'): continue  # ビルドログは ZIP 生成後に確定するため外に置く
        if fn == 'local.properties': continue
        on_disk.add(p.replace(os.sep, '/'))
in_zip = set(files)
missing = sorted(on_disk - in_zip)
extra   = sorted(in_zip - on_disk)
print(f"  実体 {len(on_disk)} ファイル / ZIP {len(in_zip)} ファイル  差分: 取りこぼし {len(missing)}・余分 {len(extra)}")
if missing: print("    取りこぼし:", *missing[:20], sep="\n      ")
if extra:   print("    余分:", *extra[:20], sep="\n      ")
if missing: fail.append(f"ディスク上にあるのに ZIP に無いファイル {len(missing)} 件（最初の 5 件）: {missing[:5]}")
if extra:   fail.append(f"ZIP にあるがディスク上に無いエントリ {len(extra)} 件: {extra[:5]}")

# 8) 旧 ZIP との比較（増減の内訳）
if os.path.exists(final):
    old = set(i.filename for i in zipfile.ZipFile(final).infolist())
    new = set(names)
    added, removed = sorted(new - old), sorted(old - new)
    print(f"  旧 ZIP（{os.path.getsize(final):,} B / {len(old)} エントリ）との比較:")
    print(f"    追加 {len(added)} 件 / 削除 {len(removed)} 件")
    for n in added:   print("      +", n)
    for n in removed: print("      -", n)
    if removed: fail.append(f"旧 ZIP にあって新 ZIP に無いエントリ {len(removed)} 件: {removed[:5]}")

print()
if fail:
    print("❌ 検証 FAILED:")
    for f in fail: print("  -", f)
    sys.exit(1)
print("✅ 検証 PASSED（破損なし・重複なし・絶対パスなし・除外漏れなし・必須バイナリ一致・主要ファイル揃い・取りこぼしなし）")
PY

echo "[3/4] SHA-256"
NEWSHA=$(sha256sum "$TMP" | cut -d' ' -f1)
echo "  新 ZIP: $NEWSHA"
if [ -f "$FINAL" ]; then echo "  旧 ZIP: $(sha256sum "$FINAL" | cut -d' ' -f1)"; fi

if [ "$COMMIT" -eq 1 ]; then
  echo "[4/4] --commit: 本番 ZIP を差し替えます（旧 ZIP は evidence へ退避して残す）"
  TS=$(date -u +%Y%m%dT%H%M%SZ)
  BAK="$ROOT/recovery/evidence/PHASE_F_superseded_zip_${TS}"
  mkdir -p "$BAK"
  if [ -f "$FINAL" ]; then
    cp -p "$FINAL" "$BAK/LiteScreen-Recovery-Kit_superseded_${TS}.zip"
    sha256sum "$BAK/LiteScreen-Recovery-Kit_superseded_${TS}.zip" > "$BAK/SHA256.txt"
  fi
  mv "$TMP" "$FINAL"
  # ZIP の実測内訳（エントリ数・ファイル数・ディレクトリ数・展開後合計）も一緒に記録する
  read -r ENTRIES NFILES NDIRS UNSUM <<< "$(python3 -c "
import zipfile,sys
z=zipfile.ZipFile('$FINAL'); n=[i.filename for i in z.infolist()]
print(len(n), sum(1 for x in n if not x.endswith('/')), sum(1 for x in n if x.endswith('/')), sum(i.file_size for i in z.infolist()))
")"
  {
    echo "# LiteScreen-Recovery-Kit.zip — ZIP 全体のハッシュと実測内訳"
    echo "# これは ZIP 全体のハッシュ（内部ファイルのハッシュ一覧は SHA256SUMS.txt）。"
    echo "# ZIP 自身のハッシュは ZIP に含められないため、このファイルを ZIP の外に置く。"
    echo "file: recovery/artifacts/LiteScreen-Recovery-Kit.zip"
    echo "sha256: $(sha256sum "$FINAL" | cut -d' ' -f1)"
    echo "size_bytes: $(stat -c %s "$FINAL")"
    echo "zip_entries: $ENTRIES"
    echo "regular_files: $NFILES"
    echo "directory_entries: $NDIRS"
    echo "uncompressed_bytes: $UNSUM"
    echo "generated_utc: $(date -u '+%Y-%m-%d %H:%M:%S')"
    echo "built_by: scripts/32_build_kit_zip.sh --commit"
    echo "verification: unzip -t / testzip() / 必須バイナリ 8 点の SHA-256 / ディスク実体との突合 / 旧 ZIP との増減（削除 0）→ すべて合格"
    echo
    echo "# ---- 差し替え後の追加検証（このファイルは ZIP の外なので、ZIP 確定後の結果を書ける）----"
    echo "unzip_t: $(cd "$ROOT" && unzip -t recovery/artifacts/LiteScreen-Recovery-Kit.zip 2>&1 | tail -1)"
    SUMOK=$(cd "$ROOT" && sha256sum -c SHA256SUMS.txt --quiet 2>&1 && echo "all OK" || echo "FAILED")
    SUMN=$(grep -Ec '^[0-9a-f]{64}  ' "$ROOT/SHA256SUMS.txt")
    echo "sha256sums_internal_files: ${SUMN} 件 → ${SUMOK}"
    echo "input_apk_check: $(cd "$ROOT/recovery/input-apk" && sha256sum -c SHA256SUMS.txt 2>&1 | tr '\n' ' ')"
    echo "input_apk_perms: $(cd "$ROOT" && ls -l recovery/input-apk/*.apk | awk '{printf "%s ", $1}')"
    echo "artifact_apk_hashes:"
    (cd "$ROOT" && sha256sum recovery/artifacts/kotlin-*/*.apk recovery/artifacts/kotlin-*/*.aar | sed 's/^/  /')
    echo "workspace_apparent_bytes: $(du -sb "$WORK" | cut -f1)"
    echo "workspace_file_count: $(find "$WORK" -type f | wc -l)"
  } > "$ART/KIT_SHA256.txt"
  cat "$ART/KIT_SHA256.txt"
else
  echo "[4/4] 検証のみ（本番 ZIP は未差し替え）。差し替えるには: bash scripts/32_build_kit_zip.sh --commit"
fi
