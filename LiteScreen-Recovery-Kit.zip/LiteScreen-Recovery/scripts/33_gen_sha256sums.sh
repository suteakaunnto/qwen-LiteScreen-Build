#!/usr/bin/env bash
# scripts/33_gen_sha256sums.sh — 内部ファイルの SHA-256 一覧（SHA256SUMS.txt）を再生成する（Phase F 追加）
#
# 使い方:  cd LiteScreen-Recovery && bash scripts/33_gen_sha256sums.sh
# 検証:    cd LiteScreen-Recovery && sha256sum -c SHA256SUMS.txt
#
# 設計:
#   - 対象は「キット ZIP に含めるファイル」と同じ集合（除外ルールも scripts/32_build_kit_zip.sh と一致させる）。
#   - **SHA256SUMS.txt 自身は含めない**（自己参照になるため）。
#   - **ZIP 全体のハッシュは含めない**（ZIP の外＝ recovery/artifacts/KIT_SHA256.txt に記録する）。
#   - 古い値を残さないため、毎回フルに生成し直す（追記方式にしない）。
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
OUT="SHA256SUMS.txt"
TMP="$(mktemp)"

# ---- 対象ファイルの列挙（ZIP の除外ルールと同じ） ----
list_files() {
  find . -type f \
    -not -path './recovery/decompiled/*' \
    -not -path './recovery/artifacts/LiteScreen-Recovery-Kit*.zip' \
    -not -path './recovery/artifacts/KIT_SHA256.txt' \
    -not -path './recovery/evidence/PHASE_F_docs_before_*/artifacts/*.zip' \
    -not -path './recovery/evidence/PHASE_F_superseded_zip_*' \
    -not -path './recovery/evidence/*kit_zip_build*.log' \
    -not -path '*/build/*' -not -path '*/.gradle/*' -not -path '*/.kotlin/*' \
    -not -path '*/out/*' -not -path '*/dist/*' -not -path '*/target/*' \
    -not -path '*/node_modules/*' -not -path '*/__pycache__/*' \
    -not -name 'local.properties' \
    -not -path './SHA256SUMS.txt' \
    | sed 's|^\./||' | LC_ALL=C sort
}

section() {  # section <見出し> <grep パターン（拡張正規表現・相対パスにマッチ）>
  local title="$1" pat="$2"
  local hits
  hits="$(grep -E "$pat" "$TMP" || true)"
  [ -z "$hits" ] && return 0
  echo "## $title"
  echo "$hits"
  echo
}

{
  echo "# LiteScreen 復旧キット — 内部ファイルの SHA-256 一覧"
  echo "# 生成: $(date -u '+%Y-%m-%dT%H:%M:%S+00:00')（scripts/33_gen_sha256sums.sh）"
  echo "# 検証: cd LiteScreen-Recovery && sha256sum -c SHA256SUMS.txt"
  echo "#"
  echo "# 注意 1: これは **ZIP の内部ファイル**のハッシュ一覧。**ZIP 全体のハッシュではない**。"
  echo "#         ZIP 全体のハッシュは recovery/artifacts/KIT_SHA256.txt（ZIP の外）に記録する（自己参照を避けるため）。"
  echo "# 注意 2: SHA256SUMS.txt 自身は掲載しない（自己参照になるため）。"
  echo "# 注意 3: 再構築 APK は元 APK と**別物**（署名が異なるため上書き更新不可・並存不可）。"
  echo "#         再構築版をインストールするには端末上の元アプリのアンインストールが必要。"
  echo "#         方針は docs/INSTALL_UNINSTALL_POLICY.md。元 APK ファイルは recovery/input-apk/ に保全済み。"
  echo "# 注意 4: 実機テスト（Test A / B / C）は **NOT TESTED / BLOCKED**（recovery/tests/ 参照）。"
  echo
} > "$OUT"

list_files > /dev/null  # 事前チェック（find の失敗を早期に検出）
list_files | while IFS= read -r f; do sha256sum "$f"; done > "$TMP"

{
  section "入力 APK（元アプリ。GitHub suteakaunnto/qwen-LiteScreen-Build から取得・chmod 444・変更禁止）" \
          '^.{64}  recovery/input-apk/.*\.apk$'
  section "出力: 再構築 APK / AAR（正式成果物。修正 #1〜#9 反映・clean ビルド・exit 0）" \
          '^.{64}  recovery/artifacts/kotlin-.*/.*\.(apk|aar)$'
  section "成果物ディレクトリのハッシュ一覧（サブリスト）" \
          '^.{64}  recovery/(input-apk|artifacts/kotlin-[^/]*)/SHA256SUMS\.txt$'
  section "トップレベルのドキュメント・ハッシュ一覧" \
          '^.{64}  (README\.md|CHECKPOINT\.md)$'
  section "docs/（手順書・方針・既知の問題）" \
          '^.{64}  docs/'
  section "recovery/tests/（実機テストの結果記録テンプレート。現状すべて NOT TESTED）" \
          '^.{64}  recovery/tests/'
  section "recovery/artifacts/（記録・台帳・整合性ログ）" \
          '^.{64}  recovery/artifacts/[^/]*\.md$'
  section "recovery/reports/（解析レポート）" \
          '^.{64}  recovery/reports/'
  section "recovery/evidence/（検証ログ・比較結果・退避した修正前ドキュメント）" \
          '^.{64}  recovery/evidence/'
  section "recovery/build-check/ と recovery/difftest/（ビルド照合・差分テスト）" \
          '^.{64}  recovery/(build-check|difftest)/'
  section "scripts/（再現可能な検証・ビルドスクリプト）" \
          '^.{64}  scripts/'
  section "LiteScreen-Recovered/（再構成した Android プロジェクト。ソース・リソース・Gradle Wrapper）" \
          '^.{64}  LiteScreen-Recovered/'
} >> "$OUT"

rm -f "$TMP"

ENTRIES=$(grep -Ec '^[0-9a-f]{64}  ' "$OUT" || true)
FILES=$(list_files | wc -l)
echo "SHA256SUMS.txt を生成しました: $ENTRIES 件（対象ファイル $FILES 件）"
if [ "$ENTRIES" -ne "$FILES" ]; then
  echo "❌ 件数が一致しません（セクションの grep パターンに取りこぼしあり）"
  comm -23 <(list_files) <(sed -nE 's|^[0-9a-f]{64}  (.+)$|\1|p' "$OUT" | LC_ALL=C sort) | sed 's/^/  未掲載: /'
  exit 1
fi
echo "検証: sha256sum -c SHA256SUMS.txt"
sha256sum -c "$OUT" --quiet && echo "✅ 全 $ENTRIES 件 OK"
