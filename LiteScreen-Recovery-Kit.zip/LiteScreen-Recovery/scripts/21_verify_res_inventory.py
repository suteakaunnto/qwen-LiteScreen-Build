#!/usr/bin/env python3
# =====================================================================
# 21_verify_res_inventory.py — リソース棚卸し検証（復元 res/ vs 元 APK）
#
# 【目的】
#   APK から復元した res/ が、元 APK のリソースを **種類ごと・名前ごと** に
#   過不足なく再現できているかを機械的に照合する。
#
# 【照合の方法】
#   元側 : recovery/decompiled/<app>-<ver>-jadx/sources/.../R.java
#          （= 元 APK の classes*.dex に入っていた R クラスの実体）
#   復元側: recovery/build-check/<mod>/r/classes の R クラス
#          （= scripts/20_compile_module.sh が aapt2 compile/link + javac で生成したもの。
#            つまり **復元した res/ を実際にビルドツールに通した結果**）
#   → 両者のリソース名集合を type ごとに比較する。
#
# 【実行】
#   python3 scripts/21_verify_res_inventory.py sender
#   python3 scripts/21_verify_res_inventory.py receiver
#   （事前に bash scripts/20_compile_module.sh <mod> を実行しておくこと）
#
# 【注意】
#   * R$id は元 APK に `activity_sender` のような「レイアウトファイル名由来の id」が
#     混ざることがある（レイアウトのルートに android:id="@+id/<レイアウト名>" が
#     付いていた名残）。コードから参照されていなければ動作に影響しないため、
#     差分として表示するが FAIL 扱いはしない（--strict で FAIL にできる）。
#   * リソース ID の **数値** は一致させない。aapt2 の割り当て順に依存するためで、
#     アプリの動作には無関係（同一 APK 内で一貫していればよい）。
# =====================================================================
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
JADX = os.path.join(ROOT, "recovery", "decompiled")
CHECK = os.path.join(ROOT, "recovery", "build-check")

MOD_PKG = {"sender": "jp.litescreen.sender", "receiver": "jp.litescreen.receiver"}


def parse_r_java(path):
    """jadx の R.java から {type: {name,...}} を作る。"""
    out = {}
    cur = None
    text = open(path, encoding="utf-8", errors="replace").read()
    for line in text.splitlines():
        m = re.match(r"\s*public static final class (\w+)", line)
        if m:
            cur = m.group(1)
            out.setdefault(cur, set())
            continue
        m = re.match(r"\s*public static (?:final )?int (\w+)\s*=", line)
        if m and cur:
            out[cur].add(m.group(1))
        if re.match(r"\s*}\s*$", line) and cur and not line.startswith("        "):
            cur = None
    return out


def parse_r_class(mod):
    """aapt2 が生成した R クラス（javap 出力）から {type: {name,...}} を作る。"""
    cp = os.path.join(CHECK, mod, "r", "classes")
    if not os.path.isdir(cp):
        sys.exit(f"[x] R クラスがありません: {cp}\n    先に `bash scripts/20_compile_module.sh {mod}` を実行してください")
    pkg = MOD_PKG[mod]
    out = {}
    # javap の出力形式に依存せず、生成されたクラスファイル名から内部クラス（=type）を求める
    base = os.path.join(cp, *pkg.split("."))
    names = [n for n in os.listdir(base) if n.startswith("R$")]
    types = sorted({n[2:-6] for n in names})
    for t in types:
        res = subprocess.run(
            ["javap", "-cp", cp, f"{pkg}.R${t}"], capture_output=True, text=True
        ).stdout
        out[t] = set(re.findall(r"\bint (\w+);", res))
    return out


def find_r_java(mod):
    hits = []
    for d in sorted(os.listdir(JADX)):
        if not d.endswith("-jadx"):
            continue
        if not d.startswith(mod):
            continue
        p = os.path.join(JADX, d, "sources", *MOD_PKG[mod].split("."), "R.java")
        if os.path.exists(p):
            hits.append((d, p))
    return hits


def main():
    if len(sys.argv) < 2 or sys.argv[1] not in MOD_PKG:
        sys.exit(f"usage: {sys.argv[0]} <{'|'.join(MOD_PKG)}> [--strict] [--version vX.Y.Z]")
    mod = sys.argv[1]
    strict = "--strict" in sys.argv
    ver = None
    if "--version" in sys.argv:
        ver = sys.argv[sys.argv.index("--version") + 1]

    hits = find_r_java(mod)
    if ver:
        hits = [h for h in hits if ver in h[0]] or hits
    if not hits:
        sys.exit(f"[x] 元 APK の R.java が見つかりません: {mod}")
    label, rjava = hits[-1]  # 一番新しいバージョンを使う

    orig = parse_r_java(rjava)
    mine = parse_r_class(mod)

    print(f"対象モジュール : {mod}")
    print(f"元 APK 側      : {label} → {os.path.relpath(rjava, ROOT)}")
    print(f"復元側         : recovery/build-check/{mod}/r/classes (aapt2 link の生成物)")
    print()
    print(f"{'type':10} {'元':>4} {'復元':>5}  不足 / 余分")
    print("-" * 78)

    all_types = sorted(set(orig) | set(mine))
    total_missing = []
    total_extra = []
    for t in all_types:
        o = orig.get(t, set())
        m = mine.get(t, set())
        missing = sorted(o - m)
        extra = sorted(m - o)
        total_missing += [(t, x) for x in missing]
        total_extra += [(t, x) for x in extra]
        note = ""
        if missing:
            note += f"不足={missing} "
        if extra:
            note += f"余分={extra}"
        if not note:
            note = "一致"
        print(f"{t:10} {len(o):4} {len(m):5}  {note}")

    print()
    # R$id のうち「レイアウトファイル名と同じ名前」の id は既知の無害差分として扱う。
    # （元ソースでレイアウトのルート View に android:id="@+id/activity_sender" のように
    #   ファイル名と同じ id が振られていた名残。コードから参照されていない。）
    layout_names = orig.get("layout", set()) | mine.get("layout", set())
    harmless = {("id", n) for (t, n) in total_missing if t == "id" and n in layout_names}
    real_missing = [(t, n) for (t, n) in total_missing if (t, n) not in harmless]

    if real_missing:
        print(f"[x] FAIL: 復元 res/ に不足があります: {real_missing}")
        sys.exit(1)
    if total_extra and strict:
        print(f"[!] --strict: 復元側に余分なリソースがあります: {total_extra}")
        sys.exit(1)

    print(f"PASS: {mod} のリソース名は元 APK と一致（不足 0 件）")
    if total_missing:
        print(f"  ※ 無視した既知差分: {total_missing}")
        print("    （レイアウトのルートに android:id=\"@+id/<レイアウト名>\" が付いていた名残。")
        print("      コードから参照されていないため動作に影響しない）")
    if total_extra:
        print(f"  ※ 復元側のみのエントリ: {len(total_extra)} 件（R$id に混ざる android: 名前空間など）")


if __name__ == "__main__":
    main()
