#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
30_zip_entry_hashes.py — [再構成新規] Phase D 検証プログラム

APK（ZIP）内の **エントリ単位** で sha256 を取り、元 APK と再構築 APK を突き合わせる。
「どのファイルが完全に一致し、どれが違うか」を一目で出すためのもの。

使い方:
  python3 scripts/30_zip_entry_hashes.py <module> <rebuilt-apk> <variant-suffix>
  例) python3 scripts/30_zip_entry_hashes.py receiver \
        LiteScreen-Recovered/receiver/build/outputs/apk/debug/receiver-debug.apk ""
出力:
  recovery/evidence/PHASE_D_zip_entries_<module><suffix>.txt
"""
import hashlib
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
EVID = ROOT / "recovery" / "evidence"


def entries(apk: Path):
    out = {}
    with zipfile.ZipFile(apk) as z:
        for i in z.infolist():
            if i.is_dir():
                continue
            with z.open(i) as f:
                data = f.read()
            out[i.filename] = (len(data), hashlib.sha256(data).hexdigest(), i.compress_type)
    return out


def main(argv):
    module = argv[1]
    new_apk = Path(argv[2])
    suffix = argv[3] if len(argv) > 3 else ""
    orig_apk = ROOT / "recovery" / "input-apk" / f"litescreen-{module}-v1.0.11-debug.apk"
    if not new_apk.is_absolute():
        new_apk = ROOT / new_apk
    o, n = entries(orig_apk), entries(new_apk)

    same = sorted(k for k in set(o) & set(n) if o[k][1] == n[k][1])
    diff = sorted(k for k in set(o) & set(n) if o[k][1] != n[k][1])
    only_o = sorted(set(o) - set(n))
    only_n = sorted(set(n) - set(o))

    L = []
    W = L.append
    W("=" * 78)
    W(f" ZIP エントリ単位 sha256 比較 : {module}{suffix}")
    W(f"   元 APK     : {orig_apk}")
    W(f"   再構築 APK : {new_apk}")
    W("=" * 78)
    W("")
    W(f"エントリ総数        : 元 {len(o)} / 再構築 {len(n)}")
    W(f"**完全一致**        : {len(same)}")
    W(f"内容が異なる        : {len(diff)}")
    W(f"元だけ / 再構築だけ : {len(only_o)} / {len(only_n)}")
    W("")
    W("--- 完全一致したエントリ ---")
    for k in same:
        W(f"  = {k}  ({o[k][0]} B)")
    W("")
    W("--- 内容が異なるエントリ ---")
    for k in diff:
        W(f"  ! {k}")
        W(f"      元     : {o[k][0]:>9} B  sha256={o[k][1]}")
        W(f"      再構築 : {n[k][0]:>9} B  sha256={n[k][1]}")
    if only_o or only_n:
        W("")
        W("--- 片方にしか存在しないエントリ ---")
        for k in only_o:
            W(f"  - 元だけ: {k}")
        for k in only_n:
            W(f"  + 再構築だけ: {k}")
    W("")
    out = EVID / f"PHASE_D_zip_entries_{module}{suffix}.txt"
    out.write_text("\n".join(L), encoding="utf-8")
    print(f"written: {out}")
    print(f"  same={len(same)} diff={len(diff)} only_orig={len(only_o)} only_new={len(only_n)}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
