#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
24_verify_class_members.py
  元 APK の smali と、復元コードをコンパイルした .class を
  **クラス単位 / フィールド・メソッド単位** で照合する。

比較するもの:
  - クラス名(内部クラス・Companion・data class 生成物を含む)
  - フィールド: 名前 + 型記述子 + アクセスフラグ(public/private/static/final/volatile)
  - メソッド: 名前 + 記述子 + アクセスフラグ

比較しないもの(意図的):
  - メソッド本体の命令列(=実装)。文字列定数は 23_verify_string_constants_bytecode.py で照合。
  - D8 生成物 … `$$ExternalSyntheticLambda*` クラス、`$r8$lambda$<hash>` メソッドは
    DEX 化の段階で初めて生成されるため、kotlinc 出力(.class)とは比較できない。双方で除外。
  - R クラス(jp.litescreen.*.R / R$xxx) … AGP が生成する R.jar と、本検証で使う
    aapt2 --java + javac の生成物では `<init>` の可視性(AGP=private / aapt2=public)と
    `<clinit>` の有無(AGP=なし: DEX の static 初期値として埋め込み / javac=あり)が異なる。
    これは復元ソースとは無関係な生成器差のため、合否判定から除外して別枠で表示する。
    (Phase D の Gradle/AGP ビルドでは一致するはず → 実 APK で確認すること)
  - ラムダ合成メソッドの番号 … `foo$lambda$7` と `foo$lambda$0` のような番号は
    コンパイラが付与する順序に依存する(Kotlin のバージョンでずれる)。
    `foo$lambda$N` へ正規化し、(正規化名, 記述子, flags) の **多重集合** として比較する。
    → 個数と引数形が一致していれば「同じラムダ構成」とみなす。

終了コード: 不足(元APKにあって復元に無いメンバ) が 0 件なら 0、それ以外は 1。

使い方:
  python3 scripts/24_verify_class_members.py receiver
  python3 scripts/24_verify_class_members.py sender --verbose
"""
from __future__ import annotations

import re
import struct
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DECOMPILED = ROOT / "recovery" / "decompiled"
BUILD_CHECK = ROOT / "recovery" / "build-check"

APK_TAG = {"receiver": "receiver-v1.0.11-apktool", "sender": "sender-v1.0.11-apktool"}
PKG = {"receiver": "jp/litescreen/receiver", "sender": "jp/litescreen/sender"}

# D8 が DEX 化時に生成する合成メソッド(kotlinc 出力には存在しない)
R8_LAMBDA_RE = re.compile(r'^\$r8\$lambda\$')
# Kotlin のラムダ合成メソッド名に含まれる連番を正規化
LAMBDA_NUM_RE = re.compile(r'\$lambda\$\d+')


LAMBDA_TAIL_RE = re.compile(r'(?:\$lambda\$\d+|\$\d+)+$')


R_CLASS_RE = re.compile(r"\.R(\$[\w]+)*$")


def is_r_class(cname: str) -> bool:
    """AGP/aapt2 が生成する R クラスかどうか。"""
    return bool(R_CLASS_RE.search(cname))


def canon_method(entry: str) -> str:
    """`name(desc) [flags]` からラムダ合成メソッドの連番部分を落として正規化する。

    ラムダ合成メソッドの名前はコンパイラのバージョンで形が変わる:
      Kotlin 2.0 系 : `runDiagnose$lambda$7$lambda$6`
      Kotlin 2.2 系 : `runDiagnose$lambda$0$0`
    どちらも「runDiagnose 内の入れ子ラムダ」なので、末尾の `$lambda$<数字>` / `$<数字>` を
    すべて落とした名前 + 記述子 + flags を同一視する(記述子が同じ＝捕捉引数が同じ)。
    """
    name_part, _, rest = entry.partition("(")
    return LAMBDA_TAIL_RE.sub("", name_part) + "(" + rest


FIELD_RE = re.compile(r'^\.field\s+((?:(?:public|private|protected|static|final|synthetic|'
                      r'volatile|transient|bridge|varargs|native|abstract|strictfp|synthetic|'
                      r'declared-synchronized|enum|interface|annotation)\s+)*)'
                      r'([A-Za-z_$][\w$]*):(\S+)')
METHOD_RE = re.compile(r'^\.method\s+((?:(?:public|private|protected|static|final|synchronized|'
                       r'bridge|varargs|native|abstract|strictfp|synthetic|declared-synchronized|'
                       r'constructor)\s+)*)([\w$<>]+)(\(.*)$')


# 双方で共通に比較するアクセスフラグ(コンパイラ差が出やすい bridge/varargs/synchronized 等は除外)
CANON_FLAGS = {"public", "private", "protected", "static", "final", "volatile",
               "transient", "synthetic", "abstract", "native", "enum"}


def flags_of(mods: str) -> str:
    """smali の修飾子列を比較用フラグ文字列へ正規化する。"""
    return " ".join(sorted(m for m in mods.split() if m in CANON_FLAGS))


# --------------------------------------------------------------- smali 側 ---

def collect_smali_members(module: str) -> dict[str, dict[str, set[str]]]:
    base = DECOMPILED / APK_TAG[module]
    out: dict[str, dict[str, set[str]]] = {}
    for p in sorted(base.rglob("*.smali")):
        posix = p.as_posix()
        if PKG[module] not in posix or "ExternalSyntheticLambda" in p.name:
            continue
        cls = re.sub(r"\.smali$", "", posix.split("/smali")[1].split("/", 1)[1]
                     if "/smali" in posix else p.stem)
        cls = posix[posix.index(PKG[module]):].replace(".smali", "")
        cname = cls.replace("/", ".")
        fields: set[str] = set()
        methods: set[str] = set()
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            fm = FIELD_RE.match(line)
            if fm:
                fields.add(f"{fm.group(2)}:{fm.group(3)} [{flags_of(fm.group(1))}]")
                continue
            mm = METHOD_RE.match(line)
            if mm:
                # smali では `.method public constructor <init>()V` のように
                # constructor 修飾子が付くが、メソッド名自体は <init>/<clinit> として出る。
                name = mm.group(2)
                if R8_LAMBDA_RE.match(name):
                    continue
                methods.add(f"{name}{mm.group(3)} [{flags_of(mm.group(1))}]")
        entry = out.setdefault(cname, {"fields": set(), "methods": set()})
        entry["fields"] |= fields
        entry["methods"] |= methods
    return out


# ------------------------------------------------------------- class 側 ---

ACC_FIELD = {0x0001: "public", 0x0002: "private", 0x0004: "protected", 0x0008: "static",
             0x0010: "final", 0x0040: "volatile", 0x0080: "transient",
             0x1000: "synthetic", 0x4000: "enum"}
ACC_METHOD = {0x0001: "public", 0x0002: "private", 0x0004: "protected", 0x0008: "static",
              0x0010: "final", 0x0020: "synchronized", 0x0040: "bridge",
              0x0100: "native", 0x0400: "abstract", 0x1000: "synthetic"}


def _flags(acc: int, table: dict[int, str]) -> str:
    got = {name for bit, name in table.items() if acc & bit and name in CANON_FLAGS}
    return " ".join(sorted(got))


def parse_class_members(data: bytes) -> tuple[str, set[str], set[str]]:
    """(クラス名, フィールド集合, メソッド集合) を返す。"""
    off = 8
    cp_count = struct.unpack_from(">H", data, off)[0]
    off += 2
    utf8: dict[int, str] = {}
    clsref: dict[int, int] = {}
    i = 1
    while i < cp_count:
        tag = data[off]
        off += 1
        if tag == 1:
            ln = struct.unpack_from(">H", data, off)[0]
            off += 2
            utf8[i] = data[off:off + ln].decode("utf-8", errors="replace")
            off += ln
        elif tag in (7, 8, 16, 19, 20):
            idx = struct.unpack_from(">H", data, off)[0]
            off += 2
            if tag == 7:
                clsref[i] = idx
        elif tag == 15:
            off += 3
        elif tag in (3, 4, 9, 10, 11, 12, 17, 18):
            off += 4
        elif tag in (5, 6):
            off += 8
            i += 1
        else:
            raise ValueError(f"unknown cp tag {tag}")
        i += 1

    access, this_c, super_c = struct.unpack_from(">HHH", data, off)
    off += 6
    cname = utf8[clsref[this_c]].replace("/", ".")
    ifc = struct.unpack_from(">H", data, off)[0]
    off += 2 + 2 * ifc

    def walk(off: int, is_field: bool, sink: set[str]) -> int:
        cnt = struct.unpack_from(">H", data, off)[0]
        off += 2
        for _ in range(cnt):
            acc, ni, di = struct.unpack_from(">HHH", data, off)
            off += 6
            name, desc = utf8[ni], utf8[di]
            if not name.startswith("$$") and not R8_LAMBDA_RE.match(name):
                if is_field:
                    sink.add(f"{name}:{desc} [{_flags(acc, ACC_FIELD)}]")
                else:
                    sink.add(f"{name}{desc} [{_flags(acc, ACC_METHOD)}]")
            ac = struct.unpack_from(">H", data, off)[0]
            off += 2
            for _ in range(ac):
                off += 2
                alen = struct.unpack_from(">I", data, off)[0]
                off += 4 + alen
        return off

    fields: set[str] = set()
    methods: set[str] = set()
    off = walk(off, True, fields)
    off = walk(off, False, methods)
    return cname, fields, methods


def collect_class_members(module: str) -> dict[str, dict[str, set[str]]]:
    """kotlinc 出力(classes) と aapt2 生成の R クラス(r/classes) を合わせて収集する。"""
    bases = [BUILD_CHECK / module / "classes", BUILD_CHECK / module / "r" / "classes"]
    out: dict[str, dict[str, set[str]]] = {}
    class_files = [p for b in bases if b.exists() for p in sorted(b.rglob("*.class"))]
    for p in class_files:
        cname, fields, methods = parse_class_members(p.read_bytes())
        entry = out.setdefault(cname, {"fields": set(), "methods": set()})
        entry["fields"] |= fields
        entry["methods"] |= methods
    return out


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] not in APK_TAG:
        print(__doc__)
        return 2
    module = argv[1]
    verbose = "--verbose" in argv

    orig = collect_smali_members(module)
    new = collect_class_members(module)
    classes = sorted(set(orig) | set(new))

    tot_f_missing = tot_m_missing = tot_f_extra = tot_m_extra = 0
    print(f"対象モジュール : {module}")
    print(f"元 APK 側      : {APK_TAG[module]} の smali (.field / .method)")
    print(f"復元側         : recovery/build-check/{module}/classes (.class の field/method)")
    print(f"比較           : クラス名・フィールド(名前:型[flags])・メソッド(名前+記述子[flags])")
    print(f"除外           : D8 生成物($$ExternalSyntheticLambda*)、$$ 始まりの合成メンバ")
    print()

    app_classes = [c for c in classes if not is_r_class(c)]
    r_classes = [c for c in classes if is_r_class(c)]
    cls_missing = [c for c in app_classes if c not in new]
    cls_extra = [c for c in app_classes if c not in orig]
    print(f"クラス数: 元 {len(orig)} / 復元 {len(new)} / 共通 {len(set(orig) & set(new))}"
          f"  (内 app クラス {len(app_classes)}, R クラス {len(r_classes)})")
    if cls_missing:
        print(f"  [復元に無いクラス] {len(cls_missing)}: {', '.join(cls_missing)}")
    if cls_extra:
        print(f"  [復元に多いクラス] {len(cls_extra)}: {', '.join(cls_extra)}")
    print()
    print(f"{'class':<52} {'f不足':>6} {'f余分':>6} {'m不足':>6} {'m余分':>6}  判定")
    print("-" * 96)

    for c in app_classes:
        o, n = orig.get(c), new.get(c)
        if o is None or n is None:
            print(f"{c:<52} {'-':>6} {'-':>6} {'-':>6} {'-':>6}  {'元のみ' if n is None else '復元のみ'}")
            continue
        fm = sorted(o["fields"] - n["fields"])
        fx = sorted(n["fields"] - o["fields"])
        om = Counter(canon_method(x) for x in o["methods"])
        nm = Counter(canon_method(x) for x in n["methods"])
        mm = sorted((om - nm).elements())
        mx = sorted((nm - om).elements())
        tot_f_missing += len(fm)
        tot_f_extra += len(fx)
        tot_m_missing += len(mm)
        tot_m_extra += len(mx)
        ok = not fm and not mm
        print(f"{c:<52} {len(fm):>6} {len(fx):>6} {len(mm):>6} {len(mx):>6}  {'OK' if ok else 'NG'}")
        if verbose or not ok:
            for x in fm:
                print(f"    [field 不足] {x}")
            for x in mm:
                print(f"    [method 不足] {x}")
            if verbose:
                for x in fx:
                    print(f"    [field 余分] {x}")
                for x in mx:
                    print(f"    [method 余分] {x}")

    print("-" * 96)
    print(f"app クラス合計: field 不足 {tot_f_missing} / 余分 {tot_f_extra} , "
          f"method 不足 {tot_m_missing} / 余分 {tot_m_extra}")

    # --- R クラス(生成器差の参考表示) ---
    r_diff = 0
    if r_classes:
        print()
        print("参考: R クラス(AGP 生成 vs aapt2+javac 生成の差。合否判定には含めない)")
        for c in r_classes:
            o, n = orig.get(c), new.get(c)
            if o is None or n is None:
                print(f"  {c:<50} {'元のみ' if n is None else '復元のみ'}")
                r_diff += 1
                continue
            fm = sorted(o["fields"] - n["fields"])
            fx = sorted(n["fields"] - o["fields"])
            mm = sorted(canon_method(x) for x in o["methods"] - n["methods"])
            mx = sorted(canon_method(x) for x in n["methods"] - o["methods"])
            if fm or fx or mm or mx:
                r_diff += 1
                print(f"  {c:<50} field不足{len(fm)} 余分{len(fx)} / method不足{len(mm)} 余分{len(mx)}")
                if verbose:
                    for x in fm + fx + mm + mx:
                        print(f"      {x}")
            else:
                print(f"  {c:<50} 一致")
        if r_diff:
            print(f"  → R クラス {r_diff} 件に生成器由来の差(フィールド名・型は一致している)")
    if tot_f_missing == 0 and tot_m_missing == 0 and not cls_missing:
        print(f"\nPASS: {module} のクラス構成・メンバ構成は元 APK と一致")
        return 0
    print(f"\nFAIL: {module} に不足あり(上記参照)")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
