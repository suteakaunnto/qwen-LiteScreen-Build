#!/usr/bin/env bash
# =====================================================================
# 10_diff_test_protocol.sh
#
# 【目的】
#   再構成した Kotlin の protocol モジュール（Proto / Framing / ProtocolException）が、
#   元 APK から取り出した実装と **バイト単位で同一の出力** を作ることを検証する。
#
# 【手法】
#   A. 元 APK (classes2.dex) を jadx で Java に復元
#   B. その Java を javac でコンパイルして「基準実装 JAR」を作る
#      → jadx 出力の protocol 3クラスは javac で無修正でコンパイルできることを確認済み
#   C. 再構成した Proto.kt を kotlinc でコンパイルして「再構成実装 JAR」を作る
#   D. DiffTest.java が両者を別 ClassLoader に読み込み、
#      同じ入力に対する出力バイト列・例外クラス名・例外メッセージを 1 件ずつ比較する
#   E. 1 件でも違えば exit 1
#
# 【この検証が証明すること / しないこと】
#   証明する: 「再構成 Kotlin」＝「jadx が DEX から復元した Java」であること。
#             定数・ビット演算・エンディアン・境界条件・例外文言の一致。
#   証明しない: jadx の復元そのものが DEX と一致していること。
#             → それは別途 scripts/11_verify_dex_constants.py が
#               apktool の smali 出力（DEX から直接逆アセンブルした正）を
#               パースして定数を独立検証する。
#
# 【実行】 bash scripts/10_diff_test_protocol.sh
# =====================================================================
set -euo pipefail

export ANDROID_HOME="${ANDROID_HOME:-/opt/android-sdk}"
PLATFORM="$ANDROID_HOME/platforms/android-36/android.jar"
[ -f "$PLATFORM" ] || PLATFORM="$ANDROID_HOME/platforms/android-34/android.jar"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APK="$ROOT/recovery/input-apk/litescreen-sender-v1.0.11-debug.apk"
JADX_SRC="$ROOT/recovery/decompiled/sender-v1.0.11-jadx/sources/jp/litescreen/protocol"
WORK="$ROOT/recovery/difftest"
KOTLIN_SRC="$ROOT/LiteScreen-Recovered/protocol/src/main/java"
KOTLINC_JAR="${KOTLINC_JAR:-/opt/tools/kotlinc/lib/kotlin-compiler.jar}"
STDLIB_JAR="${STDLIB_JAR:-/opt/tools/kotlinc/lib/kotlin-stdlib.jar}"

log(){ printf '\033[1;36m==>\033[0m %s\n' "$*"; }
die(){ printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

[ -f "$APK" ]            || die "元APKがありません: $APK"
[ -d "$JADX_SRC" ]       || die "jadx 出力がありません: $JADX_SRC (先に 02_decompile_all.sh を実行)"
[ -f "$KOTLINC_JAR" ]    || die "kotlin-compiler がありません。01_get_kotlinc.sh を先に実行 ($KOTLINC_JAR)"
[ -f "$KOTLIN_SRC/jp/litescreen/protocol/Proto.kt" ] || die "再構成ソースがありません: $KOTLIN_SRC"

rm -rf "$WORK"; mkdir -p "$WORK"

# --- A/B. jadx Java を基準実装としてコンパイル ---------------------------
log "基準実装 (jadx → javac) をビルド"
mkdir -p "$WORK/orig-src/jp/litescreen/protocol" "$WORK/orig-classes"
cp "$JADX_SRC"/Proto.java "$JADX_SRC"/Framing.java "$JADX_SRC"/ProtocolException.java \
   "$WORK/orig-src/jp/litescreen/protocol/"

# 【重要】jadx 1.5.6 は Kotlin の `UByte.MAX_VALUE`（内部表現 byte = -1）を
# int 255 と誤って解釈する Java を出力する。そのまま javac すると
# `b & UByte.MAX_VALUE` が `b & (-1)` になり符号マスクが消えて
# readInt/readHeader が全滅する（実測: readInt(47820) -> -52）。
# 詳細は recovery/reports/JADX_ERRORS.md と
# recovery/evidence/SMALI_Framing_bitops.txt（DEXからの直接逆アセンブル）を参照。
# ここでは基準実装を作る際に限り、smali で正しいことを確認済みの `and 0xff` へ置換する。
n=$(grep -c 'UByte.MAX_VALUE' "$WORK/orig-src/jp/litescreen/protocol/Framing.java" || true)
echo "    [jadx補正] Framing.java の UByte.MAX_VALUE を 0xFF に置換: ${n} 箇所"
sed -i 's/& UByte\.MAX_VALUE/\& 0xFF/g; s/^import kotlin\.UByte;$//' \
    "$WORK/orig-src/jp/litescreen/protocol/Framing.java"
grep -c 'UByte' "$WORK/orig-src/jp/litescreen/protocol/Framing.java" || true
javac -nowarn -encoding UTF-8 \
      -cp "$STDLIB_JAR:$PLATFORM" \
      -d "$WORK/orig-classes" \
      $(find "$WORK/orig-src" -name '*.java')
ORIG_JAR="$WORK/orig-protocol.jar"
(cd "$WORK/orig-classes" && jar cf "$ORIG_JAR" .)
log "  -> $ORIG_JAR ($(find "$WORK/orig-classes" -name '*.class' | wc -l) classes)"

# --- C. 再構成 Kotlin をコンパイル ---------------------------------------
log "再構成実装 (Proto.kt → kotlinc) をビルド"
mkdir -p "$WORK/new-classes"
java -cp "$KOTLINC_JAR" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
     -no-stdlib -classpath "$STDLIB_JAR" \
     -d "$WORK/new-classes" -jvm-target 17 -nowarn \
     $(find "$KOTLIN_SRC" -name '*.kt') 2>&1 | grep -vE '^warning:|^info:' || true
NEW_JAR="$WORK/new-protocol.jar"
(cd "$WORK/new-classes" && jar cf "$NEW_JAR" .)
log "  -> $NEW_JAR ($(find "$WORK/new-classes" -name '*.class' | wc -l) classes)"

# --- D. 差分テスト --------------------------------------------------------
log "差分テストをコンパイル & 実行"
mkdir -p "$WORK/test-classes"
javac -nowarn -encoding UTF-8 -d "$WORK/test-classes" "$ROOT/scripts/difftest/DiffTest.java"
set +e
java -Dfile.encoding=UTF-8 -cp "$WORK/test-classes:$STDLIB_JAR" \
     -Dorig.jar="$ORIG_JAR" -Dnew.jar="$NEW_JAR" DiffTest | tee "$WORK/difftest-output.txt"
rc=${PIPESTATUS[0]}
set -e
echo
if [ "$rc" -eq 0 ]; then
  log "PASS: 再構成 protocol 実装は基準実装と完全一致"
else
  log "FAIL: 差分あり (exit=$rc) — 詳細は $WORK/difftest-output.txt"
fi
exit "$rc"
