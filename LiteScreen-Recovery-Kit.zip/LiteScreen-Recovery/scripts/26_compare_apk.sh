#!/usr/bin/env bash
# =============================================================================
# 26_compare_apk.sh — 再構築 APK と 元 APK の「同一でないこと」を明示する比較
#                     （Phase D / ユーザー指示: 再構築APKを元APKと同一視しない）
#
# 比較項目:
#   1. ファイルサイズ / SHA-256                    … 一致しないのが正しい（別ビルド）
#   2. aapt2 dump badging                          … package / versionCode / versionName /
#                                                     minSdk / targetSdk / 権限 / コンポーネント
#   3. apksigner verify --verbose --print-certs    … 署名スキーマ(v1/v2/v3) + 証明書
#   4. ZIP エントリ一覧                            … dex / res / assets / lib / META-INF の差分
#   5. DEX ヘッダ（dexdump -f）                    … classes.dex の数・サイズ
#
# 使い方: ./scripts/26_compare_apk.sh <module: sender|receiver>
# 出力  : recovery/evidence/PHASE_D_apk_compare_<module>.txt
# =============================================================================
set -u

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BT=/opt/android-sdk/build-tools/34.0.0
AAPT2="$BT/aapt2"
APKSIGNER="$BT/apksigner"
DEXDUMP="$BT/dexdump"
EVID="$ROOT/recovery/evidence"
WORK="$ROOT/out/phase-d"
PROJ="$ROOT/LiteScreen-Recovered"

MODULE="${1:-receiver}"
case "$MODULE" in
  sender)   ORIG="$ROOT/recovery/input-apk/litescreen-sender-v1.0.11-debug.apk" ;;
  receiver) ORIG="$ROOT/recovery/input-apk/litescreen-receiver-v1.0.11-debug.apk" ;;
  *) echo "usage: $0 <sender|receiver>"; exit 2 ;;
esac
# 第2引数で再構築 APK を差し替え可能（Kotlin バージョン比較用）。第3引数はレポート名のサフィックス。
NEW="${2:-$PROJ/$MODULE/build/outputs/apk/debug/$MODULE-debug.apk}"
SUFFIX="${3:-}"
OUT="$EVID/PHASE_D_apk_compare_$MODULE$SUFFIX.txt"

[ -f "$ORIG" ] || { echo "missing original: $ORIG"; exit 3; }
[ -f "$NEW"  ] || { echo "missing rebuilt : $NEW"; exit 3; }

mkdir -p "$WORK/$MODULE$SUFFIX/orig" "$WORK/$MODULE$SUFFIX/new"

hash_of() { sha256sum "$1" | awk '{print $1}'; }
size_of() { stat -c %s "$1"; }

{
echo "###############################################################################"
echo "# Phase D 再構築 APK 比較レポート : $MODULE"
echo "# generated : $(date -Is)"
echo "# original  : $ORIG"
echo "# rebuilt   : $NEW"
echo "###############################################################################"
echo
echo "=== 1. サイズ / SHA-256 （一致しないのが正常。同一物として扱わないこと） ==="
printf '%-10s %12s  %s\n' "" "SIZE(B)" "SHA-256"
printf '%-10s %12s  %s\n' "original" "$(size_of "$ORIG")" "$(hash_of "$ORIG")"
printf '%-10s %12s  %s\n' "rebuilt"  "$(size_of "$NEW")"  "$(hash_of "$NEW")"
echo
echo "=== 2. aapt2 dump badging の差分（左<= 元 / 右=> 再構築） ==="
"$AAPT2" dump badging "$ORIG" > "$WORK/$MODULE$SUFFIX/orig/badging.txt" 2>&1
"$AAPT2" dump badging "$NEW"  > "$WORK/$MODULE$SUFFIX/new/badging.txt"  2>&1
echo "--- 主要項目の抽出 ---"
for side in orig new; do
  f="$WORK/$MODULE$SUFFIX/$side/badging.txt"
  echo "[$side]"
  grep -E "^package:|^sdkVersion:|^targetSdkVersion:|^application-label:|^launchable-activity:|^uses-permission:|^native-code:|^densities:|^application-debuggable" "$f" | sed 's/^/    /'
done
echo "--- diff (original => rebuilt) ---"
diff "$WORK/$MODULE$SUFFIX/orig/badging.txt" "$WORK/$MODULE$SUFFIX/new/badging.txt" && echo "    (差分なし)"
echo
echo "=== 3. 署名（apksigner verify --verbose --print-certs） ==="
for side in orig new; do
  case "$side" in orig) apk="$ORIG";; new) apk="$NEW";; esac
  echo "[$side] $apk"
  "$APKSIGNER" verify --verbose --print-certs "$apk" 2>&1 | sed 's/^/    /'
done
echo
echo "=== 4. ZIP エントリ比較 ==="
( cd "$WORK/$MODULE$SUFFIX/orig" && unzip -Z1 "$ORIG" | LC_ALL=C sort > entries.txt )
( cd "$WORK/$MODULE$SUFFIX/new"  && unzip -Z1 "$NEW"  | LC_ALL=C sort > entries.txt )
echo "original entries : $(wc -l < "$WORK/$MODULE$SUFFIX/orig/entries.txt")"
echo "rebuilt  entries : $(wc -l < "$WORK/$MODULE$SUFFIX/new/entries.txt")"
echo "--- 元だけに存在（<= only in original） / 再構築だけに存在（=> only in rebuilt） ---"
diff "$WORK/$MODULE$SUFFIX/orig/entries.txt" "$WORK/$MODULE$SUFFIX/new/entries.txt" | head -80 || true
echo "--- カテゴリ別エントリ数 ---"
for side in orig new; do
  f="$WORK/$MODULE$SUFFIX/$side/entries.txt"
  echo "[$side] dex=$(grep -c '\.dex$' "$f") res=$(grep -c '^res/' "$f") arsc=$(grep -c 'resources.arsc' "$f") assets=$(grep -c '^assets/' "$f") lib=$(grep -c '^lib/' "$f") META-INF=$(grep -c '^META-INF/' "$f")"
done
echo
echo "=== 5. DEX ヘッダ（dexdump -f） ==="
for side in orig new; do
  case "$side" in orig) apk="$ORIG";; new) apk="$NEW";; esac
  echo "[$side]"
  rm -rf "$WORK/$MODULE$SUFFIX/$side/dex"; mkdir -p "$WORK/$MODULE$SUFFIX/$side/dex"
  ( cd "$WORK/$MODULE$SUFFIX/$side/dex" && unzip -o -q "$apk" 'classes*.dex' )
  for d in "$WORK/$MODULE$SUFFIX/$side/dex"/classes*.dex; do
    [ -f "$d" ] || continue
    echo "  -- $(basename "$d") size=$(size_of "$d") sha256=$(hash_of "$d")"
    "$DEXDUMP" -f "$d" 2>/dev/null | grep -E "class_defs_size|method_ids_size|field_ids_size|string_ids_size|header_size|checksum|signature" | sed 's/^/     /'
  done
done
echo
echo "=== 6. 判定サマリ ==="
echo "  ※ このレポートは『再構築 APK が元 APK と同一ではない』ことを示すためのもの。"
echo "  ※ 署名証明書が異なる場合、既存インストール済みアプリの上書き更新はできず、"
echo "     アンインストール → 新規インストール が必要になる（データは消える）。"
} 2>&1 | tee "$OUT"

echo
echo "written: $OUT"
