#!/usr/bin/env bash
# kotlinc (Kotlin コンパイラ) の取得。
# Gradle を使わない軽量な検証（差分テスト・単体コンパイル）に使う。
set -euo pipefail
VER="${1:-2.2.20}"
DEST=/opt/tools
if [ -x "$DEST/kotlinc/bin/kotlinc" ]; then echo "既にある: $DEST/kotlinc"; exit 0; fi
mkdir -p "$DEST"
curl -sSL -o "$DEST/kotlinc.zip" \
  "https://github.com/JetBrains/kotlin/releases/download/v$VER/kotlin-compiler-$VER.zip"
rm -rf "$DEST/kotlinc" && unzip -q "$DEST/kotlinc.zip" -d "$DEST"
rm -f "$DEST/kotlinc.zip"
ls "$DEST/kotlinc/lib" | head -5
"$DEST/kotlinc/bin/kotlinc" -version 2>&1 | head -2
