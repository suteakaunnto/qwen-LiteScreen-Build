#!/usr/bin/env bash
# =====================================================================
# 02_decompile_all.sh — 逆コンパイルの再現スクリプト
#
# 原本APK（recovery/input-apk/, chmod 444）から apktool / jadx の出力を
# recovery/decompiled/ へ生成する。既存の出力がある場合はスキップする
# （証拠を破壊しないため、--force を付けたときだけ再生成する）。
#
# 実行: bash scripts/02_decompile_all.sh [--force]
# =====================================================================
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
IN="$ROOT/recovery/input-apk"
OUT="$ROOT/recovery/decompiled"
EV="$ROOT/recovery/evidence"
FORCE=0
[ "${1:-}" = "--force" ] && FORCE=1

log(){ printf '\033[1;36m==>\033[0m %s\n' "$*"; }
mkdir -p "$OUT" "$EV"

declare -A TARGETS=(
  [litescreen-sender-v1.0.11-debug.apk]="sender-v1.0.11"
  [litescreen-receiver-v1.0.11-debug.apk]="receiver-v1.0.11"
  [litescreen-sender-v1.0.10-debug.apk]="sender-v1.0.10"
)

for apk in "${!TARGETS[@]}"; do
  name="${TARGETS[$apk]}"
  src="$IN/$apk"
  [ -f "$src" ] || { echo "[x] 原本APKがありません: $src"; exit 1; }

  # --- apktool ---
  if [ -d "$OUT/$name-apktool" ] && [ "$FORCE" -eq 0 ]; then
    log "skip (既存): $name-apktool"
  else
    log "apktool d: $apk"
    [ -d "$OUT/$name-apktool" ] && chmod -R u+w "$OUT/$name-apktool"
    apktool d -f -o "$OUT/$name-apktool" "$src" > "$EV/apktool-$name.log" 2>&1
    chmod -R a-w "$OUT/$name-apktool"
  fi

  # --- jadx ---
  if [ -d "$OUT/$name-jadx" ] && [ "$FORCE" -eq 0 ]; then
    log "skip (既存): $name-jadx"
  else
    log "jadx: $apk"
    [ -d "$OUT/$name-jadx" ] && chmod -R u+w "$OUT/$name-jadx"
    # 注意: jadx は kotlin-stdlib のクラスで多数のエラーを出す（406件程度）が、
    # jp.litescreen.* の独自クラスにはエラーが出ないことを確認済み。
    set +e
    jadx -d "$OUT/$name-jadx" --show-bad-code -j 2 "$src" > "$EV/jadx-$name.log" 2>&1
    log "  jadx exit=$? (独自クラスのエラーは0件であることを grep で確認すること)"
    set -e
    chmod -R a-w "$OUT/$name-jadx"
  fi
done

log "完了"
echo "--- 独自クラスに jadx エラーが無いかの確認 ---"
for name in sender-v1.0.11 receiver-v1.0.11 sender-v1.0.10; do
  n=$(grep -ci "litescreen" "$EV/jadx-$name.log" 2>/dev/null || echo 0)
  echo "  $name : ログ中の 'litescreen' 言及 = $n 件 (0 が正常)"
done
