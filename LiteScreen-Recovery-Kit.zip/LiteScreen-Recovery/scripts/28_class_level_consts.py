#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
28_class_level_consts.py — [再構成新規] Phase D 補助検証

script 27 は「メソッド単位」で定数を比較するため、
  * ラムダの番号ずれ（Kotlin 2.0.x = クラス内連番 / 2.1+ = 関数内連番）
  * ユーザー承認済みの意図的差分（MirrorService.startMirroring 関数化）
によって「同じ定数が別のメソッドに移動しただけ」のケースが差分として出る。

そこで本スクリプトは **クラス単位（メソッド帰属を無視）** で
const-string / 数値定数のマルチセットを比較し、
「クラス内から本当に消えた・増えた定数」だけを抽出する。

実行: python3 scripts/28_class_level_consts.py <sender|receiver|both>
出力: recovery/evidence/PHASE_D_class_consts_<module>.txt
"""
import os
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEC = ROOT / "recovery" / "decompiled"
WORK = ROOT / "out" / "phase-d"
EVID = ROOT / "recovery" / "evidence"
APP_PREFIX = "jp/litescreen"

RE_CONST_STR = re.compile(r"const-string(?:/jumbo)?\s+\S+,\s*(\"(?:[^\"\\]|\\.)*\")")
RE_CONST_NUM = re.compile(
    r"^\s*(const(?:/4|/16|/high16)?|const-wide(?:/16|/32|/high16)?)\s+(\S+),\s*(-?(?:0x[0-9a-fA-F]+|\d+))"
)
RE_EXT = re.compile(r"\$\$ExternalSyntheticLambda\d+$")


def collect(base: Path):
    out = {}
    for root in sorted(p for p in base.iterdir() if p.is_dir() and p.name.startswith("smali")):
        app = root / APP_PREFIX
        if not app.exists():
            continue
        for p in app.rglob("*.smali"):
            out[p.relative_to(root).as_posix()[: -len(".smali")]] = p
    return out


def scan(path: Path):
    s, n = Counter(), Counter()
    for l in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = RE_CONST_STR.search(l)
        if m:
            s[m.group(1)] += 1
        m = RE_CONST_NUM.match(l)
        if m:
            # opcode 幅（const/4 vs const/16 …）は無視して「値」だけで数える
            n[m.group(3).lower()] += 1
    return s, n


def dec(v: str) -> str:
    try:
        return f"={int(v, 0)}"
    except ValueError:
        return ""


def run(module: str):
    o = collect(DEC / f"{module}-v1.0.11-apktool")
    variant = os.environ.get("PHASE_D_VARIANT", "")
    n = collect(WORK / f"{module}-rebuilt{variant}-apktool")
    L = []
    W = L.append
    W("=" * 78)
    W(f" クラス単位 定数比較（メソッド帰属を無視） : {module}")
    W("   元 APK     : recovery/decompiled/%s-v1.0.11-apktool" % module)
    W("   再構築 APK : out/phase-d/%s-rebuilt%s-apktool" % (module, variant))
    W("=" * 78)
    W("")
    # 合成ラムダクラスはクラス単位でも番号差があるので、まとめて集計する
    def bucket(name):
        return RE_EXT.sub("$$ExternalSyntheticLambda*", name)

    ob, nb = Counter(), Counter()
    oagg, nagg = {}, {}
    for name, p in o.items():
        b = bucket(name)
        ob[b] += 1
        s, num = scan(p)
        oagg.setdefault(b, (Counter(), Counter()))
        oagg[b][0].update(s)
        oagg[b][1].update(num)
    for name, p in n.items():
        b = bucket(name)
        nb[b] += 1
        s, num = scan(p)
        nagg.setdefault(b, (Counter(), Counter()))
        nagg[b][0].update(s)
        nagg[b][1].update(num)

    total_str_diff = total_num_diff = 0
    for b in sorted(set(oagg) | set(nagg)):
        os_, on = oagg.get(b, (Counter(), Counter()))
        ns, nn = nagg.get(b, (Counter(), Counter()))
        ds, dn = os_ - ns, ns - os_
        dsn, dnn = on - nn, nn - on
        if not (ds or dn or dsn or dnn):
            continue
        cnt_o, cnt_n = ob.get(b, 0), nb.get(b, 0)
        W(f"[{b}]" + (f"  (クラス数 元{cnt_o}/再構築{cnt_n})" if cnt_o != cnt_n else ""))
        if ds or dn:
            W("  const-string:")
            for k, v in sorted(ds.items()):
                W(f"    - 元だけ: {k} x{v}")
            for k, v in sorted(dn.items()):
                W(f"    + 再構築だけ: {k} x{v}")
            total_str_diff += sum(ds.values()) + sum(dn.values())
        if dsn or dnn:
            W("  数値定数:")
            for k, v in sorted(dsn.items()):
                W(f"    - 元だけ: {k}{dec(k)} x{v}")
            for k, v in sorted(dnn.items()):
                W(f"    + 再構築だけ: {k}{dec(k)} x{v}")
            total_num_diff += sum(dsn.values()) + sum(dnn.values())
        W("")
    W("### サマリ")
    W(f"  クラス単位で見て差が出た const-string 件数 : {total_str_diff}")
    W(f"  クラス単位で見て差が出た 数値定数 件数     : {total_num_diff}")
    W("")
    out = EVID / f"PHASE_D_class_consts_{module}{variant}.txt"
    out.write_text("\n".join(L), encoding="utf-8")
    print(f"written: {out}  (string_diff={total_str_diff}, num_diff={total_num_diff})")


if __name__ == "__main__":
    mods = ["sender", "receiver"] if (len(sys.argv) < 2 or sys.argv[1] == "both") else [sys.argv[1]]
    for m in mods:
        run(m)
