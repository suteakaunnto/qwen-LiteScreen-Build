#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
03_convert_res.py — [再構成新規] 復旧作業で作成したツール

apktool が出力した res/ を、AAPT2 がそのままコンパイルできる
「元のソース形式」へ戻す。

【やること】
 1. `N.0dip` → `Ndp` / `N.0sp` → `Nsp`（整数値のときだけ。11.5sp などは維持）
 2. `fill_parent` → `match_parent`
 3. layout の `@id/xxx` → `@+id/xxx`（apktool は ids.xml に分離するため。
    再構成では ids.xml / public.xml を使わず layout 内で宣言する形に戻す）
 4. vector drawable の `android:fillColor="@drawable/$xxx__N"` を、
    `$xxx__N.xml` の中身の <gradient .../> でインライン置換し、
    `<aapt:attr name="android:fillColor">` 形式へ戻す（AAPT2 の元ソース形式）
 5. shape の gradient の `android:angle="315.0"` → `"315"`（angle は整数属性）
 6. `android:angle="0.0"` かつ startX/Y,endX/Y 指定のあるものは angle を削除
    （startX/Y・endX/Y が優先されるため見た目は同一。§KNOWN_GAPS に記録）
 7. values/{colors,strings,styles}.xml、layout/、drawable/、xml/、mipmap-anydpi-v26/ を出力
    ids.xml / public.xml は出力しない（AAPT2 が自動生成するため）

【実行】
  python3 scripts/03_convert_res.py <apktool出力dir> <出力先res dir>
"""
import os
import re
import shutil
import sys

SKIP_VALUES = {"ids.xml", "public.xml"}


def norm_dim(m):
    """'30.0dip' -> '30dp', '11.5sp' -> '11.5sp' (維持)"""
    num, unit = m.group(1), m.group(2)
    if num.endswith(".0"):
        return num[:-2] + ("dp" if unit == "dip" else unit)
    return num + ("dp" if unit == "dip" else unit)


DIM_RE = re.compile(r'(-?\d+(?:\.\d+)?)(dip|sp)\b')


def convert_text(s):
    s = DIM_RE.sub(norm_dim, s)
    s = s.replace('"fill_parent"', '"match_parent"')
    s = s.replace('"wrap_parent"', '"wrap_content"')
    # shape/gradient の angle は整数属性
    s = re.sub(r'android:angle="(-?\d+)\.0+"', r'android:angle="\1"', s)
    return s


GRADIENT_FILE_RE = re.compile(r'android:(fillColor|strokeColor)="@drawable/\$([A-Za-z0-9_]+?)__(\d+)"')


def load_gradient(src_drawable_dir, base, idx):
    """$base__idx.xml を読んで <gradient .../> 要素を返す（angle正規化・不要属性除去済み）"""
    p = os.path.join(src_drawable_dir, "$%s__%s.xml" % (base, idx))
    if not os.path.exists(p):
        return None
    txt = open(p, encoding="utf-8").read()
    m = re.search(r"<gradient\b[^>]*/>", txt, re.S)
    if not m:
        return None
    g = m.group(0)
    # 名前空間宣言は <aapt:attr> 内では不要
    g = re.sub(r'\s*xmlns:[a-z]+="[^"]*"', "", g)
    g = convert_text(g)
    # angle=0 かつ 始点終点が明示されている場合は angle を落とす（整数属性の制約回避）
    if re.search(r'android:angle="0"', g) and "android:endX=" in g:
        g = re.sub(r'\s*android:angle="0"', "", g)
    return g


def convert_vector_with_inline_gradients(txt, src_drawable_dir):
    """@drawable/$xxx__N 参照を <aapt:attr> インライングラデーションへ戻す"""
    def repl(m):
        attr, base, idx = m.group(1), m.group(2), m.group(3)
        g = load_gradient(src_drawable_dir, base, idx)
        if g is None:
            return m.group(0)
        # 置換先: 属性を削除し、path 要素内に aapt:attr を入れる必要があるので
        # ここでは「マーカー」を返して後段で処理する
        return '@@INLINE:%s:%s@@' % (attr, g.replace("@@", "@\u0040@"))

    if "@drawable/$" not in txt:
        return txt

    # <path ... /> を1要素ずつ処理する
    def fix_path(pm):
        tag = pm.group(0)
        if "@drawable/$" not in tag:
            return tag
        attrs = []
        inlines = []
        def attr_repl(am):
            attr, base, idx = am.group(1), am.group(2), am.group(3)
            g = load_gradient(src_drawable_dir, base, idx)
            if g is None:
                return am.group(0)
            inlines.append((attr, g))
            return ""
        body = GRADIENT_FILE_RE.sub(attr_repl, tag)
        if not inlines:
            return tag
        # 自己終端タグを開きタグに変換
        body = re.sub(r"\s*/>$", ">", body.rstrip())
        body = re.sub(r"\s+$", "", body)
        inner = "".join(
            '<aapt:attr name="android:%s">%s</aapt:attr>' % (a, g) for a, g in inlines
        )
        return body + inner + "</path>"

    txt = re.sub(r"<path\b[^>]*/>", fix_path, txt, flags=re.S)
    # aapt 名前空間を root に追加
    if "xmlns:aapt=" not in txt:
        txt = txt.replace("<vector ", '<vector xmlns:aapt="http://schemas.android.com/aapt" ', 1)
    return txt


def main():
    if len(sys.argv) != 3:
        print(__doc__)
        return 2
    src = sys.argv[1]
    dst = sys.argv[2]
    src_res = os.path.join(src, "res")
    if not os.path.isdir(src_res):
        print("[x] res が見つかりません: %s" % src_res)
        return 1
    if os.path.exists(dst):
        print("[!] 出力先が既に存在します（削除せず上書きコピーします）: %s" % dst)
    os.makedirs(dst, exist_ok=True)

    src_drawable = os.path.join(src_res, "drawable")
    stats = {"values": 0, "layout": 0, "drawable": 0, "xml": 0, "mipmap": 0, "skipped": 0, "inlined": 0}

    # --- values ---
    vdir = os.path.join(src_res, "values")
    if os.path.isdir(vdir):
        os.makedirs(os.path.join(dst, "values"), exist_ok=True)
        for fn in sorted(os.listdir(vdir)):
            if not fn.endswith(".xml"):
                continue
            if fn in SKIP_VALUES:
                stats["skipped"] += 1
                print("  [skip] values/%s (AAPT2 が自動生成するため不要)" % fn)
                continue
            txt = open(os.path.join(vdir, fn), encoding="utf-8").read()
            txt = convert_text(txt)
            open(os.path.join(dst, "values", fn), "w", encoding="utf-8").write(txt)
            stats["values"] += 1

    # --- layout ---
    for d in ("layout", "layout-land", "xml"):
        sd = os.path.join(src_res, d)
        if not os.path.isdir(sd):
            continue
        os.makedirs(os.path.join(dst, d), exist_ok=True)
        for fn in sorted(os.listdir(sd)):
            if not fn.endswith(".xml"):
                continue
            txt = open(os.path.join(sd, fn), encoding="utf-8").read()
            txt = convert_text(txt)
            if d.startswith("layout"):
                txt = re.sub(r'"@id/', '"@+id/', txt)
                stats["layout"] += 1
            else:
                stats["xml"] += 1
            open(os.path.join(dst, d, fn), "w", encoding="utf-8").write(txt)

    # --- drawable ---
    if os.path.isdir(src_drawable):
        os.makedirs(os.path.join(dst, "drawable"), exist_ok=True)
        for fn in sorted(os.listdir(src_drawable)):
            if not fn.endswith(".xml"):
                continue
            if fn.startswith("$"):
                stats["skipped"] += 1
                continue  # インライン展開済みなので単体ファイルは不要
            txt = open(os.path.join(src_drawable, fn), encoding="utf-8").read()
            txt = convert_text(txt)
            if "@drawable/$" in txt:
                before = txt
                txt = convert_vector_with_inline_gradients(txt, src_drawable)
                if "@@INLINE" in txt:
                    print("  [warn] %s に未処理のインラインマーカーが残った" % fn)
                if txt != before:
                    stats["inlined"] += 1
                    print("  [inline] drawable/%s のグラデーションをインライン化" % fn)
            open(os.path.join(dst, "drawable", fn), "w", encoding="utf-8").write(txt)
            stats["drawable"] += 1

    # --- mipmap-anydpi(-v21) → mipmap-anydpi-v26 ---
    for d in sorted(os.listdir(src_res)):
        if not d.startswith("mipmap"):
            continue
        sd = os.path.join(src_res, d)
        if not os.path.isdir(sd):
            continue
        # adaptive-icon は API 26+。元プロジェクトは mipmap-anydpi-v26 だったと推定。
        out_d = "mipmap-anydpi-v26" if "anydpi" in d else d
        os.makedirs(os.path.join(dst, out_d), exist_ok=True)
        for fn in sorted(os.listdir(sd)):
            if not fn.endswith(".xml"):
                continue
            txt = convert_text(open(os.path.join(sd, fn), encoding="utf-8").read())
            open(os.path.join(dst, out_d, fn), "w", encoding="utf-8").write(txt)
            stats["mipmap"] += 1
        print("  [mipmap] %s -> %s" % (d, out_d))

    print("--- 変換結果 ---")
    for k, v in stats.items():
        print("  %-10s %d" % (k, v))
    return 0


if __name__ == "__main__":
    sys.exit(main())
