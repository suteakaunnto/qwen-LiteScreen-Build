#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
27_compare_rebuilt_smali.py — [再構成新規] Phase D 検証プログラム（v2）

【目的】
  Gradle で実際にビルドした APK（再構築 APK）を apktool で smali に戻し、
  元 APK の smali と **アプリ側クラス (jp/litescreen/**)** を機械比較する。
  「再構築 APK を元 APK と同一視しない」ための差分の可視化が目的で、
  一致すべきもの（クラス構成・メンバ宣言・文字列定数・数値定数・MAGIC配列）と、
  違って当然のもの（Kotlin バージョン由来の @Metadata mv / 合成ラムダの命名 /
  レジスタ割当 / .line）を分けて報告する。

【v2 で追加した正規化】
  * 合成ラムダの命名差を吸収する:
      - `Foo$lambda$7(...)` / `Foo$lambda$17$lambda$16(...)` → `Foo$lambda$*(...)`
      - `$r8$lambda$<hash>(...)`                             → `$r8$lambda$*(...)`
      - `Foo$$ExternalSyntheticLambda3` クラス群は **番号を無視して形状
        (implements + field + method) のマルチセット** として比較する
    （Kotlin 2.0.x は「クラス内連番」、2.1+ は「関数内連番」で名前を付けるため、
      番号そのものは比較しても意味がない。D8 が付ける $r8$lambda$ のハッシュも同様）
  * 定数は **メソッド単位** で帰属させて比較する（クラス全体の合計だと
    「どの関数の差か」が分からなくなるため）
  * @Metadata の mv は改行を潰して 1 行で表示

【実行】 python3 scripts/27_compare_rebuilt_smali.py <sender|receiver|both>
"""
import os
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEC = ROOT / "recovery" / "decompiled"
WORK = ROOT / "out" / "phase-d"
PROJ = ROOT / "LiteScreen-Recovered"
EVID = ROOT / "recovery" / "evidence"

APP_PREFIX = "jp/litescreen"

RE_CLASS = re.compile(r"^\.class\s+(.*)$")
RE_SUPER = re.compile(r"^\.super\s+(\S+)")
RE_IMPL = re.compile(r"^\.implements\s+(\S+)")
RE_SOURCE = re.compile(r"^\.source\s+\"(.*)\"")
RE_FIELD = re.compile(r"^\.field\s+(.*)$")
RE_METHOD = re.compile(r"^\.method\s+(.*)$")
RE_END_METHOD = re.compile(r"^\.end method")
RE_CONST_STR = re.compile(r"const-string(?:/jumbo)?\s+\S+,\s*(\"(?:[^\"\\]|\\.)*\")")
RE_CONST_NUM = re.compile(
    r"^\s*(const(?:/4|/16|/high16)?|const-wide(?:/16|/32|/high16)?)\s+\S+,\s*(-?(?:0x[0-9a-fA-F]+|\d+))"
)
RE_ARRAY_DATA = re.compile(r"^\.array-data\s+(\d+)")
RE_MV = re.compile(r"mv\s*=\s*\{([^}]*)\}", re.S)

# 合成ラムダ名の正規化
RE_LAMBDA_FN = re.compile(r"\$lambda\$\d+")
RE_R8_LAMBDA = re.compile(r"\$r8\$lambda\$[A-Za-z0-9_\-]+")
RE_EXT_LAMBDA_CLS = re.compile(r"^(?P<base>.*)\$\$ExternalSyntheticLambda\d+$")


def norm_method(sig: str) -> str:
    s = RE_R8_LAMBDA.sub("$r8$lambda$*", sig)
    s = RE_LAMBDA_FN.sub("$lambda$*", s)
    return s


def norm_class(name: str) -> str:
    return RE_EXT_LAMBDA_CLS.sub(lambda m: m.group("base") + "$$ExternalSyntheticLambda*", name)


def find_smali_roots(base: Path):
    return sorted(p for p in base.iterdir() if p.is_dir() and p.name.startswith("smali"))


def collect_classes(base: Path):
    out = {}
    for root in find_smali_roots(base):
        app = root / APP_PREFIX
        if not app.exists():
            continue
        for p in app.rglob("*.smali"):
            rel = p.relative_to(root).as_posix()
            out[rel[: -len(".smali")]] = p
    return out


def parse_smali(path: Path):
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    d = {
        "class": next((RE_CLASS.match(l).group(1).strip() for l in lines if RE_CLASS.match(l)), ""),
        "super": next((RE_SUPER.match(l).group(1) for l in lines if RE_SUPER.match(l)), ""),
        "implements": sorted(RE_IMPL.match(l).group(1) for l in lines if RE_IMPL.match(l)),
        "source": next((RE_SOURCE.match(l).group(1) for l in lines if RE_SOURCE.match(l)), ""),
        "fields": [RE_FIELD.match(l).group(1).strip() for l in lines if RE_FIELD.match(l)],
        "methods_raw": [],
        "methods": Counter(),          # 正規化名 -> 個数
        "per_method_strings": {},      # 正規化名 -> Counter(const-string)
        "per_method_numbers": {},      # 正規化名   -> Counter(数値)
        "arrays": [],
        "mv": "",
    }
    cur = None
    cur_s = Counter()
    cur_n = Counter()
    for l in lines:
        m = RE_METHOD.match(l)
        if m:
            cur = m.group(1).strip()
            cur_s, cur_n = Counter(), Counter()
            continue
        if RE_END_METHOD.match(l) and cur is not None:
            key = norm_method(cur)
            d["methods_raw"].append(cur)
            d["methods"][key] += 1
            d["per_method_strings"][key] = d["per_method_strings"].get(key, Counter()) + cur_s
            d["per_method_numbers"][key] = d["per_method_numbers"].get(key, Counter()) + cur_n
            cur = None
            continue
        if cur is None:
            continue
        ms = RE_CONST_STR.search(l)
        if ms:
            cur_s[ms.group(1)] += 1
        mn = RE_CONST_NUM.match(l)
        if mn:
            cur_n[mn.group(2).lower()] += 1
    # .array-data
    i = 0
    while i < len(lines):
        m = RE_ARRAY_DATA.match(lines[i])
        if m:
            vals = []
            i += 1
            while i < len(lines) and not lines[i].startswith(".end array-data"):
                vals.append(lines[i].strip())
                i += 1
            d["arrays"].append((m.group(1), tuple(vals)))
        i += 1
    mm = RE_MV.search("\n".join(lines))
    if mm:
        d["mv"] = re.sub(r"\s+", " ", mm.group(1)).strip()
    return d


def ensure_rebuilt(module: str) -> Path:
    # PHASE_D_VARIANT   : 出力ディレクトリのサフィックス（例 "-k2021"）
    # PHASE_D_APK_DIR   : 再構築 APK を置くディレクトリ（未指定なら build/outputs/apk/debug）
    variant = os.environ.get("PHASE_D_VARIANT", "")
    apk_dir = os.environ.get("PHASE_D_APK_DIR")
    dst = WORK / f"{module}-rebuilt{variant}-apktool"
    apk = (Path(apk_dir) / f"{module}-debug.apk" if apk_dir
           else PROJ / module / "build" / "outputs" / "apk" / "debug" / f"{module}-debug.apk")
    if dst.exists() and (dst / "AndroidManifest.xml").exists():
        return dst
    if not apk.exists():
        raise SystemExit(f"ERROR: rebuilt APK not found: {apk}")
    dst.parent.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, JAVA_OPTS="-Xmx384m -XX:MaxMetaspaceSize=192m")
    subprocess.run(["apktool", "d", "-f", "-o", str(dst), str(apk)], check=True, env=env,
                   stdout=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    return dst


def fmt_counter_delta(a: Counter, b: Counter, indent="      ", limit=30):
    only_a, only_b = a - b, b - a
    out = []
    if only_a:
        out.append(f"{indent}元だけ ({sum(only_a.values())} 件):")
        for k, v in list(only_a.items())[:limit]:
            out.append(f"{indent}  - {k}  x{v}")
    if only_b:
        out.append(f"{indent}再構築だけ ({sum(only_b.values())} 件):")
        for k, v in list(only_b.items())[:limit]:
            out.append(f"{indent}  + {k}  x{v}")
    return out


def compare_module(module: str):
    o_root = DEC / f"{module}-v1.0.11-apktool"
    if not o_root.exists():
        raise SystemExit(f"ERROR: {o_root} not found")
    n_root = ensure_rebuilt(module)
    o_cls, n_cls = collect_classes(o_root), collect_classes(n_root)

    L = []
    W = L.append
    W("=" * 78)
    W(f" モジュール: {module}")
    W(f"   元 APK smali     : {o_root}")
    W(f"   再構築 APK smali : {n_root}")
    W("=" * 78)
    W("")

    # ---- 1. クラス一覧 ----
    W("### 1. クラス一覧（jp/litescreen 以下・DEX 分割位置は無視）")
    W(f"   元 APK     : {len(o_cls)} クラス")
    W(f"   再構築 APK : {len(n_cls)} クラス")
    only_o = sorted(set(o_cls) - set(n_cls))
    only_n = sorted(set(n_cls) - set(o_cls))
    for c in only_o:
        W(f"   - 元だけ: {c}")
    for c in only_n:
        W(f"   + 再構築だけ: {c}")
    if not only_o and not only_n:
        W("   → クラス構成は完全一致（不足 0 / 余分 0）")
    W("")

    # ---- 2. 合成ラムダクラスは形状で比較 ----
    def shape_of(info):
        return (tuple(info["implements"]),
                tuple(sorted(info["fields"])),
                tuple(sorted(info["methods"].elements())))

    o_ext = {c: parse_smali(p) for c, p in o_cls.items() if RE_EXT_LAMBDA_CLS.match(c)}
    n_ext = {c: parse_smali(p) for c, p in n_cls.items() if RE_EXT_LAMBDA_CLS.match(c)}
    W("### 2. 合成ラムダクラス（D8 生成 $$ExternalSyntheticLambdaN）の形状比較")
    W(f"   元 APK     : {len(o_ext)} 個")
    W(f"   再構築 APK : {len(n_ext)} 個")
    so = Counter(shape_of(v) for v in o_ext.values())
    sn = Counter(shape_of(v) for v in n_ext.values())
    if so == sn:
        W("   → 番号を除いた形状（implements / field / method）は完全一致")
        W("     （番号の振り方だけが違う: 元=クラス内連番, 再構築=D8 の生成順）")
    else:
        W("   [DIFF] 形状が一致しないものがある:")
        for k in (so - sn):
            W(f"     - 元だけ: {k}")
        for k in (sn - so):
            W(f"     + 再構築だけ: {k}")
    W("")

    # ---- 3. 通常クラスの詳細比較 ----
    W("### 3. クラスごとの詳細比較（合成ラムダクラスは §2 で扱うため除外）")
    W("   比較対象: .class/.super/.implements/.source/.field/.method(正規化名)/")
    W("             メソッド別 const-string / メソッド別 数値定数 / .array-data / @Metadata mv")
    W("")
    common = sorted((set(o_cls) & set(n_cls)) - set(o_ext) - set(n_ext))
    identical, diff_list = 0, []
    for c in common:
        a, b = parse_smali(o_cls[c]), parse_smali(n_cls[c])
        d = []
        if a["class"] != b["class"]:
            d.append(f"   .class     : 元 `{a['class']}` → 再構築 `{b['class']}`")
        if a["super"] != b["super"]:
            d.append(f"   .super     : 元 {a['super']} → 再構築 {b['super']}")
        if a["implements"] != b["implements"]:
            d.append(f"   .implements: 元 {a['implements']} → 再構築 {b['implements']}")
        if a["source"] != b["source"]:
            d.append(f"   .source    : 元 {a['source']} → 再構築 {b['source']}")
        if Counter(a["fields"]) != Counter(b["fields"]):
            d.append("   .field 差分:")
            d += fmt_counter_delta(Counter(a["fields"]), Counter(b["fields"]))
        if a["methods"] != b["methods"]:
            d.append("   .method 差分（ラムダ名は正規化済み）:")
            d += fmt_counter_delta(a["methods"], b["methods"], indent="     ")
        for mk in sorted(set(a["per_method_strings"]) | set(b["per_method_strings"])):
            ca, cb = a["per_method_strings"].get(mk, Counter()), b["per_method_strings"].get(mk, Counter())
            if ca != cb:
                d.append(f"   const-string 差分 in `{mk}`:")
                d += fmt_counter_delta(ca, cb)
        for mk in sorted(set(a["per_method_numbers"]) | set(b["per_method_numbers"])):
            ca, cb = a["per_method_numbers"].get(mk, Counter()), b["per_method_numbers"].get(mk, Counter())
            if ca != cb:
                d.append(f"   数値定数 差分 in `{mk}`:")
                d += fmt_counter_delta(ca, cb)
        if a["arrays"] != b["arrays"]:
            d.append("   .array-data 差分:")
            d.append(f"     元     : {a['arrays']}")
            d.append(f"     再構築 : {b['arrays']}")
        if a["mv"] != b["mv"]:
            d.append(f"   @Metadata mv : 元 {{{a['mv']}}} → 再構築 {{{b['mv']}}}"
                     "   ← Kotlin コンパイラのバージョン差（想定内）")
        if d:
            diff_list.append((c, d))
        else:
            identical += 1
    for c, d in diff_list:
        W(f"   [DIFF] {c}")
        L.extend(d)
        W("")
    if not diff_list:
        W("   （すべて完全一致）")
        W("")

    # ---- 4. サマリ ----
    W("### 4. サマリ")
    W(f"   元 APK のクラス数            : {len(o_cls)}")
    W(f"   再構築 APK のクラス数        : {len(n_cls)}")
    W(f"   クラス名の不足 / 余分        : {len(only_o)} / {len(only_n)}")
    W(f"   合成ラムダクラス（形状比較） : 元 {len(o_ext)} / 再構築 {len(n_ext)}"
        f" → {'形状一致' if so == sn else '形状差あり'}")
    W(f"   通常クラス完全一致           : {identical} / {len(common)}")
    W(f"   通常クラスに差分             : {len(diff_list)}")
    mv_only = sum(1 for c, d in diff_list
                  if all(x.startswith("   @Metadata mv") for x in d))
    W(f"     うち @Metadata mv のみ     : {mv_only}")
    W("")
    return {"classes_o": len(o_cls), "classes_n": len(n_cls), "only_o": len(only_o),
            "only_n": len(only_n), "ext_o": len(o_ext), "ext_n": len(n_ext),
            "ext_shape_ok": so == sn, "identical": identical, "common": len(common),
            "diff": len(diff_list), "mv_only": mv_only, "text": "\n".join(L)}


def main(argv):
    targets = argv[1] if len(argv) > 1 else "both"
    mods = ["sender", "receiver"] if targets == "both" else [targets]
    EVID.mkdir(parents=True, exist_ok=True)
    for m in mods:
        st = compare_module(m)
        out = EVID / f"PHASE_D_smali_compare_{m}{os.environ.get('PHASE_D_VARIANT', '')}.txt"
        head = "\n".join([
            "#" * 78,
            "# Phase D: 再構築 APK ⇔ 元 APK  smali レベル比較レポート",
            f"# module: {m}",
            "# 生成: scripts/27_compare_rebuilt_smali.py",
            "#" * 78, "",
        ])
        out.write_text(head + st["text"], encoding="utf-8")
        print(f"written: {out}")
        print(f"  classes orig={st['classes_o']} rebuilt={st['classes_n']} "
              f"(only_o={st['only_o']} only_n={st['only_n']})")
        print(f"  ext-lambda orig={st['ext_o']} rebuilt={st['ext_n']} shape_ok={st['ext_shape_ok']}")
        print(f"  normal classes identical={st['identical']}/{st['common']} diff={st['diff']} "
              f"(mv_only={st['mv_only']})")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
