/*
 * DiffTest.java — [再構成新規] 復旧作業で作成した検証プログラム
 *
 * 元 APK の classes2.dex から d8 で .class に戻した「オリジナル実装」と、
 * 復旧作業で書き起こした Kotlin をコンパイルした「再構成実装」を、
 * リフレクション経由で同じ入力に通し、出力バイト列が完全一致するかを検査する。
 *
 * 両者は同じ FQCN (jp.litescreen.protocol.Framing / Proto) を持つため、
 * 別々の ClassLoader に読み込ませて比較する。
 *
 * 検証項目:
 *   1. Proto の全公開定数（MAGIC / メッセージID / ポート / フラグ / 上限値）
 *   2. Framing.writeHeader  … type x payloadLength の網羅（境界値を含む）
 *   3. Framing.intBytes     … 0, ±1, 255/256, 65535/65536, MAX_VALUE, MIN_VALUE, 24bit境界
 *   4. Framing.longBytes    … 同上の long 版
 *   5. Framing.writeInt/readInt, writeLong/readLong の往復
 *   6. Framing.writeMessage + readHeader/readPayload の往復（全メッセージ種別）
 *   7. Framing.readHeader の異常系（magic不一致 / payloadLength超過 / ストリーム末端）
 *      → 例外クラス名とメッセージ文字列まで一致させる
 *   8. 実際に APK から観測されたペイロード構造（HELLO/VIDEO_CONFIG/CODEC_CONFIG/
 *      VIDEO/PING/STATS/PROPOSE/PROPOSE_ACK）を組み立てたときのバイト列一致
 */
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class DiffTest {

    static int checks = 0;
    static int failures = 0;
    static final List<String> failureMsgs = new ArrayList<>();

    public static void main(String[] args) throws Exception {
        String origJar = System.getProperty("orig.jar");
        String newJar  = System.getProperty("new.jar");
        if (origJar == null || newJar == null) {
            System.err.println("usage: java -Dorig.jar=... -Dnew.jar=... DiffTest");
            System.exit(2);
        }
        ClassLoader origCl = newLoader(origJar);
        ClassLoader newCl  = newLoader(newJar);

        Object origFraming = singleton(origCl, "jp.litescreen.protocol.Framing");
        Object newFraming  = singleton(newCl,  "jp.litescreen.protocol.Framing");
        Object origProto   = singleton(origCl, "jp.litescreen.protocol.Proto");
        Object newProto    = singleton(newCl,  "jp.litescreen.protocol.Proto");

        System.out.println("=== 1. Proto 定数の一致 ===");
        compareProtoConstants(origProto, newProto);

        System.out.println("=== 2. writeHeader の網羅比較 ===");
        compareWriteHeader(origFraming, newFraming);

        System.out.println("=== 3. intBytes の一致 ===");
        int[] ints = {0, 1, -1, 255, 256, 65535, 65536, 8388607, 8388608, 16777215, 16777216,
                      47820, 47821, Integer.MAX_VALUE, Integer.MIN_VALUE, -2147414011, 1280, 1920,
                      1088, 1728, 1080, 30, 60, 2500, 16000, 20000, 2000, 1500};
        for (int v : ints) {
            byte[] a = (byte[]) call(origFraming, "intBytes", new Class[]{int.class}, v);
            byte[] b = (byte[]) call(newFraming,  "intBytes", new Class[]{int.class}, v);
            eq("intBytes(" + v + ")", a, b);
        }

        System.out.println("=== 4. longBytes の一致 ===");
        long[] longs = {0L, 1L, -1L, 255L, 256L, 1000L, 1700000000000L,
                        Long.MAX_VALUE, Long.MIN_VALUE, 0xFFFFFFFFL, 0x100000000L};
        for (long v : longs) {
            byte[] a = (byte[]) call(origFraming, "longBytes", new Class[]{long.class}, v);
            byte[] b = (byte[]) call(newFraming,  "longBytes", new Class[]{long.class}, v);
            eq("longBytes(" + v + ")", a, b);
        }

        System.out.println("=== 5. readInt / readLong の一致 ===");
        for (int v : ints) {
            byte[] buf = new byte[8];
            // 元実装の intBytes で作ったバッファを両方の readInt に食わせる
            byte[] ib = (byte[]) call(origFraming, "intBytes", new Class[]{int.class}, v);
            System.arraycopy(ib, 0, buf, 0, 4);
            System.arraycopy(ib, 0, buf, 4, 4);
            int ra = (Integer) call(origFraming, "readInt", new Class[]{byte[].class, int.class}, buf, 0);
            int rb = (Integer) call(newFraming,  "readInt", new Class[]{byte[].class, int.class}, buf, 0);
            eq("readInt(buf from " + v + ")", ra, rb);
            eq("readInt roundtrip(" + v + ")", v, rb);
        }
        for (long v : longs) {
            byte[] lb = (byte[]) call(origFraming, "longBytes", new Class[]{long.class}, v);
            long ra = (Long) call(origFraming, "readLong", new Class[]{byte[].class, int.class}, lb, 0);
            long rb = (Long) call(newFraming,  "readLong", new Class[]{byte[].class, int.class}, lb, 0);
            eq("readLong(buf from " + v + ")", ra, rb);
            eq("readLong roundtrip(" + v + ")", v, rb);
        }

        System.out.println("=== 6. writeMessage + readHeader/readPayload 往復（全メッセージ種別） ===");
        int[][] payloads = {
            {1, 16}, {2, 16}, {3, 0}, {3, 4 + 4 + 8}, {4, 16}, {4, 16 + 4096},
            {5, 0}, {6, 8}, {7, 8}, {8, 24}, {8, 8}, {9, 0}, {10, 0},
            {11, 1}, {11, 4096}, {12, 12}, {13, 12}, {14, 24}, {14, 16}, {14, 24 + 300},
            {255, 1}, {0, 0},
        };
        for (int[] tp : payloads) {
            int type = tp[0], len = tp[1];
            byte[] payload = new byte[len];
            for (int i = 0; i < len; i++) payload[i] = (byte) ((i * 31 + type * 7) & 0xFF);

            byte[] wireA = writeMessage(origFraming, type, payload);
            byte[] wireB = writeMessage(newFraming,  type, payload);
            eq("writeMessage(type=" + type + ", len=" + len + ") 線上バイト列", wireA, wireB);

            // 両実装で読み戻し
            int[] ra = readHeader(origFraming, wireA);
            int[] rb = readHeader(newFraming,  wireA);
            eq("readHeader type (type=" + type + ")", ra[0], rb[0]);
            eq("readHeader len  (type=" + type + ")", ra[1], rb[1]);
            eq("readHeader type == 期待値", type, rb[0]);
            eq("readHeader len == 期待値", len, rb[1]);
            byte[] pa = readPayload(origFraming, wireA, ra[1]);
            byte[] pb = readPayload(newFraming,  wireA, rb[1]);
            eq("readPayload (type=" + type + ")", pa, pb);
            eq("readPayload == 元payload", payload, pb);
        }

        System.out.println("=== 7. readHeader 異常系（例外クラス名・メッセージ文字列） ===");
        // 7-a magic 不一致
        for (int bad = 0; bad < 3; bad++) {
            byte[] h = {0x4C, 0x53, 0x43, 0x01, 1, 0, 0, 0};
            h[bad] = (byte) 0x00;
            compareThrow("magic mismatch (byte" + bad + "破壊)", origFraming, newFraming, h);
        }
        // 7-b payloadLength 超過 (MAX_PAYLOAD+1 = 8388609)
        compareThrow("payload too large", origFraming, newFraming,
                     new byte[]{0x4C, 0x53, 0x43, 0x01, 4, (byte) 0x80, 0x00, 0x01});
        // 7-c ストリーム末端
        compareThrowShortStream("unexpected end of stream", origFraming, newFraming,
                                new byte[]{0x4C, 0x53});

        System.out.println("=== 8. 実APKで観測されたペイロード構造の再現 ===");
        // HELLO（受信側が送る形）: version=1, audioSupport=1, 0, udpPort=47821
        byte[] helloRecv = cat(intB(origFraming, 1), intB(origFraming, 1),
                               intB(origFraming, 0), intB(origFraming, 47821));
        eq("HELLO(受信側) 16バイト", 16, helloRecv.length);
        eq("HELLO(受信側) 新旧一致", helloRecv,
           cat(intB(newFraming, 1), intB(newFraming, 1), intB(newFraming, 0), intB(newFraming, 47821)));
        // HELLO のオフセット読み
        eq("HELLO off0 version (orig)", 1, (Integer) call(origFraming, "readInt", new Class[]{byte[].class, int.class}, helloRecv, 0));
        eq("HELLO off0 version (new)",  1, (Integer) call(newFraming,  "readInt", new Class[]{byte[].class, int.class}, helloRecv, 0));
        // HELLO のフィールド順: off0=version, off4=audioSupport, off8=予約(0), off12=udpPort
        // （受信側 ReceiverServer が intBytes(1), intBytes(1), intBytes(0), intBytes(DEFAULT_UDP_PORT)
        //   の順で連結していることを APK から確認済み。送信側 SenderClient は off0 と off4 を読む）
        eq("HELLO off0 version",      1,     (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, helloRecv, 0));
        eq("HELLO off4 audioSupport", 1,     (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, helloRecv, 4));
        eq("HELLO off8 reserved",     0,     (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, helloRecv, 8));
        eq("HELLO off12 udpPort",     47821, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, helloRecv, 12));
        // 送信側が返す HELLO は off12 が 0
        byte[] helloSend = cat(intB(newFraming, 1), intB(newFraming, 1), intB(newFraming, 0), intB(newFraming, 0));
        eq("HELLO(送信側) off12 = 0", 0, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, helloSend, 12));

        // VIDEO_CONFIG: 1280x800@30fps 2500kbps
        byte[] vc = cat(intB(origFraming, 1280), intB(origFraming, 800),
                        intB(origFraming, 30), intB(origFraming, 2500));
        eq("VIDEO_CONFIG 新旧一致", vc,
           cat(intB(newFraming, 1280), intB(newFraming, 800), intB(newFraming, 30), intB(newFraming, 2500)));
        eq("VIDEO_CONFIG off4 height", 800, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, vc, 4));

        // STATS v2 (24B): fps=30, kbps=2500, lastSendMs=999, dropped=3, pending=1, decoded=1234
        byte[] st = cat(intB(origFraming, 30), intB(origFraming, 2500), intB(origFraming, 999),
                        intB(origFraming, 3), intB(origFraming, 1), intB(origFraming, 1234));
        eq("STATS v2 長さ24", 24, st.length);
        eq("STATS 新旧一致", st,
           cat(intB(newFraming, 30), intB(newFraming, 2500), intB(newFraming, 999),
               intB(newFraming, 3), intB(newFraming, 1), intB(newFraming, 1234)));
        eq("STATS off12 dropped", 3, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, st, 12));
        eq("STATS off16 pending", 1, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, st, 16));

        // PROPOSE_ACK v2: ok=1, 1280, 800, 30, profile=8(High), level=8192(4.0)
        byte[] pa = cat(intB(origFraming, 1), intB(origFraming, 1280), intB(origFraming, 800),
                        intB(origFraming, 30), intB(origFraming, 8), intB(origFraming, 8192),
                        "対応可能".getBytes("UTF-8"));
        byte[] pb2 = cat(intB(newFraming, 1), intB(newFraming, 1280), intB(newFraming, 800),
                         intB(newFraming, 30), intB(newFraming, 8), intB(newFraming, 8192),
                         "対応可能".getBytes("UTF-8"));
        eq("PROPOSE_ACK 新旧一致", pa, pb2);
        eq("PROPOSE_ACK off16 profile", 8, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, pa, 16));
        eq("PROPOSE_ACK off20 level", 8192, (Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, pa, 20));

        // VIDEO: pts(long) + flags(int) + sendMs(int) + annexB
        byte[] vid = cat(longB(origFraming, 123456789L), intB(origFraming, 1), intB(origFraming, 999),
                         new byte[]{0, 0, 0, 1, 0x67, 0x42, 0x00, 0x1e});
        byte[] vid2 = cat(longB(newFraming, 123456789L), intB(newFraming, 1), intB(newFraming, 999),
                          new byte[]{0, 0, 0, 1, 0x67, 0x42, 0x00, 0x1e});
        eq("VIDEO ヘッダ部 新旧一致", vid, vid2);
        eq("VIDEO off0 ptsUs", 123456789L, (Long) call(newFraming, "readLong", new Class[]{byte[].class, int.class}, vid, 0));
        eq("VIDEO off8 flags & FLAG_KEY_FRAME", true, ((Integer) call(newFraming, "readInt", new Class[]{byte[].class, int.class}, vid, 8) & 1) != 0);

        // CODEC_CONFIG: count=2, {len, sps}, {len, pps}
        byte[] sps = {0x67, 0x42, 0x00, 0x1e, (byte) 0xe9, 0x40, 0x14, 0x07};
        byte[] pps = {0x68, (byte) 0xce, 0x38, (byte) 0x80};
        byte[] cc = cat(intB(origFraming, 2), intB(origFraming, sps.length), sps,
                        intB(origFraming, pps.length), pps);
        byte[] cc2 = cat(intB(newFraming, 2), intB(newFraming, sps.length), sps,
                         intB(newFraming, pps.length), pps);
        eq("CODEC_CONFIG 新旧一致", cc, cc2);

        System.out.println();
        System.out.println("--------------------------------------------------");
        System.out.println("総チェック数 : " + checks);
        System.out.println("不一致       : " + failures);
        if (failures > 0) {
            System.out.println("---- 失敗詳細 (先頭20件) ----");
            for (int i = 0; i < Math.min(20, failureMsgs.size()); i++) System.out.println("  " + failureMsgs.get(i));
            System.exit(1);
        }
        System.out.println("結果: PASS — 再構成 protocol 実装は元APK実装と完全一致");
    }

    // ------------------------------------------------------------------
    static ClassLoader newLoader(String jar) throws Exception {
        // 親は「アプリクラスローダ」にする。kotlin-stdlib はアプリ側の classpath にあるため、
        // platform classloader を親にすると kotlin.text.Charsets が見つからなくなる。
        return new URLClassLoader(new URL[]{Paths.get(jar).toUri().toURL()},
                                  DiffTest.class.getClassLoader());
    }

    static Object singleton(ClassLoader cl, String fqcn) throws Exception {
        Class<?> c = Class.forName(fqcn, true, cl);
        Field f = c.getField("INSTANCE");
        return f.get(null);
    }

    static Object call(Object target, String name, Class<?>[] sig, Object... args) {
        try {
            Method m = target.getClass().getMethod(name, sig);
            m.setAccessible(true);
            return m.invoke(target, args);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e.getCause());
        } catch (Exception e) {
            throw new RuntimeException(name + ": " + e, e);
        }
    }

    static byte[] writeMessage(Object framing, int type, byte[] payload) throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        call(framing, "writeMessage",
             new Class[]{java.io.OutputStream.class, int.class, byte[].class}, bos, type, payload);
        return bos.toByteArray();
    }

    static int[] readHeader(Object framing, byte[] wire) throws Exception {
        Object pair = call(framing, "readHeader", new Class[]{java.io.InputStream.class},
                           new ByteArrayInputStream(wire));
        Integer t = (Integer) call(pair, "component1", new Class[]{});
        Integer l = (Integer) call(pair, "component2", new Class[]{});
        return new int[]{t, l};
    }

    static byte[] readPayload(Object framing, byte[] wire, int len) throws Exception {
        // ヘッダ8バイトを飛ばして読む
        ByteArrayInputStream bis = new ByteArrayInputStream(wire);
        bis.skip(8);
        return (byte[]) call(framing, "readPayload",
                             new Class[]{java.io.InputStream.class, int.class}, bis, len);
    }

    static void compareThrow(String label, Object origF, Object newF, byte[] header) {
        String a = throwSignature(origF, header);
        String b = throwSignature(newF, header);
        eq("readHeader 例外 " + label, a, b);
        System.out.println("    " + label + " -> " + b);
    }

    static void compareThrowShortStream(String label, Object origF, Object newF, byte[] partial) {
        String a = throwSignatureShort(origF, partial);
        String b = throwSignatureShort(newF, partial);
        eq("readHeader 例外 " + label, a, b);
        System.out.println("    " + label + " -> " + b);
    }

    static String throwSignature(Object framing, byte[] header) {
        try {
            call(framing, "readHeader", new Class[]{java.io.InputStream.class},
                 new ByteArrayInputStream(header));
            return "(例外なし)";
        } catch (RuntimeException re) {
            Throwable t = re.getCause() == null ? re : re.getCause();
            return t.getClass().getName() + ": " + t.getMessage();
        }
    }

    static String throwSignatureShort(Object framing, byte[] partial) {
        try {
            call(framing, "readHeader", new Class[]{java.io.InputStream.class},
                 new ByteArrayInputStream(partial));
            return "(例外なし)";
        } catch (RuntimeException re) {
            Throwable t = re.getCause() == null ? re : re.getCause();
            return t.getClass().getName() + ": " + t.getMessage();
        }
    }

    static void compareProtoConstants(Object origProto, Object newProto) throws Exception {
        String[] intNames = {"VERSION", "MSG_HELLO", "MSG_VIDEO_CONFIG", "MSG_CODEC_CONFIG", "MSG_VIDEO",
            "MSG_KEYFRAME_REQUEST", "MSG_PING", "MSG_PONG", "MSG_STATS", "STATS_V2_SIZE", "MSG_BYE",
            "MSG_AUDIO_UNSUPPORTED", "MSG_ERROR", "MSG_INFO", "MAX_TEXT", "MSG_PROPOSE", "MSG_PROPOSE_ACK",
            "PROPOSE_ACK_V2_HEADER", "CODEC_ERROR_UNSUPPORTED", "HEADER_SIZE", "MAX_PAYLOAD",
            "FLAG_KEY_FRAME", "FLAG_CODEC_CONFIG", "DEFAULT_TCP_PORT", "DEFAULT_UDP_PORT"};
        for (String n : intNames) {
            int a = constInt(origProto, n);
            int b = constInt(newProto, n);
            eq("Proto." + n, a, b);
        }
        byte[] ma = (byte[]) call(origProto, "getMAGIC", new Class[]{});
        byte[] mb = (byte[]) call(newProto, "getMAGIC", new Class[]{});
        eq("Proto.MAGIC", ma, mb);
        byte[] pa = (byte[]) call(origProto, "getPROBE", new Class[]{});
        byte[] pb = (byte[]) call(newProto, "getPROBE", new Class[]{});
        eq("Proto.PROBE", pa, pb);
        byte[] aa = (byte[]) call(origProto, "getPROBE_ACK", new Class[]{});
        byte[] ab = (byte[]) call(newProto, "getPROBE_ACK", new Class[]{});
        eq("Proto.PROBE_ACK", aa, ab);
        System.out.println("    MAGIC=" + hex(mb) + " PROBE=" + new String(pb, "US-ASCII")
                           + " PROBE_ACK=" + new String(ab, "US-ASCII"));
    }

    static int constInt(Object proto, String name) throws Exception {
        // Kotlin object の const val は static フィールドとして現れる
        try {
            Field f = proto.getClass().getField(name);
            return f.getInt(null);
        } catch (NoSuchFieldException e) {
            Field f = proto.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.getInt(proto);
        }
    }

    static void compareWriteHeader(Object origF, Object newF) throws Exception {
        int[] types = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 127, 128, 255};
        int[] lens = {0, 1, 255, 256, 65535, 65536, 8388607, 8388608, 16777215};
        for (int t : types) for (int l : lens) {
            ByteArrayOutputStream a = new ByteArrayOutputStream();
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            call(origF, "writeHeader", new Class[]{java.io.OutputStream.class, int.class, int.class}, a, t, l);
            call(newF,  "writeHeader", new Class[]{java.io.OutputStream.class, int.class, int.class}, b, t, l);
            eq("writeHeader(type=" + t + ", len=" + l + ")", a.toByteArray(), b.toByteArray());
            checks++; // 追加で件数カウント（eq内でも数えているので表示用の粒度調整）
        }
        System.out.println("    " + (types.length * lens.length) + " 組合せを比較");
    }

    // --- assertion helpers --------------------------------------------
    static void eq(String label, Object a, Object b) {
        checks++;
        boolean ok = (a == null) ? b == null : a.equals(b);
        if (!ok) { failures++; failureMsgs.add(label + " : orig=" + a + " new=" + b); }
    }

    static void eq(String label, byte[] a, byte[] b) {
        checks++;
        if (!Arrays.equals(a, b)) {
            failures++;
            failureMsgs.add(label + " : orig=" + hex(a) + " new=" + hex(b));
        }
    }

    static byte[] intB(Object framing, int v) {
        return (byte[]) call(framing, "intBytes", new Class[]{int.class}, v);
    }

    static byte[] longB(Object framing, long v) {
        return (byte[]) call(framing, "longBytes", new Class[]{long.class}, v);
    }

    static byte[] cat(byte[]... parts) {
        int n = 0;
        for (byte[] p : parts) n += p.length;
        byte[] out = new byte[n];
        int o = 0;
        for (byte[] p : parts) { System.arraycopy(p, 0, out, o, p.length); o += p.length; }
        return out;
    }

    static String hex(byte[] b) {
        if (b == null) return "null";
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.length() > 64 ? sb.substring(0, 64) + "...(" + b.length + "B)" : sb.toString();
    }
}
