#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
29_smali_ctx.py — [再構成新規] Phase D 調査ヘルパー

元 APK の smali と 再構築 APK の smali から、指定メソッド本体を取り出して
指定パターンの周辺を行番号付きで並べる（差分の意味を目視確認するため）。

使い方:
  python3 scripts/29_smali_ctx.py <sender|receiver> <クラス相対パス> \
      <メソッド部分文字列> [正規表現パターン] [--ctx N] [--full]

例:
  python3 scripts/29_smali_ctx.py sender jp/litescreen/sender/core/SenderClient.smali \
      'sendFrame([BJZ)Z' '0xf4240|0x3e8'
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ORIG_BASE = ROOT / "recovery" / "decompiled"
NEW_BASE = ROOT / "out" / "phase-d"


def find(base_glob: str, rel: str):
    for p in sorted(Path(ROOT).glob(base_glob)):
        for sm in sorted(x for x in p.iterdir() if x.is_dir() and x.name.startswith("smali")):
            f = sm / rel
            if f.exists():
                return f
    return None


def body(path: Path, meth: str):
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    st = None
    out = []
    for l in lines:
        if l.startswith(".method") and meth in l:
            st = l.strip()
            out = [l]
        elif st is not None:
            out.append(l)
            if l.startswith(".end method"):
                return st, [x for x in out if x.strip()]
    return None, []


def main(argv):
    module, rel, meth = argv[1], argv[2], argv[3]
    pat = argv[4] if len(argv) > 4 and not argv[4].startswith("--") else None
    ctx, full = 6, False
    if "--full" in argv:
        full = True
    if "--ctx" in argv:
        ctx = int(argv[argv.index("--ctx") + 1])
    o = find(f"recovery/decompiled/{module}-v1.0.11-apktool", rel)
    n = find(f"out/phase-d/{module}-rebuilt-apktool", rel)
    if not o or not n:
        print(f"ERROR: smali not found (orig={o}, new={n})")
        return 2
    for tag, p in (("元 APK", o), ("再構築 APK", n)):
        sig, b = body(p, meth)
        print("#" * 78)
        print(f"# {tag} : {p}")
        print(f"# method: {sig}   ({len(b)} 有効行)")
        print("#" * 78)
        if full or not pat:
            for x in b:
                print("  " + x)
        else:
            idxs = [i for i, l in enumerate(b) if re.search(pat, l)]
            if not idxs:
                print(f"  (パターン {pat!r} に一致する行なし)")
            shown = set()
            for i in idxs:
                for j in range(max(0, i - ctx), min(len(b), i + ctx + 1)):
                    if j not in shown:
                        shown.add(j)
                        mark = ">>" if j == i else "  "
                        print(f"{mark}{j:5d} {b[j]}")
                print("  ----")
        print()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
