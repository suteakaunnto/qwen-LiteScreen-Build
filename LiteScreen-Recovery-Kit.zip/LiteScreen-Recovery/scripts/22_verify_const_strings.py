#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
22_verify_const_strings.py — smali の const-string と復元 Kotlin の文字列リテラルを自動照合する。

目的:
  復元コードが「ログ文言・UI文言・JSON キー・SharedPreferences キー・タグ名」などの
  文字列定数を元 APK と同一に保持しているかを、目視ではなく機械的に確認する。

判定の難点と対処(重要):
  A) Kotlin の文字列テンプレート ("a=${x}b") は、コンパイル後に
     const-string "a=" / const-string "b" のように **断片へ分割** される。
     → smali 側断片は「復元ソースのリテラル断片の部分文字列か」で照合する。
  B) 引数名 ("msg", "handler") や "getName(...)" などは
     Intrinsics.checkNotNullParameter 等が使う **コンパイラ生成文字列** で、
     ソースには書かれない。
     → smali 上で const-string の直後に Intrinsics 呼び出しが来るものを機械的に除外する。
  C) キャスト失敗メッセージ "null cannot be cast to non-null type ..." も同様に生成物。

判定方法:
  1) 元 APK 側: apktool 出力の app クラス smali から const-string / const-string/jumbo を収集し、
     `.source "Xxx.kt"` により元ファイル単位で束ねる。B/C を「compiler生成」として分離。
  2) 復元側: .kt からコメントを除いた文字列リテラルを収集し、`${...}` で断片分割する。
  3) smali 断片 → 復元断片(部分文字列一致)、復元断片 → smali 断片(部分文字列一致) の双方向で照合。

終了コード: 不足(smali にあって復元に無い、compiler生成を除く) が 0 件なら 0、1 件以上なら 1。

使い方:
  python3 scripts/22_verify_const_strings.py receiver
  python3 scripts/22_verify_const_strings.py sender --verbose
"""
from __future__ import annotations

import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DECOMPILED = ROOT / "recovery" / "decompiled"
PROJECT = ROOT / "LiteScreen-Recovered"

APK_TAG = {
    "receiver": "receiver-v1.0.11-apktool",
    "sender": "sender-v1.0.11-apktool",
}
PKG = {
    "receiver": "jp/litescreen/receiver",
    "sender": "jp/litescreen/sender",
}

CONST_STRING_RE = re.compile(r'^\s*const-string(?:/jumbo)?\s+([vp]\d+),\s*"(.*)"\s*$')
SOURCE_RE = re.compile(r'^\.source\s+"(.*)"\s*$')
INTRINSICS_RE = re.compile(
    r'^\s*invoke-static\s+\{([^}]*)\},\s+Lkotlin/jvm/internal/Intrinsics;->(\w+)')
# キャスト失敗など、ソースに書かれない生成メッセージの接頭辞
GENERATED_PREFIX = (
    "null cannot be cast to non-null type",
    "Parameter specified as non-null is null",
    "Check failed.",
    "Required value was null",
)


def _unescape(s: str, extra: dict[str, str] | None = None) -> str:
    mapping = {"n": "\n", "t": "\t", "r": "\r", "b": "\b", "f": "\f",
               '"': '"', "'": "'", "\\": "\\"}
    if extra:
        mapping.update(extra)
    out: list[str] = []
    i = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c != "\\" or i + 1 >= n:
            out.append(c)
            i += 1
            continue
        nxt = s[i + 1]
        if nxt in mapping:
            out.append(mapping[nxt])
            i += 2
        elif nxt == "u" and i + 6 <= n:
            try:
                out.append(chr(int(s[i + 2:i + 6], 16)))
                i += 6
            except ValueError:
                out.append(c)
                i += 1
        else:
            out.append(nxt)
            i += 2
    return "".join(out)


def unescape_smali(s: str) -> str:
    return _unescape(s)


def unescape_kotlin(s: str) -> str:
    return _unescape(s, {"$": "$"})


def normalize(s: str) -> str:
    """比較用正規化: NFKC + 連続空白の 1 空白化 + 前後除去。"""
    return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", s)).strip()


# ---------------------------------------------------------------- smali 側 ---

def collect_smali(module: str) -> dict[str, dict[str, set[str]]]:
    """{元ファイル名: {"app": {...}, "generated": {...}}} を返す。"""
    base = DECOMPILED / APK_TAG[module]
    per_file: dict[str, dict[str, set[str]]] = {}
    smali_files = [
        p for p in base.rglob("*.smali")
        if PKG[module] in p.as_posix()
        and "ExternalSyntheticLambda" not in p.name
        and not re.match(r"^R(\$|\.smali$)", p.name)
    ]
    for p in sorted(smali_files):
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        src = next((SOURCE_RE.match(l).group(1) for l in lines if SOURCE_RE.match(l)),
                   p.stem + ".kt")
        bucket = per_file.setdefault(src, {"app": set(), "generated": set()})

        for idx, line in enumerate(lines):
            m = CONST_STRING_RE.match(line)
            if not m:
                continue
            reg, raw = m.group(1), unescape_smali(m.group(2))
            if not raw.strip():
                continue
            generated = raw.startswith(GENERATED_PREFIX)
            # 直後 3 行以内に、このレジスタを使う Intrinsics 呼び出しがあれば生成物
            if not generated:
                for j in range(idx + 1, min(idx + 4, len(lines))):
                    im = INTRINSICS_RE.match(lines[j])
                    if im and reg in [r.strip() for r in im.group(1).split(",")]:
                        generated = True
                        break
                    if CONST_STRING_RE.match(lines[j]) or lines[j].strip().startswith("."):
                        break
            bucket["generated" if generated else "app"].add(raw)
    return per_file


# --------------------------------------------------------------- Kotlin 側 ---

def strip_kotlin_comments(text: str) -> str:
    out: list[str] = []
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == '"':
            if text.startswith('"""', i):
                end = text.find('"""', i + 3)
                end = n if end < 0 else end + 3
                out.append(text[i:end])
                i = end
            else:
                j = i + 1
                while j < n:
                    if text[j] == "\\":
                        j += 2
                        continue
                    if text[j] == '"':
                        j += 1
                        break
                    j += 1
                out.append(text[i:j])
                i = j
        elif text.startswith("/*", i):
            depth, j = 1, i + 2
            while j < n and depth:
                if text.startswith("/*", j):
                    depth += 1
                    j += 2
                elif text.startswith("*/", j):
                    depth -= 1
                    j += 2
                else:
                    j += 1
            i = j
        elif text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
        else:
            out.append(c)
            i += 1
    return "".join(out)


LITERAL_RE = re.compile(r'"""(.*?)"""|"((?:[^"\\\n]|\\.)*)"', re.S)
TEMPLATE_SPLIT_RE = re.compile(r"\$\{[^{}]*\}|\$[A-Za-z_][A-Za-z0-9_]*")


def collect_kotlin(module: str) -> dict[str, set[str]]:
    """{ファイル名: リテラル断片の集合}。テンプレートは ${...} で分割する。"""
    base = PROJECT / module / "src" / "main" / "java"
    per_file: dict[str, set[str]] = {}
    for p in sorted(base.rglob("*.kt")):
        text = strip_kotlin_comments(p.read_text(encoding="utf-8", errors="replace"))
        fragments: set[str] = set()
        for m in LITERAL_RE.finditer(text):
            raw = m.group(1) if m.group(1) is not None else unescape_kotlin(m.group(2))
            for part in TEMPLATE_SPLIT_RE.split(raw):
                if part.strip():
                    fragments.add(part)
        per_file[p.name] = fragments
    return per_file


# ------------------------------------------------------------------ 照合 ---

def covered(frag: str, pool_norm: list[str]) -> bool:
    """frag が pool のいずれかの部分文字列(またはその逆)なら True。"""
    f = normalize(frag)
    if not f:
        return True
    for cand in pool_norm:
        if f in cand or cand in f:
            return True
    return False


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] not in APK_TAG:
        print(__doc__)
        return 2
    module = argv[1]
    verbose = "--verbose" in argv

    smali = collect_smali(module)
    kotlin = collect_kotlin(module)
    files = sorted(set(smali) | set(kotlin))

    tot_missing = tot_extra = tot_gen = tot_app = 0
    print(f"対象モジュール : {module}")
    print(f"元 APK 側      : {APK_TAG[module]} (const-string を .source 単位で束ねる)")
    print(f"復元側         : LiteScreen-Recovered/{module}/src/main/java/**/*.kt")
    print("照合方式       : テンプレート断片の部分文字列照合(双方向) / Intrinsics 生成文字列は除外")
    print()
    print(f"{'file':<24} {'smali':>6} {'kt断片':>7} {'不足':>5} {'余分':>5} {' compiler生成':>13}  判定")
    print("-" * 78)

    for f in files:
        app = smali.get(f, {}).get("app", set())
        gen = smali.get(f, {}).get("generated", set())
        kt = kotlin.get(f, set())
        kt_norm = [normalize(x) for x in kt]
        app_norm = [normalize(x) for x in app]

        missing = [s for s in sorted(app) if not covered(s, kt_norm)]
        extra = [s for s in sorted(kt) if not covered(s, app_norm)]

        tot_missing += len(missing)
        tot_extra += len(extra)
        tot_gen += len(gen)
        tot_app += len(app)

        print(f"{f:<24} {len(app):>6} {len(kt):>7} {len(missing):>5} {len(extra):>5} "
              f"{len(gen):>13}  {'OK' if not missing else 'NG'}")
        if missing or verbose:
            for s in missing:
                print(f"    [不足] {s!r}")
        if verbose:
            for s in extra:
                print(f"    [余分] {s!r}")
            for s in sorted(gen):
                print(f"    [compiler生成] {s!r}")

    print("-" * 78)
    print(f"合計: smali 側 app 文字列 {tot_app} / 不足 {tot_missing} / 余分 {tot_extra} "
          f"/ compiler生成(除外) {tot_gen}")
    if tot_missing == 0:
        print(f"\nPASS: {module} の文字列定数は元 APK と一致(不足 0 件)")
        print("      「余分」= 復元側リテラル断片が smali 側に見つからないもの。")
        print("      テンプレート分割差や定数畳み込み由来の可能性があるため参考情報として扱う。")
        return 0
    print(f"\nFAIL: {module} に不足 {tot_missing} 件 → 文言の実装漏れの疑い(要個別確認)")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
