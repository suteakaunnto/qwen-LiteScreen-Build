#!/usr/bin/env bash
# ============================================================
# 31_switch_kotlin_version.sh — Kotlin プラグイン版の切り替え
#   対象: LiteScreen-Recovered/build.gradle.kts の version("…") 1行のみ
#   使い方:
#     scripts/31_switch_kotlin_version.sh 2.0.21      # 切替のみ
#     scripts/31_switch_kotlin_version.sh 2.2.20 --build   # 切替 + 全モジュール再ビルド
#   注意:
#     - 低メモリ環境のためビルドは1モジュールずつ・daemon 1本。
#     - 版を切り替えたら必ず clean してからビルドすること（増分状態が混ざる）。
#     - 2.0.21 では kotlin{compilerOptions{}} DSL が使えないため
#       app/build.gradle.kts 側は android{kotlinOptions{jvmTarget}} 記法でも通る形にしてある。
# ============================================================
set -euo pipefail
cd "$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

ROOT=LiteScreen-Recovered/build.gradle.kts
[ -f "$ROOT" ] || { echo "ERR: $ROOT が見つからない" >&2; exit 2; }

WANT="${1:-}"; DO_BUILD="${2:-}"
case "$WANT" in
  2.0.21|2.2.20) ;;
  "") grep -nE 'jetbrains.kotlin.android' "$ROOT"; exit 0 ;;
  *) echo "ERR: 指定できるのは 2.0.21 / 2.2.20 のみ（引数なしで現在値を表示）" >&2; exit 2 ;;
esac

# バックアップ（上書きしない・削除しない）
cp -n "$ROOT" "$ROOT.bak.$(date +%Y%m%d%H%M%S)" 2>/dev/null || true

CUR=$(grep -E 'jetbrains.kotlin.android' "$ROOT" | sed -E 's/.*version "([0-9.]+)".*/\1/')
if [ "$CUR" = "$WANT" ]; then
  echo "すでに Kotlin $WANT です（変更なし）"
else
  sed -i -E "/jetbrains.kotlin.android/ s/(version \")[0-9.]+(\")/\1${WANT}\2/" "$ROOT"
  echo "Kotlin $CUR -> $WANT に切り替えました:"
  grep -nE 'jetbrains.kotlin.android' "$ROOT"
fi

if [ "$DO_BUILD" = "--build" ]; then
  GRADLE_USER_HOME=/root/.gradle /opt/gradle/dist/gradle-8.13/bin/gradle \
      -p LiteScreen-Recovered clean \
      >> "recovery/evidence/PHASE_D_k${WANT//./}_clean.log" 2>&1 || true
  for M in protocol receiver sender; do
    LOG="recovery/evidence/PHASE_D_k${WANT//./}_build_$M.log"
    echo "--- :$M:assembleDebug (log: $LOG) ---"
    if GRADLE_USER_HOME=/root/.gradle /opt/gradle/dist/gradle-8.13/bin/gradle \
        -p LiteScreen-Recovered ":$M:assembleDebug" > "$LOG" 2>&1; then
      echo ":$M BUILD SUCCESSFUL (exit 0)"
      tail -2 "$LOG"
    else
      echo ":$M FAILED (exit $?)"; tail -25 "$LOG"; exit 1
    fi
    grep -c "" "$LOG" >/dev/null
    cat /proc/meminfo | grep -E "^MemAvailable" || true
  done
  echo "--- 成果物 ---"
  find LiteScreen-Recovered -path '*/build/outputs/*' \( -name '*.apk' -o -name '*.aar' \) \
       -exec sha256sum {} \; -exec stat -c '  size=%s  %n' {} \;
fi
