# PROJECT_OVERVIEW — LiteScreen の仕様と確認済み事実

新しいセッション／新しい作業者が、**APK を解析し直さなくても作業を始められるように**まとめたもの。
証拠ラベル: `[APK確認]` = 元 APK から直接確認 / `[検証済]` = 実際に実行して確認 / `[旧報告]` = 過去の開発報告（未裏取り）/ `[推定]` / `[未確認]`

## 1. これは何をするアプリか

LAN 内で **Android 端末の画面を別の Android 端末に映す**アプリ（有線/無線 LAN、独自プロトコル）。

- 送信側: 画面を MediaProjection で取得 → MediaCodec で H.264 エンコード → TCP で送信。
- 受信側: TCP で受信 → MediaCodec でデコード → SurfaceView に描画。
- **Miracast / Smart Cast / Chromecast の受信機ではない** `[APK確認]`（UPnP も RTSP も WiFi Display も実装なし）。
- 音声は送信しない `[APK確認]`（sender に `RECORD_AUDIO` 権限が無い）。
- 認証・暗号化なし（平文）`[APK確認]`。同一 LAN 内での利用が前提。

想定端末: 送信 = REDMAGIC Astra（Android 16 / API 36）、受信 = チャレンジパッドNext TAB-A05-BA1（Android 9 / API 28）。

## 2. パッケージ構成 `[APK確認]`

| | sender | receiver |
|---|---|---|
| applicationId | `jp.litescreen.sender.debug` | `jp.litescreen.receiver.debug` |
| versionCode / versionName | 11 / `1.0.11-debug` | 11 / `1.0.11-debug` |
| minSdk / targetSdk / compileSdk | 28 / 36 / 36 | 28 / 36 / 36 |
| アプリ名 | LiteScreen 送信 | LiteScreen 受信 |
| 起動 Activity | `jp.litescreen.sender.SenderActivity` | `jp.litescreen.receiver.ReceiverActivity` |
| Service | `MirrorService`（foreground / mediaProjection 型） | — |
| 権限 | FOREGROUND_SERVICE, FOREGROUND_SERVICE_MEDIA_PROJECTION, POST_NOTIFICATIONS, INTERNET, ACCESS_NETWORK_STATE, ACCESS_WIFI_STATE, CHANGE_WIFI_MULTICAST_STATE（7件） | INTERNET, ACCESS_NETWORK_STATE, CHANGE_WIFI_MULTICAST_STATE（3件） |
| debuggable | true | true |
| ネイティブライブラリ | なし | なし |
| アイコン | `res/mipmap-anydpi-v21/ic_launcher.xml`（VectorDrawable） | 同左 |
| クラス数（`jp.litescreen` 配下） | 49 | 65 |

署名: 元 APK はどちらも **v2 のみ**（v1/v3/v3.1/v4 = false）、証明書 DN `C=US, O=Android, CN=Android Debug`、
証明書 SHA-256 `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf`。**鍵は復元不能**。

## 3. ビルド構成（元プロジェクト）`[検証済]`

- **Kotlin 2.0.21**（`classes.dex` = kotlin-stdlib DEX 2,338,632 B が当方の 2.0.21 ビルドとバイト一致して確定）
- **AGP 8.13.2**（`META-INF/com/android/build/gradle/app-metadata.properties` 57 B がバイト一致）
- Gradle 8.13（`@Metadata mv = {2,0,0}`、builtins 7 個の一致も傍証）
- 依存は **kotlin-stdlib のみ**（AndroidX / Material /  coroutine ライブラリは無し）`[APK確認]`
- `BuildConfig` クラスは生成されていない、R クラスは **non-final**（`--non-final-ids` 相当）`[APK確認]`
- DEX 分割: `classes.dex`=stdlib(1036) / `classes2.dex`=protocol(3) / `classes3.dex`=R(9〜10) /
  `classes4.dex`,`classes5.dex`=アプリ本体 `[検証済]`
- **`classes3.dex`（R クラス）は当方の再ビルドとバイト完全一致** → リソース ID の復元は完全 `[検証済]`

## 4. 通信プロトコル `[APK確認]`（詳細は `recovery/reports/APK_FORENSICS.md` §8）

- MAGIC: `4C 53 43 01`（"LSC" + version 1）。**検査は先頭 3 バイトのみ**（4 バイト目は見ていない）。
- ヘッダ 8 バイト、MAX_PAYLOAD = 8,388,608。
- TCP **47820**（`0xbacc`）: 映像・制御。UDP **47821**: 受信側の存在通知（discovery）。
  通知 JSON: `{"proto":1,"app":"LiteScreen Receiver","tcpPort":47820,"android":28}`
- メッセージ種別 1..14。主なものは VIDEO / STATS / PROPOSE / PROPOSE_ACK / HELLO 系。
- VIDEO ペイロード: `ptsUs(i64) + flags(i32, bit0=key frame) + sendMs(i32) + Annex-B NAL`。
  `sendMs = System.currentTimeMillis() % 1000000`（**1000 ではない**。smali `rem-long 0xf4240`）。
- STATS v2 = 24 バイト。
- PROPOSE_ACK = `ok, w, h, fps, profile, level, detail`。
- `ProtocolException` は `IOException` のサブクラスとして定義（catch 順に注意）。

## 5. ソース構成（再構成後）

```
protocol/  Proto.kt ……………… Proto(object) / Framing / ProtocolException の 3 クラス（1ファイル）
receiver/  ReceiverActivity, core/{ReceiverServer, H264Decoder, DecoderCaps, NetUtil, LocalLog}
sender/    SenderActivity, MirrorService, core/{ScreenCapturer, SenderClient, ReceiverDiscovery, NetInfo, StreamConfig}
```
計 14 .kt ファイル / 51 .xml。ログタグ（logcat のフィルタに使う）:

| タグ | 場所 |
|---|---|
| `LiteScreen` | receiver `LocalLog`（アプリ内ログ表示・保持 200 行） |
| `LiteScreen.Decoder` | receiver `H264Decoder` |
| `LiteScreen.Caps` | receiver `DecoderCaps`（能力診断） |
| `LiteScreen.Net` / `LiteScreen.Discovery` | receiver `NetUtil` / `DiscoveryResponder` |
| `LiteScreen.Capture` | sender `ScreenCapturer` |
| `LiteScreen.Sender` | sender `SenderClient` |
| `LiteScreen.Service` / `LiteScreen.Activity` | sender `MirrorService` / `SenderActivity` |
| `LiteScreen.NetInfo` / `LiteScreen.Discovery` | sender `NetInfo` / `ReceiverDiscovery` |

## 6. UI・機能 `[APK確認]`（見た目）/ `[旧報告]`（意図）

- 送信側はインディゴ〜バイオレット系、受信側はエメラルド〜シアン系。角丸カード・グラデーション・
  ピル型ステータス表示・VectorDrawable アイコン（`res/drawable/bg_card*.xml`, `bg_pill_status.xml`, `dot_accent.xml` は
  **再ビルドした APK とバイト一致** = 完全に復元できている `[検証済]`）。
- 受信側には**能力診断**機能がある（`DecoderCaps.diagnose()`）: デコーダー名、HW/SW 種別、対応サイズ、FPS、
  アラインメント、High/Main/Baseline プロファイル対応、規格表から計算した必要レベル、1920x1200 を要求した場合の
  自動縮小結果などを表示する。
- 送信側の自動ビットレート提案は「提案」と「適用」が分かれており、ユーザーの明示的な選択を上書きしない設計 `[旧報告]`。
  → `StreamConfig` に既定値 `port` は**無い**（復元時に誤って付けたが修正済み・KNOWN_ISSUES #5）。

## 7. 過去バージョンの経緯 `[旧報告]`（APK では裏取りできないもの）

- v1.0.0〜v1.0.6: 接続とデコード経路の修正
- v1.0.7〜v1.0.10: 画質・UI・設定の改善
- v1.0.11: 受信側のデコード能力判定の強化、回復可能なコーデックエラー時の再構成をコールバック実行中から退避
  （デッドロック防止）など
- **v1.0.11 で報告された「遅延 30〜60ms」等の数値は実測未確認**。ベンチマーク値を捏造しないこと。

## 8. 復元できないもの／復元しなかったもの

- **署名鍵（debug keystore）**: 復元不能。APK からは公開鍵と証明書しか取り出せない。
  AOSP の testkey とも不一致であることを確認済み `[APK確認]`。
- **元のソースのコメント・変数名の一部**: smali にはローカル変数名が残る（`.local` / `.param`）ので多くは復元できたが、
  コメントは残らないため、根拠コメントは当方が追記したもの。
- **`@Metadata` の d1（バイナリ）**: デコードは放棄し、d2（文字列）と smali から復元した（rabbit hole 注意）。
