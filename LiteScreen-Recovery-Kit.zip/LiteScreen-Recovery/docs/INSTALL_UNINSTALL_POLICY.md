# INSTALL_UNINSTALL_POLICY — 「元 APK ファイルの保存」と「インストール済みアプリの扱い」の確定方針

作成: 2026-10-30（Phase F） / 根拠: ユーザー指示書『LiteScreen-Recovery-Kit 最終整合性修正・インストール手順修正・実機テスト実施指示書』
証拠ラベル: [APK確認] = 元 APK から直接確認 / [検証済] = 当セッションで実行して確認 / [旧報告] / [推定] / [未確認]

> **この文書が最終方針。** README.md / CHECKPOINT.md / docs/DEVICE_TEST_GUIDE.md / docs/SIGNING_GUIDE.md /
> recovery/reports/PHASE_D_BUILD_VERIFICATION.md の該当記述は本文書に従って読み替えること（訂正対応表は §7）。

---

## 0. この文書が解消する矛盾

Phase D 時点の記録には、次の 2 つが**同時に**書かれていた。

- (a)「再構築 APK は元アプリへの**上書き更新ができない**（`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）」→ **正しい** [検証済]
- (b)「既存の元アプリは**アンインストールせずに残す**」→ **テストを実施する限り成立しない**

同一 packageName のアプリは端末に 1 つしか入らないため、(b) を厳守すると再構築版は**永久にインストールできず、
実機テスト（Test A/B/C）は原理的に不能**になる。この矛盾を Phase F で解消した。

---

## 1. 原則（Phase F 確定・全ドキュメント共通）

1. **元 APK「ファイル」は必ず保存する。** 改変・削除・上書きを一切行わない。
   - 実体: `recovery/input-apk/` の 3 本（`chmod 444`＝読み取り専用）＋ ZIP 内コピー＋ SHA-256 記録（§2 表）。
   - 作業の前後で SHA-256 を照合し、無改変であることを確認する（Phase F で実施済み・全 OK）。
2. **同一 packageName の再構築版をインストールするには、端末上の元アプリのアンインストールが必要。**
   - 「**ファイルの保存**」と「**インストール済みアプリの維持**」は**別問題**。混同してはならない。
   - ファイルが残っていれば、アンインストール後もいつでも `adb install` で元に戻せる（§5）。
3. **アンインストールはユーザー承認済み**（2026-10-30 指示書）。承認条件は「元 APK が安全に保存されていること」で、
   **条件は満たされている**（§2 の 3 本が読み取り専用＋ハッシュ記録付きでキット内に存在）。
4. アンインストールの**直前に必ず記録**する（§4 の様式。対象端末／アプリ／packageName／失われるデータ／実行コマンド）。
5. テスト後は**元 APK を入れ直して復元**する（§5）。復元後もハッシュ・versionCode を確認する。
6. **Test A では受信側をアンインストールしない。** Test A は「再構築 sender ↔ **元** receiver」の互換性試験であり、
   元 receiver を消すと試験が成立しない。アンインストールが発生するのは送信側（Astra）のみ。
7. 対象端末は **REDMAGIC Astra（NP05J）** と **チャレンジパッドNext（TAB-A05-BA1）** の 2 台のみ。他端末では操作しない。

---

## 2. 保存済み元 APK と再構築 APK の実測値 [検証済 2026-10-30]

### 2.1 元 APK（`recovery/input-apk/`, chmod 444, 絶対に変更しない）

| ファイル | サイズ(B) | SHA-256 | packageName | versionCode / versionName |
|---|---|---|---|---|
| `litescreen-receiver-v1.0.11-debug.apk` | 2,512,825 | `384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473` | `jp.litescreen.receiver.debug` | 11 / `1.0.11-debug` |
| `litescreen-sender-v1.0.11-debug.apk` | 2,521,362 | `70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4` | `jp.litescreen.sender.debug` | 11 / `1.0.11-debug` |
| `litescreen-sender-v1.0.10-debug.apk` | 2,518,766 | `b070a194377103aa3c00ab99ffd17edc52f81d1e7daf1c9488ae65e862890dfc` | `jp.litescreen.sender.debug` | **10** / `1.0.10-debug` |

- 3 本とも `minSdk 28` / `targetSdk 36` / `compileSdk 36`、debuggable。
- ⚠ **sender v1.0.10 と v1.0.11 は「同じ packageName・違う versionCode」の別物**。同一視禁止。
  端末にはどちらか 1 つしか入らない（§3.3）。Test B の基準は **v1.0.11**（§6）。

### 2.2 再構築 APK（`recovery/artifacts/`, 復元バグ修正 #1–#9 適用済み）

| ファイル | サイズ(B) | SHA-256 | packageName / versionCode |
|---|---|---|---|
| `kotlin-2.0.21/receiver-debug_kotlin2.0.21_fix8-9.apk` | 2,512,149 | `50d3f7158ce22b61779f4e5d8a46d08657f066282be0354af00169924152a408` | `jp.litescreen.receiver.debug` / 11 |
| `kotlin-2.0.21/sender-debug_kotlin2.0.21_fix8-9.apk` | 2,521,242 | `d57b619bcf44d47aa5f6b2643736f789e5c7efc9fe5e212b3f986259239322fd` | `jp.litescreen.sender.debug` / 11 |
| `kotlin-2.2.20/receiver-debug_kotlin2.2.20_fix8-9.apk` | 2,616,008 | `93163c5a3b92b078aca0985fcffaab38de567ee4337f11a486687be33eb70cf5` | `jp.litescreen.receiver.debug` / 11 |
| `kotlin-2.2.20/sender-debug_kotlin2.2.20_fix8-9.apk` | 2,625,017 | `4aa5d63dcaceae3343eb53213fb99bc50ade891c1e5c368383e2843233a55116` | `jp.litescreen.sender.debug` / 11 |
| `kotlin-2.2.20/protocol-debug_fix8-9.aar` | 5,786 | `ebfc031a2862e368a557d8d2686a6748b8d68f76690efc7d6b6d3ba62f374d25` | （ライブラリ。両 Kotlin 版でバイト一致） |

- **最初の実機テストは Kotlin 2.0.21 版を使う**（ユーザー指示）。2.2.20 版は削除も上書きもしない。

---

## 3. なぜ上書きインストールできないか（実測根拠）

### 3.1 署名証明書 [検証済: `apksigner verify --print-certs`]

| 群 | 証明書 SHA-256 | 証明書 SHA-1 | DN | 署名スキーム |
|---|---|---|---|---|
| **元 APK 3 本（すべて同一）** | `bf068d16d233cd6aa35e3b21648036032c6aba7a3161a74e43320001f4ddfdaf` | `812c5dfd0b1bd48098dc6dbb844b9077dd341984` | `C=US, O=Android, CN=Android Debug` | v1=false / **v2=true**（signer 1 個） |
| **再構築 APK 4 本（2.0.21 / 2.2.20 とも同一）** | `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847` | `51e27981323a821f4bb9ffede06f29d4f09a16d9` | `C=US, O=Android, CN=Android Debug` | v1=false / **v2=true**（signer 1 個） |

- DN は同じ「Android Debug」だが**鍵（証明書）が別物**。元の debug keystore は復元不能（APK からは公開鍵しか取り出せない）。
- ⚠ debug keystore は `~/.android/debug.keystore` に**環境ごとに自動生成**されるため、再構築側の証明書は
  ビルド環境を変えると変わる（実測: 旧環境 `7a1fd7bb1a40a6e6a4cdcfea6edae6608f80222c90a8e4ca09dbfc72aa3277bd`
  → 現環境 `530053f9f0d32c2380e753c311e96a5fcb22d76ab110af99afe30c2e9a87d847`）。
  **上表の値は 2026-10-30 に当環境の APK を実測した結果**であり、別環境でビルドし直すと変わる。

### 3.2 帰結

- 同一 packageName ＋ 異なる署名 ⇒ 更新インストールは **`INSTALL_FAILED_UPDATE_INCOMPATIBLE`** で失敗する。
- packageName が衝突するため**並存インストールもできない**（別アプリとして共存するのは packageName を変えた場合のみ）。
- したがって **再構築版を入れるには元アプリのアンインストールが必要**（原則 §1-2）。

### 3.3 元 APK 同士の入れ替え（v1.0.10 ⇔ v1.0.11）

- 元 sender v1.0.10 と v1.0.11 は**証明書が同一**（`bf068d16…fdaf`）なので、相互に更新インストールできる。
- ただし v1.0.11 → v1.0.10 は **versionCode が下がる（11 → 10）**ため、ダウングレード許可が必要:
  `adb install -r -d litescreen-sender-v1.0.10-debug.apk`
- Test B ではこの 2 つを**混同しない**。基準は §6。

---

## 4. アンインストール前の記録様式（**必須**。実行前に埋める）

```text
[アンインストール記録]
- 実施日時（ローカル / UTC）:
- 対象端末（機種・型番・Android/API）: REDMAGIC Astra NP05J (Android 16 / API 36)
                                      チャレンジパッドNext TAB-A05-BA1 (Android 9 / API 28)
- 対象アプリ名（ラベル）: LiteScreen 送信 / LiteScreen 受信
- packageName:
- versionCode / versionName:
- 署名（dumpsys の signatures 行）:
- 失われるデータ（§4.1 を参照して具体的に）:
- 元 APK のバックアップ場所と SHA-256:
- 実行コマンド: adb uninstall <packageName>
- 実行結果: Success / Failure（出力をそのまま貼る）
- 復元予定（いつ・どの APK で戻すか）:
```

記録先: `recovery/tests/TEST_<A|B|C>_RESULT.md` の該当欄（テンプレート用意済み）。

### 4.1 失われるデータ（**ソース実測**）

| アプリ | 永続データ | アンインストールで失われるもの |
|---|---|---|
| **送信**（`jp.litescreen.sender.debug`） | `SharedPreferences("litescreen")`：`host` / `port` / `res_pos` / `fps_pos` / `bitrate_pos`（`SenderActivity.persistSettings()`） | 接続先 IP・ポート・解像度/FPS/ビットレートの選択状態。**再入力で復旧可能**。個人のファイル・アカウント・認証情報は保持していない |
| **受信**（`jp.litescreen.receiver.debug`） | **なし**（ソースに `SharedPreferences` / ファイル書き込み / 外部ストレージ利用なし。`LocalLog` はメモリ内 200 行のみ） | **アプリ本体のみ**。ユーザーデータは失われない |

- MediaProjection（画面収録）の許可は**セッション単位**で、そもそも保存されない（Android 14 以降は毎回確認）。
- root 化・システム改変は不要。アンインストール／インストールは通常の adb 操作のみ。

---

## 5. 復元手順（テスト後・必須）

```bash
# 1) 元 APK のハッシュ確認（PC 側。Windows は certutil）
sha256sum recovery/input-apk/litescreen-sender-v1.0.11-debug.apk
certutil -hashfile recovery\input-apk\litescreen-sender-v1.0.11-debug.apk SHA256
#   期待値: 70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4

# 2) 端末への入れ直し（-r = 既存があれば更新、なければ新規）
adb -s <serial> install -r recovery/input-apk/litescreen-sender-v1.0.11-debug.apk

# 3) 入ったものの確認（versionCode / 署名）
adb -s <serial> shell dumpsys package jp.litescreen.sender.debug | findstr /C:"versionCode" /C:"versionName"
adb -s <serial> shell pm list packages -f | findstr litescreen
```

- 受信側を戻す場合は `litescreen-receiver-v1.0.11-debug.apk`（期待値 `384662bc…ca03473`）。
- v1.0.10 を入れ直す場合のみ `-r -d`（ダウングレード）。
- 復元後は**再度テストして元どうし（元 sender ↔ 元 receiver）が動くことを確認**すると、
  「再構築版のせいで壊れた」のか「元から」なのかを切り分けられる。

---

## 6. テストごとのアンインストール要否マトリクス

| テスト | Astra（送信側端末） | TAB-A05-BA1（受信側端末） | アンインストール発生 |
|---|---|---|---|
| **Test A** | 元 sender → **再構築 sender（Kotlin 2.0.21）** | **元 receiver のまま（一切触らない）** | **Astra のみ** |
| **Test B** | **元 sender（v1.0.11 基準）** | 元 receiver → **再構築 receiver（Kotlin 2.0.21）** | **TAB-A05-BA1 のみ** |
| **Test C**（任意） | 再構築 sender（2.0.21） | 再構築 receiver（2.0.21） | A・B 実施済みなら追加なし |

- **Test B の基準は元 sender v1.0.11**（versionCode 11）。v1.0.10 を使う場合は
  「なぜ v1.0.10 か」を記録し、v1.0.11 の結果と**分けて**報告する（同一視禁止）。
- 詳細なコマンド手順は `docs/DEVICE_TEST_GUIDE.md`、Windows の adb 準備は `docs/ADB_SETUP_WINDOWS.md`。

---

## 7. 旧記述の訂正対応表（Phase F で実施）

| 場所 | 旧記述 | Phase F の扱い |
|---|---|---|
| `CHECKPOINT.md` §4.8（旧 L643-645） | 「**既存アプリはアンインストールせず残す**。再構築 APK は上書き更新できず…別アプリとして並存インストールになる」 | **訂正本文を追記**（「並存インストールになる」も誤り。packageName 衝突で並存不可）。原文は履歴として残す |
| `CHECKPOINT.md` §Phase D 手順（旧 L587） | ユーザー指示の引用文中「既存アプリはアンインストールせず残し」 | **引用は改変せず注記**（当時の指示文言であり、Phase F で方針更新） |
| `CHECKPOINT.md` 旧 L810 | 「474 ファイル」 | **「473 ZIP エントリ（360 ファイル＋113 ディレクトリ）」に修正** |
| `recovery/reports/PHASE_D_BUILD_VERIFICATION.md` 冒頭・§3.2 | 「既存アプリは**アンインストールせずに残し**、再構築版は別アプリとして検証する」 | **【Phase F 訂正】注記を追記**（過去レポートの原文は改変しない） |
| `docs/DEVICE_TEST_GUIDE.md` §0 | 「既存の元アプリはアンインストールせずに残すこと」＋「退避→入れる→戻す」の混在記述 | **Test A/B/C の手順として全面的に書き直し**（本書 §1–§6 に整合） |
| `docs/SIGNING_GUIDE.md` §冒頭 | 「元アプリのアンインストールが必要」自体は正しいが、記録義務・データ影響の記載なし | **本書への参照と記録様式へのリンクを追加**、証明書値をフルハッシュで再掲 |
| `README.md` §注意事項 | 「アンインストールが必要→元 APK を必ず保管」 | 正しい。**「ファイル保存 ≠ インストール済みアプリ維持」の一文と本書リンクを追加** |

---

## 8. 実機テストの実施状況（2026-10-30 時点）

| 項目 | 状態 | 根拠 |
|---|---|---|
| Test A（再構築 sender ↔ 元 receiver） | **NOT TESTED / BLOCKED** | 復旧環境に実機なし。`adb devices` の一覧が空、`/dev/bus/usb` が存在しない（実測: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`） |
| Test B（元 sender ↔ 再構築 receiver） | **NOT TESTED / BLOCKED** | 同上 |
| Test C（再構築同士） | **NOT TESTED / BLOCKED** | 同上 |
| アンインストールの実行 | **未実行（0 件）** | 実機が無いため実行していない。記録様式のみ整備 |

**実施はユーザー側（Windows PC ＋ USB）で行う。** 手順書・記録テンプレートは以下のとおり用意済み。

- `docs/ADB_SETUP_WINDOWS.md` — Windows での adb 準備と基本コマンド
- `docs/DEVICE_TEST_GUIDE.md` — Test A / B / C の実施手順と PASS 判定基準
- `recovery/tests/TEST_A_RESULT.md` / `TEST_B_RESULT.md` / `TEST_C_RESULT.md` — 結果記録テンプレート（現状すべて NOT TESTED）
