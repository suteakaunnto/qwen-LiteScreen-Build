# RECOVERY_LOG — 何をどの順で実行し、何を見つけ、何を変えたか

すべて 2026-10-29 の 1 日で実施。時系列順。**「実行していないことを実行したと書かない」**を貫き、
ビルドは exit code、比較はスクリプト出力を根拠にしている。

## Phase A — 環境確認と入力 APK の保全 ✅

- 環境: Debian 12 / 2 CPU / **MemTotal 1,083 MB・swap 無し** / ディスク約 6.4 GB / root。
  `strings`, `file`, `ps`, `free` が無い（`grep -a`, `python3`, `/proc` で代用）。
- ツール導入（`scripts/00_setup_env.sh`, `01_get_kotlinc.sh`）: JDK 17.0.21, Gradle 8.13, apktool 2.11.1,
  jadx 1.5.6, kotlinc 2.2.20, Android SDK（platform 36 / build-tools 36）。
- GitHub（`suteakaunnto/qwen-LiteScreen-Build`, public, main）から APK 3 本を取得 → `recovery/input-apk/` に保存し
  **chmod 444**（以後一切変更していない。ハッシュは `recovery/input-apk/SHA256SUMS.txt`）。
  - receiver v1.0.11 = 2,512,825 B `384662bc…3473`
  - sender v1.0.11 = 2,521,362 B `70c0a9a7…9ed4` / sender v1.0.10 = 2,518,766 B `b070a194…0dfc`
- リポジトリに**ソースは無く APK 3 本だけ**であることを確認。

## Phase B — APK フォレンジック ✅

- apktool で 3 本を展開（`recovery/decompiled/*-apktool/`）、jadx で Java 化（`*-jadx/`）。**読み取り専用の証拠**として保存。
- `recovery/reports/APK_FORENSICS.md`: パッケージ構成、権限、Manifest、リソース、プロトコル仕様（§8）を記録。
- `recovery/reports/JADX_ERRORS.md`: **jadx 1.5.6 の描画バグを一覧化**（`UByte.MAX_VALUE` を −1 ではなく 255 と出す等）。
  これ以降、ビット演算・符号・キャストは必ず smali で裏取りする方針にした。
- 判明: Miracast/Smart Cast ではない、音声なし、認証なし、依存は kotlin-stdlib のみ、R は non-final、BuildConfig なし。
- 誤解の訂正: 旧報告にあった「DecoderCaps.probe の 3 引数版で fps=448」は誤り。
  `0x1c0`(=448) は `DecoderCaps$Probe` 合成コンストラクタの**既定値マスク**だった（Phase D で確定・修正 #8）。

## Phase C — Android プロジェクトの再構成 ✅

- `LiteScreen-Recovered/` に Gradle 骨格を作成（settings / build.gradle.kts / gradle.properties / 3 モジュール）。
  AGP **8.13.2** は APK 内の `app-metadata.properties` から確認した値。
- **モジュールごとに段階的に復元し、都度検証**（ユーザー指示）:
  1. `protocol`（Proto / Framing / ProtocolException）→ 差分テスト **650 checks / 0 failures**、
     DEX 定数の独立照合 **37 / 0**（`scripts/10`, `11`）。
  2. `sender`（7 ファイル）→ kotlinc コンパイル **errors=0 / warnings=0**、文字列 **350/0/0**、メンバ **24/27 exact**、
     リソース棚卸し 8 type / 不足 0（`scripts/20`〜`24`）。
  3. `receiver`（6 ファイル）→ 文字列 **343/0/0**、メンバ **16/16 exact**。
- リソースは aapt2 でリンク検証（`--non-final-ids` で元の R 形状に合わせた）。アイコンは元 APK のパスに合わせて
  `mipmap-anydpi-v21/`（当初 `v26` にしていたため APK 内パスがずれた → 修正。
  **res ディレクトリ名を変えたら必ず module clean** すること。増分マージ状態が残って失敗する）。
- この時点の検証は **kotlinc + aapt2 による轻量検証**であって Gradle の `BUILD SUCCESSFUL` ではない、と明示して報告した。

## Phase D — Gradle 実ビルドと元 APK との照合 ✅（→ 詳細 `recovery/reports/PHASE_D_BUILD_VERIFICATION.md`）

1. **OOM との戦い**（attempt 1〜4）: 1 GB RAM で Gradle daemon が落ち続けた。
   無限リトライはせず、毎回ログと `hs_err_pid*.log` を保存して JVM 設定を詰め、
   `-Xmx384m -XX:MaxMetaspaceSize=224m …` + `parallel=false` + `workers.max=1` + Kotlin in-process で安定化。
2. 3 モジュールとも **BUILD SUCCESSFUL / exit 0** を確認（Kotlin 2.2.20）。
3. `scripts/26`〜`30` を作成して元 APK と照合。badging 差分ゼロ、クラス数一致を確認する一方、
   **定数レベルの差分**を `scripts/28`（クラス単位）で洗い出し、smali と突き合わせて**復元バグ 7 件を発見・修正**。
4. ユーザー決定 "try_both" に従い **Kotlin 2.0.21 でもビルド**（`scripts/31` で 1 行切替）。
   → `classes.dex`（stdlib DEX）が**元 APK とバイト一致**し、**元アプリの Kotlin が 2.0.21 であることを確定**。
   ZIP エントリも 41/41・54/54 で完全一致。さらに構造差分 2 件（修正 #6 #7）を修正してクラス数を元に一致させた。
5. `scripts/30_zip_entry_hashes.py`（エントリ単位 sha256）を新規作成 → **`classes3.dex`（R クラス）が全ビルドで
   元とバイト一致**（＝リソース ID 復元が完全）、2.0.21 では 15 エントリが一致することを発見。
6. ユーザー決定 "keep_function" に従い `MirrorService.startMirroring()` は関数のまま維持（意図的な差として記録）。
7. 2.2.20 で最終 clean ビルド（3 モジュール exit 0）→ 成果物とハッシュを記録。
8. ドキュメント化の途中で **`DecoderCaps` の残存差分を精査し、さらに 2 件のバグを発見・修正（#8 fps=448→0、
   #9 `30L` → `val fps = 30` + `fps.toLong()`）**。両 Kotlin 版で clean 再ビルドし、
   `0x1c0` が 6個→3個（元と一致）、`const-wide/16 0x1e` が消滅することを確認。
9. **ビルド再現性を確認**: clean ビルド 2 回で、ソース未変更モジュール（protocol AAR / sender APK）が**バイト一致**。
10. **インクリメンタルビルドの罠を発見**: dex 差 28 B に対し APK が +96 KB（パディング）。→ 配布物は clean ビルド限定。

## インシデント — 作業コンテナの再生成と成果物消失（2026-10-29 22:30 頃）

- Phase D の報告書を作成中にコンテナが再生成され、**`out/` 配下の成果物（APK/AAR/展開物/台帳）と
  `*/build/`、ツールチェーン一式（JDK/SDK/Gradle）、`/root/.gradle`、debug keystore が消失**。
  原因: `out` というディレクトリ名が**ワークスペースのスナップショット対象外**だった。
- **無傷**: 復元ソース、`recovery/evidence/`（120 ファイル）、`recovery/decompiled/`、`recovery/input-apk/`（元 APK）、
  `CHECKPOINT.md`、各レポート、`scripts/`。
- 対応: `scripts/00_setup_env.sh` でツールチェーン再導入（46 秒）→ SDK に android-36 / build-tools 36・35 を追加 →
  Gradle 8.13 再取得 → clean 後に**2 段階ビルド**（一括ビルドは OOM で失敗したため）で全モジュールを再ビルド。
- **復元の証明**: 消失前に作っていた**エントリ単位 sha256 の証拠**が残っていたので、それと新ビルドを突き合わせ、
  receiver 41/41・sender 54/54（2.2.20）、40/40・53/53（2.0.21）が**バイト一致**、protocol AAR は
  **ファイル全体が消失前と同一ハッシュ**であることを確認。APK 全体のハッシュが変わるのは署名ブロックのみ
  （debug keystore が環境ごとに自動生成されるため: `7a1fd7bb…` → `530053f9…`）。
- 再発防止: 成果物の正式な置き場所を **`recovery/artifacts/`** に変更。`out/`, `build/`, `dist/` は使わない。

## Phase E — 成果物と再発防止 ✅（このディレクトリ）

- `README.md`（目的・構成・セットアップ・ビルド・検証・インストール注意・既知の問題）
- `docs/PROJECT_OVERVIEW.md`（アプリ仕様と確認済み事実）/ `docs/RECOVERY_LOG.md`（これ）/
  `docs/KNOWN_ISSUES.md`（修正済み・未修正・未確認）/ `docs/DEVICE_TEST_GUIDE.md`（実機テスト手順）/
  `docs/SIGNING_GUIDE.md`（自分の署名鍵の作り方）
- `SHA256SUMS.txt`（入力 APK / 出力 APK / キット ZIP のハッシュ）
- `recovery/artifacts/LiteScreen-Recovery-Kit.zip`（配布用アーカイブ）
- `scripts/` 00〜31（**すべて実際に実行して出力を evidence に保存済み**。作っただけのスクリプトは無い）

## Phase F — 引き継ぎ

- `CHECKPOINT.md` に各フェーズの完了記録（§6 = Phase C、§7 = Phase D、§8 = インシデントと Phase E）。
- 次のセッションで保存すべきファイルは **`CHECKPOINT.md`** と
  **`recovery/reports/PHASE_D_BUILD_VERIFICATION.md`** の 2 つ（これで現在地と検証結果がすべて分かる）。
- GitHub への自動書き込みは行っていない。アップロード手順は `docs/SIGNING_GUIDE.md` の末尾に記載。
