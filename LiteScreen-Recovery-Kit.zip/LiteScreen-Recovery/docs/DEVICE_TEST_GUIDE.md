# DEVICE_TEST_GUIDE — 実機テスト手順（Test A / Test B / Test C）とログの見かた

作成: 2026-10-29 / **全面改訂: 2026-10-30（Phase F）**
改訂理由: 旧版 §0 に「既存アプリはアンインストールせずに残す」と「上書き更新はできない」が併記され、
　　　　　**このままでは再構築版を永久にインストールできず実機テストが原理的に不能**という矛盾があった。
　　　　　方針は `docs/INSTALL_UNINSTALL_POLICY.md` に確定した。旧版は
　　　　　`recovery/evidence/PHASE_F_docs_before_*/docs/DEVICE_TEST_GUIDE.md` に退避済み。

---

## 0. 前提

### 0.1 実施状況（2026-10-30 時点）

| テスト | 状態 | 根拠 |
|---|---|---|
| Test A / Test B / Test C | **NOT TESTED（BLOCKED）** | 復旧環境に実機接続がない。`adb devices` 一覧が空・`/dev/bus/usb` 不在（実測: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`） |

**本書はユーザーが Windows PC ＋ USB で実施するための手順書。**
Windows 側の adb 準備・ドライバ・無線 adb は `docs/ADB_SETUP_WINDOWS.md`。

### 0.2 端末と APK

| 役割 | 端末 | 型番 | Android / API | 備考 |
|---|---|---|---|---|
| **送信側** | REDMAGIC Astra | nubia NP05J | 16 / 36 | 画面配信元 |
| **受信側** | チャレンジパッドNext | TAB-A05-BA1 | 9 / **28** | **minSdk 28＝下限端末。ここでの動作確認が最重要** |

この 2 台以外では操作しない。

| テスト | Astra に入れる | TAB-A05-BA1 に入れる |
|---|---|---|
| **Test A** | **再構築 sender（Kotlin 2.0.21）** `recovery/artifacts/kotlin-2.0.21/sender-debug_kotlin2.0.21_fix8-9.apk` | **元 receiver v1.0.11**（そのまま・**触らない**） |
| **Test B** | **元 sender v1.0.11** `recovery/input-apk/litescreen-sender-v1.0.11-debug.apk` | **再構築 receiver（Kotlin 2.0.21）** `recovery/artifacts/kotlin-2.0.21/receiver-debug_kotlin2.0.21_fix8-9.apk` |
| **Test C**（任意） | 再構築 sender（2.0.21） | 再構築 receiver（2.0.21） |

- **最初の実機テストは必ず Kotlin 2.0.21 版**で行う（ユーザー指示）。2.2.20 版は消さない・上書きしない。
  2.0.21 版が動いたあと、比較用に 2.2.20 版（`recovery/artifacts/kotlin-2.2.20/`）を試すのは可。
- **sender v1.0.10 と v1.0.11 は別物**（packageName 同一 `jp.litescreen.sender.debug`、versionCode 10 と 11）。
  Test B の基準は **v1.0.11**。v1.0.10 を使う場合は理由を記録し、結果を分けて報告する。
  v1.0.10 を入れるときだけ `adb install -r -d`（ダウングレード許可）が必要（証明書は v1.0.11 と同一）。

### 0.3 PASS / FAIL の判定基準（**重要**）

| 判定 | 条件 |
|---|---|
| **PASS** | 受信側の画面に**送信側の映像が実際に表示された**（静止画でもよいが、送信側を操作して受信側の表示が変わること）。加えて両側の logcat が保存されている |
| **FAIL** | インストールはできたが映像が出ない／接続できない／色が壊れる／途中で止まる。症状と logcat を記録 |
| **NOT TESTED** | 実施していない |
| **BLOCKED** | 実施しようとしたが環境要因で不能（実機なし・USB デバッグが有効化できない・AP アイソレーション等）。理由を記録 |

> **APK のインストール成功や TCP 接続の成功だけでは PASS にしない。**
> 「映像が映った」ことを必ず目視し、`adb exec-out screencap -p` か写真で証拠を残す。

### 0.4 アンインストールの扱い（方針は `docs/INSTALL_UNINSTALL_POLICY.md`）

- 再構築 APK は**元アプリと署名が違う**（証明書 SHA-256: 元 `bf068d16…fdaf` / 再構築 `530053f9…d847`）ため、
  **上書き更新はできず**（`INSTALL_FAILED_UPDATE_INCOMPATIBLE`）、packageName が同じなので**並存もできない**。
  → 再構築版を入れるには**端末上の元アプリのアンインストールが必要**。
- **元 APK「ファイル」はキット内に安全に保存済み**（`recovery/input-apk/`, chmod 444, SHA-256 記録）。
  アンインストールしても、いつでも入れ直せる。**「ファイルの保存」と「インストール済みアプリの維持」は別問題。**
- アンインストールは**ユーザー承認済み**（2026-10-30 指示書、条件＝元 APK が保存されていること → 満たしている）。
- **実行前に必ず記録**する（`docs/INSTALL_UNINSTALL_POLICY.md` §4 の様式。テンプレートに欄あり）。
- **Test A では受信側をアンインストールしない**（元 receiver を使うテストなので消すと成立しない）。

---

## 1. 事前準備（全テスト共通）

1. Windows PC に adb を入れる（`docs/ADB_SETUP_WINDOWS.md` §1–§2）。`adb devices -l` で **2 台とも `device`** になることを確認。
   ```powershell
   adb devices -l
   adb -s %ASTRA% shell getprop ro.product.model   # → NP05J
   adb -s %TAB%     shell getprop ro.product.model   # → TAB-A05-BA1
   ```
2. **2 台を同じ Wi-Fi（同一サブネット）に接続**。学校・公共 Wi-Fi は AP アイソレーションで端末間通信が
   遮断されることがある（アプリ内にも同じ注意書き）。繋がらない場合は家庭用ルータ／テザリングを使う。
3. ポート確認（TCP **47820** / UDP **47821**。値は `LiteScreen-Recovered/protocol/.../Proto.kt` L58-59 で再確認済み）:
   ```powershell
   adb -s %TAB% shell ip -f inet addr show wlan0      # 受信側の IP を控える
   adb -s %ASTRA% shell ping -c 4 <受信側IP>          # 送信側→受信側の疎通
   ```
4. 元 APK のバックアップを確認（**アンインストール作業の前に必須**）:
   ```powershell
   dir recovery\input-apk
   certutil -hashfile recovery\input-apk\litescreen-sender-v1.0.11-debug.apk SHA256
   :: 期待値 70c0a9a719f788783df8b6fbbc76f8f13b4b978479486ed350f7cb1542e19ed4
   certutil -hashfile recovery\input-apk\litescreen-receiver-v1.0.11-debug.apk SHA256
   :: 期待値 384662bcbb3309f9d8d0d0996cfdc74557b671e6598798bf36c2537cbca03473
   ```
5. logcat を**両側で**録れるようにターミナルを 2 つ開く（コマンドは §5）。

---

## 2. Test A — 再構築 sender（2.0.21） ↔ **元** receiver

**目的**: 復元した送信側が、**元の受信側**とプロトコル互換で映像を流せるか。
**受信側は一切変更しない**（アンインストール禁止）。

### 2.1 手順

| # | 操作 | コマンド／確認 |
|---|---|---|
| A-1 | 現状を記録 | `adb -s %ASTRA% shell dumpsys package jp.litescreen.sender.debug \| findstr /C:"versionCode" /C:"versionName"` → **元 v1.0.11 (versionCode 11)** が入っていることを確認し、テンプレートに記入 |
| A-2 | **アンインストール記録を記入** | `docs/INSTALL_UNINSTALL_POLICY.md` §4 の様式を `recovery/tests/TEST_A_RESULT.md` に転記。失われるデータ＝送信側 SharedPreferences（接続先 IP・ポート・解像度/FPS/ビットレート選択）。**現在の設定値を先にメモ/スクショ**しておく |
| A-3 | 元 sender をアンインストール | `adb -s %ASTRA% uninstall jp.litescreen.sender.debug` → 出力 `Success` を記録 |
| A-4 | 再構築 sender（2.0.21）をインストール | `adb -s %ASTRA% install -r "recovery\artifacts\kotlin-2.0.21\sender-debug_kotlin2.0.21_fix8-9.apk"` |
| A-5 | 入ったものを確認 | `adb -s %ASTRA% shell dumpsys package jp.litescreen.sender.debug \| findstr /C:"versionCode"` → 11 |
| A-6 | **元 receiver を起動**（TAB 側） | `adb -s %TAB% shell am start -n jp.litescreen.receiver.debug/jp.litescreen.receiver.ReceiverActivity`<br>画面の「この端末のIPアドレス」「受信ポート: 47820」を記録 |
| A-7 | 受信側 logcat 開始 | §5 の受信側コマンド |
| A-8 | 送信側 logcat 開始 | §5 の送信側コマンド |
| A-9 | **再構築 sender を起動** | `adb -s %ASTRA% shell am start -n jp.litescreen.sender.debug/jp.litescreen.sender.SenderActivity` |
| A-10 | 受信端末を検索 | 画面の「**受信端末を検索**」→「見つかった受信端末」ダイアログに TAB-A05-BA1 が出るか（**UDP 47821 discovery の確認**）。出なければ IP 手入力（例 `192.168.1.20`、ポート `47820`） |
| A-11 | 配信開始 | 「**接続して配信を開始**」→「画面配信の許可」を読む → Android の収録許可で「**全画面**」を選んで許可（**Android 14 以降はセッションごとに許可が必要**） |
| A-12 | **映像確認（PASS 判定の本体）** | 受信側の SurfaceView に Astra の画面が出るか。送信側で時計アプリや動画を再生し、**受信側の表示が追従して変わるか**を目視 |
| A-13 | 証拠保存 | `adb -s %TAB% exec-out screencap -p > testA_recv_screen.png`（映像が写っている状態で）＋端末を並べて写真撮影 |
| A-14 | 追加確認 | §2.2 のチェックリスト |
| A-15 | 停止 | 送信側で「**配信を停止**」→ 受信側の表示が止まること |
| A-16 | ログ保存 | 両側の logcat を止めてファイル保存（§5） |
| A-17 | **判定を記録** | `recovery/tests/TEST_A_RESULT.md` に PASS / FAIL / BLOCKED ＋ 症状 |
| A-18 | 復元（Test B へ進むなら続けてよい） | 元 sender を戻す: `adb -s %ASTRA% install -r "recovery\input-apk\litescreen-sender-v1.0.11-debug.apk"` → versionCode 11 を確認 → 設定を再入力 |

### 2.2 Test A チェックリスト

- [ ] UDP 47821 の discovery で受信端末が見つかる（見つからない場合、手入力 IP で接続できるか）
- [ ] TCP 47820 に接続できる（送信側 logcat `LiteScreen.Sender`）
- [ ] **受信側の画面に映像が出る**（PASS の必須条件）
- [ ] 色がおかしくない（緑・紫のノイズは CSD/SPS/PPS 処理の誤り）
- [ ] 画面回転・解像度変更で受信側が追従する（デコーダー再構成）
- [ ] 停止 → 再開ができる（古い世代のコールバック／buffer index を使っていないか）
- [ ] 送信側の通知をタップしても Activity が複製されない（`FLAG_ACTIVITY_SINGLE_TOP`＝修正 #2）
- [ ] 静止画面でビットレートが下がり続けない（過負荷誤判定の確認）

---

## 3. Test B — **元** sender ↔ 再構築 receiver（2.0.21）

**目的**: 復元した受信側が、**元の送信側**から映像を受けられるか（**最重要**。デコーダ・プロトコル解析の正しさの実証）。
**このテストでアンインストールするのは受信側（TAB-A05-BA1）のみ。送信側は元に戻す。**

### 3.1 手順

| # | 操作 | コマンド／確認 |
|---|---|---|
| B-1 | Astra に**元 sender v1.0.11** が入っている状態にする | Test A の A-18 で戻していれば OK。確認: `adb -s %ASTRA% shell dumpsys package jp.litescreen.sender.debug \| findstr /C:"versionCode"` → 11 |
| B-2 | TAB 側の現状を記録 | `adb -s %TAB% shell dumpsys package jp.litescreen.receiver.debug \| findstr /C:"versionCode" /C:"versionName"` → 元 v1.0.11 |
| B-3 | **アンインストール記録を記入** | `docs/INSTALL_UNINSTALL_POLICY.md` §4 の様式を `recovery/tests/TEST_B_RESULT.md` に転記。**受信側に永続データは無い**（ソース実測: SharedPreferences もファイル書き込みも無し。アプリ内ログはメモリ内 200 行のみ）→ 失われるのはアプリ本体だけ |
| B-4 | 元 receiver をアンインストール | `adb -s %TAB% uninstall jp.litescreen.receiver.debug` → `Success` を記録 |
| B-5 | 再構築 receiver（2.0.21）をインストール | `adb -s %TAB% install -r "recovery\artifacts\kotlin-2.0.21\receiver-debug_kotlin2.0.21_fix8-9.apk"` |
| B-6 | 入ったものを確認 | versionCode 11、`pm list packages -f \| findstr litescreen` |
| B-7 | 両側 logcat 開始 | §5 |
| B-8 | **再構築 receiver を起動** | `adb -s %TAB% shell am start -n jp.litescreen.receiver.debug/jp.litescreen.receiver.ReceiverActivity` → 表示された IP・ポート 47820 を記録 |
| B-9 | **元 sender を起動**（Astra） | `adb -s %ASTRA% shell am start -n jp.litescreen.sender.debug/jp.litescreen.sender.SenderActivity` |
| B-10 | 検索 → 選択 | 「受信端末を検索」で TAB が見つかるか（元 sender の discovery が**再構築 receiver の PROBE 応答**を解釈できるかの確認＝修正 #8 の Probe 関連） |
| B-11 | 配信開始 | Test A の A-11 と同じ |
| B-12 | **映像確認（PASS 判定の本体）** | 受信側の SurfaceView に Astra の画面が出るか。**fps 表示が上がるか**、色・ブロックノイズの有無 |
| B-13 | 能力診断 | 受信側の「**能力診断**」を実行しスクショ。デコーダー名・HW/SW・対応サイズ・FPS・アラインメント・プロファイル・必要レベル・1920x1200 要求時の自動縮小結果。**失敗時に fps=448 ではなく fps=0 / width=0 で返れば修正 #8 が効いている** |
| B-14 | 証拠保存 | `adb -s %TAB% exec-out screencap -p > testB_recv_screen.png` ＋ 並べて写真撮影 |
| B-15 | 追加確認 | §3.2 |
| B-16 | 判定を記録 | `recovery/tests/TEST_B_RESULT.md` |
| B-17 | **復元** | 元 receiver を戻す: `adb -s %TAB% install -r "recovery\input-apk\litescreen-receiver-v1.0.11-debug.apk"` → versionCode 11 確認 → 元どうし（元 sender ↔ 元 receiver）で一度映ることを確認すると切り分けになる |

### 3.2 Test B チェックリスト

- [ ] 再構築 receiver が TCP 47820 で LISTEN（`adb -s %TAB% shell "netstat -an \| grep 47820"`）
- [ ] 元 sender の PROBE（UDP 47821, `LITESCREEN?`）に再構築 receiver が応答し、**元 sender 側で端末名が出る**
- [ ] **受信側の画面に映像が出る**（PASS の必須条件）
- [ ] H.264 デコーダが生成され csd（SPS/PPS）を処理できる（`LiteScreen.Decoder` ログ）
- [ ] 解像度/FPS 変更でデコーダーを作り直せる
- [ ] 「能力診断」の結果が妥当（fps=448 が出ない＝修正 #8）
- [ ] 受信側アプリ内ログ（200 行）にエラーが無い／内容が元アプリと同等

---

## 4. Test C（任意） — 再構築 sender ↔ 再構築 receiver

Test A・B が終わっていれば、両端末とも再構築版を入れるだけ（追加のアンインストールは発生しない）。

1. Astra: `adb -s %ASTRA% install -r "recovery\artifacts\kotlin-2.0.21\sender-debug_kotlin2.0.21_fix8-9.apk"`
   （Test B で元 sender を戻した場合は、先に §2 の A-2〜A-3 の記録とアンインストールが必要）
2. TAB: Test B の B-5 で再構築 receiver が入っていればそのまま。
3. §2.1 の A-6 以降と同じ流れで配信し、**映像が出ること**を確認。
4. 余裕があれば Kotlin 2.2.20 版（`recovery/artifacts/kotlin-2.2.20/`）でも同じテストを繰り返し、
   **2.0.21 と 2.2.20 の挙動差が無いこと**を確認する（差分はコンパイラ由来のみのはず）。2.0.21 版の APK は消さない。
5. 結果は `recovery/tests/TEST_C_RESULT.md` に記録。

---

## 5. ログの取得（**両側とも必須**）

タグは**元 APK の DEX から実測**し、現行ソース・再構築 APK とも一致を確認済み
（証拠: `recovery/evidence/PHASE_F_logtags_ports_verification_*.txt`）。

```powershell
:: === 受信側（TAB-A05-BA1）===
adb -s %TAB% logcat -c
adb -s %TAB% logcat -v threadtime -s LiteScreen:V LiteScreen.Decoder:V LiteScreen.Caps:V LiteScreen.Net:V LiteScreen.Discovery:V > recv_logcat.txt

:: === 送信側（Astra）===
adb -s %ASTRA% logcat -c
adb -s %ASTRA% logcat -v threadtime -s LiteScreen:V LiteScreen.Capture:V LiteScreen.Sender:V LiteScreen.Service:V LiteScreen.Activity:V LiteScreen.NetInfo:V LiteScreen.Discovery:V > send_logcat.txt

:: === テスト後に一括保存（フィルタなし・全体）===
adb -s %TAB%     logcat -d -v threadtime > recv_full.txt
adb -s %ASTRA% logcat -d -v threadtime > send_full.txt
```

| タグ | 端末 | 内容 |
|---|---|---|
| `LiteScreen` | 受信 | LocalLog（アプリ内「ログを表示」と同じ内容・保持 200 行） |
| `LiteScreen.Decoder` | 受信 | H.264 デコーダの生成・再構成・エラー（**修正 #1 スレッド優先度 −8、#4 CSD 判定、#8 能力 probe**） |
| `LiteScreen.Caps` | 受信 | デコーダ能力の判定（解像度/FPS/プロファイル/レベル） |
| `LiteScreen.Net` / `LiteScreen.Discovery` | 受信 | 受信ソケット / UDP 存在通知（PROBE 応答） |
| `LiteScreen.Capture` | 送信 | MediaProjection・VirtualDisplay の開始/停止（`virtualDisplay paused/resumed/stopped`、`MediaProjection onStop（…）`） |
| `LiteScreen.Sender` | 送信 | 送信クライアント・STATS・バックプレッシャ |
| `LiteScreen.Service` / `LiteScreen.Activity` | 送信 | MirrorService / UI |
| `LiteScreen.NetInfo` | 送信 | 自端末 IP の取得 |
| `LiteScreen.Discovery` | 送信 | 受信端末の検索（UDP 47821） |

### 5.1 正常系の目安

- 受信: デコーダ生成 → `csd` 受信 → 描画開始、fps 表示が上がる。
- 送信: `virtualDisplay` 生成 → フレーム送信 → STATS 受信。
- 「能力診断」でデコーダー名・HW/SW・対応サイズ・FPS・アラインメント・プロファイル対応・必要レベル・
  1920x1200 要求時の自動縮小結果が一覧表示される（**修正 #8 #9 の確認に使える**）。

### 5.2 異常系の見かた

| 症状 | 見るべきログ | 疑う箇所 |
|---|---|---|
| 接続できない | 送信 `LiteScreen.Discovery` / 受信 `LiteScreen.Net` | AP アイソレーション、ポート 47820/47821 のブロック、IP 違い |
| 検索で見つからない | 受信 `LiteScreen.Discovery`（応答したか） | UDP ブロードキャストの遮断、サブネット違い |
| 繋がるが真っ黒 | 受信 `LiteScreen.Decoder` の `csd` 有無 | SPS/PPS（CSD）の二重送信・欠落、key frame 待ち |
| 色が壊れる／ブロックノイズ | 同上 | Annex-B 分割（`splitAnnexB`）、NAL 境界 |
| `MediaCodec.CodecException` | 受信 `LiteScreen.Decoder` | 能力不足（`LiteScreen.Caps` の診断と突き合わせる）。`0x80010005` = ERROR_UNSUPPORTED（アプリ表示は原文どおり `0x80001005`） |
| 途中で止まる／復帰しない | 受信 `LiteScreen.Decoder` の再構成ログ | コールバック実行中の再構成、古い buffer index の使用 |
| 送信側だけ停止 | 送信 `LiteScreen.Capture` の `MediaProjection onStop` | ユーザーが許可を取り消し／システムが停止 |
| fps が 0 のまま | 受信 `LiteScreen.Caps` | デコーダ能力 probe の失敗（修正 #8 が効いていれば fps=0/width=0 で返る） |

---

## 6. 性能（遅延・FPS）を測るとき

- **過去に報告された「遅延 30〜60ms」等は実測未確認**（`[旧報告]`）。比べるなら同じ条件で測り直す。
- 目安の測り方: 送信側に秒針付きタイマーを表示し、受信側と一緒に撮影してフレーム差から遅延を出す。
- 受信側の STATS（v2, 24 バイト）に受信 fps / 破棄数などが入る。アプリ内ログの値を使う。
- **静止画面で受信 fps が低いのは正常**（フレームが来ないだけ）。破棄率・キュー深さ・遅延と分けて判断する。

---

## 7. テスト後に返してほしいもの

1. `recovery/tests/TEST_A_RESULT.md` / `TEST_B_RESULT.md` /（実施した場合）`TEST_C_RESULT.md`
   — **PASS / FAIL / NOT TESTED / BLOCKED** のいずれかと、アンインストール記録。
2. `send_logcat.txt` と `recv_logcat.txt`（**両側**）。
3. `testA_recv_screen.png` / `testB_recv_screen.png`（**映像が写っている証拠**）または 2 台を並べた写真。
4. 受信側アプリの「ログを表示」画面のスクリーンショット（端末内ログ 200 行）。
5. 「能力診断」の結果スクリーンショット（Test B）。
6. 症状が出た場合の動画／写真と、そのときの操作手順・設定値（解像度/FPS/ビットレート）。

これらが揃えば `CHECKPOINT.md` の「未確認」を「検証済」に更新し、次の修正に入れる。
**報告されていない結果を成功として記録することはない**（実施していないテストは NOT TESTED のまま）。
