# ADB_SETUP_WINDOWS — Windows PC で adb を使う準備と基本コマンド（実機テスト用）

作成: 2026-10-30（Phase F） / 対象: Windows 10 / 11（PowerShell または コマンドプロンプト）
目的: `LiteScreen` の実機テスト（Test A / B / C）を **ユーザー側で実施できる状態**にする。
※ 復旧作業を行ったコンテナには実機接続が無かった（実測: `recovery/evidence/PHASE_F_adb_no_device_evidence_*.txt`）。
　そのため **Test A / B / C はすべて NOT TESTED**。本書の手順でユーザーが実施する。

---

## 1. adb（platform-tools）のインストール

1. <https://developer.android.com/tools/releases/platform-tools> から
   **「Download SDK Platform-Tools for Windows」**を取得（`platform-tools_r##.#-windows.zip`）。
2. ZIP を解凍し、例として `C:\platform-tools\` に置く（**パスに日本語・空白を入れない**）。
3. PATH に追加（任意だが推奨）:
   ```powershell
   # PowerShell（管理者不要・現在のユーザーのみ）
   [Environment]::SetEnvironmentVariable("Path", $env:Path + ";C:\platform-tools", "User")
   ```
   追加後は**ターミナルを開き直す**。
4. 確認:
   ```powershell
   adb version
   # 期待: Android Debug Bridge version 1.0.41 / Version 3x.x.x
   ```
   PATH を通していない場合は `cd C:\platform-tools` して `.\adb` の形で実行する。

> 復旧コンテナで使った adb は **1.0.41（37.0.1-15733141）**。これ以降のバージョンで問題ない。

---

## 2. 端末側の準備（2 台とも）

### 2.1 開発者オプションと USB デバッグ

| 端末 | 型番 | Android | 手順 |
|---|---|---|---|
| **REDMAGIC Astra**（送信側） | nubia NP05J | 16 / API 36 | 設定 → 端末情報 →「ビルド番号」を 7 回タップ → 設定 → システム → 開発者向けオプション →「USB デバッグ」ON |
| **チャレンジパッドNext**（受信側） | TAB-A05-BA1 | 9 / API 28 | 設定 → タブレット情報 →「ビルド番号」を 7 回タップ → 設定 → システム → 開発者向けオプション →「USB デバッグ」ON |

- 接続時に端末へ出る **「USB デバッグを許可しますか？」は「許可」**（“このパソコンを常に許可” にチェック）。
- チャレンジパッドNext は**学習管理用端末**の場合があり、開発者向けオプションが制限されていることがある。
  出ない場合は **BLOCKED** として記録し、無理に解除しようとしない（root 化・改変は行わない）。
- 画面ロック解除した状態で接続する（ロック中は adb 認証ダイアログが出ないことがある）。

### 2.2 USB ドライバ（認識しないとき）

1. デバイスマネージャーで端末を確認。`ADB Interface` / `Android Phone` 系に出ていれば OK。
2. 未知のデバイスになる場合:
   - **Google USB Driver** を SDK Manager で入れるか、<https://developer.android.com/studio/run/win-usb> の手順で更新。
   - REDMAGIC（nubia）は純正ドライバが別途必要な場合あり。
   - 汎用策: デバイスマネージャー → 該当デバイスを右クリック →「ドライバーの更新」→
     「コンピューターを参照」→「利用可能なドライバーの一覧」→ **Android Device → Android ADB Interface** を手動選択。
3. USB ケーブルは**データ通信対応**のものを使う（充電専用ケーブルでは認識しない）。USB ポートも本体直挿しを推奨。

### 2.3 接続確認

```powershell
adb devices -l
# 期待例:
# List of devices attached
# XXXXXXXX    device  product:... model:NP05J device:... transport_id:1
# YYYYmmdd    device  product:... model:TAB-A05-BA1 ...
```

| 表示 | 意味 | 対処 |
|---|---|---|
| （空欄） | 1 台も認識していない | §2.2 ドライバ／ケーブル／USB デバッグ ON を確認 |
| `unauthorized` | 端末側で許可していない | 端末のダイアログで「許可」、出なければケーブルを挿し直す |
| `offline` | 通信が不安定 | `adb kill-server` → `adb start-server` → 再接続 |
| `no permissions` | ドライバ／権限 | §2.2、管理者権限のターミナルで再試行 |

2 台同時に接続したら、以降は **`-s <シリアル>` を必ず付けて**対象を明示する（誤操作防止。
指示書: Astra と TAB-A05-BA1 以外では操作しない）。

```powershell
adb devices                 # シリアルを確認
set ASTRA=XXXXXXXX          # ← Astra のシリアル（PowerShell なら $env:ASTRA="XXXXXXXX"）
set TAB=YYYYmmdd            # ← チャレンジパッドNext のシリアル
adb -s %ASTRA% shell getprop ro.product.model
adb -s %TAB%     shell getprop ro.product.model
```

---

## 3. 無線（Wi-Fi）で adb を使いたい場合

- **Astra（Android 16）**: 開発者向けオプション →「ワイヤレス デバッグ」ON →「ペア設定コードによるデバイスのペア設定」で
  ```powershell
  adb pair <端末IP>:<ペアポート>      # コードを入力
  adb connect <端末IP>:<接続ポート>
  ```
- **TAB-A05-BA1（Android 9）**: ワイヤレス デバッグ UI が無いので、**一度 USB で接続してから** TCP/IP 化:
  ```powershell
  adb -s %TAB% tcpip 5555
  adb connect <端末IP>:5555
  # 終わったら: adb -s %TAB% usb
  ```
- ⚠ **アプリの映像配信は Wi-Fi 経由**。adb の接続方式（USB/無線）とは無関係に、
  **2 台が同じ Wi-Fi（同一サブネット）に繋がっている必要がある**（§4）。

---

## 4. LAN・ポートの疎通確認（テスト前に必ず）

アプリは **TCP 47820（映像・制御）/ UDP 47821（受信端末の発見 PROBE）** を使う。
値は現行ソース `LiteScreen-Recovered/protocol/.../Proto.kt` L58-59 で再確認済み（変更なし）。

```powershell
# 1) 受信側の IP を確認（アプリ画面の「この端末のIPアドレス」でも可）
adb -s %TAB% shell ip -f inet addr show wlan0

# 2) 送信側から受信側へ ping（同一サブネットか、AP アイソレーションでないか）
adb -s %ASTRA% shell ping -c 4 <受信側IP>

# 3) 受信アプリ起動中に TCP 47820 が LISTEN しているか
adb -s %TAB% shell "netstat -an | grep 47820"
#   （netstat が無い端末では） adb -s %TAB% shell "ss -ltnp | grep 47820"

# 4) PC からポート到達確認（Windows）
Test-NetConnection <受信側IP> -Port 47820
```

- 学校・公共 Wi-Fi は **AP アイソレーション**で端末間通信が遮断されることがある。
  その場合は **家庭用ルータかスマホのテザリング**で 2 台を同一ネットワークに置く（アプリ内にも同注意書きあり）。
- ファイアウォールは端末間通信には無関係（PC を経由しない）が、`adb connect` を使う場合は PC 側許可が必要。

---

## 5. よく使うコマンド（インストール／アンインストール／ログ）

```powershell
# --- インストール ---
adb -s %ASTRA% install -r "recovery\artifacts\kotlin-2.0.21\sender-debug_kotlin2.0.21_fix8-9.apk"
adb -s %TAB%     install -r "recovery\artifacts\kotlin-2.0.21\receiver-debug_kotlin2.0.21_fix8-9.apk"
# 元 APK を戻す
adb -s %ASTRA% install -r "recovery\input-apk\litescreen-sender-v1.0.11-debug.apk"
adb -s %TAB%     install -r "recovery\input-apk\litescreen-receiver-v1.0.11-debug.apk"
# v1.0.10 を入れるときだけダウングレード許可
adb -s %ASTRA% install -r -d "recovery\input-apk\litescreen-sender-v1.0.10-debug.apk"

# --- アンインストール（実行前に docs/INSTALL_UNINSTALL_POLICY.md §4 の記録を埋める）---
adb -s %ASTRA% uninstall jp.litescreen.sender.debug
adb -s %TAB%     uninstall jp.litescreen.receiver.debug      # ← Test A では実行しない

# --- 入っているものの確認 ---
adb -s %ASTRA% shell dumpsys package jp.litescreen.sender.debug | findstr /C:"versionCode" /C:"versionName" /C:"codePath"
adb -s %TAB%     shell pm list packages -f | findstr litescreen

# --- 署名の確認（端末側で見られる範囲）---
adb -s %ASTRA% shell dumpsys package jp.litescreen.sender.debug | findstr /C:"signatures" /C:"certif"

# --- アプリ起動 ---
adb -s %ASTRA% shell am start -n jp.litescreen.sender.debug/jp.litescreen.sender.SenderActivity
adb -s %TAB%     shell am start -n jp.litescreen.receiver.debug/jp.litescreen.receiver.ReceiverActivity

# --- ログ取得（LiteScreen* タグ。値は元 APK の DEX と現行ソースの両方で確認済み）---
:: 受信側（タブレット）
adb -s %TAB% logcat -c
adb -s %TAB% logcat -v threadtime -s LiteScreen:V LiteScreen.Decoder:V LiteScreen.Caps:V LiteScreen.Net:V LiteScreen.Discovery:V > recv_logcat.txt
:: 送信側（Astra）
adb -s %ASTRA% logcat -c
adb -s %ASTRA% logcat -v threadtime -s LiteScreen:V LiteScreen.Capture:V LiteScreen.Sender:V LiteScreen.Service:V LiteScreen.Activity:V LiteScreen.NetInfo:V LiteScreen.Discovery:V > send_logcat.txt
:: テスト後に一括保存するなら -d（ダンプして終了）
adb -s %TAB%     logcat -d -v threadtime > recv_full.txt
adb -s %ASTRA% logcat -d -v threadtime > send_full.txt

# --- 画面の証拠（映像が出たことの記録に）---
adb -s %TAB% exec-out screencap -p > recv_screen.png
adb -s %ASTRA% exec-out screencap -p > send_screen.png

# --- ファイル回収 ---
adb -s %TAB% pull /sdcard/Download/xxx.png .
```

> **logcat は 2 台ぶんを別々に**取得する（送信側・受信側の両方が必須。指示書の要件）。
> 2 台を同じターミナルで同時に扱う場合は、ウィンドウを 2 つ開くか `start /b` で並行実行する。

### 5.1 タグ一覧（元 APK の DEX から実測・再構築版とも一致）

| 端末 | タグ |
|---|---|
| 受信 | `LiteScreen`（アプリ内ログ LocalLog と同内容, 200 行）, `LiteScreen.Decoder`, `LiteScreen.Caps`, `LiteScreen.Net`, `LiteScreen.Discovery` |
| 送信 | `LiteScreen`, `LiteScreen.Capture`, `LiteScreen.Sender`, `LiteScreen.Service`, `LiteScreen.Activity`, `LiteScreen.NetInfo`, `LiteScreen.Discovery` |

---

## 6. エラー別対処

| エラー | 原因 | 対処 |
|---|---|---|
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | **署名違い**（元アプリの上に再構築版を入れようとした） | `adb uninstall <pkg>` してから再インストール。**必ず事前に `docs/INSTALL_UNINSTALL_POLICY.md` §4 の記録を付ける** |
| `INSTALL_FAILED_VERSION_DOWNGRADE` | versionCode が下がる（v1.0.11 → v1.0.10） | `-d` を付ける |
| `INSTALL_FAILED_OLDER_SDK` | 端末の API が minSdk 28 未満 | 対象外（TAB-A05-BA1 は API 28 でちょうど下限） |
| `error: device unauthorized` | 端末で許可していない | 端末ダイアログで許可 |
| `error: more than one device/emulator` | 2 台接続時に `-s` を付けていない | `-s <シリアル>` を付ける |
| 映像が映らない | ネットワーク／CSD／デコーダ能力 | `docs/DEVICE_TEST_GUIDE.md` §「異常系の見かた」 |

---

## 7. 成果物の提出先

テストを実施したら、以下を `recovery/tests/` のテンプレートに貼り付けて返すこと。

1. `recovery/tests/TEST_A_RESULT.md`（再構築 sender ↔ **元** receiver）
2. `recovery/tests/TEST_B_RESULT.md`（**元** sender ↔ 再構築 receiver）
3. `recovery/tests/TEST_C_RESULT.md`（再構築同士・任意）
4. `send_logcat.txt` / `recv_logcat.txt`（両側）、`recv_screen.png`（**映像が写った証拠**）

**PASS の条件は「受信側の画面に送信側の映像が実際に出たこと」。**
インストール成功・TCP 接続成功だけでは PASS にしない（判定基準は `docs/DEVICE_TEST_GUIDE.md` §0.3）。
